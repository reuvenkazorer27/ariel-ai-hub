# powerbi-report-reviewer (Plugin)

חבילת plugin ל-Claude Cowork / Claude Code שסוקרת דוחות **Power BI (PBIP/PBIR)** ומחזירה
**דוח ביקורת מסודר בעברית**.

## מה זה נותן
> **גרסת `main` — סורק בלבד.** ברנץ' זה מכיל את **הסורק** (דוח ביקורת קריא-בלבד) בלבד. הבונה
> האג'נטי (`powerbi-pbip-builder`) שמיישם תיקונים נמצא ב**ברנץ' `full-agent`** (הגרסה המלאה,
> עם PR פתוח ל-main).

שני skills משלימים:

**1. `powerbi-report-reviewer`** — סוקר דוח Power BI קיים ומחזיר **דוח ביקורת בעברית** (קריא-בלבד).
   בתחילת כל סשן שואל **"דוח מתקדם או רגיל?"** — הרמה קובעת את אורך הדוח, לא את עומק הבדיקה —
   ומפיק דוח HTML עם **פרומפט-להעתקה** לכל שיפור. כולל אימות מבנה (`pbi_validate.py`, בלי Desktop)
   ומנוע BPA דטרמיניסטי (`pbi_check.py`). **אינו מיישם תיקונים** — הפלט הוא דוח בלבד.
**2. `powerbi-design-search`** — מנוע חיפוש BM25 (Python, ללא תלויות) על 8 מאגרי ידע עיצובי:
   פלטות צבע, סוגי גרפים עם `visualType`, תבניות DAX, פריסות עם מיקומי פיקסלים, תבניות PBIR JSON,
   סגנונות פורמט, כרטיסי KPI, והנחיות UX. מבוסס על `ui-ux-pro-max-powerbi-analytics` (MIT).

הסוקר קורא את קבצי הפרויקט (דפים, ויזואלים, theme, לוגו, מדדי DAX) ומפיק:
  הערכה כללית · מה עובד טוב · ממצאים לפי חומרה (🔴/🟡/🟢) · ויזואלים מומלצים מקטלוג בן 44 פריטים ·
  המלצות תפריט צד/ניווט · בדיקת לוגו מחלקה/אוניברסיטה · אייקונים ל-KPI · ערכת צבעים (עם theme JSON) ·
  **המלצות HTML Content (RTL) עם מדד DAX מוכן** · בדיקת כותרות ברורות ובהקשר הנכון · **מנוע BPA דטרמיניסטי (pbi_check)**: מעל 100 כללים על מודל/DAX/דוח/נגישות/עיצוב
(Auto date/time, טבלת תאריכים חסרה/לא מסומנת, RLS, IFERROR, חילוק חשוף `/`, מדדים מרומזים
בוויזואלים, קשרים דו-כיווניים/many-to-many, צבעים חקוקים, מסננים סמויים ועוד)
עם מזהה יציב, מקור לכל כלל, וציון בריאות להשוואה בין ביקורות.

## התקנה

### Cowork (דסקטופ)
גררו את הקובץ `powerbi-report-reviewer.plugin` לצ'אט בדסקטופ ואשרו בכפתור ההתקנה.

### Claude Code (CLI, בדסקטופ)
ה-`.plugin` הוא ZIP של תיקיית ה-plugin. שתי דרכים:

1. **פירוק ידני לספריית ה-plugins** (הכי פשוט):
   ```bash
   mkdir -p ~/.claude/plugins/powerbi-report-reviewer
   unzip -o powerbi-report-reviewer.plugin -d ~/.claude/plugins/powerbi-report-reviewer
   ```
   הפעילו מחדש את `claude`; הסקיל ייטען אוטומטית לפי `SKILL.md`.

2. **דרך marketplace מקומי** (אם עובדים עם `claude plugin`):
   ```bash
   unzip -o powerbi-report-reviewer.plugin -d ./powerbi-report-reviewer
   claude plugin validate ./powerbi-report-reviewer/.claude-plugin/plugin.json
   claude plugin install ./powerbi-report-reviewer     # או דרך /plugin בתוך claude
   ```

בשני המקרים ודאו שהמבנה הוא `powerbi-report-reviewer/.claude-plugin/plugin.json` +
`powerbi-report-reviewer/skills/powerbi-report-reviewer/SKILL.md`.

## שימוש
ציינו את תיקיית פרויקט ה-PBIP (או גררו קבצים) ובקשו:
> "עבור על הדוח ותן סיכום ביקורת" · "בקר לי את ה-PBIP" · "מה חסר בדשבורד"

## רכיבים
| רכיב | כמות | תפקיד |
|------|------|--------|
| Skills | 2 | סוקר דוח Power BI (ביקורת בעברית, קריא-בלבד) + חיפוש ידע עיצובי (BM25) |
| Scripts | 7 | pbi_extract / pbi_analyze / pbi_check / pbi_doc / pbi_map / pbi_bench / pbi_validate (סוקר) · BM25 search |
| Tests | 22 | test_pbi_bench + test_pbi_check + test_stability (סוקר) |
| Agents / Hooks / MCP | 0 | לא נדרש — הסוכן עצמאי לחלוטין |

## הערות
- עצמאי לחלוטין: כל הידע (מבנה PBIP, צ'קליסט, קטלוג ויזואלים, תבניות DAX, ערכות צבע) מוטמע בתוך
  ה-skill. אין תלות ב-GitHub או בשירות חיצוני בזמן ריצה.
- הפלט תמיד בעברית (RTL). הצבעים גמישים — הסוכן מציע ערכות אך אינו כופה אחת קבועה.

רישיון: MIT.
