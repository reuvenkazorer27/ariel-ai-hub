#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
F3 - sync lock engine<->docs (prevents the drift fixed in round 62).

Every rule code emitted by the engines MUST be documented in its references
file, and every code in the docs must exist in the engine. A failure means a
new rule shipped without docs or an orphaned doc entry - fix in the same round
(single-source-of-truth rule from known-issues-log).

Run:  python tests/test_docs_sync.py   (stdlib only, offline)
"""
import os, re, unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

CHECKER = os.path.join(ROOT, 'skills', 'powerbi-report-reviewer', 'scripts', 'pbi_check.py')
BPA_DOC = os.path.join(ROOT, 'skills', 'powerbi-report-reviewer', 'references', 'bpa-checks.md')
VALIDATOR = os.path.join(ROOT, 'skills', 'powerbi-pbip-builder', 'scripts', 'pbi_validate.py')
VAL_DOC = os.path.join(ROOT, 'skills', 'powerbi-pbip-builder', 'references', 'validate-checks.md')

CODE_RE = r'([A-Z]{3,5}-\d+)'
RM_RE = r'((?:R|M)-\d+)'


class TestDocsSync(unittest.TestCase):

    def _read(self, path):
        with open(path, encoding='utf-8') as fh:
            return fh.read()

    def test_reviewer_engine_codes_all_documented(self):
        code = self._read(CHECKER)
        doc = self._read(BPA_DOC)
        engine = set(re.findall(r"add\('" + CODE_RE, code))
        documented = set(re.findall(r'\b' + CODE_RE + r'\b', doc))
        missing = sorted(engine - documented)
        orphaned = sorted(c for c in documented - engine
                          if re.match(r'^(MDL|DAX|ADV|RPT|PQ|A11Y)-\d+$', c))
        self.assertEqual(missing, [],
                         'rules in engine without docs in bpa-checks.md: %s' % missing)
        self.assertEqual(orphaned, [],
                         'orphaned codes in bpa-checks.md not in engine: %s' % orphaned)

    def test_builder_engine_codes_all_documented(self):
        code = self._read(VALIDATOR)
        doc = self._read(VAL_DOC)
        engine = set(re.findall(r"'" + RM_RE + r"'", code))
        documented = set(re.findall(r'\b' + RM_RE + r'\b', doc))
        missing = sorted(engine - documented)
        orphaned = sorted(documented - engine)
        self.assertEqual(missing, [],
                         'rules in validator without docs in validate-checks.md: %s' % missing)
        self.assertEqual(orphaned, [],
                         'orphaned codes in validate-checks.md (calibration notes must not use rule codes): %s' % orphaned)


CLAUDE_EX = os.path.join(ROOT, 'CLAUDE.example.md')

# נעילת החיווט (סבב 71, תיקון משתמש): CLAUDE.example.md מועתק לתיקיות פרויקט
# בארגונים שבהם לא נטענים סקילים — הוא החיווט היחיד של הסוכן לקבצי הידע.
# כל נתיב TOOLKIT שהוא מציין חייב להתקיים בריפו, אחרת הסוכן בארגון מופנה לקובץ
# שאינו (drift שקרה בסבב 62 כשהרשימה הפכה למצביע בלבד).
class TestClaudeExampleWiring(unittest.TestCase):

    def test_every_wired_file_exists(self):
        # כל קובץ (backticked, עם סיומת) שהתבנית מחווטת אליו חייב להתקיים בריפו —
        # לפי basename, כי הרשימה כותבת שמות יחסית לבסיס TOOLKIT מוצהר.
        text = open(CLAUDE_EX, encoding='utf-8').read()
        names = set(m.split('/')[-1] for m in
                    re.findall(r'`([A-Za-z0-9_./-]+\.(?:md|html|csv|py))`', text))
        names.discard('CLAUDE.md')  # שם העותק בתיקיית המשתמש, לא קובץ בריפו
        self.assertTrue(len(names) >= 15,
                        'expected the wiring to name >=15 toolkit files, got %d' % len(names))
        have = set()
        for _dp, _dn, fn in os.walk(ROOT):
            have.update(fn)
        missing = sorted(n for n in names if n not in have)
        self.assertEqual(missing, [],
                         'CLAUDE.example.md wires files that do not exist: %s' % missing)

    def test_five_core_references_wired(self):
        # חמשת ה-references שהמשתמש דרש במפורש (11.9) שיהיו מחווטים ישירות
        text = open(CLAUDE_EX, encoding='utf-8').read()
        for name in ('known-issues', 'extraction-guide', 'bpa-checks',
                     'blind-structure', 'report-assembly'):
            self.assertIn(name, text,
                          'core reference %s not wired in CLAUDE.example.md' % name)



# נעילת שאלת ההסתעפות (סבב 130, כשל שדה אמיתי 14.9): השאלה נכתבה במקור רק בסקיל
# הבונה — ובסשן ביקורת רגיל הסוקר מסיים בלי שהיא נורית בכלל. השאלה חייבת להופיע
# בכל ארבע נקודות החיווט, ואזהרת ההדבקה (# מפעיל פקודת זיכרון ב-Claude Code)
# חייבת להופיע בשני מסמכי ההתקנה.
REVIEWER_SKILL = os.path.join(ROOT, 'skills', 'powerbi-report-reviewer', 'SKILL.md')
BUILDER_SKILL = os.path.join(ROOT, 'skills', 'powerbi-pbip-builder', 'SKILL.md')
OUT_FORMAT = os.path.join(ROOT, 'skills', 'powerbi-report-reviewer', 'references', 'output-format.md')
INSTALL_HTML = os.path.join(ROOT, 'INSTALL.html')

QUESTION_ANCHOR = 'דשבורד חלופי עם סיכום השינויים'


class TestBranchingQuestionWiring(unittest.TestCase):

    def _read(self, path):
        with open(path, encoding='utf-8') as fh:
            return fh.read()

    def test_branching_question_present_everywhere(self):
        for path in (REVIEWER_SKILL, BUILDER_SKILL, CLAUDE_EX, OUT_FORMAT):
            text = re.sub(r'\s+', ' ', self._read(path))  # ניסוח עובר שורה במסמכים
            self.assertIn(QUESTION_ANCHOR, text,
                          'שאלת ההסתעפות חסרה ב-%s' % os.path.basename(path))
            self.assertIn('דוח ממצאים ותיקונים', text,
                          'נוסח השאלה חסר ב-%s' % os.path.basename(path))

    def test_reviewer_asks_first_before_scanning(self):
        # סבב 140 (הנחיית משתמש 14.9): "הדבר הראשון שהוא עושה זה שואל, לא סורק ואז שואל" —
        # שאלת ההסתעפות היא שלב 0א, לפני שלב 0 (איתור/סריקה). מסלול דשבורד = בלי ביקורת כלל;
        # ברירת מחדל בלי תשובה = דוח; אין שאלה כפולה בסוף.
        text = self._read(REVIEWER_SKILL)
        self.assertIn('שלב 0א', text, 'שלב 0א (שאלה ראשונה) חסר בסקיל הסוקר')
        i0a = text.find('שלב 0א — שאלת ההסתעפות')
        i0 = text.find('שלב 0 — איתור הקבצים')
        self.assertGreater(i0a, -1, 'כותרת שלב 0א חסרה')
        self.assertGreater(i0, i0a, 'שלב 0א חייב לבוא לפני שלב 0 (איתור/סריקה)')
        iq = text.find(QUESTION_ANCHOR, i0a)
        self.assertGreater(iq, i0a, 'שלב 0א קיים אבל השאלה לא בתוכו')
        self.assertLess(iq, i0, 'השאלה חייבת להופיע לפני שלב הסריקה')
        self.assertIn('אין ביקורת בכלל', text,
                      'מסלול דשבורד חייב לדלג על הביקורת (ישר לבונה)')
        self.assertIn('ברירת מחדל', text)
        self.assertNotIn('חובה בסוף כל ביקורת', text,
                         'השאלה אסורה להיות חובה בסוף — נשאלה כבר בפתיח')
        self.assertIn('אין לשאול אותה שוב בסוף', text, 'איסור שאלה כפולה חסר')

    def test_hash_paste_warning_present(self):
        for path in (CLAUDE_EX, INSTALL_HTML):
            text = self._read(path)
            self.assertIn('פקודת הזיכרון', text,
                          'אזהרת ההדבקה (# memory command) חסרה ב-%s' % os.path.basename(path))



SVG_REF = os.path.join(ROOT, 'skills', 'powerbi-pbip-builder', 'references', 'svg-visuals.md')
VAL_CHECKS = os.path.join(ROOT, 'skills', 'powerbi-pbip-builder', 'references', 'validate-checks.md')


class TestSvgBindWiring(unittest.TestCase):
    """נעילת חיווט --bind ו-debom (סבב 131): SVG שלא נקשר לוויזואל לא מתממש —
    כשל שדה אמיתי. כל נקודות התיעוד חייבות להורות --bind, ותיקון debom חייב
    להיות מתועד לצד M-22."""

    def _read(self, path):
        with open(path, encoding='utf-8') as fh:
            return fh.read()

    def test_bind_documented_everywhere(self):
        for path in (BUILDER_SKILL, SVG_REF, CLAUDE_EX):
            self.assertIn('--bind', self._read(path),
                          '--bind לא מתועד ב-%s' % os.path.basename(path))

    def test_debom_documented_with_m22(self):
        for path in (BUILDER_SKILL, VAL_CHECKS):
            self.assertIn('debom', self._read(path),
                          'debom לא מתועד ב-%s' % os.path.basename(path))

    def test_csv_bom_and_autobind_documented(self):
        # סבב 132: כלל כתיבת CSV בלי BOM, כיסוי .csv ב-M-22, וקשירה אוטומטית
        # של pbi_variant — כשלי שדה שחייבים להיות מתועדים כדי שלא יחזרו.
        import re
        skill = re.sub(r'\s+', ' ', self._read(BUILDER_SKILL))
        self.assertIn('utf8NoBOM', skill, 'כלל כתיבת CSV בלי BOM לא מתועד בסקיל')
        self.assertIn('מקשר לדף הראשון אוטומטית', skill,
                      'קשירה אוטומטית של variant לא מתועדת בסקיל')
        self.assertIn('.csv', self._read(VAL_CHECKS), 'כיסוי CSV של M-22 לא מתועד')
        self.assertNotIn('לפי שיקול דעת — ראה `references/svg-visuals.md`', skill,
                         'נוסח "שיקול דעת" שאיפשר לדלג על SVG נותר בסקיל')

    def test_m23_schema_table_documented(self):
        # סבב 132 (בקשת משתמש): טבלת גרסאות ה-schema הנתמכות + כלל כתיבה בסקיל.
        self.assertIn('M-23', self._read(VAL_CHECKS), 'M-23 לא מתועד')
        self.assertIn('2.9.0', self._read(VAL_CHECKS), 'גרסת היעד לתיקון לא מתועדת')
        import re
        skill = re.sub(r'\s+', ' ', self._read(BUILDER_SKILL))
        self.assertIn('לעולם לא לנחש מספר גרסה', skill,
                      'כלל $schema למחולל לא מתועד בסקיל')
        self.assertIn('schemaver', skill, 'תיקון schemaver לא מתועד בסקיל')


if __name__ == '__main__':
    unittest.main()
