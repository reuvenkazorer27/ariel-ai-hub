#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
בדיקות יחידה לכלי הבונה: pbi_validate.py (אימות מבנה) ו-pbi_fix.py (תיקונים דטרמיניסטיים).

שיטה: כמו test_pbi_check.py — fixture סינתטי עם מלכודות מכוונות, ופרויקט תקין כמגן
false-positives. בודקים גם שהתיקון *כותב נכון* (read-back) וגם שהוא **אידמפוטנטי**
(הרצה שנייה לא משנה כלום).

הרצה:  python tests/test_builder_tools.py      (stdlib בלבד, בלי רשת)
"""
import json, os, sys, shutil, subprocess, tempfile, unittest, importlib.util

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def load(mod_name, script):
    spec = importlib.util.spec_from_file_location(mod_name, script)
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


V = load('pbi_validate', os.path.join(ROOT, 'skills/powerbi-pbip-builder/scripts/pbi_validate.py'))
F = load('pbi_fix', os.path.join(ROOT, 'skills/powerbi-pbip-builder/scripts/pbi_fix.py'))
SW = load('pbi_swap', os.path.join(ROOT, 'skills/powerbi-pbip-builder/scripts/pbi_swap.py'))
C = load('pbi_check', os.path.join(ROOT, 'skills/powerbi-report-reviewer/scripts/pbi_check.py'))
S = load('pbi_svg', os.path.join(ROOT, 'skills/powerbi-pbip-builder/scripts/pbi_svg.py'))
E = load('pbi_extract', os.path.join(ROOT, 'skills/powerbi-report-reviewer/scripts/pbi_extract.py'))
FIX = os.path.join(ROOT, 'tests', 'fixture')


def w(path, text):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, 'w', encoding='utf-8') as fh:
        fh.write(text)


class ValidateOnFixture(unittest.TestCase):
    """ה-fixture הסטטי (עם המלכודות המכוונות שלו) — pbi_validate תופס את האמיתיות."""

    def setUp(self):
        V._ISSUES.clear()
        self.sm = os.path.join(FIX, 'MiniReport.SemanticModel')
        self.rp = os.path.join(FIX, 'MiniReport.Report')
        mt = V.read_model_map(self.sm)
        V.validate_model(self.sm)
        V.validate_report(self.rp, mt)

    def codes(self):
        return {i['code'] for i in V._ISSUES}

    def test_no_structural_errors(self):
        self.assertEqual([i for i in V._ISSUES if i['level'] == 'err'], [],
                         'ה-fixture התקין מבחינה מבנית — אסורות שגיאות')

    def test_catches_field_to_missing_column(self):
        # vis002 מקושר ל-dimמוצרים[שם מוצר] שלא קיים בטבלה — מלכודת מתועדת ב-fixture
        r15 = [i for i in V._ISSUES if i['code'] == 'R-15']
        self.assertTrue(any('שם מוצר' in i['title'] for i in r15))

    def test_missing_version_json_warned(self):
        self.assertIn('R-02', self.codes())

    def test_no_geometry_or_ref_false_positives(self):
        # ה-fixture ה"תקין" נבנה כמו פלט Desktop: z ייחודי, בלי חפיפות, בלי שבורים
        bad = {'R-16', 'R-18', 'R-19', 'R-20', 'R-21', 'R-22', 'R-23', 'R-24', 'R-25',
                   'R-26', 'R-27', 'R-28', 'R-29', 'R-30', 'R-31', 'R-32', 'R-33', 'R-34', 'R-35',
                   'R-36', 'R-37', 'R-38', 'R-39', 'R-40', 'R-41', 'R-42', 'R-43',
                   'R-44', 'R-45', 'R-46', 'R-47', 'R-48', 'R-49', 'R-50', 'R-51', 'R-52', 'R-53', 'R-54', 'R-55', 'R-56', 'R-57', 'R-66',
                   'M-04', 'M-06', 'M-07', 'M-08', 'M-09', 'M-10', 'M-11', 'M-12', 'M-13', 'M-14', 'M-15', 'M-16', 'M-17', 'R-84', 'R-85'} & self.codes()
        self.assertEqual(bad, set(), 'כללים חדשים ירו על פרויקט תקין: %s' % bad)


class ValidateBreakages(unittest.TestCase):
    """שיבושים מכוונים בעותק זמני — כל אחד חייב להיתפס."""

    def setUp(self):
        self.root = tempfile.mkdtemp(prefix='pbival-')
        self.dst = os.path.join(self.root, 'P')
        shutil.copytree(FIX, self.dst)
        self.sm = os.path.join(self.dst, 'MiniReport.SemanticModel')
        self.rp = os.path.join(self.dst, 'MiniReport.Report')

    def tearDown(self):
        shutil.rmtree(self.root, ignore_errors=True)

    def run_val(self):
        V._ISSUES.clear()
        mt = V.read_model_map(self.sm)
        V.validate_model(self.sm)
        V.validate_report(self.rp, mt)
        return V._ISSUES

    def test_page_missing_from_pageorder_is_error(self):
        pj = os.path.join(self.rp, 'definition', 'pages', 'pages.json')
        w(pj, json.dumps({'activePageName': 'page001', 'pageOrder': ['page001']}))
        issues = self.run_val()
        errs = [i for i in issues if i['code'] == 'R-04' and i['level'] == 'err']
        self.assertTrue(any('page002' in i['title'] for i in errs), 'דף חסר ב-pageOrder לא נתפס')

    def test_broken_visual_json_is_error(self):
        vj = os.path.join(self.rp, 'definition', 'pages', 'page001', 'visuals', 'vis001', 'visual.json')
        w(vj, '{not json')
        issues = self.run_val()
        self.assertTrue(any(i['code'] == 'R-06' and i['level'] == 'err' for i in issues))

    def test_out_of_bounds_visual_warned(self):
        vj = os.path.join(self.rp, 'definition', 'pages', 'page001', 'visuals', 'vis001', 'visual.json')
        d = json.load(open(vj, encoding='utf-8-sig'))
        d['position']['x'] = 99999
        w(vj, json.dumps(d, ensure_ascii=False))
        issues = self.run_val()
        self.assertTrue(any(i['code'] == 'R-07' for i in issues), 'חריגה מהקנבס לא נתפסה')

    def test_dangling_bookmark_caught(self):
        bm = os.path.join(self.rp, 'definition', 'bookmarks')
        w(os.path.join(bm, 'bookmarks.json'), json.dumps({'items': [{'name': 'b1'}]}))
        # בלי b1.bookmark.json בכוונה
        issues = self.run_val()
        self.assertTrue(any(i['code'] == 'R-11' and i['level'] == 'err' for i in issues))

    def test_relationship_to_missing_column_is_error(self):
        w(os.path.join(self.sm, 'definition', 'relationships.tmdl'),
          'relationship rx\n\tfromColumn: factמכירות.לאקיים\n\ttoColumn: dimתאריך.Date\n')
        issues = self.run_val()
        self.assertTrue(any(i['code'] == 'M-03' and i['level'] == 'err' and 'לאקיים' in i['title']
                            for i in issues))

    def test_inline_model_tmdl_relationship_valid_no_fp(self):
        # קשר תקין inline בתוך model.tmdl (לא relationships.tmdl) — אסור M-03.
        # מבנה התיקיות ב-TMDL הוא ברירת-מחדל בלבד (MS Learn tmdl-overview); סבב 112.
        w(os.path.join(self.sm, 'definition', 'model.tmdl'),
          'model Model\n\tculture: he-IL\n\n'
          'relationship ri\n\tfromColumn: factמכירות.תאריך\n\ttoColumn: dimתאריך.Date\n'
          '\tisActive: false\n')
        issues = self.run_val()
        self.assertFalse(any(i['code'] == 'M-03' for i in issues),
                         'קשר inline תקין סומן כ-M-03 (FP)')

    def test_inline_model_tmdl_relationship_broken_caught(self):
        # קצה שבור בקשר inline — חייב M-03 בדיוק כמו ב-relationships.tmdl
        w(os.path.join(self.sm, 'definition', 'model.tmdl'),
          'model Model\n\n'
          'relationship rb\n\tfromColumn: factמכירות.לאקיים\n\ttoColumn: dimתאריך.Date\n'
          '\tisActive: false\n')
        issues = self.run_val()
        self.assertTrue(any(i['code'] == 'M-03' and 'לאקיים' in i['title'] for i in issues),
                        'קצה שבור בקשר inline לא נתפס')

    def _set_vis(self, page, vis, mut):
        vj = os.path.join(self.rp, 'definition', 'pages', page, 'visuals', vis, 'visual.json')
        d = json.load(open(vj, encoding='utf-8-sig'))
        mut(d)
        w(vj, json.dumps(d, ensure_ascii=False))

    def test_overlap_between_data_visuals_warned(self):
        # vis003 מוזז לתוך vis002 — חפיפה מלאה
        self._set_vis('page001', 'vis003', lambda d: d['position'].update(x=200, y=10))
        issues = self.run_val()
        self.assertTrue(any(i['code'] == 'R-16' for i in issues), 'חפיפה לא נתפסה')

    def test_fractional_position_not_warned(self):
        # מלכודת שהוכחשה בסבב 13: קואורדינטות עשרוניות הן הנורמה בפלט Desktop אמיתי
        # (אומת מול data-goblin / clientfirsttech / Mofaji) — אסור להתריע עליהן.
        self._set_vis('page001', 'vis001', lambda d: d['position'].update(x=10.513, width=149.75))
        issues = self.run_val()
        self.assertFalse(any(i['code'] == 'R-17' for i in issues),
                         'התרעה על position עשרוני היא false-positive — R-17 הוצא משימוש')

    def test_zero_size_visual_is_error(self):
        self._set_vis('page001', 'vis001', lambda d: d['position'].update(height=0))
        issues = self.run_val()
        self.assertTrue(any(i['code'] == 'R-19' and i['level'] == 'err' for i in issues))

    def test_tiny_chart_warned(self):
        # R-66: tableEx בגודל 60x40 — מתחת למינימום קריא 80x60 (horizun-pbi-mcp, Apache-2.0)
        self._set_vis('page001', 'vis002', lambda d: d['position'].update(width=60, height=40))
        issues = self.run_val()
        self.assertTrue(any(i['code'] == 'R-66' and 'vis002' in i['location'] for i in issues),
                        'תרשים זעיר לא נתפס')

    def test_tiny_card_clean(self):
        # כרטיס KPI קומפקטי לגיטימי (44px בקורפוס אמיתי) — לא מסמנים
        self._set_vis('page001', 'vis001', lambda d: d['position'].update(width=120, height=44))
        issues = self.run_val()
        self.assertFalse(any(i['code'] == 'R-66' and 'vis001' in i['location'] for i in issues),
                         'כרטיס קומפקטי סומן (FP)')

    def test_tiny_slicer_clean(self):
        # סליסר שורה 38px לגיטימי (כיול corpus: insurance/metro) — לא מסמנים
        def mut(d):
            d['visual']['visualType'] = 'slicer'
            d['position'].update(width=165, height=38)
        self._set_vis('page001', 'vis002', mut)
        issues = self.run_val()
        self.assertFalse(any(i['code'] == 'R-66' and 'vis002' in i['location'] for i in issues),
                         'סליסר קומפקטי סומן (FP)')

    def test_invalid_display_option_is_error(self):
        pj = os.path.join(self.rp, 'definition', 'pages', 'page001', 'page.json')
        d = json.load(open(pj, encoding='utf-8-sig'))
        d['displayOption'] = 'FitToScream'
        w(pj, json.dumps(d, ensure_ascii=False))
        issues = self.run_val()
        self.assertTrue(any(i['code'] == 'R-18' and i['level'] == 'err' for i in issues))

    def test_duplicate_z_warned(self):
        self._set_vis('page001', 'vis002', lambda d: d['position'].update(z=1))
        issues = self.run_val()
        self.assertTrue(any(i['code'] == 'R-20' for i in issues), 'z כפול לא נתפס')

    def test_invalid_visualtype_name_warned(self):
        self._set_vis('page001', 'vis001', lambda d: d['visual'].update(visualType='stackedBarChart'))
        issues = self.run_val()
        self.assertTrue(any(i['code'] == 'R-21' and 'barChart' in i['title'] for i in issues),
                        'visualType לא-חוקי (stackedBarChart) לא נתפס')

    def test_sort_by_field_not_in_visual_warned(self):
        def mut(d):
            d['visual'].setdefault('query', {})['sortDefinition'] = {'sort': [{
                'field': {'Measure': {'Expression': {'SourceRef': {'Entity': 'factמכירות'}},
                                      'Property': 'מדד שלא מוקרן'}},
                'direction': 'Ascending'}]}
        self._set_vis('page001', 'vis001', mut)
        issues = self.run_val()
        self.assertTrue(any(i['code'] == 'R-25' and 'ממוין' in i['title'] for i in issues),
                        'מיון לפי שדה לא-מוקרן לא נתפס')

    def test_sort_direction_invalid_warned(self):
        def mut(d):
            d['visual'].setdefault('query', {})['sortDefinition'] = {'sort': [{
                'field': {'Measure': {'Expression': {'SourceRef': {'Entity': 'factמכירות'}},
                                      'Property': 'סכום ללא הגנה'}},
                'direction': 'Sideways'}]}
        self._set_vis('page001', 'vis001', mut)
        issues = self.run_val()
        self.assertTrue(any(i['code'] == 'R-25' and 'direction' in i['title'] for i in issues),
                        'direction לא חוקי לא נתפס')

    def test_insert_visual_without_howcreated_warned(self):
        self._set_vis('page001', 'vis001', lambda d: d['visual'].update(visualType='actionButton'))
        issues = self.run_val()
        self.assertTrue(any(i['code'] == 'R-24' for i in issues), 'actionButton בלי howCreated לא נתפס')

    def test_insert_visual_with_howcreated_ok(self):
        def mut(d):
            d['visual']['visualType'] = 'actionButton'
            d['howCreated'] = 'InsertVisualButton'
        self._set_vis('page001', 'vis001', mut)
        issues = self.run_val()
        self.assertFalse(any(i['code'] == 'R-24' for i in issues))

    def test_dangling_sortbycolumn_is_error(self):
        tf = os.path.join(self.sm, 'definition', 'tables', 'dimתאריך.tmdl')
        t = open(tf, encoding='utf-8-sig').read()
        w(tf, t + "\n\tcolumn MonthName\n\t\tsortByColumn: MonthNumberThatIsGone\n")
        issues = self.run_val()
        self.assertTrue(any(i['code'] == 'M-07' and i['level'] == 'err' for i in issues),
                        'sortByColumn שבור לא נתפס')

    def test_circular_dep_sortbycolumn_is_error(self):
        # סבב 100 — M-14: הרבי-פרודוקציה של pbip-tools TOOLCHAIN-FINDINGS #1:
        # עמודה מחושבת שעמודת המיון שלה נגזרת ממנה = מעגל; Desktop מסרב לטעון
        w(os.path.join(self.sm, 'definition', 'tables', 'cyc.tmdl'),
          "table cyc\n"
          "\tcolumn DueDate\n\t\tdataType: dateTime\n"
          "\tcolumn 'Due Status' = IF(cyc[DueDate] < TODAY(), \"Overdue\", \"OK\")\n"
          "\t\tsortByColumn: 'Due Status Order'\n"
          "\tcolumn 'Due Status Order' = SWITCH(cyc[Due Status], \"Overdue\", 1, \"OK\", 2, 0)\n")
        issues = self.run_val()
        m14 = [i for i in issues if i['code'] == 'M-14']
        self.assertTrue(any(i['level'] == 'err' for i in m14),
                        'מעגל sortByColumn לא נתפס')
        self.assertTrue(any('Due Status' in i['title'] for i in m14),
                        'נתיב המעגל לא מדווח')

    def test_sort_by_calc_derived_from_column_is_error(self):
        # endjin quick-tip: מיון עמודה לפי עמודה מחושבת הנגזרת ממנה = circular ref
        w(os.path.join(self.sm, 'definition', 'tables', 'ppl.tmdl'),
          "table ppl\n"
          "\tcolumn Month\n\t\tdataType: string\n\t\tsortByColumn: MonthOrder\n"
          "\tcolumn MonthOrder = SWITCH(ppl[Month], \"Jan\", 1, 2)\n")
        issues = self.run_val()
        self.assertTrue(any(i['code'] == 'M-14' and i['level'] == 'err' for i in issues),
                        'מעגל endjin (מיון לפי נגזרת) לא נתפס')

    def test_measure_column_cycle_is_error(self):
        # עמודה מחושבת המפנה למדד שמפנה חזרה אליה
        w(os.path.join(self.sm, 'definition', 'tables', 'mcyc.tmdl'),
          "table mcyc\n"
          "\tcolumn X\n\t\tdataType: int64\n"
          "\tcolumn Y = [M1] + mcyc[X]\n"
          "\tmeasure M1 = SUM(mcyc[Y])\n")
        issues = self.run_val()
        self.assertTrue(any(i['code'] == 'M-14' for i in issues),
                        'מעגל עמודה↔מדד לא נתפס')

    def test_calc_chain_no_cycle_clean(self):
        # שרשרת חוקית: B מ-A, C מ-B, מיון לפי עמודת נתונים — אין מעגל
        w(os.path.join(self.sm, 'definition', 'tables', 'chain.tmdl'),
          "table chain\n"
          "\tcolumn A\n\t\tdataType: int64\n"
          "\tcolumn SortA\n\t\tdataType: int64\n"
          "\tcolumn B = chain[A] * 2\n\t\tsortByColumn: SortA\n"
          "\tcolumn C = chain[B] + 1\n"
          "\tmeasure Tot = SUM(chain[C])\n")
        issues = self.run_val()
        self.assertEqual([i for i in issues if i['code'] == 'M-14'], [],
                         'M-14 הופעל על שרשרת תלות חוקית (FP)')

    def test_kpi_self_reference_clean(self):
        # FP אמיתי מהקורפוס (retail TotalSalesTY): statusExpression של KPI
        # מפנה חוקית למדד עצמו — אינו מעגל
        w(os.path.join(self.sm, 'definition', 'tables', 'kpis.tmdl'),
          "table kpis\n"
          "\tcolumn G\n\t\tdataType: int64\n"
          "\tmeasure Base = SUM(kpis[G])\n"
          "\tmeasure WithKpi = [Base]\n"
          "\t\tkpi\n"
          "\t\t\ttargetExpression = 'kpis'[Base]\n"
          "\t\t\tstatusExpression = ```\n"
          "\t\t\t\tvar x = 'kpis'[WithKpi] return if(ISBLANK(x), BLANK(), 1)\n"
          "\t\t\t\t```\n")
        issues = self.run_val()
        self.assertEqual([i for i in issues if i['code'] == 'M-14'], [],
                         'M-14 הופעל על KPI statusExpression (FP)')

    def test_dynamic_format_self_reference_clean(self):
        # FP אמיתי מהקורפוס (cap-daq Gross Revenue): formatStringDefinition
        # דינמי מפנה חוקית למדד עצמו
        w(os.path.join(self.sm, 'definition', 'tables', 'dynfmt.tmdl'),
          "table dynfmt\n"
          "\tcolumn V\n\t\tdataType: int64\n"
          "\tmeasure Rev = SUM(dynfmt[V])\n"
          "\t\tformatStringDefinition = IF(ABS([Rev]) >= 1000, \"0,.0k\", \"0\")\n")
        issues = self.run_val()
        self.assertEqual([i for i in issues if i['code'] == 'M-14'], [],
                         'M-14 הופעל על formatStringDefinition (FP)')

    def test_absolute_local_path_in_partition_warned(self):
        # סבב 103 — M-16 (pbi-assure PBI-SOURCE-001, MIT): נתיב מקומי מוחלט
        # בביטוי M של מחיצה. נמצא בקורפוס: claude (Csv.Document מ-Downloads),
        # advw (Excel.Workbook מ-F:\PowerBI), pbisample (C:\Users\...).
        w(os.path.join(self.sm, 'definition', 'tables', 'local.tmdl'),
          "table local\n"
          "\tcolumn V\n\t\tdataType: int64\n"
          "\tpartition local = m\n"
          "\t\tmode: import\n"
          "\t\tsource =\n"
          "\t\t\tlet\n"
          '\t\t\t  Source = Csv.Document(File.Contents("C:\\Users\\someone\\Downloads\\data.csv"))\n'
          "\t\t\tin\n"
          "\t\t\t  Source\n")
        issues = self.run_val()
        self.assertTrue(any(i['code'] == 'M-16' and i['level'] == 'warn' and 'local' in i['title']
                            for i in issues), 'נתיב מקומי מוחלט לא נתפס')
        self.assertFalse(any('C:' in i['title'] or 'C:' in i.get('detail', '')
                             for i in issues if i['code'] == 'M-16'),
                         'ערך הנתיב עצמו דולף לדיווח (פרטיות)')

    def test_unc_path_in_partition_warned(self):
        w(os.path.join(self.sm, 'definition', 'tables', 'unc.tmdl'),
          "table unc\n"
          "\tcolumn V\n\t\tdataType: int64\n"
          "\tpartition unc = m\n"
          "\t\tmode: import\n"
          "\t\tsource =\n"
          "\t\t\tlet\n"
          '\t\t\t  Source = Folder.Files("\\\\fileserver\\share\\data")\n'
          "\t\t\tin\n"
          "\t\t\t  Source\n")
        issues = self.run_val()
        self.assertTrue(any(i['code'] == 'M-16' for i in issues),
                        'נתיב רשת UNC לא נתפס')

    def test_server_source_no_path_false_positive(self):
        # מקור שרת/ענן חוקי — לא נתיב מקומי; ומחרוזת DAX עם C:\ במדד אינה
        # בבלוק המחיצה ואינה אמורה להיתפס כלל
        w(os.path.join(self.sm, 'definition', 'tables', 'srv.tmdl'),
          "table srv\n"
          "\tcolumn V\n\t\tdataType: int64\n"
          "\tmeasure Note = \"ראו C:\\temp\\readme\"\n"
          "\tpartition srv = m\n"
          "\t\tmode: import\n"
          "\t\tsource =\n"
          "\t\t\tlet\n"
          '\t\t\t  Source = Sql.Database("sqlsrv", "db"),\n'
          '\t\t\t  W = Web.Contents("https://example.com/api")\n'
          "\t\t\tin\n"
          "\t\t\t  Source\n")
        issues = self.run_val()
        self.assertEqual([i for i in issues if i['code'] == 'M-16'], [],
                         'M-16 הופעל על מקור שרת/מחרוזת DAX (FP)')

    def test_pbir_bypath_missing_is_error(self):
        # סבב 104 — R-84 (pbip-doctor PBIP002/PBIP005, MIT): byPath ב-definition.pbir
        # חייב להיות יחסי ולהצביע לתיקיית מודל קיימת
        w(os.path.join(self.rp, 'definition.pbir'),
          '{"version":"4.0","datasetReference":{"byPath":{"path":"../Gone.SemanticModel"}}}')
        issues = self.run_val()
        self.assertTrue(any(i['code'] == 'R-84' and i['level'] == 'err'
                            for i in issues), 'byPath שבור לא נתפס')

    def test_pbir_bypath_absolute_warned(self):
        w(os.path.join(self.rp, 'definition.pbir'),
          '{"version":"4.0","datasetReference":{"byPath":{"path":"C:\\\\pbip\\\\MiniReport.SemanticModel"}}}')
        issues = self.run_val()
        r84 = [i for i in issues if i['code'] == 'R-84']
        self.assertTrue(any(i['level'] == 'warn' for i in r84),
                        'byPath מוחלט לא סומן כאזהרה')
        self.assertFalse(any('C:' in i['title'] for i in r84),
                         'ערך הנתיב המוחלט דולף לכותרת (פרטיות)')

    def test_pbir_bypath_resolves_clean(self):
        w(os.path.join(self.rp, 'definition.pbir'),
          '{"version":"4.0","datasetReference":{"byPath":{"path":"../MiniReport.SemanticModel"}}}')
        issues = self.run_val()
        self.assertEqual([i for i in issues if i['code'] == 'R-84'], [],
                         'R-84 הופעל על byPath יחסי תקין (FP)')

    def test_pbip_artifact_missing_is_error(self):
        w(os.path.join(self.dst, 'MiniReport.pbip'),
          '{"version":"1.0","artifacts":[{"report":{"path":"Gone.Report"}}]}')
        V._ISSUES.clear()
        argv, sys.argv = sys.argv, ['pbi_validate.py', self.dst]
        try:
            import io, contextlib
            with contextlib.redirect_stdout(io.StringIO()):
                V.main()
        finally:
            sys.argv = argv
        self.assertTrue(any(i['code'] == 'R-84' and i['level'] == 'err'
                            and 'Gone.Report' in i['title'] for i in V._ISSUES),
                        'artifact שבור ב-pbip לא נתפס')

    def test_local_cache_artifacts_warned(self):
        # סבב 106 — R-85 (MS Learn projects-overview, CC-BY-4.0: ה-.gitignore
        # ש-Desktop יוצר מתעלם מ-.pbi/localSettings.json ו-.pbi/cache.abf).
        # נמצא בקורפוס: claude (שניהם + localSettings בדוח), metro (pbix)
        os.makedirs(os.path.join(self.sm, '.pbi'))
        w(os.path.join(self.sm, '.pbi', 'localSettings.json'), '{}')
        w(os.path.join(self.sm, '.pbi', 'cache.abf'), 'x')
        issues = self.run_val()
        r85 = [i for i in issues if i['code'] == 'R-85']
        self.assertEqual(len(r85), 2, 'שני פריטי cache לא נתפסו')
        self.assertTrue(all(i['level'] == 'warn' for i in r85))

    def test_editor_settings_not_flagged(self):
        # editorSettings.json אינו ברשימת ההתעלמות של Desktop — לא לסמן
        os.makedirs(os.path.join(self.sm, '.pbi'))
        w(os.path.join(self.sm, '.pbi', 'editorSettings.json'), '{}')
        issues = self.run_val()
        self.assertEqual([i for i in issues if i['code'] == 'R-85'], [],
                         'R-85 הופעל על editorSettings.json (FP)')

    def test_pbix_at_project_root_warned(self):
        w(os.path.join(self.dst, 'legacy.pbix'), 'PK')
        V._ISSUES.clear()
        argv, sys.argv = sys.argv, ['pbi_validate.py', self.dst]
        try:
            import io, contextlib
            with contextlib.redirect_stdout(io.StringIO()):
                V.main()
        finally:
            sys.argv = argv
        self.assertTrue(any(i['code'] == 'R-85' and 'legacy.pbix' in i['title']
                            for i in V._ISSUES), 'pbix בשורש הפרויקט לא נתפס')

    def test_shared_expression_absolute_path_warned(self):
        # סבב 105 — M-17 (MS Learn Power Query parameters, CC-BY-4.0): נתיב
        # מקומי מוחלט בפרמטר/ביטוי משותף. נמצא בקורפוס: metro SourceFile,
        # insurance pProjectRoot
        w(os.path.join(self.sm, 'definition', 'expressions.tmdl'),
          "expression SourceFile = \"C:\\data\\input.csv\" meta [IsParameterQuery=true]\n"
          "\tlineageTag: 11111111-2222-3333-4444-555555555555\n")
        issues = self.run_val()
        self.assertTrue(any(i['code'] == 'M-17' and i['level'] == 'warn'
                            and 'SourceFile' in i['title'] for i in issues),
                        'נתיב מוחלט בביטוי משותף לא נתפס')
        self.assertFalse(any('C:' in i['title'] for i in issues if i['code'] == 'M-17'),
                         'ערך הנתיב דולף לכותרת (פרטיות)')

    def test_shared_expression_unc_path_warned(self):
        w(os.path.join(self.sm, 'definition', 'expressions.tmdl'),
          'expression GetData = ```let S = Folder.Files("\\\\srv\\share") in S```\n')
        issues = self.run_val()
        self.assertTrue(any(i['code'] == 'M-17' for i in issues),
                        'נתיב UNC בביטוי משותף לא נתפס')

    def test_shared_expression_relative_clean(self):
        # פרמטר שמפנה לנתיב יחסי/ללא נתיב — לא אמור לירות; וגם הביטוי השני
        # בקובץ (שאין בו נתיב) לא אמור להיתפס בשל הראשון
        w(os.path.join(self.sm, 'definition', 'expressions.tmdl'),
          "expression pRel = \"data\\input.csv\" meta [IsParameterQuery=true]\n"
          "\tlineageTag: 11111111-2222-3333-4444-555555555555\n\n"
          "expression fnLoad = ```(p as text) => Csv.Document(File.Contents(p))```\n"
          "\tlineageTag: 22222222-3333-4444-5555-666666666666\n")
        issues = self.run_val()
        self.assertEqual([i for i in issues if i['code'] == 'M-17'], [],
                         'M-17 הופעל על ביטויים ללא נתיב מוחלט (FP)')

    def test_duplicate_measure_name_across_tables_is_error(self):
        w(os.path.join(self.sm, 'definition', 'tables', 'extra.tmdl'),
          "table extra\n\tmeasure 'סכום ללא הגנה' = 1\n")
        issues = self.run_val()
        self.assertTrue(any(i['code'] == 'M-08' and i['level'] == 'err' and 'פעמיים' in i['title']
                            for i in issues), 'מדד כפול במודל לא נתפס')

    def test_column_colliding_with_measure_is_error(self):
        w(os.path.join(self.sm, 'definition', 'tables', 'extra.tmdl'),
          "table extra\n\tcolumn 'סכום ללא הגנה'\n")
        issues = self.run_val()
        self.assertTrue(any(i['code'] == 'M-08' and i['level'] == 'err' and 'מתנגש' in i['title']
                            for i in issues), 'עמודה המתנגשת עם מדד לא נתפסה')

    def test_two_active_relationships_same_pair_is_error(self):
        # סבב 102 — M-15: שני קשרים פעילים בין אותו זוג טבלאות = נתיב סינון
        # לא דטרמיניסטי (MS Learn relationships-active-inactive, CC-BY-4.0)
        w(os.path.join(self.sm, 'definition', 'relationships.tmdl'),
          'relationship r1\n\tfromColumn: fact\u05de\u05db\u05d9\u05e8\u05d5\u05ea.Date\n\ttoColumn: dim\u05ea\u05d0\u05e8\u05d9\u05da.Date\n'
          'relationship r2\n\tfromColumn: fact\u05de\u05db\u05d9\u05e8\u05d5\u05ea.ShipDate\n\ttoColumn: dim\u05ea\u05d0\u05e8\u05d9\u05da.Date\n')
        issues = self.run_val()
        m15 = [i for i in issues if i['code'] == 'M-15']
        self.assertTrue(any(i['level'] == 'err' for i in m15),
                        'שני קשרים פעילים לאותו זוג לא נתפסו')

    def test_active_plus_inactive_clean(self):
        w(os.path.join(self.sm, 'definition', 'relationships.tmdl'),
          'relationship r1\n\tfromColumn: fact\u05de\u05db\u05d9\u05e8\u05d5\u05ea.Date\n\ttoColumn: dim\u05ea\u05d0\u05e8\u05d9\u05da.Date\n'
          'relationship r2\n\tfromColumn: fact\u05de\u05db\u05d9\u05e8\u05d5\u05ea.ShipDate\n\ttoColumn: dim\u05ea\u05d0\u05e8\u05d9\u05da.Date\n\tisActive: false\n')
        issues = self.run_val()
        self.assertEqual([i for i in issues if i['code'] == 'M-15'], [],
                         'M-15 הופעל על זוג פעיל+לא-פעיל חוקי (FP)')

    def test_two_actives_different_pairs_clean(self):
        w(os.path.join(self.sm, 'definition', 'relationships.tmdl'),
          'relationship r1\n\tfromColumn: fact\u05de\u05db\u05d9\u05e8\u05d5\u05ea.Date\n\ttoColumn: dim\u05ea\u05d0\u05e8\u05d9\u05da.Date\n'
          'relationship r2\n\tfromColumn: fact\u05de\u05db\u05d9\u05e8\u05d5\u05ea.\u05de\u05e7\u05f4\u05d8\n\ttoColumn: dim\u05de\u05d5\u05e6\u05e8\u05d9\u05dd.\u05de\u05e7\u05f4\u05d8\n')
        issues = self.run_val()
        self.assertEqual([i for i in issues if i['code'] == 'M-15'], [],
                         'M-15 הופעל על זוגות שונים (FP)')

    def test_self_relationship_is_error(self):
        w(os.path.join(self.sm, 'definition', 'relationships.tmdl'),
          'relationship rx\n\tfromColumn: dimתאריך.Date\n\ttoColumn: dimתאריך.Date\n')
        issues = self.run_val()
        self.assertTrue(any(i['code'] == 'M-04' and i['level'] == 'err' for i in issues))

    def test_rls_missing_table_is_error(self):
        rd = os.path.join(self.sm, 'definition', 'roles')
        os.makedirs(rd, exist_ok=True)
        w(os.path.join(rd, 'Bad.tmdl'),
          "role 'Bad'\n\tmodelPermission: read\n\ttablePermission טבלה_שאיננה = 'טבלה_שאיננה'[X] = 1\n")
        issues = self.run_val()
        self.assertTrue(any(i['code'] == 'M-09' and i['level'] == 'err' and 'טבלה_שאיננה' in i['title']
                            for i in issues), 'tablePermission לטבלה חסרה לא נתפס')

    def test_rls_missing_column_is_error(self):
        rd = os.path.join(self.sm, 'definition', 'roles')
        os.makedirs(rd, exist_ok=True)
        w(os.path.join(rd, 'Bad.tmdl'),
          "role 'Bad'\n\tmodelPermission: read\n\ttablePermission dimתאריך = 'dimתאריך'[עמודה שנמחקה] = 1\n")
        issues = self.run_val()
        self.assertTrue(any(i['code'] == 'M-09' and i['level'] == 'err' and 'עמודה שנמחקה' in i['title']
                            for i in issues), 'RLS לעמודה חסרה לא נתפס')

    def test_rls_valid_role_no_issue(self):
        rd = os.path.join(self.sm, 'definition', 'roles')
        os.makedirs(rd, exist_ok=True)
        w(os.path.join(rd, 'Good.tmdl'),
          "role 'Good'\n\tmodelPermission: read\n\ttablePermission dimתאריך = 'dimתאריך'[Year] = 2026\n")
        issues = self.run_val()
        self.assertFalse(any(i['code'] == 'M-09' for i in issues),
                         'תפקיד תקין סומן ב-M-09 (false positive)')

    def _write_visual_roles(self, vid, vtype, roles):
        qs = {role: {"projections": [
            {"field": {kind: {"Expression": {"SourceRef": {"Entity": ent}}, "Property": prop}},
             "queryRef": "%s.%s" % (ent, prop)}
            for kind, ent, prop in flds]} for role, flds in roles.items()}
        vj = os.path.join(self.rp, 'definition', 'pages', 'page001', 'visuals', vid, 'visual.json')
        w(vj, json.dumps({"name": vid,
                          "position": {"x": 0, "y": 0, "z": 1, "width": 4, "height": 3},
                          "visual": {"visualType": vtype, "query": {"queryState": qs}}},
                         ensure_ascii=False))

    def test_card_with_legacy_fields_role_is_error(self):
        # המלכודת המתועדת של MS: cardVisual עם "Fields" מרונדר ריק
        self._write_visual_roles('vr1', 'cardVisual',
                                 {'Fields': [('Measure', 'factמכירות', 'כמות שנתית')]})
        issues = self.run_val()
        r26 = [i for i in issues if i['code'] == 'R-26']
        self.assertTrue(any(i['level'] == 'err' and 'Data' in i['title'] for i in r26),
                        'role חובה Data חסר לא נתפס')
        self.assertTrue(any(i['level'] == 'warn' and 'Fields' in i['title'] for i in r26),
                        "role מושגה בשם שגוי ('Fields') לא סומן")

    def test_bar_chart_measure_only_warns_but_not_error(self):
        self._write_visual_roles('vr2', 'clusteredBarChart',
                                 {'Y': [('Measure', 'factמכירות', 'כמות שנתית')]})
        issues = [i for i in self.run_val() if i['code'] == 'R-26' and 'vr2' in i['location']]
        self.assertTrue(any(i['level'] == 'warn' and 'Category' in i['title'] for i in issues))
        self.assertFalse(any(i['level'] == 'err' for i in issues),
                         'ציר חסר סומן כ-err (חוקי ב-Desktop)')

    def test_wellformed_roles_no_r26(self):
        self._write_visual_roles('vr3', 'lineChart',
                                 {'Category': [('Column', 'dimתאריך', 'Date')],
                                  'Y': [('Measure', 'factמכירות', 'כמות שנתית')],
                                  'Tooltips': [('Measure', 'factמכירות', 'כמות שנתית')]})
        issues = [i for i in self.run_val() if i['code'] == 'R-26' and 'vr3' in i['location']]
        self.assertFalse(issues, 'ויזואל תקין (כולל Tooltips) סומן ב-R-26 (FP)')

    def test_projections_outside_querystate_is_error(self):
        # שגיאת שיכון: role ברמת query במקום בתוך queryState (MS authoring.md)
        vj = os.path.join(self.rp, 'definition', 'pages', 'page001', 'visuals', 'vr4', 'visual.json')
        w(vj, json.dumps({"name": "vr4",
                          "position": {"x": 0, "y": 0, "z": 1, "width": 4, "height": 3},
                          "visual": {"visualType": "cardVisual", "query": {
                              "Data": {"projections": [
                                  {"field": {"Measure": {"Expression": {"SourceRef": {"Entity": "factמכירות"}},
                                                          "Property": "כמות שנתית"}},
                                   "queryRef": "factמכירות.כמות שנתית"}]}}}},
                         ensure_ascii=False))
        issues = self.run_val()
        self.assertTrue(any(i['code'] == 'R-27' and i['level'] == 'err' for i in issues),
                        'projections מחוץ ל-queryState לא נתפסו')

    def test_slicer_tooltips_without_show_warned(self):
        vj = os.path.join(self.rp, 'definition', 'pages', 'page001', 'visuals', 'vr5', 'visual.json')
        w(vj, json.dumps({"name": "vr5",
                          "position": {"x": 0, "y": 0, "z": 1, "width": 4, "height": 3},
                          "visual": {"visualType": "slicer", "query": {"queryState": {
                              "Values": {"projections": [
                                  {"field": {"Column": {"Expression": {"SourceRef": {"Entity": "dimתאריך"}},
                                                         "Property": "Year"}},
                                   "queryRef": "dimתאריך.Year"}]},
                              "Tooltips": {"projections": [
                                  {"field": {"Measure": {"Expression": {"SourceRef": {"Entity": "factמכירות"}},
                                                          "Property": "כמות שנתית"}},
                                   "queryRef": "factמכירות.כמות שנתית"}]}}}}},
                         ensure_ascii=False))
        issues = self.run_val()
        self.assertTrue(any(i['code'] == 'R-28' and i['level'] == 'warn' for i in issues),
                        'slicer עם Tooltips בלי show=true לא סומן')

    def test_slicer_tooltips_with_show_clean(self):
        vj = os.path.join(self.rp, 'definition', 'pages', 'page001', 'visuals', 'vr6', 'visual.json')
        w(vj, json.dumps({"name": "vr6",
                          "position": {"x": 0, "y": 0, "z": 1, "width": 4, "height": 3},
                          "visual": {"visualType": "slicer",
                                     "visualContainerObjects": {"visualTooltip": [
                                         {"properties": {"show": {"expr": {"Literal": {"Value": "'true'"}}}}}]},
                                     "query": {"queryState": {
                                         "Values": {"projections": [
                                             {"field": {"Column": {"Expression": {"SourceRef": {"Entity": "dimתאריך"}},
                                                                    "Property": "Year"}},
                                              "queryRef": "dimתאריך.Year"}]},
                                         "Tooltips": {"projections": [
                                             {"field": {"Measure": {"Expression": {"SourceRef": {"Entity": "factמכירות"}},
                                                                     "Property": "כמות שנתית"}},
                                              "queryRef": "factמכירות.כמות שנתית"}]}}}}},
                         ensure_ascii=False))
        issues = [i for i in self.run_val() if i['code'] == 'R-28' and 'vr6' in i['location']]
        self.assertFalse(issues, 'slicer עם show=true סומן ב-R-28 (FP)')

    def _write_visual_filter(self, vid, filt):
        vj = os.path.join(self.rp, 'definition', 'pages', 'page001', 'visuals', vid, 'visual.json')
        w(vj, json.dumps({"name": vid,
                          "position": {"x": 0, "y": 0, "z": 1, "width": 4, "height": 3},
                          "visual": {"visualType": "cardVisual",
                                     "query": {"queryState": {"Data": {"projections": [
                                         {"field": {"Measure": {"Expression": {"SourceRef": {"Entity": "factמכירות"}},
                                                                 "Property": "כמות שנתית"}},
                                          "queryRef": "factמכירות.כמות שנתית"}]}}}},
                          "filterConfig": {"filters": [filt]}}, ensure_ascii=False))

    def test_topn_orderby_without_aggregation_is_error(self):
        self._write_visual_filter('vf1', {
            "name": "f1", "type": "TopN", "howCreated": "User",
            "field": {"Column": {"Expression": {"SourceRef": {"Entity": "dimתאריך"}}, "Property": "Year"}},
            "filter": {"Version": 2, "From": [], "Where": [],
                       "OrderBy": [{"Direction": 2, "Expression": {
                           "Column": {"Expression": {"SourceRef": {"Entity": "factמכירות"}},
                                      "Property": "כמות"}}}]}})
        issues = self.run_val()
        self.assertTrue(any(i['code'] == 'R-30' and i['level'] == 'err' for i in issues),
                        'TopN OrderBy בלי Aggregation לא נתפס')

    def test_topn_at_report_level_is_error(self):
        rj = os.path.join(self.rp, 'definition', 'report.json')
        d = json.load(open(rj, encoding='utf-8-sig'))
        d['filterConfig'] = {"filters": [{
            "name": "f1", "type": "TopN", "howCreated": "User",
            "field": {"Column": {"Expression": {"SourceRef": {"Entity": "dimתאריך"}}, "Property": "Year"}},
            "filter": {"Version": 2, "From": [], "Where": []}}]}
        json.dump(d, open(rj, 'w', encoding='utf-8'), ensure_ascii=False)
        issues = self.run_val()
        self.assertTrue(any(i['code'] == 'R-30' and 'ויזואל בלבד' in i['detail'] for i in issues),
                        'TopN ברמת דוח לא נתפס')

    def test_filter_without_howcreated_warned(self):
        self._write_visual_filter('vf2', {
            "name": "f2", "type": "Categorical",
            "field": {"Column": {"Expression": {"SourceRef": {"Entity": "dimתאריך"}}, "Property": "Year"}},
            "filter": {"Version": 2, "From": [], "Where": []}})
        issues = self.run_val()
        self.assertTrue(any(i['code'] == 'R-31' and i['level'] == 'warn' for i in issues),
                        'מסנן בלי howCreated לא סומן')

    def test_where_entity_instead_of_source_warned(self):
        self._write_visual_filter('vf3', {
            "name": "f3", "type": "Categorical", "howCreated": "User",
            "field": {"Column": {"Expression": {"SourceRef": {"Entity": "dimתאריך"}}, "Property": "Year"}},
            "filter": {"Version": 2,
                       "From": [{"Name": "d", "Entity": "dimתאריך", "Type": 0}],
                       "Where": [{"Condition": {"In": {"Expressions": [
                           {"Column": {"Expression": {"SourceRef": {"Entity": "dimתאריך"}},
                                       "Property": "Year"}}], "Values": []}}}]}})
        issues = self.run_val()
        self.assertTrue(any(i['code'] == 'R-32' and i['level'] == 'warn' for i in issues),
                        'Entity בתוך Where לא סומן')

    def test_gradient3_without_mid_is_error(self):
        vj = os.path.join(self.rp, 'definition', 'pages', 'page001', 'visuals', 'vg1', 'visual.json')
        w(vj, json.dumps({"name": "vg1",
                          "position": {"x": 0, "y": 0, "z": 1, "width": 4, "height": 3},
                          "visual": {"visualType": "tableEx",
                                     "query": {"queryState": {"Values": {"projections": [
                                         {"field": {"Measure": {"Expression": {"SourceRef": {"Entity": "factמכירות"}},
                                                                 "Property": "כמות שנתית"}},
                                          "queryRef": "factמכירות.כמות שנתית"}]}}},
                                     "objects": {"values": [{"properties": {
                                         "backColor": {"solid": {"color": {"expr": {"FillRule": {
                                             "linearGradient3": {"min": {"color": "#fff"},
                                                                 "max": {"color": "#000"}}}}}}}}}]}}},
                         ensure_ascii=False))
        issues = self.run_val()
        self.assertTrue(any(i['code'] == 'R-29' and i['level'] == 'err' for i in issues),
                        'linearGradient3 בלי mid לא נתפס')

    def _write_cf_visual(self, vid, vtype, objects_entry):
        vj = os.path.join(self.rp, 'definition', 'pages', 'page001', 'visuals', vid, 'visual.json')
        w(vj, json.dumps({"name": vid,
                          "position": {"x": 0, "y": 0, "z": 1, "width": 4, "height": 3},
                          "visual": {"visualType": vtype,
                                     "query": {"queryState": {"Values": {"projections": [
                                         {"field": {"Measure": {"Expression": {"SourceRef": {"Entity": "factמכירות"}},
                                                                 "Property": "כמות שנתית"}},
                                          "queryRef": "factמכירות.כמות שנתית"}]}}},
                                     "objects": {"values": [objects_entry]}}},
                         ensure_ascii=False))

    def _cf_color(self):
        return {"solid": {"color": {"expr": {"Conditional": {"Cases": [
            {"Condition": {"Comparison": {"ComparisonKind": 0}},
             "Value": {"Literal": {"Value": "'#FF0000'"}}}]}}}}}

    def test_table_cf_without_selector_warned(self):
        self._write_cf_visual('cf1', 'tableEx', {"properties": {"backColor": self._cf_color()}})
        issues = self.run_val()
        self.assertTrue(any(i['code'] == 'R-33' and i['level'] == 'warn' for i in issues),
                        'CF בטבלה בלי selector מלא לא נתפס')

    def test_chart_cf_with_metadata_warned(self):
        self._write_cf_visual('cf2', 'clusteredColumnChart', {
            "selector": {"data": [{"dataViewWildcard": {"matchingOption": 1}}],
                         "metadata": "factמכירות.כמות שנתית"},
            "properties": {"backColor": self._cf_color()}})
        issues = self.run_val()
        self.assertTrue(any(i['code'] == 'R-33' and 'metadata' in i['title'] for i in issues),
                        'CF בתרשים עם metadata לא נתפס')

    def test_table_cf_full_selector_clean(self):
        self._write_cf_visual('cf3', 'tableEx', {
            "selector": {"data": [{"dataViewWildcard": {"matchingOption": 1}}],
                         "metadata": "factמכירות.כמות שנתית"},
            "properties": {"backColor": self._cf_color()}})
        issues = [i for i in self.run_val() if i['code'] == 'R-33' and 'cf3' in i['location']]
        self.assertFalse(issues, 'CF תקין בטבלה סומן (FP)')

    def test_invalid_icon_name_is_error(self):
        icon = {"kind": "Icon", "expr": {"Conditional": {"Cases": [
            {"Condition": {"Comparison": {"ComparisonKind": 0}},
             "Value": {"Literal": {"Value": "'CircleBogus'"}}}]}}}
        self._write_cf_visual('cf4', 'tableEx', {
            "selector": {"data": [{"dataViewWildcard": {"matchingOption": 1}}],
                         "metadata": "factמכירות.כמות שנתית"},
            "properties": {"icon": icon}})
        issues = self.run_val()
        self.assertTrue(any(i['code'] == 'R-34' and i['level'] == 'err' for i in issues),
                        'אייקון לא חוקי לא נתפס')

    def test_valid_icon_name_clean(self):
        icon = {"kind": "Icon", "expr": {"Conditional": {"Cases": [
            {"Condition": {"Comparison": {"ComparisonKind": 0}},
             "Value": {"Literal": {"Value": "'CircleHigh'"}}}]}}}
        self._write_cf_visual('cf5', 'tableEx', {
            "selector": {"data": [{"dataViewWildcard": {"matchingOption": 1}}],
                         "metadata": "factמכירות.כמות שנתית"},
            "properties": {"icon": icon}})
        issues = [i for i in self.run_val() if i['code'] in ('R-33', 'R-34') and 'cf5' in i['location']]
        self.assertFalse(issues, 'אייקון חוקי סומן (FP)')

    def test_hallucinated_rule_property_warned(self):
        self._write_cf_visual('cf6', 'tableEx', {
            "selector": {"data": [{"dataViewWildcard": {"matchingOption": 1}}],
                         "metadata": "factמכירות.כמות שנתית"},
            "properties": {"backColorRule": {"x": 1}}})
        issues = self.run_val()
        self.assertTrue(any(i['code'] == 'R-35' and 'backColorRule' in i['title'] for i in issues),
                        'מאפיין מומצא לא נתפס')

    def _set_page_objects(self, objects):
        pj = os.path.join(self.rp, 'definition', 'pages', 'page001', 'page.json')
        d = json.load(open(pj, encoding='utf-8-sig'))
        d['objects'] = objects
        w(pj, json.dumps(d, ensure_ascii=False))

    def _plot_area_image(self, image_prop):
        self._write_cf_visual('img1', 'clusteredColumnChart', {"plotArea": 1})  # placeholder replaced below
        vj = os.path.join(self.rp, 'definition', 'pages', 'page001', 'visuals', 'img1', 'visual.json')
        d = json.load(open(vj, encoding='utf-8-sig'))
        d['visual']['objects'] = {"plotArea": [{"properties": {"image": image_prop}}]}
        w(vj, json.dumps(d, ensure_ascii=False))

    def test_page_background_show_rejected(self):
        self._set_page_objects({"background": [{"properties": {
            "color": {"solid": {"color": {"expr": {"Literal": {"Value": "'#FFFFFF'"}}}}},
            "show": {"expr": {"Literal": {"Value": "true"}}}}}]})
        issues = self.run_val()
        self.assertTrue(any(i['code'] == 'R-36' and i['level'] == 'err' for i in issues),
                        'show ברקע דף לא נתפס')

    def test_flat_image_structure_warned(self):
        self._plot_area_image({"name": {"expr": {"Literal": {"Value": "'bg.png'"}}},
                               "url": {"expr": {"Literal": {"Value": "'x'"}}},
                               "scaling": {"expr": {"Literal": {"Value": "'Fit'"}}}})
        issues = self.run_val()
        self.assertTrue(any(i['code'] == 'R-37' and i['level'] == 'warn' for i in issues),
                        'מבנה image שטוח לא נתפס')

    def test_nested_image_valid_scaling_clean(self):
        self._plot_area_image({"image": {
            "name": {"expr": {"Literal": {"Value": "'bg.png'"}}},
            "url": {"expr": {"ResourcePackageItem": {"PackageName": "RegisteredResources",
                                                     "PackageType": 1, "ItemName": "bg.png"}}},
            "scaling": {"expr": {"Literal": {"Value": "'Fit'"}}}}})
        issues = [i for i in self.run_val() if i['code'] in ('R-37', 'R-38') and 'img1' in i['location']]
        self.assertFalse(issues, 'מבנה image תקין סומן (FP)')

    def test_invalid_scaling_is_error(self):
        self._plot_area_image({"image": {
            "name": {"expr": {"Literal": {"Value": "'bg.png'"}}},
            "scaling": {"expr": {"Literal": {"Value": "'Squish'"}}}}})
        issues = self.run_val()
        self.assertTrue(any(i['code'] == 'R-38' and i['level'] == 'err' for i in issues),
                        'scaling לא חוקי לא נתפס')

    def test_filter_card_lowercase_id_warned(self):
        self._set_page_objects({"filterCard": [
            {"properties": {"textSize": {"expr": {"Literal": {"Value": "9D"}}}},
             "selector": {"id": "applied"}}]})
        issues = self.run_val()
        self.assertTrue(any(i['code'] == 'R-39' and i['level'] == 'warn' for i in issues),
                        'filterCard id לא-PascalCase לא נתפס')

    def test_filter_card_valid_states_clean(self):
        self._set_page_objects({"filterCard": [
            {"properties": {}, "selector": {"id": "Applied"}},
            {"properties": {}, "selector": {"id": "Available"}}]})
        issues = [i for i in self.run_val() if i['code'] == 'R-39']
        self.assertFalse(issues, 'filterCard תקין סומן (FP)')

    def _write_scopeid_visual(self, vid, kind):
        self._write_cf_visual(vid, 'barChart', {"x": 1})
        vj = os.path.join(self.rp, 'definition', 'pages', 'page001', 'visuals', vid, 'visual.json')
        d = json.load(open(vj, encoding='utf-8-sig'))
        comparison = {
            "ComparisonKind": kind,
            "Left": {"Column": {"Expression": {"SourceRef": {"Entity": "factמכירות"}},
                                "Property": "כמות שנתית"}},
            "Right": {"Literal": {"Value": "'X'"}},
        }
        entry = {
            "properties": {"fill": {"solid": {"color": {"expr": {"Literal": {"Value": "'#E66C37'"}}}}}},
            "selector": {"data": [{"scopeId": {"Comparison": comparison}}]},
        }
        d['visual']['objects'] = {"dataPoint": [entry]}
        w(vj, json.dumps(d, ensure_ascii=False))

    def test_scopeid_kind_1_to_4_warned(self):
        self._write_scopeid_visual('sc1', 2)
        issues = self.run_val()
        self.assertTrue(any(i['code'] == 'R-40' and i['level'] == 'warn' for i in issues),
                        'ComparisonKind 1-4 לא סומן')

    def test_scopeid_kind_5plus_is_error(self):
        self._write_scopeid_visual('sc2', 6)
        issues = self.run_val()
        self.assertTrue(any(i['code'] == 'R-40' and i['level'] == 'err' for i in issues),
                        'ComparisonKind >=5 לא נתפס כשגיאה')

    def test_scopeid_kind_0_clean(self):
        self._write_scopeid_visual('sc3', 0)
        issues = [i for i in self.run_val() if i['code'] == 'R-40' and 'sc3' in i['location']]
        self.assertFalse(issues, 'ComparisonKind=0 סומן (FP)')

    def test_selector_on_legend_warned(self):
        self._write_cf_visual('lg1', 'barChart', {"x": 1})
        vj = os.path.join(self.rp, 'definition', 'pages', 'page001', 'visuals', 'lg1', 'visual.json')
        d = json.load(open(vj, encoding='utf-8-sig'))
        d['visual']['objects'] = {"legend": [{"properties": {"show": {"expr": {"Literal": {"Value": "true"}}}},
                                              "selector": {"id": "default"}}]}
        w(vj, json.dumps(d, ensure_ascii=False))
        issues = self.run_val()
        self.assertTrue(any(i['code'] == 'R-41' and i['level'] == 'warn' for i in issues),
                        'selector על legend לא נתפס')

    def _write_table_visual(self, vid, vtype, objects, style_preset='ABSENT'):
        vj = os.path.join(self.rp, 'definition', 'pages', 'page001', 'visuals', vid, 'visual.json')
        vis = {"visualType": vtype,
               "query": {"queryState": {"Values": {"projections": [
                   {"field": {"Measure": {"Expression": {"SourceRef": {"Entity": "factמכירות"}},
                                             "Property": "כמות שנתית"}},
                    "queryRef": "factמכירות.כמות שנתית"}]}}},
               "objects": objects}
        if style_preset != 'ABSENT':
            vis["visualContainerObjects"] = {"stylePreset": [{"properties": {
                "name": {"expr": {"Literal": {"Value": "'%s'" % style_preset}}}}}]}
        w(vj, json.dumps({"name": vid,
                          "position": {"x": 0, "y": 0, "z": 1, "width": 4, "height": 3},
                          "visual": vis}, ensure_ascii=False))

    def test_table_custom_colors_without_preset_none_warned(self):
        self._write_table_visual('tc1', 'tableEx', {"values": [{"properties": {
            "backColorPrimary": {"solid": {"color": {"expr": {"Literal": {"Value": "'#FFFFFF'"}}}}}}}]})
        issues = self.run_val()
        self.assertTrue(any(i['code'] == 'R-42' and 'stylePreset' in i['title'] for i in issues),
                        'צבעים מותאמים בלי stylePreset=None לא נתפסו')

    def test_table_custom_colors_with_preset_none_clean(self):
        self._write_table_visual('tc2', 'tableEx', {"values": [{"properties": {
            "backColorPrimary": {"solid": {"color": {"expr": {"Literal": {"Value": "'#FFFFFF'"}}}}}}}]},
            style_preset='None')
        issues = [i for i in self.run_val() if i['code'] == 'R-42' and 'tc2' in i['location']]
        self.assertFalse(issues, "stylePreset='None' תקין סומן (FP)")

    def test_unknown_style_preset_warned(self):
        self._write_table_visual('tc3', 'tableEx', {}, style_preset='FancyRainbow')
        issues = self.run_val()
        self.assertTrue(any(i['code'] == 'R-42' and 'FancyRainbow' in i['title'] for i in issues),
                        'stylePreset לא מוכר לא נתפס')

    def test_tableex_only_preset_on_pivottable_warned(self):
        self._write_table_visual('tc4', 'pivotTable', {}, style_preset='Default')
        issues = self.run_val()
        self.assertTrue(any(i['code'] == 'R-42' and 'tableEx' in i['title'] for i in issues),
                        'preset של tableEx על pivotTable לא נתפס')

    def _register_image(self, name, item_type='Image', write_file=True):
        rj = os.path.join(self.rp, 'definition', 'report.json')
        d = json.load(open(rj, encoding='utf-8-sig'))
        d['resourcePackages'] = [{"name": "RegisteredResources", "type": "RegisteredResources",
                                  "items": [{"name": name, "path": name, "type": item_type}]}]
        w(rj, json.dumps(d, ensure_ascii=False))
        if write_file:
            sr = os.path.join(self.rp, 'StaticResources', 'RegisteredResources')
            os.makedirs(sr, exist_ok=True)
            w(os.path.join(sr, name), 'PNG')

    def _write_image_visual(self, vid, item_name):
        vj = os.path.join(self.rp, 'definition', 'pages', 'page001', 'visuals', vid, 'visual.json')
        rpi = {"PackageName": "RegisteredResources", "PackageType": 1, "ItemName": item_name}
        inner = {
            "name": {"expr": {"Literal": {"Value": "'img.png'"}}},
            "url": {"expr": {"ResourcePackageItem": rpi}},
            "scaling": {"expr": {"Literal": {"Value": "'Fit'"}}},
        }
        objects = {"image": [{"properties": {"image": {"image": inner}}}]}
        visual = {"visualType": "image", "objects": objects}
        doc = {"name": vid,
               "position": {"x": 0, "y": 0, "z": 1, "width": 4, "height": 3},
               "visual": visual}
        w(vj, json.dumps(doc, ensure_ascii=False))

    def test_unregistered_image_is_error(self):
        self._write_image_visual('im1', 'ghost123.png')
        issues = self.run_val()
        self.assertTrue(any(i['code'] == 'R-43' and i['level'] == 'err' and 'ghost123.png' in i['title']
                            for i in issues), 'הפניה לתמונה לא רשומה לא נתפסה')

    def test_registered_image_clean(self):
        self._register_image('img17123456789012345.png')
        self._write_image_visual('im2', 'img17123456789012345.png')
        issues = [i for i in self.run_val() if i['code'] in ('R-43', 'R-37', 'R-38') and 'im2' in i['location']]
        self.assertFalse(issues, 'תמונה רשומה תקינה סומנה (FP): %s' % issues)

    def test_wrong_item_type_is_error(self):
        self._register_image('img2.png', item_type='ResourceItem')
        self._write_image_visual('im3', 'img2.png')
        issues = self.run_val()
        self.assertTrue(any(i['code'] == 'R-43' and 'ResourceItem' in i['title'] for i in issues),
                        "type!='Image' לא נתפס")

    def test_registered_but_file_missing_is_error(self):
        self._register_image('img3.png', write_file=False)
        self._write_image_visual('im4', 'img3.png')
        issues = self.run_val()
        self.assertTrue(any(i['code'] == 'R-43' and 'חסר' in i['title'] for i in issues),
                        'קובץ חסר ב-StaticResources לא נתפס')

    def _write_slicer(self, vid, vtype, ent, prop, mode='ABSENT', kind='Column'):
        field = {kind: {"Expression": {"SourceRef": {"Entity": ent}}, "Property": prop}}
        objects = {}
        if mode != 'ABSENT':
            objects = {"data": [{"properties": {"mode": {"expr": {"Literal": {"Value": "'%s'" % mode}}}}}]}
        vj = os.path.join(self.rp, 'definition', 'pages', 'page001', 'visuals', vid, 'visual.json')
        w(vj, json.dumps({"name": vid,
                          "position": {"x": 0, "y": 0, "z": 1, "width": 4, "height": 3},
                          "visual": {"visualType": vtype,
                                     "query": {"queryState": {"Values": {"projections": [
                                         {"field": field, "queryRef": "%s.%s" % (ent, prop)}]}}},
                                     "objects": objects}}, ensure_ascii=False))

    def _set_col_type(self, table_file, col, dtype):
        tf = os.path.join(self.sm, 'definition', 'tables', table_file)
        txt = open(tf, encoding='utf-8-sig').read()
        txt = txt.replace('\tcolumn %s\n' % col,
                          '\tcolumn %s\n\t\tdataType: %s\n' % (col, dtype), 1)
        w(tf, txt)

    def test_slicer_unknown_mode_warned(self):
        self._write_slicer('sl1', 'slicer', 'dimמוצרים', 'שם מוצר', mode='Wobbly')
        issues = self.run_val()
        self.assertTrue(any(i['code'] == 'R-44' and 'Wobbly' in i['title'] for i in issues),
                        'data.mode לא מוכר לא נתפס')

    def test_slicer_valid_mode_clean(self):
        self._write_slicer('sl2', 'slicer', 'dimמוצרים', 'שם מוצר', mode='Dropdown')
        issues = [i for i in self.run_val() if i['code'] == 'R-44' and 'sl2' in i['location']]
        self.assertFalse(issues, 'data.mode חוקי סומן (FP)')

    def test_relative_datepicker_accepted(self):
        # סבב 75: 'RelativeDatePicker' אומת כערך ש-Desktop כותב בייצוא אמיתי (advw בקורפוס)
        self._write_slicer('sl2b', 'slicer', 'dimמוצרים', 'שם מוצר', mode='RelativeDatePicker')
        issues = [i for i in self.run_val() if i['code'] == 'R-44' and 'sl2b' in i['location']]
        self.assertFalse(issues, "RelativeDatePicker סומן כלא-חוקי (FP מול ייצוא אמיתי)")

    def test_r68_short_inline_slicer_flagged(self):
        # סבב 76: סלייסר inline אנכי ב-h<48 — כל שורה נקצצת (קורפוס: insurance h=38)
        self._write_slicer('slh1', 'slicer', 'dimמוצרים', 'שם מוצר')
        import json as _json, os as _os
        vj = _os.path.join(self.rp, 'definition', 'pages', 'page001', 'visuals', 'slh1', 'visual.json')
        d = _json.load(open(vj, encoding='utf-8-sig'))
        d['position']['height'] = 38
        w(vj, _json.dumps(d, ensure_ascii=False))
        issues = self.run_val()
        self.assertTrue(any(i['code'] == 'R-68' and 'slh1' in i['location'] for i in issues),
                        'סלייסר inline ב-h=38 לא נתפס')

    def test_r68_tall_inline_slicer_clean(self):
        self._write_slicer('slh2', 'slicer', 'dimמוצרים', 'שם מוצר')  # fixture height=3
        import json as _json, os as _os
        vj = _os.path.join(self.rp, 'definition', 'pages', 'page001', 'visuals', 'slh2', 'visual.json')
        d = _json.load(open(vj, encoding='utf-8-sig'))
        d['position']['height'] = 200
        w(vj, _json.dumps(d, ensure_ascii=False))
        issues = [i for i in self.run_val() if i['code'] == 'R-68']
        self.assertFalse(issues, 'סלייסר inline בגובה תקין סומן (FP)')

    def test_r68_dropdown_and_orientation_exempt(self):
        import json as _json, os as _os
        # Dropdown ב-h=44 (metro בקורפוס) — פטור (פופ-אפ, לא inline)
        self._write_slicer('slh3', 'slicer', 'dimמוצרים', 'שם מוצר', mode='Dropdown')
        vj = _os.path.join(self.rp, 'definition', 'pages', 'page001', 'visuals', 'slh3', 'visual.json')
        d = _json.load(open(vj, encoding='utf-8-sig'))
        d['position']['height'] = 38
        w(vj, _json.dumps(d, ensure_ascii=False))
        # orientation קיים (אופקי) — פטור
        self._write_slicer('slh4', 'slicer', 'dimמוצרים', 'שם מוצר')
        vj2 = _os.path.join(self.rp, 'definition', 'pages', 'page001', 'visuals', 'slh4', 'visual.json')
        d2 = _json.load(open(vj2, encoding='utf-8-sig'))
        d2['position']['height'] = 38
        d2['visual']['objects']['general'] = [{"properties": {"orientation": {"expr": {"Literal": {"Value": "1D"}}}}}]
        w(vj2, _json.dumps(d2, ensure_ascii=False))
        issues = [i for i in self.run_val() if i['code'] == 'R-68']
        self.assertFalse(issues, 'Dropdown/orientation סומנו ב-R-68 (FP)')

    def test_mode_on_listslicer_warned(self):
        self._write_slicer('sl3', 'listSlicer', 'dimמוצרים', 'שם מוצר', mode='Basic')
        issues = self.run_val()
        self.assertTrue(any(i['code'] == 'R-44' and 'listSlicer' in i['title'] for i in issues),
                        'data.mode על listSlicer לא נתפס')

    def test_between_on_string_column_warned(self):
        self._set_col_type('dimתאריך.tmdl', 'Year', 'string')
        self._write_slicer('sl4', 'slicer', 'dimתאריך', 'Year', mode='Between')
        issues = self.run_val()
        self.assertTrue(any(i['code'] == 'R-45' for i in issues),
                        'Between על עמודת טקסט לא נתפס')

    def test_between_on_date_column_clean(self):
        self._set_col_type('dimתאריך.tmdl', 'Date', 'dateTime')
        self._write_slicer('sl5', 'slicer', 'dimתאריך', 'Date', mode='Between')
        issues = [i for i in self.run_val() if i['code'] == 'R-45' and 'sl5' in i['location']]
        self.assertFalse(issues, 'Between על עמודת תאריך סומן (FP)')

    def test_hierarchy_slicer_wrong_mode_warned(self):
        vj = os.path.join(self.rp, 'definition', 'pages', 'page001', 'visuals', 'sl6', 'visual.json')
        w(vj, json.dumps({"name": "sl6",
                          "position": {"x": 0, "y": 0, "z": 1, "width": 4, "height": 3},
                          "visual": {"visualType": "slicer",
                                     "query": {"queryState": {"Values": {"projections": [
                                         {"field": {"HierarchyLevel": {
                                             "Expression": {"Hierarchy": {
                                                 "Expression": {"SourceRef": {"Entity": "dimתאריך"}},
                                                 "Hierarchy": "Drill"}},
                                             "Level": "Date"}},
                                          "queryRef": "dimתאריך.Drill.Date"}]}}},
                                     "objects": {"data": [{"properties": {
                                         "mode": {"expr": {"Literal": {"Value": "'Between'"}}}}}]}}},
                         ensure_ascii=False))
        issues = self.run_val()
        self.assertTrue(any(i['code'] == 'R-46' for i in issues),
                        'סליסר היררכיה במצב Between לא נתפס')

    def _write_report_filter(self, entity, prop):
        rj = os.path.join(self.rp, 'definition', 'report.json')
        d = json.load(open(rj, encoding='utf-8-sig'))
        d.setdefault('filterConfig', {})['filters'] = [{
            'name': 'f1', 'field': {'Column': {'Expression': {'SourceRef': {'Entity': entity}},
                                               'Property': prop}}, 'type': 'Categorical'}]
        w(rj, json.dumps(d, ensure_ascii=False))

    def test_report_filter_to_missing_table_is_error(self):
        self._write_report_filter('טבלאקיים', 'x')
        issues = self.run_val()
        self.assertTrue(any(i['code'] == 'R-22' and i['level'] == 'err' for i in issues),
                        'מסנן לטבלה חסרה לא נתפס')

    def test_report_filter_to_missing_column_warned(self):
        self._write_report_filter('dimתאריך', 'עמודהשאינה')
        issues = self.run_val()
        self.assertTrue(any(i['code'] == 'R-22' and i['level'] == 'warn' for i in issues),
                        'מסנן לעמודה חסרה לא נתפס')

    def test_bookmark_stale_state_warned(self):
        bm = os.path.join(self.rp, 'definition', 'bookmarks')
        w(os.path.join(bm, 'bookmarks.json'), json.dumps({'items': [{'name': 'b1'}]}))
        w(os.path.join(bm, 'b1.bookmark.json'), json.dumps({
            'name': 'b1',
            'explorationState': {'sections': {
                'page001': {'visualContainers': {'vis999': {}, 'vis001': {}}},
                'page999': {'visualContainers': {}},
            }}}))
        issues = self.run_val()
        r23 = [i for i in issues if i['code'] == 'R-23']
        self.assertTrue(any('vis999' in i['title'] for i in r23), 'מצב סימנייה לוויזואל מת לא נתפס')
        self.assertTrue(any('page999' in i['title'] for i in r23), 'מצב סימנייה לדף מת לא נתפס')
        # vis001 קיים — לא אמורה להיות עליו התרעה
        self.assertFalse(any('vis001' in i['title'] and 'vis999' not in i['title'] for i in r23))

    def test_tmdl_ref_to_missing_column_warned(self):
        w(os.path.join(self.sm, 'definition', 'tables', 'extra.tmdl'),
          "table extra\n\tmeasure m = SUM('dimתאריך'[עמודהשאינה])\n")
        issues = self.run_val()
        self.assertTrue(any(i['code'] == 'M-06' and 'עמודהשאינה' in i['title'] for i in issues),
                        'הפניה שבורה בביטוי TMDL לא נתפסה')


class CardVisualChecks(unittest.TestCase):
    """R-47/48 — cardVisual selector חובה + visualType מיושן (MS card.md)."""

    def setUp(self):
        self.td = tempfile.mkdtemp()
        self.proot = os.path.join(self.td, 'MiniReport')
        shutil.copytree(FIX, self.proot)
        self.rp = os.path.join(self.proot, 'MiniReport.Report')
        self.sm = os.path.join(self.proot, 'MiniReport.SemanticModel')

    def tearDown(self):
        shutil.rmtree(self.td, ignore_errors=True)

    def run_val(self):
        V._ISSUES.clear()
        mt = V.read_model_map(self.sm)
        V.validate_model(self.sm)
        V.validate_report(self.rp, mt)
        return V._ISSUES

    def _write_cardvisual_objects(self, vid, objects):
        vj = os.path.join(self.rp, 'definition', 'pages', 'page001', 'visuals', vid, 'visual.json')
        w(vj, json.dumps({"name": vid,
                          "position": {"x": 0, "y": 0, "z": 1, "width": 4, "height": 3},
                          "visual": {"visualType": "cardVisual",
                                     "query": {"queryState": {"Data": {"projections": [
                                         {"field": {"Measure": {"Expression": {"SourceRef": {"Entity": "factמכירות"}},
                                                                "Property": "כמות שנתית"}},
                                          "queryRef": "factמכירות.כמות שנתית"}]}}},
                                     "objects": objects}}, ensure_ascii=False))

    def _write_legacy_visual(self, vid, vtype):
        vj = os.path.join(self.rp, 'definition', 'pages', 'page001', 'visuals', vid, 'visual.json')
        w(vj, json.dumps({"name": vid,
                          "position": {"x": 0, "y": 0, "z": 1, "width": 4, "height": 3},
                          "visual": {"visualType": vtype,
                                     "query": {"queryState": {"Values": {"projections": [
                                         {"field": {"Measure": {"Expression": {"SourceRef": {"Entity": "factמכירות"}},
                                                                "Property": "כמות שנתית"}},
                                          "queryRef": "factמכירות.כמות שנתית"}]}}}}},
                         ensure_ascii=False))

    def test_cardvisual_object_without_selector_warned(self):
        self._write_cardvisual_objects('cv1', {"label": [{"properties": {}}]})
        issues = self.run_val()
        self.assertTrue(any(i['code'] == 'R-47' and 'label' in i['title'] for i in issues),
                        'אובייקט label בלי selector לא נתפס')

    def test_cardvisual_object_with_selector_clean(self):
        self._write_cardvisual_objects('cv2', {"label": [{"properties": {},
                                                          "selector": {"id": "default"}}]})
        issues = [i for i in self.run_val() if i['code'] == 'R-47' and 'cv2' in i['location']]
        self.assertFalse(issues, 'אובייקט עם selector סומן (FP)')

    def test_cardvisual_exempt_objects_clean(self):
        self._write_cardvisual_objects('cv3', {"cardCalloutArea": [{"properties": {}}],
                                               "referenceLabel": [{"properties": {}}],
                                               "referenceLabelLayout": [{"properties": {}}]})
        issues = [i for i in self.run_val() if i['code'] == 'R-47' and 'cv3' in i['location']]
        self.assertFalse(issues, 'אובייקטים פטורים סומנו (FP)')

    def test_legacy_card_warned(self):
        self._write_legacy_visual('cv4', 'card')
        issues = self.run_val()
        self.assertTrue(any(i['code'] == 'R-48' and 'cardVisual' in i['title'] for i in issues),
                        'card מיושן לא סומן')

    def test_legacy_multirowcard_warned(self):
        self._write_legacy_visual('cv5', 'multiRowCard')
        issues = self.run_val()
        self.assertTrue(any(i['code'] == 'R-48' and 'cv5' in i['location'] for i in issues),
                        'multiRowCard מיושן לא סומן')

    def test_cardvisual_not_flagged_deprecated(self):
        self._write_legacy_visual('cv6', 'cardVisual')
        issues = [i for i in self.run_val() if i['code'] == 'R-48' and 'cv6' in i['location']]
        self.assertFalse(issues, 'cardVisual סומן כמיושן (FP)')


class CartesianObjectChecks(unittest.TestCase):
    """R-49/50 — lineStyles/markers/seriesLabels/y2Axis מול סוג ויזואל + enum (MS cartesian.md)."""

    def setUp(self):
        self.td = tempfile.mkdtemp()
        self.proot = os.path.join(self.td, 'MiniReport')
        shutil.copytree(FIX, self.proot)
        self.rp = os.path.join(self.proot, 'MiniReport.Report')
        self.sm = os.path.join(self.proot, 'MiniReport.SemanticModel')

    def tearDown(self):
        shutil.rmtree(self.td, ignore_errors=True)

    def run_val(self):
        V._ISSUES.clear()
        mt = V.read_model_map(self.sm)
        V.validate_model(self.sm)
        V.validate_report(self.rp, mt)
        return V._ISSUES

    def _write_cart(self, vid, vtype, objects=None, y2=False):
        roles = {"Category": {"projections": [
                     {"field": {"Column": {"Expression": {"SourceRef": {"Entity": "dimתאריך"}},
                                           "Property": "Date"}},
                      "queryRef": "dimתאריך.Date"}]},
                 "Y": {"projections": [
                     {"field": {"Measure": {"Expression": {"SourceRef": {"Entity": "factמכירות"}},
                                            "Property": "כמות שנתית"}},
                      "queryRef": "factמכירות.כמות שנתית"}]}}
        if y2:
            roles["Y2"] = {"projections": [
                {"field": {"Measure": {"Expression": {"SourceRef": {"Entity": "factמכירות"}},
                                       "Property": "כמות שנתית"}},
                 "queryRef": "factמכירות.כמות שנתית 2"}]}
        vj = os.path.join(self.rp, 'definition', 'pages', 'page001', 'visuals', vid, 'visual.json')
        w(vj, json.dumps({"name": vid,
                          "position": {"x": 0, "y": 0, "z": 1, "width": 4, "height": 3},
                          "visual": {"visualType": vtype,
                                     "query": {"queryState": roles},
                                     "objects": objects or {}}}, ensure_ascii=False))

    @staticmethod
    def _ls(props):
        return {"lineStyles": [{"properties": {
            k: {"expr": {"Literal": {"Value": "'%s'" % v}}} for k, v in props.items()}}]}

    def test_linestyles_on_barchart_warned(self):
        self._write_cart('co1', 'clusteredBarChart', objects=self._ls({'lineStyle': 'dashed'}))
        self.assertTrue(any(i['code'] == 'R-49' and 'lineStyles' in i['title']
                            for i in self.run_val()), 'lineStyles על bar לא נתפס')

    def test_linestyles_on_linechart_clean(self):
        self._write_cart('co2', 'lineChart', objects=self._ls({'lineStyle': 'dashed'}))
        issues = [i for i in self.run_val() if i['code'] == 'R-49' and 'co2' in i['location']]
        self.assertFalse(issues, 'lineStyles על lineChart סומן (FP)')

    def test_markers_on_scatter_clean(self):
        self._write_cart('co3', 'scatterChart', objects={"markers": [{"properties": {}}]})
        issues = [i for i in self.run_val() if i['code'] == 'R-49' and 'co3' in i['location']]
        self.assertFalse(issues, 'markers על scatterChart סומן (FP)')

    def test_markers_on_barchart_warned(self):
        self._write_cart('co4', 'barChart', objects={"markers": [{"properties": {}}]})
        self.assertTrue(any(i['code'] == 'R-49' and 'markers' in i['title']
                            for i in self.run_val()), 'markers על barChart לא נתפס')

    def test_serieslabels_on_area_warned(self):
        self._write_cart('co5', 'areaChart', objects={"seriesLabels": [{"properties": {}}]})
        self.assertTrue(any(i['code'] == 'R-49' and 'seriesLabels' in i['title']
                            for i in self.run_val()), 'seriesLabels על areaChart לא נתפס')

    def test_y2axis_without_y2_role_warned(self):
        self._write_cart('co6', 'lineChart', objects={"y2Axis": [{"properties": {}}]})
        self.assertTrue(any(i['code'] == 'R-49' and 'y2Axis' in i['title']
                            for i in self.run_val()), 'y2Axis בלי role Y2 לא נתפס')

    def test_y2axis_with_y2_role_clean(self):
        self._write_cart('co7', 'lineChart', objects={"y2Axis": [{"properties": {}}]}, y2=True)
        issues = [i for i in self.run_val() if i['code'] == 'R-49' and 'co7' in i['location']]
        self.assertFalse(issues, 'y2Axis עם Y2 מאויש סומן (FP)')

    def test_bad_markershape_warned(self):
        self._write_cart('co8', 'lineChart', objects=self._ls({'markerShape': 'hexagon'}))
        self.assertTrue(any(i['code'] == 'R-50' and 'hexagon' in i['title']
                            for i in self.run_val()), 'markerShape לא חוקי לא נתפס')

    def test_valid_enums_clean(self):
        self._write_cart('co9', 'lineChart',
                         objects=self._ls({'markerShape': 'diamond', 'lineStyle': 'dotted',
                                           'lineChartType': 'smooth'}))
        issues = [i for i in self.run_val()
                  if i['code'] in ('R-49', 'R-50') and 'co9' in i['location']]
        self.assertFalse(issues, 'ערכי enum חוקיים סומנו (FP)')

    def test_bad_linecharttype_warned(self):
        self._write_cart('c10', 'lineChart', objects=self._ls({'lineChartType': 'curved'}))
        self.assertTrue(any(i['code'] == 'R-50' for i in self.run_val()),
                        'lineChartType לא חוקי לא נתפס')


class ThemeDataColorChecks(unittest.TestCase):
    """R-55 — ThemeDataColor ב-dataPoint.fill עם metadata selector (MS theming.md §8)."""

    def setUp(self):
        self.td = tempfile.mkdtemp()
        self.proot = os.path.join(self.td, 'MiniReport')
        shutil.copytree(FIX, self.proot)
        self.rp = os.path.join(self.proot, 'MiniReport.Report')
        self.sm = os.path.join(self.proot, 'MiniReport.SemanticModel')

    def tearDown(self):
        shutil.rmtree(self.td, ignore_errors=True)

    def run_val(self):
        V._ISSUES.clear()
        mt = V.read_model_map(self.sm)
        V.validate_model(self.sm)
        V.validate_report(self.rp, mt)
        return V._ISSUES

    def _write_dp(self, vid, dp_entry):
        roles = {"Category": {"projections": [
                     {"field": {"Column": {"Expression": {"SourceRef": {"Entity": "dimתאריך"}},
                                           "Property": "Date"}},
                      "queryRef": "dimתאריך.Date"}]},
                 "Y": {"projections": [
                     {"field": {"Measure": {"Expression": {"SourceRef": {"Entity": "factמכירות"}},
                                            "Property": "כמות שנתית"}},
                      "queryRef": "factמכירות.כמות שנתית"}]}}
        vj = os.path.join(self.rp, 'definition', 'pages', 'page001', 'visuals', vid, 'visual.json')
        w(vj, json.dumps({"name": vid,
                          "position": {"x": 0, "y": 0, "z": 1, "width": 4, "height": 3},
                          "visual": {"visualType": "columnChart",
                                     "query": {"queryState": roles},
                                     "objects": {"dataPoint": dp_entry if isinstance(dp_entry, list) else [dp_entry]}}}, ensure_ascii=False))

    def test_themedatacolor_with_metadata_warned(self):
        self._write_dp('td1', {"properties": {"fill": {"solid": {"color": {
                                   "expr": {"ThemeDataColor": {"ColorId": 0, "Percent": 0}}}}}},
                               "selector": {"metadata": "Sum(factמכירות.כמות שנתית)"}})
        self.assertTrue(any(i['code'] == 'R-55' for i in self.run_val()),
                        'ThemeDataColor עם metadata לא נתפס')

    def test_literal_hex_with_metadata_clean(self):
        self._write_dp('td2', {"properties": {"fill": {"solid": {"color": {
                                   "expr": {"Literal": {"Value": "'#FF6B35'"}}}}}},
                               "selector": {"metadata": "Sum(factמכירות.כמות שנתית)"}})
        issues = [i for i in self.run_val() if i['code'] == 'R-55' and 'td2' in i['location']]
        self.assertFalse(issues, 'hex ליטרלי עם metadata סומן (FP)')

    def test_themedatacolor_without_metadata_clean(self):
        self._write_dp('td3', {"properties": {"fill": {"solid": {"color": {
                                   "expr": {"ThemeDataColor": {"ColorId": 0, "Percent": 0}}}}}}})
        issues = [i for i in self.run_val() if i['code'] == 'R-55' and 'td3' in i['location']]
        self.assertFalse(issues, 'ThemeDataColor בלי metadata סומן (FP)')

    def test_multiple_series_aggregated_to_one_issue(self):
        dp = {"properties": {"fill": {"solid": {"color": {
                  "expr": {"ThemeDataColor": {"ColorId": 0, "Percent": 0}}}}}},
              "selector": {"metadata": "Sum(factמכירות.כמות שנתית)"}}
        self._write_dp('td4', [dp, dict(dp), dict(dp)])
        issues = [i for i in self.run_val() if i['code'] == 'R-55' and 'td4' in i['location']]
        self.assertEqual(len(issues), 1, 'R-55 לא אוגד לבעיה אחת לוויזואל')
        self.assertIn('3 סידרות', issues[0]['title'])


class StackedObjectChecks(unittest.TestCase):
    """R-52 — ribbonBands/totals רק ב-stacked; smallMultiplesLayout דורש Rows (MS cartesian.md)."""

    def setUp(self):
        self.td = tempfile.mkdtemp()
        self.proot = os.path.join(self.td, 'MiniReport')
        shutil.copytree(FIX, self.proot)
        self.rp = os.path.join(self.proot, 'MiniReport.Report')
        self.sm = os.path.join(self.proot, 'MiniReport.SemanticModel')

    def tearDown(self):
        shutil.rmtree(self.td, ignore_errors=True)

    def run_val(self):
        V._ISSUES.clear()
        mt = V.read_model_map(self.sm)
        V.validate_model(self.sm)
        V.validate_report(self.rp, mt)
        return V._ISSUES

    def _write_chart(self, vid, vtype, objects=None, rows=False):
        roles = {"Category": {"projections": [
                     {"field": {"Column": {"Expression": {"SourceRef": {"Entity": "dimתאריך"}},
                                           "Property": "Date"}},
                      "queryRef": "dimתאריך.Date"}]},
                 "Y": {"projections": [
                     {"field": {"Measure": {"Expression": {"SourceRef": {"Entity": "factמכירות"}},
                                            "Property": "כמות שנתית"}},
                      "queryRef": "factמכירות.כמות שנתית"}]}}
        if rows:
            roles["Rows"] = {"projections": [
                {"field": {"Column": {"Expression": {"SourceRef": {"Entity": "dimמוצרים"}},
                                      "Property": "שם מוצר"}},
                 "queryRef": "dimמוצרים.שם מוצר"}]}
        vj = os.path.join(self.rp, 'definition', 'pages', 'page001', 'visuals', vid, 'visual.json')
        w(vj, json.dumps({"name": vid,
                          "position": {"x": 0, "y": 0, "z": 1, "width": 4, "height": 3},
                          "visual": {"visualType": vtype,
                                     "query": {"queryState": roles},
                                     "objects": objects or {}}}, ensure_ascii=False))

    def test_ribbonbands_on_linechart_warned(self):
        self._write_chart('so1', 'lineChart', objects={"ribbonBands": [{"properties": {}}]})
        self.assertTrue(any(i['code'] == 'R-52' and 'ribbonBands' in i['title']
                            for i in self.run_val()), 'ribbonBands על lineChart לא נתפס')

    def test_totals_on_columnchart_clean(self):
        self._write_chart('so2', 'columnChart', objects={"totals": [{"properties": {}}]})
        issues = [i for i in self.run_val() if i['code'] == 'R-52' and 'so2' in i['location']]
        self.assertFalse(issues, 'totals על columnChart סומן (FP)')

    def test_totals_on_linechart_warned(self):
        self._write_chart('so3', 'lineChart', objects={"totals": [{"properties": {}}]})
        self.assertTrue(any(i['code'] == 'R-52' and 'so3' in i['location']
                            for i in self.run_val()), 'totals על lineChart לא נתפס')

    def test_totals_on_table_clean(self):
        # בטבלאות/matrices totals הוא אובייקט שורות-סכום לגיטימי — לא מסמנים
        self._write_chart('so6', 'tableEx', objects={"totals": [{"properties": {}}]})
        issues = [i for i in self.run_val() if i['code'] == 'R-52' and 'so6' in i['location']]
        self.assertFalse(issues, 'totals על tableEx סומן (FP)')

    def test_smallmultiples_without_rows_warned(self):
        self._write_chart('so4', 'columnChart',
                          objects={"smallMultiplesLayout": [{"properties": {}}]})
        self.assertTrue(any(i['code'] == 'R-52' and 'smallMultiplesLayout' in i['title']
                            for i in self.run_val()), 'smallMultiplesLayout בלי Rows לא נתפס')

    def test_smallmultiples_with_rows_clean(self):
        self._write_chart('so5', 'columnChart',
                          objects={"smallMultiplesLayout": [{"properties": {}}]}, rows=True)
        issues = [i for i in self.run_val() if i['code'] == 'R-52' and 'so5' in i['location']]
        self.assertFalse(issues, 'smallMultiplesLayout עם Rows סומן (FP)')


class AxisColorChecks(unittest.TestCase):
    """R-53/54 — defaultColor ב-clustered + logAxisScale (MS cartesian.md)."""

    def setUp(self):
        self.td = tempfile.mkdtemp()
        self.proot = os.path.join(self.td, 'MiniReport')
        shutil.copytree(FIX, self.proot)
        self.rp = os.path.join(self.proot, 'MiniReport.Report')
        self.sm = os.path.join(self.proot, 'MiniReport.SemanticModel')

    def tearDown(self):
        shutil.rmtree(self.td, ignore_errors=True)

    def run_val(self):
        V._ISSUES.clear()
        mt = V.read_model_map(self.sm)
        V.validate_model(self.sm)
        V.validate_report(self.rp, mt)
        return V._ISSUES

    def _write_chart(self, vid, vtype, objects):
        roles = {"Category": {"projections": [
                     {"field": {"Column": {"Expression": {"SourceRef": {"Entity": "dimתאריך"}},
                                           "Property": "Date"}},
                      "queryRef": "dimתאריך.Date"}]},
                 "Y": {"projections": [
                     {"field": {"Measure": {"Expression": {"SourceRef": {"Entity": "factמכירות"}},
                                            "Property": "כמות שנתית"}},
                      "queryRef": "factמכירות.כמות שנתית"}]}}
        vj = os.path.join(self.rp, 'definition', 'pages', 'page001', 'visuals', vid, 'visual.json')
        w(vj, json.dumps({"name": vid,
                          "position": {"x": 0, "y": 0, "z": 1, "width": 4, "height": 3},
                          "visual": {"visualType": vtype,
                                     "query": {"queryState": roles},
                                     "objects": objects}}, ensure_ascii=False))

    @staticmethod
    def _lit(v):
        return {"expr": {"Literal": {"Value": v}}}

    def test_defaultcolor_on_clustered_warned(self):
        self._write_chart('ax1', 'clusteredColumnChart',
                          {"dataPoint": [{"properties": {"defaultColor": self._lit("''")}}]})
        self.assertTrue(any(i['code'] == 'R-53' for i in self.run_val()),
                        'defaultColor על clustered לא נתפס')

    def test_defaultcolor_on_stacked_clean(self):
        self._write_chart('ax2', 'columnChart',
                          {"dataPoint": [{"properties": {"defaultColor": self._lit("''")}}]})
        issues = [i for i in self.run_val() if i['code'] == 'R-53' and 'ax2' in i['location']]
        self.assertFalse(issues, 'defaultColor על stacked סומן (FP)')

    def test_datapoint_fill_on_clustered_clean(self):
        self._write_chart('ax3', 'clusteredBarChart',
                          {"dataPoint": [{"properties": {"fill": self._lit("''")}}]})
        issues = [i for i in self.run_val() if i['code'] == 'R-53' and 'ax3' in i['location']]
        self.assertFalse(issues, 'fill עם selector סומן (FP)')

    def test_logaxis_warned(self):
        self._write_chart('ax4', 'lineChart',
                          {"valueAxis": [{"properties": {"logAxisScale": self._lit("true")}}]})
        self.assertTrue(any(i['code'] == 'R-54' for i in self.run_val()),
                        'logAxisScale לא סומן')

    def test_logaxis_false_clean(self):
        self._write_chart('ax5', 'lineChart',
                          {"valueAxis": [{"properties": {"logAxisScale": self._lit("false")}}]})
        issues = [i for i in self.run_val() if i['code'] == 'R-54' and 'ax5' in i['location']]
        self.assertFalse(issues, 'logAxisScale=false סומן (FP)')


class FilterPanePropChecks(unittest.TestCase):
    """R-56 — שמות מאפיינים ב-outspacePane/filterCard מול הרשימה הסגורה (MS filter-pane.md)."""

    def setUp(self):
        self.td = tempfile.mkdtemp()
        self.proot = os.path.join(self.td, 'MiniReport')
        shutil.copytree(FIX, self.proot)
        self.rp = os.path.join(self.proot, 'MiniReport.Report')
        self.sm = os.path.join(self.proot, 'MiniReport.SemanticModel')

    def tearDown(self):
        shutil.rmtree(self.td, ignore_errors=True)

    def run_val(self):
        V._ISSUES.clear()
        mt = V.read_model_map(self.sm)
        V.validate_model(self.sm)
        V.validate_report(self.rp, mt)
        return V._ISSUES

    def _set_page_objects(self, objects):
        pj = os.path.join(self.rp, 'definition', 'pages', 'page001', 'page.json')
        d = json.loads(open(pj, encoding='utf-8-sig').read())
        d['objects'] = objects
        w(pj, json.dumps(d, ensure_ascii=False))

    def test_unknown_outspaceprop_warned(self):
        self._set_page_objects({"outspacePane": [{"properties": {"fontSizeHuge": {"expr": {"Literal": {"Value": "30D"}}}}}]})
        self.assertTrue(any(i['code'] == 'R-56' and 'fontSizeHuge' in i['title']
                            for i in self.run_val()), 'מאפיין outspacePane לא מוכר לא נתפס')

    def test_known_outspaceprops_clean(self):
        self._set_page_objects({"outspacePane": [{"properties": {
            "width": {"expr": {"Literal": {"Value": "250D"}}},
            "backgroundColor": {"solid": {"color": {"expr": {"Literal": {"Value": "'#FFFFFF'"}}}}}}}]})
        issues = [i for i in self.run_val() if i['code'] == 'R-56']
        self.assertFalse(issues, 'מאפיינים חוקיים סומנו (FP)')

    def test_unknown_filtercardprop_warned(self):
        self._set_page_objects({"filterCard": [{"properties": {"shadowDepth": {"expr": {"Literal": {"Value": "3D"}}}},
                                                 "selector": {"id": "Applied"}}]})
        self.assertTrue(any(i['code'] == 'R-56' and 'shadowDepth' in i['title']
                            for i in self.run_val()), 'מאפיין filterCard לא מוכר לא נתפס')

    def test_known_filtercardprops_clean(self):
        self._set_page_objects({"filterCard": [{"properties": {
            "textSize": {"expr": {"Literal": {"Value": "9D"}}},
            "border": {"expr": {"Literal": {"Value": "true"}}}},
            "selector": {"id": "Available"}}]})
        issues = [i for i in self.run_val() if i['code'] == 'R-56']
        self.assertFalse(issues, 'מאפייני filterCard חוקיים סומנו (FP)')


class ExpansionStateChecks(unittest.TestCase):
    """R-57 — expansionStates מול היררכיה/queryRefs/roles (MS expressions.md)."""

    def setUp(self):
        self.td = tempfile.mkdtemp()
        self.proot = os.path.join(self.td, 'MiniReport')
        shutil.copytree(FIX, self.proot)
        self.rp = os.path.join(self.proot, 'MiniReport.Report')
        self.sm = os.path.join(self.proot, 'MiniReport.SemanticModel')

    def tearDown(self):
        shutil.rmtree(self.td, ignore_errors=True)

    def run_val(self):
        V._ISSUES.clear()
        mt = V.read_model_map(self.sm)
        V.validate_model(self.sm)
        V.validate_report(self.rp, mt)
        return V._ISSUES

    def _write_matrix(self, vid, expansion, hierarchy=True, qref='dimתאריך.Drill.Date',
                      role='Rows'):
        proj = {"queryRef": qref}
        if hierarchy:
            proj["field"] = {"HierarchyLevel": {
                "Expression": {"Hierarchy": {
                    "Expression": {"SourceRef": {"Entity": "dimתאריך"}},
                    "Hierarchy": "Drill"}},
                "Level": "Date"}}
        else:
            proj["field"] = {"Column": {"Expression": {"SourceRef": {"Entity": "dimתאריך"}},
                                        "Property": "Date"}}
        query = {"queryState": {role: {"projections": [proj]},
                                "Values": {"projections": [
                                    {"field": {"Measure": {"Expression": {"SourceRef": {"Entity": "factמכירות"}},
                                                           "Property": "כמות שנתית"}},
                                     "queryRef": "factמכירות.כמות שנתית"}]}}}
        if expansion is not None:
            query["expansionStates"] = expansion
        vj = os.path.join(self.rp, 'definition', 'pages', 'page001', 'visuals', vid, 'visual.json')
        w(vj, json.dumps({"name": vid,
                          "position": {"x": 0, "y": 0, "z": 1, "width": 4, "height": 3},
                          "visual": {"visualType": "pivotTable", "query": query}},
                         ensure_ascii=False))

    def test_expansion_without_hierarchy_warned(self):
        self._write_matrix('ex1', [{"roles": ["Rows"],
                                    "levels": [{"queryRefs": ["dimתאריך.Drill.Date"]}]}],
                           hierarchy=False)
        self.assertTrue(any(i['code'] == 'R-57' and 'היררכיה' in i['title']
                            for i in self.run_val()), 'expansionStates בלי היררכיה לא נתפס')

    def test_valid_expansion_clean(self):
        self._write_matrix('ex2', [{"roles": ["Rows"],
                                    "levels": [{"queryRefs": ["dimתאריך.Drill.Date"]}]}])
        issues = [i for i in self.run_val() if i['code'] == 'R-57' and 'ex2' in i['location']]
        self.assertFalse(issues, 'expansionStates תקין סומן (FP)')

    def test_dangling_queryref_warned(self):
        self._write_matrix('ex3', [{"roles": ["Rows"],
                                    "levels": [{"queryRefs": ["dimתאריך.Drill.Year"]}]}])
        self.assertTrue(any(i['code'] == 'R-57' and 'queryRefs' in i['title']
                            for i in self.run_val()), 'queryRef מת לא נתפס')

    def test_unknown_role_warned(self):
        self._write_matrix('ex4', [{"roles": ["Columns"],
                                    "levels": [{"queryRefs": ["dimתאריך.Drill.Date"]}]}])
        self.assertTrue(any(i['code'] == 'R-57' and 'Columns' in i['title']
                            for i in self.run_val()), 'role לא קיים לא נתפס')

    def test_no_expansion_clean(self):
        self._write_matrix('ex5', None)
        issues = [i for i in self.run_val() if i['code'] == 'R-57' and 'ex5' in i['location']]
        self.assertFalse(issues, 'וויזואל בלי expansionStates סומן (FP)')


class CalibrationFixes(unittest.TestCase):
    """R-59 — כיול על דוחות PBIP אמיתיים מהרשת (aurora/insurance/capital/svcops)."""

    def setUp(self):
        self.td = tempfile.mkdtemp()
        self.proot = os.path.join(self.td, 'MiniReport')
        shutil.copytree(FIX, self.proot)
        self.rp = os.path.join(self.proot, 'MiniReport.Report')
        self.sm = os.path.join(self.proot, 'MiniReport.SemanticModel')

    def tearDown(self):
        shutil.rmtree(self.td, ignore_errors=True)

    def run_val(self):
        V._ISSUES.clear()
        mt = V.read_model_map(self.sm)
        V.validate_model(self.sm)
        V.validate_report(self.rp, mt)
        return V._ISSUES

    def _write_visual(self, vid, vtype, query=None, objects=None, howCreated=None):
        vis = {"visualType": vtype}
        if query is not None:
            vis["query"] = query
        if objects is not None:
            vis["objects"] = objects
        d = {"name": vid,
             "position": {"x": 0, "y": 0, "z": 1, "width": 4, "height": 3},
             "visual": vis}
        if howCreated:
            d["howCreated"] = howCreated
        vj = os.path.join(self.rp, 'definition', 'pages', 'page001', 'visuals', vid,
                          'visual.json')
        w(vj, json.dumps(d, ensure_ascii=False))

    def test_bracket_color_section_not_datetime_chars(self):
        # [Red] בפורמט דרום-אפריקאי אמיתי — לא קודי תאריך (FP שתוקן)
        tf = os.path.join(self.sm, 'definition', 'tables', 'extra.tmdl')
        w(tf, 'table extra\n\tmeasure m1 = 1\n\t\tformatString: "R #,##0.00;[Red]-R #,##0.00;R 0.00"\n')
        issues = [i for i in self.run_val() if i['code'] == 'M-10']
        self.assertEqual(issues, [], '[Red] סומן כתווי תאריך (FP)')

    def test_pp_literal_still_warned(self):
        # '0.0 pp' — p לא מצוטט = AM/PM designator; ממצא אמיתי מ-insurance
        tf = os.path.join(self.sm, 'definition', 'tables', 'extra.tmdl')
        w(tf, 'table extra\n\tmeasure m1 = 1\n\t\tformatString: "0.0 pp"\n')
        issues = [i for i in self.run_val() if i['code'] == 'M-10']
        self.assertTrue(any(i['level'] == 'warn' for i in issues), "'0.0 pp' לא נתפס")

    def test_calculation_group_partition_clean(self):
        tf = os.path.join(self.sm, 'definition', 'tables', 'Time Comparison.tmdl')
        w(tf, "table 'Time Comparison'\n\tpartition 'Time Comparison' = calculationGroup\n")
        issues = [i for i in self.run_val() if i['code'] == 'M-02' and 'Time Comparison' in i['title']]
        self.assertEqual(issues, [], 'מחיצת calculationGroup סומנה ב-M-02 (FP)')

    def test_calculated_partition_clean(self):
        tf = os.path.join(self.sm, 'definition', 'tables', 'Calc.tmdl')
        w(tf, "table Calc\n\tpartition Calc = calculated\n\t\t= SELECTCOLUMNS('factמכירות', \"x\", [כמות שנתית])\n")
        issues = [i for i in self.run_val() if i['code'] == 'M-02' and 'Calc' in i['title']]
        self.assertEqual(issues, [], 'מחיצה calculated סומנה ב-M-02 (FP)')

    def test_empty_querystate_no_r26(self):
        # ויזואל placeholder בלי projections — לא לדרוש roles (FP שתוקן)
        self._write_visual('cal1', 'scatterChart', query={"queryState": {}})
        issues = [i for i in self.run_val() if i['code'] == 'R-26' and 'cal1' in i['location']]
        self.assertEqual(issues, [], 'placeholder scatterChart סומן ב-R-26 (FP)')

    def test_map_latitude_role_clean(self):
        # MS map.md: Y = Latitude, role חוקי (FP שתוקן)
        qs = {"queryState": {
            "Category": {"projections": [{"field": {"Column": {"Expression": {"SourceRef": {"Entity": "dimתאריך"}}, "Property": "Year"}}, "queryRef": "dimתאריך.Year"}]},
            "Y": {"projections": [{"field": {"Column": {"Expression": {"SourceRef": {"Entity": "dimתאריך"}}, "Property": "Year"}}, "queryRef": "dimתאריך.Year2"}]}}}
        self._write_visual('cal2', 'map', query=qs)
        issues = [i for i in self.run_val() if i['code'] == 'R-26' and 'cal2' in i['location']]
        self.assertEqual(issues, [], 'map עם Y (Latitude) סומן ב-R-26 (FP)')

    def test_r26_scatter_category_alias_clean(self):
        # סבב 66: retail האמיתי (ייצוא Desktop) כותב Category+Series+Size+X+Y ל-scatter —
        # Category הוא alias של Details, לא role שגוי (FP שתוקן)
        col = lambda prop: {"projections": [{"field": {"Column": {"Expression": {"SourceRef": {"Entity": "dimמוצרים"}}, "Property": prop}}, "queryRef": "dimמוצרים." + prop}]}
        mea = lambda prop: {"projections": [{"field": {"Measure": {"Expression": {"SourceRef": {"Entity": "factמכירות"}}, "Property": prop}}, "queryRef": "factמכירות." + prop}]}
        qs = {"queryState": {"Category": col("קטגוריה"), "Series": col("שם מוצר"),
                             "X": mea("כמות שנתית"), "Y": mea("רווח שנתי")}}
        self._write_visual('al1', 'scatterChart', query=qs)
        issues = [i for i in self.run_val() if i['code'] == 'R-26' and 'al1' in i['location']]
        self.assertEqual(issues, [], 'scatterChart עם Category (alias של Details) סומן ב-R-26 (FP)')

    def test_r26_map_location_gradient_clean(self):
        # superstore האמיתי: map עם Location + Gradient — Location הוא alias של Category
        col = lambda prop: {"projections": [{"field": {"Column": {"Expression": {"SourceRef": {"Entity": "dimמוצרים"}}, "Property": prop}}, "queryRef": "dimמוצרים." + prop}]}
        qs = {"queryState": {"Location": col("קטגוריה"), "Gradient": col("שם מוצר")}}
        self._write_visual('al2', 'map', query=qs)
        issues = [i for i in self.run_val() if i['code'] == 'R-26' and 'al2' in i['location']]
        self.assertEqual(issues, [], 'map עם Location/Gradient סומן ב-R-26 (FP)')

    def test_r26_azuremap_legacy_roles_clean(self):
        # סבב 69: advw האמיתי כותב Category/Size ל-azureMap (capital כותב dataset) —
        # שתי משפחות ייצוא חוקיות, הכולן alias של dataset (אומת מול
        # josiahsiegel/claude-plugin-marketplace pbir-schema-reference.md, MIT)
        col = lambda prop: {"projections": [{"field": {"Column": {"Expression": {"SourceRef": {"Entity": "dimגיאו"}}, "Property": prop}}, "queryRef": "dimגיאו." + prop}]}
        mea = lambda prop: {"projections": [{"field": {"Measure": {"Expression": {"SourceRef": {"Entity": "factמכירות"}}, "Property": prop}}, "queryRef": "factמכירות." + prop}]}
        qs = {"queryState": {"Category": col("עיר"), "Size": mea("סכום"),
                             "Tooltips": col("מדינה")}}
        self._write_visual('az1', 'azureMap', query=qs)
        issues = [i for i in self.run_val() if i['code'] == 'R-26' and 'az1' in i['location']]
        self.assertEqual(issues, [], 'azureMap עם Category/Size (משפחת ייצוא ישנה) סומן ב-R-26 (FP)')

    def test_r26_decomp_legacy_roles_clean(self):
        # סבב 69: insurance האמיתי כותב Category/Y/Series ל-decompositionTreeVisual
        # במקום Analyze/ExplainBy (גרסת Desktop ישנה)
        col = lambda prop: {"projections": [{"field": {"Column": {"Expression": {"SourceRef": {"Entity": "dimתביעות"}}, "Property": prop}}, "queryRef": "dimתביעות." + prop}]}
        mea = lambda prop: {"projections": [{"field": {"Measure": {"Expression": {"SourceRef": {"Entity": "factתביעות"}}, "Property": prop}}, "queryRef": "factתביעות." + prop}]}
        qs = {"queryState": {"Y": mea("סכום תביעה"), "Category": col("סניף"),
                             "Series": col("איזור")}}
        self._write_visual('dt1', 'decompositionTreeVisual', query=qs)
        issues = [i for i in self.run_val() if i['code'] == 'R-26' and 'dt1' in i['location']]
        self.assertEqual(issues, [], 'decompositionTreeVisual עם Category/Y/Series (ייצוא ישן) סומן ב-R-26 (FP)')

    def _write_group_container(self, gid, members, x=0, y=0, wdt=400, hgt=300):
        # מבנה אומת מול mudassir09/pbi-enterprise-cli visual_group_add (MIT):
        # מכולה = visual.json עם visualGroup במקום visual; חברים עם parentGroupName.
        # מפזר את החברים על ציר x כדי שלא יחפפו זה את זה.
        import json as _j
        base = os.path.join(self.rp, 'definition', 'pages', 'page001', 'visuals')
        g = {"name": gid,
             "position": {"x": x, "y": y, "z": 1, "width": wdt, "height": hgt, "tabOrder": 1},
             "visualGroup": {"displayName": "grp", "groupMode": "ScaleMode"}}
        w(os.path.join(base, gid, 'visual.json'), _j.dumps(g, ensure_ascii=False))
        for idx, m in enumerate(members):
            vj = os.path.join(base, m, 'visual.json')
            d = _j.loads(open(vj, encoding='utf-8').read())
            d['parentGroupName'] = gid
            d['position']['x'] = x + idx * 50
            d['position']['y'] = y
            w(vj, _j.dumps(d, ensure_ascii=False))

    def test_group_container_clean(self):
        # סבב 70: מכולת visualGroup חוקית — לא R-06 (אין visualType בכוונה) ולא R-16
        # (ה-bbox מכיל את החברים מתוך כוונה). אין ייצואים מקובצים בקורפוס — הזרקה סינתטית.
        self._write_visual('gm1', 'barChart', query={"queryState": {}})
        self._write_visual('gm2', 'cardVisual', query={"queryState": {}})
        self._write_group_container('g70', ['gm1', 'gm2'])
        issues = [i for i in self.run_val()
                  if i['code'] in ('R-06', 'R-16', 'R-67') and
                  any(t in i['location'] + i['title'] for t in ('g70', 'gm1', 'gm2'))]
        self.assertEqual(issues, [], 'מכולת קבוצה חוקית סומנה: %s' % [i['title'][:60] for i in issues])

    def test_group_dangling_parent_fires(self):
        self._write_visual('gm3', 'barChart', query={"queryState": {}})
        self._write_visual('gm4', 'cardVisual', query={"queryState": {}})
        self._write_group_container('g71', ['gm3', 'gm4'])
        # שבירה: מחיקת המכולה — החברים נשארים מתויגים
        import shutil as _sh, os as _os
        _sh.rmtree(_os.path.join(self.rp, 'definition', 'pages', 'page001', 'visuals', 'g71'))
        issues = [i for i in self.run_val() if i['code'] == 'R-67']
        self.assertTrue(any(i['level'] == 'err' and 'g71' in i['title'] for i in issues),
                        'parentGroupName תלוי לא נתפס')

    def test_group_single_member_and_bbox_fires(self):
        self._write_visual('gm5', 'barChart', query={"queryState": {}})
        self._write_group_container('g72', ['gm5'], x=0, y=0, wdt=10, hgt=10)
        import json as _j2, os as _o2
        _vj = _o2.path.join(self.rp, 'definition', 'pages', 'page001', 'visuals', 'gm5', 'visual.json')
        _d = _j2.loads(open(_vj, encoding='utf-8').read())
        _d['position']['x'] = 500  # מחוץ ל-bbox של המכולה (0..10)
        w(_vj, _j2.dumps(_d, ensure_ascii=False))
        issues = [i for i in self.run_val() if i['code'] == 'R-67']
        self.assertTrue(any('2 חברים' in i['title'] or 'חברים בלבד' in i['title'] for i in issues),
                        'קבוצה עם חבר יחיד לא נתפסה')
        self.assertTrue(any('חורג מה-bbox' in i['title'] for i in issues),
                        'חבר החורג מה-bbox לא נתפס')

    def test_swap_group_container_refused(self):
        # pbi_swap על מכולת קבוצה — סירוב מנומק, לא קריסה
        self._write_visual('gm6', 'barChart', query={"queryState": {}})
        self._write_visual('gm7', 'cardVisual', query={"queryState": {}})
        self._write_group_container('g73', ['gm6', 'gm7'])
        vj = os.path.join(self.rp, 'definition', 'pages', 'page001', 'visuals', 'g73', 'visual.json')
        r = SW.swap_visual(vj, 'barChart', apply=False)
        self.assertFalse(r['ok'])
        self.assertIn('visualGroup', r['reason'])

    def test_swap_grouped_child_keeps_membership(self):
        # סבב 96 (B2 probe על קורפוס אמיתי + סינתטי): החלפת ויזואל *חבר בקבוצה*
        # חייבת לשמור parentGroupName — אחרת הוויזואל מתנתק מהקבוצה בשקט
        # (יתום R-67). אומת חיה על עותק metro: bar->column בקבוצה סינתטית.
        col = {"projections": [{"field": {"Column": {"Expression": {"SourceRef": {"Entity": "dimמוצרים"}}, "Property": "קטגוריה"}}, "queryRef": "dimמוצרים.קטגוריה"}]}
        mea = {"projections": [{"field": {"Measure": {"Expression": {"SourceRef": {"Entity": "factמכירות"}}, "Property": "כמות שנתית"}}, "queryRef": "factמכירות.כמות שנתית"}]}
        self._write_visual('gs1', 'clusteredBarChart',
                           query={"queryState": {"Category": col, "Y": mea}})
        self._write_visual('gs2', 'cardVisual', query={"queryState": {}})
        self._write_group_container('g96', ['gs1', 'gs2'])
        vj = os.path.join(self.rp, 'definition', 'pages', 'page001', 'visuals', 'gs1', 'visual.json')
        r = SW.swap_visual(vj, 'clusteredColumnChart', apply=True)
        self.assertTrue(r['ok'], 'החלפת חבר בקבוצה נדחתה: %s' % r.get('reason'))
        d = json.loads(open(vj, encoding='utf-8').read())
        self.assertEqual(d['visual']['visualType'], 'clusteredColumnChart')
        self.assertEqual(d.get('parentGroupName'), 'g96',
                         'החלפה ניתקה את הוויזואל ממכולת הקבוצה (parentGroupName אבד)')
        issues = [i for i in self.run_val() if i['code'] == 'R-67'
                  and 'g96' in i['title'] + i['location']]
        self.assertEqual(issues, [], 'R-67 יתום אחרי החלפת חבר בקבוצה')

    def test_r26_typo_role_still_fires(self):
        # מגן: role עם שגיאת כתיב (שאינו alias ידוע) עדיין נתפס
        col = lambda prop: {"projections": [{"field": {"Column": {"Expression": {"SourceRef": {"Entity": "dimמוצרים"}}, "Property": prop}}, "queryRef": "dimמוצרים." + prop}]}
        mea = lambda prop: {"projections": [{"field": {"Measure": {"Expression": {"SourceRef": {"Entity": "factמכירות"}}, "Property": prop}}, "queryRef": "factמכירות." + prop}]}
        qs = {"queryState": {"Catgory": col("קטגוריה"), "Y": mea("כמות שנתית")}}
        self._write_visual('al3', 'barChart', query=qs)
        issues = [i for i in self.run_val() if i['code'] == 'R-26' and 'al3' in i['location']]
        self.assertTrue(any('Catgory' in i['title'] for i in issues),
                        'role עם שגיאת כתיב לא נתפס — הרשלנות ה-alias הרחיבה יתר על המידה')

    def test_r26_pivot_table_columns_role_clean(self):
        # matrix עם Columns (קיבוץ עמודות) — role חוקי לפי MS Learn matrix (סבב 68)
        col = lambda prop: {"projections": [{"field": {"Column": {"Expression": {"SourceRef": {"Entity": "dimמוצרים"}}, "Property": prop}}, "queryRef": "dimמוצרים." + prop}]}
        mea = lambda prop: {"projections": [{"field": {"Measure": {"Expression": {"SourceRef": {"Entity": "factמכירות"}}, "Property": prop}}, "queryRef": "factמכירות." + prop}]}
        qs = {"queryState": {"Rows": col("קטגוריה"), "Columns": col("שם מוצר"), "Values": mea("כמות שנתית")}}
        self._write_visual('mx1', 'pivotTable', query=qs)
        issues = [i for i in self.run_val() if i['code'] == 'R-26' and 'mx1' in i['location']]
        self.assertEqual(issues, [], 'pivotTable עם Columns סומן ב-R-26 (FP)')

    def test_cardvisual_reset_entry_clean(self):
        # דפוס Desktop אמיתי: רשומת reset בלי selector + רשומת id:default (FP שתוקן)
        lit = {"expr": {"Literal": {"Value": "0D"}}}
        objects = {"layout": [
            {"properties": {"topOuterMargin": lit}},
            {"properties": {"paddingUniform": lit}, "selector": {"id": "default"}}]}
        qs = {"queryState": {"Data": {"projections": [
            {"field": {"Measure": {"Expression": {"SourceRef": {"Entity": "factמכירות"}},
                                   "Property": "כמות שנתית"}},
             "queryRef": "factמכירות.כמות שנתית"}]}}}
        self._write_visual('cal3', 'cardVisual', query=qs, objects=objects)
        issues = [i for i in self.run_val() if i['code'] == 'R-47' and 'cal3' in i['location']]
        self.assertEqual(issues, [], 'רשומת reset של Desktop סומנה ב-R-47 (FP)')

    def test_cardvisual_no_selector_at_all_still_warned(self):
        lit = {"expr": {"Literal": {"Value": "0D"}}}
        objects = {"layout": [{"properties": {"topOuterMargin": lit}}]}
        qs = {"queryState": {"Data": {"projections": [
            {"field": {"Measure": {"Expression": {"SourceRef": {"Entity": "factמכירות"}},
                                   "Property": "כמות שנתית"}},
             "queryRef": "factמכירות.כמות שנתית"}]}}}
        self._write_visual('cal4', 'cardVisual', query=qs, objects=objects)
        issues = [i for i in self.run_val() if i['code'] == 'R-47' and 'cal4' in i['location']]
        self.assertTrue(issues, 'layout בלי selector כלל לא נתפס')

    def test_actionbutton_no_howcreated_is_info_now(self):
        self._write_visual('cal5', 'actionButton')
        issues = [i for i in self.run_val() if i['code'] == 'R-24' and 'cal5' in i['location']]
        self.assertTrue(all(i['level'] == 'info' for i in issues) and issues,
                        'R-24 לא הורכך ל-info')

class RelationshipTypeChecks(unittest.TestCase):
    """R-61 / M-12 + M-13: dataType תואם בקצוות קשר + שמות עם רווחים (TE built-in BPA)."""

    def setUp(self):
        self.td = tempfile.mkdtemp()
        self.proot = os.path.join(self.td, 'MiniReport')
        shutil.copytree(FIX, self.proot)
        self.sm = os.path.join(self.proot, 'MiniReport.SemanticModel')

    def tearDown(self):
        shutil.rmtree(self.td, ignore_errors=True)

    def _run(self, rel, extra_table=None):
        w(os.path.join(self.sm, 'definition', 'relationships.tmdl'), rel)
        if extra_table:
            w(os.path.join(self.sm, 'definition', 'tables', 'extra.tmdl'), extra_table)
        V._ISSUES.clear()
        V.validate_model(self.sm)
        return V._ISSUES

    TYPED = ("table a\n\tcolumn id_a\n\t\tdataType: int64\n"
             "table b\n\tcolumn id_b\n\t\tdataType: string\n")

    def _typed_tables(self, btype='string'):
        w(os.path.join(self.sm, 'definition', 'tables', 'za.tmdl'),
          "table za\n\tcolumn id_a\n\t\tdataType: int64\n")
        w(os.path.join(self.sm, 'definition', 'tables', 'zb.tmdl'),
          "table zb\n\tcolumn id_b\n\t\tdataType: %s\n" % btype)

    def test_type_mismatch_is_error(self):
        self._typed_tables('string')
        issues = self._run('relationship rx\n\tfromColumn: za.id_a\n\ttoColumn: zb.id_b\n')
        self.assertTrue(any(i['code'] == 'M-12' and i['level'] == 'err' for i in issues),
                        'קשר int64<-string לא נתפס')

    def test_matching_types_clean(self):
        self._typed_tables('int64')
        issues = self._run('relationship rx\n\tfromColumn: za.id_a\n\ttoColumn: zb.id_b\n')
        self.assertFalse(any(i['code'] == 'M-12' for i in issues),
                         'קשר בטיפוסים תואמים סומן (FP)')

    def test_unknown_type_skipped(self):
        # עמודה בלי dataType מזוהה — אין ראיה, לא מתריעים
        issues = self._run('relationship rx\n\tfromColumn: za2.id_a\n\ttoColumn: zb2.id_b\n',
                           "table za2\n\tcolumn id_a\ntable zb2\n\tcolumn id_b\n")
        self.assertFalse(any(i['code'] == 'M-12' for i in issues))

    def test_trailing_space_column_warned(self):
        issues = self._run('',
                           "table extra\n\tcolumn 'שם עם רווח '\n\t\tdataType: string\n")
        self.assertTrue(any(i['code'] == 'M-13' and i['level'] == 'warn' for i in issues),
                        'רווח נגרר בשם עמודה לא נתפס')

    def test_normal_names_clean(self):
        issues = self._run('', "table extra\n\tcolumn שםנקי\n\t\tdataType: string\n")
        self.assertFalse(any(i['code'] == 'M-13' for i in issues), 'שם נקי סומן (FP)')

class VolatileTimestampChecks(unittest.TestCase):
    """R-60 / M-11: מאפייני timestamps תנודתיים ב-TMDL (pbi-tools DefaultIgnoreProperties)."""

    def setUp(self):
        self.td = tempfile.mkdtemp()
        self.proot = os.path.join(self.td, 'MiniReport')
        shutil.copytree(FIX, self.proot)
        self.sm = os.path.join(self.proot, 'MiniReport.SemanticModel')

    def tearDown(self):
        shutil.rmtree(self.td, ignore_errors=True)

    def _run(self, extra):
        w(os.path.join(self.sm, 'definition', 'tables', 'extra.tmdl'), extra)
        V._ISSUES.clear()
        V.validate_model(self.sm)
        return [i for i in V._ISSUES if i['code'] == 'M-11']

    def test_modified_time_warned(self):
        issues = self._run("table extra\n\tmeasure m1 = 1\n\tmodifiedTime: 2026-09-10T00:00:00\n")
        self.assertTrue(any(i['level'] == 'warn' and 'modifiedTime' in i['title'] for i in issues),
                        'modifiedTime לא נתפס')

    def test_several_volatile_props_listed(self):
        issues = self._run("table extra\n\tmeasure m1 = 1\n\tlastProcessed: 2026-01-01T00:00:00\n\tstructureModifiedTime: 2026-01-01T00:00:00\n")
        self.assertTrue(any('lastProcessed' in i['title'] and 'structureModifiedTime' in i['title']
                            for i in issues), 'רשימת מאפיינים חלקית')

    def test_lineage_tag_not_flagged(self):
        issues = self._run("table extra\n\tmeasure m1 = 1\n\tlineageTag: abc-123\n")
        self.assertEqual(issues, [], 'lineageTag סומן ב-M-11 (FP — הוא זהות, לא רעש)')

    def test_clean_table_no_issue(self):
        issues = self._run("table extra\n\tmeasure m1 = 1\n")
        self.assertEqual(issues, [], 'טבלה נקייה סומנה ב-M-11 (FP)')

class FormatStringChecks(unittest.TestCase):
    """R-58 / M-10: תחביר formatString — מרכאות, escape לא נתמך, תווי תאריך לא מצוטטים."""

    def setUp(self):
        self.root = tempfile.mkdtemp(prefix='pbival-')
        self.dst = os.path.join(self.root, 'P')
        shutil.copytree(FIX, self.dst)
        self.sm = os.path.join(self.dst, 'MiniReport.SemanticModel')

    def tearDown(self):
        shutil.rmtree(self.root, ignore_errors=True)

    def _run(self, fmt_line):
        w(os.path.join(self.sm, 'definition', 'tables', 'extra.tmdl'),
          "table extra\n\tmeasure m1 = 1\n\t\t" + fmt_line + "\n")
        V._ISSUES.clear()
        V.validate_model(self.sm)
        return [i for i in V._ISSUES if i['code'] == 'M-10']

    def test_unbalanced_quotes_is_error(self):
        issues = self._run('formatString: "0.0" kg"')
        self.assertTrue(any(i['level'] == 'err' and 'מרכאות' in i['title'] for i in issues),
                        'מרכאות לא מאוזנות לא נתפסו')

    def test_unicode_escape_warned(self):
        issues = self._run('formatString: "0.0 \\u00B0"')
        self.assertTrue(any(i['level'] == 'warn' and 'escape' in i['title'] for i in issues),
                        'רצף \\uXXXX לא נתפס')

    def test_hex_escape_warned(self):
        issues = self._run('formatString: "0.0 0xB0"')
        self.assertTrue(any(i['level'] == 'warn' and 'escape' in i['title'] for i in issues),
                        'רצף 0xNN לא נתפס')

    def test_unquoted_datetime_char_in_numeric_format_warned(self):
        issues = self._run('formatString: "0.0 m"')
        self.assertTrue(any(i['level'] == 'warn' and 'לא מצוטטים' in i['title'] for i in issues),
                        'm לא מצוטט בפורמט מספרי לא נתפס')

    def test_quoted_literal_clean(self):
        issues = self._run('formatString: "0.0\\" m\\""')
        self.assertEqual(issues, [], 'ליטרל מצוטט סומן ב-M-10 (false positive)')

    def test_pure_date_format_clean(self):
        issues = self._run('formatString: "dd/mm/yyyy"')
        self.assertEqual(issues, [], 'פורמט תאריך טהור סומן ב-M-10 (false positive)')

    def test_simple_numeric_clean(self):
        issues = self._run('formatString: "#,##0.0%"')
        self.assertEqual(issues, [], 'פורמט מספרי תקין סומן ב-M-10 (false positive)')

class ThemeChecks(unittest.TestCase):
    """R-42 (theme-aware) / R-51 — stylePreset מול רישום ב-theme + תקינות theme (MS theming.md)."""

    def setUp(self):
        self.td = tempfile.mkdtemp()
        self.proot = os.path.join(self.td, 'MiniReport')
        shutil.copytree(FIX, self.proot)
        self.rp = os.path.join(self.proot, 'MiniReport.Report')
        self.sm = os.path.join(self.proot, 'MiniReport.SemanticModel')

    def tearDown(self):
        shutil.rmtree(self.td, ignore_errors=True)

    def run_val(self):
        V._ISSUES.clear()
        mt = V.read_model_map(self.sm)
        V.validate_model(self.sm)
        V.validate_report(self.rp, mt)
        return V._ISSUES

    def _write_table_preset(self, vid, preset):
        vco = {"stylePreset": [{"properties": {"name": {"expr": {"Literal": {"Value": "'%s'" % preset}}}}}]}
        vj = os.path.join(self.rp, 'definition', 'pages', 'page001', 'visuals', vid, 'visual.json')
        w(vj, json.dumps({"name": vid,
                          "position": {"x": 0, "y": 0, "z": 1, "width": 4, "height": 3},
                          "visual": {"visualType": "tableEx",
                                     "query": {"queryState": {"Values": {"projections": [
                                         {"field": {"Measure": {"Expression": {"SourceRef": {"Entity": "factמכירות"}},
                                                                "Property": "כמות שנתית"}},
                                          "queryRef": "factמכירות.כמות שנתית"}]}}},
                                     "visualContainerObjects": vco}}, ensure_ascii=False))

    def _write_theme(self, name, obj):
        w(os.path.join(self.rp, 'StaticResources', 'RegisteredResources', name + '.json'),
          json.dumps(obj, ensure_ascii=False))

    def test_theme_registered_preset_clean(self):
        self._write_theme('MyTheme', {"name": "MyTheme",
                                      "visualStyles": {"tableEx": {"Corporate Blue": {
                                          "legend": [{"show": False}]}}}})
        self._write_table_preset('th1', 'Corporate Blue')
        issues = [i for i in self.run_val() if i['code'] == 'R-42' and 'th1' in i['location']]
        self.assertFalse(issues, 'preset הרשום ב-theme סומן כלא מוכר (FP)')

    def test_unregistered_preset_warned(self):
        self._write_theme('MyTheme', {"name": "MyTheme",
                                      "visualStyles": {"tableEx": {"Corporate Blue": {}}}})
        self._write_table_preset('th2', 'Nope')
        self.assertTrue(any(i['code'] == 'R-42' and 'Nope' in i['title'] for i in self.run_val()),
                        'preset לא רשום לא נתפס')

    def test_builtin_preset_clean_without_theme(self):
        self._write_table_preset('th3', 'Minimal')
        issues = [i for i in self.run_val() if i['code'] == 'R-42' and 'th3' in i['location']]
        self.assertFalse(issues, 'preset מובנה סומן (FP)')

    def test_bad_datacolor_warned(self):
        self._write_theme('BadTheme', {"name": "BadTheme",
                                       "dataColors": ["#118DFF", "blue"]})
        self.assertTrue(any(i['code'] == 'R-51' and 'blue' in i['title'] for i in self.run_val()),
                        'dataColor לא hex לא נתפס')

    def test_valid_theme_clean(self):
        self._write_theme('GoodTheme', {"name": "GoodTheme",
                                        "dataColors": ["#118DFF", "#E66C37"],
                                        "bad": "#D64554",
                                        "textClasses": {"callout": {"fontSize": 45,
                                                                    "color": "#252423"}}})
        self.assertFalse(any(i['code'] == 'R-51' for i in self.run_val()),
                         'theme תקין סומן (FP)')

    def test_bad_textclass_fontsize_warned(self):
        self._write_theme('BadTC', {"name": "BadTC",
                                    "textClasses": {"callout": {"fontSize": "45"}}})
        self.assertTrue(any(i['code'] == 'R-51' and 'fontSize' in i['title'] for i in self.run_val()),
                        'fontSize מחרוזת לא נתפס')

    def test_bad_structural_color_warned(self):
        self._write_theme('BadSC', {"name": "BadSC", "bad": "red"})
        self.assertTrue(any(i['code'] == 'R-51' and "'bad'" in i['title'] for i in self.run_val()),
                        'צבע מבני לא hex לא נתפס')


class MobilePositionChecks(unittest.TestCase):
    """R-13 · mobile.json: position חייב להיות אובייקט עם x/y לא-שליליים
    ו-width/height חיוביים (visualContainerMobileState; סבב 73,
    מקור microsoft/powerbi-models - NOASSERTION, עובדות פורמט בלבד)."""

    def setUp(self):
        self.root = tempfile.mkdtemp(prefix='pbimob-')
        self.dst = os.path.join(self.root, 'P')
        shutil.copytree(FIX, self.dst)
        self.sm = os.path.join(self.dst, 'MiniReport.SemanticModel')
        self.rp = os.path.join(self.dst, 'MiniReport.Report')
        self.vis = os.path.join(self.rp, 'definition', 'pages', 'page001',
                                'visuals', 'vis001')

    def tearDown(self):
        shutil.rmtree(self.root, ignore_errors=True)

    def run_val(self):
        V._ISSUES.clear()
        mt = V.read_model_map(self.sm)
        V.validate_model(self.sm)
        V.validate_report(self.rp, mt)
        return V._ISSUES

    def _mob(self, pos):
        w(os.path.join(self.vis, 'mobile.json'),
          json.dumps({'$schema': 's', 'position': pos} if pos is not None else {'$schema': 's'}))

    def test_valid_mobile_clean(self):
        self._mob({'x': 8, 'y': 16, 'width': 300, 'height': 200, 'z': 1, 'tabOrder': 1})
        self.assertEqual([i for i in self.run_val() if i['code'] == 'R-13'], [])

    def test_missing_position_is_error(self):
        self._mob(None)
        errs = [i for i in self.run_val() if i['code'] == 'R-13' and i['level'] == 'err']
        self.assertTrue(any('position' in i['title'] for i in errs))

    def test_missing_numeric_key_is_error(self):
        self._mob({'x': 8, 'y': 16, 'width': 300})
        errs = [i for i in self.run_val() if i['code'] == 'R-13' and i['level'] == 'err']
        self.assertTrue(any('x/y/width/height' in i['title'] for i in errs))

    def test_negative_or_zero_geometry_is_error(self):
        self._mob({'x': -5, 'y': 0, 'width': 300, 'height': 200})
        errs = [i for i in self.run_val() if i['code'] == 'R-13' and i['level'] == 'err']
        self.assertTrue(any('לא הגיוני' in i['title'] for i in errs))
        self._mob({'x': 0, 'y': 0, 'width': 0, 'height': 200})
        errs = [i for i in self.run_val() if i['code'] == 'R-13' and i['level'] == 'err']
        self.assertTrue(any('לא הגיוני' in i['title'] for i in errs))

    def test_bool_not_accepted_as_number(self):
        self._mob({'x': True, 'y': 0, 'width': 300, 'height': 200})
        errs = [i for i in self.run_val() if i['code'] == 'R-13' and i['level'] == 'err']
        self.assertTrue(errs, 'bool התקבל כמספר — אסור')


class FixLoop(unittest.TestCase):
    """התיקונים: dry-run לא כותב, apply כותב נכון, הרצה חוזרת אידמפוטנטית."""

    def setUp(self):
        self.root = tempfile.mkdtemp(prefix='pbifix-')
        self.dst = os.path.join(self.root, 'P')
        shutil.copytree(FIX, self.dst)
        self.sm = os.path.join(self.dst, 'MiniReport.SemanticModel')
        self.rp = os.path.join(self.dst, 'MiniReport.Report')

    def tearDown(self):
        shutil.rmtree(self.root, ignore_errors=True)

    def fact(self):
        return open(os.path.join(self.sm, 'definition', 'tables', 'factמכירות.tmdl'),
                    encoding='utf-8-sig').read()

    def test_divide_and_hidefk_apply(self):
        docs = F.Docs()
        F.fix_divide(docs, self.sm)
        F.fix_hide_fk(docs, self.sm)
        # dry-run state: nothing written yet
        self.assertIn('/ [מכנה]', self.fact())
        docs.write_all()
        t = self.fact()
        self.assertIn("measure 'סכום ללא הגנה' = DIVIDE([כמות שנתית], [מכנה])", t)
        self.assertNotIn('= [כמות שנתית] / [מכנה]', t)
        # שני מפתחות זרים הוסתרו
        self.assertEqual(t.count('isHidden'), 2)
        # אידמפוטנטי: הרצה שנייה לא משנה
        docs2 = F.Docs()
        F.fix_divide(docs2, self.sm)
        F.fix_hide_fk(docs2, self.sm)
        self.assertEqual(docs2.changed(), [])

    def test_divide_skips_complex(self):
        # חילוק בתוך ביטוי מורכב — לא מתקן אוטומטית, מדווח דילוג
        w(os.path.join(self.sm, 'definition', 'tables', 'extra.tmdl'),
          "table extra\n\tmeasure c = IFERROR ( [a] / [b], 0 )\n")
        docs = F.Docs()
        skipped = F.fix_divide(docs, self.sm)
        self.assertTrue(any('extra' in s for s in skipped))
        changed_extra = [p for p, v in docs.changed() if 'extra' in p]
        self.assertEqual(changed_extra, [], 'חילוק מורכב שונה אוטומטית — אסור')

    def test_alttext_apply_and_title_source(self):
        docs = F.Docs()
        skipped = F.fix_alttext(docs, self.rp)
        docs.write_all()
        v1 = json.load(open(os.path.join(self.rp, 'definition', 'pages', 'page001',
                                         'visuals', 'vis001', 'visual.json'), encoding='utf-8-sig'))
        gen = v1['visual']['visualContainerObjects']['general']
        alt = gen[0]['properties']['altText']['expr']['Literal']['Value']
        self.assertEqual(alt, "'כמות שנתית'", 'altText חייב להיגזר מהכותרת הקיימת')
        # vis002 בלי כותרת אבל עם שדות — altText מסונתז מהשדות (WCAG 1.1.1, סבב 67)
        v2 = json.load(open(os.path.join(self.rp, 'definition', 'pages', 'page001',
                                         'visuals', 'vis002', 'visual.json'), encoding='utf-8-sig'))
        gen2 = v2['visual']['visualContainerObjects']['general']
        alt2 = gen2[0]['properties']['altText']['expr']['Literal']['Value']
        # סבב 137 (כשל שדה #8): הפיקסצר מזוהה כדוח עברי → סינתזה עם שם סוג עברי
        self.assertEqual(alt2, "'טבלה: שם מוצר'", 'altText בדוח עברי חייב שם סוג עברי (כשל שדה #8)')
        # סבב 134 (דיווח שדה #2): כתיבה תמיד מסירה BOM — Desktop 2.157 חוסם פתיחה.
        v3_path = os.path.join(self.rp, 'definition', 'pages', 'page001', 'visuals', 'vis003', 'visual.json')
        raw = open(v3_path, 'rb').read()
        if any(v3_path == p for p, v in docs.changed()):
            self.assertFalse(raw.startswith(b'\xef\xbb\xbf'), 'BOM לא הוסר בכתיבה (חוסם פתיחה ב-Desktop 2.157)')

    def test_alttext_no_title_no_fields_skipped(self):
        # בלי כותרת ובלי שדות (placeholder) — אין ממה לגזור alt text; דילוג מתועד
        import json as _j
        vp = os.path.join(self.rp, 'definition', 'pages', 'page001', 'visuals', 'vis999')
        os.makedirs(vp, exist_ok=True)
        w(os.path.join(vp, 'visual.json'),
          _j.dumps({"name": "vis999", "visual": {"visualType": "barChart", "query": {"queryState": {}}}}))
        docs = F.Docs()
        skipped = F.fix_alttext(docs, self.rp)
        self.assertTrue(any('vis999' in x for x in skipped), 'placeholder ללא שדות חייב להידלג')
        changed = [p for p, v in docs.changed() if 'vis999' in p]
        self.assertEqual(changed, [], 'placeholder ללא שדות שונה — אסור')

    def test_pageorder_repairs_silently_dropped_page(self):
        pj = os.path.join(self.rp, 'definition', 'pages', 'pages.json')
        w(pj, json.dumps({'activePageName': 'page001', 'pageOrder': ['page001']}, indent=1))
        docs = F.Docs()
        F.fix_pageorder(docs, self.rp)
        docs.write_all()
        obj = json.load(open(pj, encoding='utf-8-sig'))
        self.assertEqual(sorted(obj['pageOrder']), ['page001', 'page002'])


class SwapPivotColumns(unittest.TestCase):
    """pbi_swap: pivotTable (matrix) עם role Columns — סבב 68 (MS Learn desktop-matrix-visual)."""

    def _doc(self, with_columns=True):
        col = lambda prop: {"field": {"Column": {"Expression": {"SourceRef": {"Entity": "dim"}}, "Property": prop}}, "queryRef": "dim." + prop}
        mea = lambda prop: {"field": {"Measure": {"Expression": {"SourceRef": {"Entity": "fact"}}, "Property": prop}}, "queryRef": "fact." + prop}
        qs = {"Rows": {"projections": [col("קטגוריה")]}, "Values": {"projections": [mea("סכום")]}}
        if with_columns:
            qs["Columns"] = {"projections": [col("אזור")]}
        return {"visual": {"visualType": "pivotTable", "query": {"queryState": qs}}}

    def test_plan_out_of_matrix_with_columns(self):
        # החלפה החוצה מ-matrix עם Columns: עמודות ה-Columns זורמות לתפקידי היעד, לא נזרקות בדממה
        ok, msg, qs, _drop = SW.plan_swap(self._doc(), 'clusteredColumnChart')
        self.assertTrue(ok, msg)
        got = [pr['queryRef'] for blk in qs.values() for pr in blk['projections']]
        self.assertIn('dim.אזור', got, 'עמודת Columns אבדה בהחלפה החוצה מ-matrix')

    def test_plan_into_matrix_never_autofills_columns(self):
        # החלפה פנימה ל-matrix לא מאוותרת Columns לבד - רק Rows/Values
        ok, msg, qs, _drop = SW.plan_swap(self._doc(with_columns=False), 'pivotTable')
        self.assertTrue(ok, msg)
        self.assertNotIn('Columns', qs, 'Columns אוותר אוטומטית — אסור')
        self.assertIn('Rows', qs)
        self.assertIn('Values', qs)


class FixHowcreated(unittest.TestCase):
    """pbi_fix howcreated: howCreated='InsertVisualButton' לוויזואלי insert בלעדיו (R-24).
    סבב 72 — מקורות: jonathan-pap/powerbi-report-mcp (MIT) + Russell-Shean/powerbpy
    button.py (GPL-3.0, עובדת פורמט בלבד)."""

    def setUp(self):
        self.root = tempfile.mkdtemp(prefix='pbihc-')
        self.dst = os.path.join(self.root, 'P')
        shutil.copytree(FIX, self.dst)
        self.rp = os.path.join(self.dst, 'MiniReport.Report')

    def tearDown(self):
        shutil.rmtree(self.root, ignore_errors=True)

    def _vis(self, vid, vtype, how=None):
        d = {"name": vid,
             "position": {"x": 0, "y": 0, "z": 1, "width": 40, "height": 30},
             "visual": {"visualType": vtype}}
        if how:
            d['howCreated'] = how
        vj = os.path.join(self.rp, 'definition', 'pages', 'page001', 'visuals', vid,
                          'visual.json')
        w(vj, json.dumps(d, ensure_ascii=False))
        return vj

    def test_insert_visuals_get_howcreated(self):
        va = self._vis('hc1', 'actionButton')
        vi = self._vis('hc2', 'image')
        docs = F.Docs()
        F.fix_howcreated(docs, self.rp)
        # dry-run: לא נכתב
        self.assertNotIn('howCreated', json.load(open(va, encoding='utf-8-sig')))
        docs.write_all()
        for v in (va, vi):
            d = json.load(open(v, encoding='utf-8-sig'))
            self.assertEqual(d['howCreated'], 'InsertVisualButton')
        # אידמפוטנטי
        docs2 = F.Docs()
        F.fix_howcreated(docs2, self.rp)
        self.assertEqual(docs2.changed(), [])

    def test_existing_value_not_overwritten(self):
        va = self._vis('hc3', 'actionButton', how='Copilot')
        docs = F.Docs()
        F.fix_howcreated(docs, self.rp)
        docs.write_all()
        d = json.load(open(va, encoding='utf-8-sig'))
        self.assertEqual(d['howCreated'], 'Copilot', 'howCreated קיים נדרס — אסור')

    def test_data_visuals_and_group_containers_skipped(self):
        vb = self._vis('hc4', 'barChart')
        vg = os.path.join(self.rp, 'definition', 'pages', 'page001', 'visuals', 'hc5',
                          'visual.json')
        w(vg, json.dumps({"name": "hc5",
                          "position": {"x": 0, "y": 0, "z": 1, "width": 40, "height": 30},
                          "visualGroup": {"displayName": "g", "groupMode": "ScaleMode"}},
                         ensure_ascii=False))
        docs = F.Docs()
        F.fix_howcreated(docs, self.rp)
        changed = [p for p, v in docs.changed()]
        self.assertFalse(any('hc4' in p or 'hc5' in p for p in changed),
                         'וויזואל נתונים או מכולת קבוצה קיבלו howCreated — אסור')


class FixFilterhowcreated(unittest.TestCase):
    """pbi_fix filterhowcreated: howCreated='User' לרשומות מסנן בלי השדה (R-31),
    בשלוש הרמות — report/page/visual. סבב 80 — מקור MS Learn projects-report
    (CC-BY-4.0) + עובדת קורפוס: Desktop כותב 'User' למסנני UI."""

    def setUp(self):
        self.root = tempfile.mkdtemp(prefix='pbifhc-')
        self.dst = os.path.join(self.root, 'P')
        shutil.copytree(FIX, self.dst)
        self.rp = os.path.join(self.dst, 'MiniReport.Report')

    def tearDown(self):
        shutil.rmtree(self.root, ignore_errors=True)

    def _filters_json(self, path, entries):
        w(path, json.dumps({"name": "x", "filterConfig": {"filters": entries}},
                           ensure_ascii=False))
        return path

    def _run(self, apply=True):
        docs = F.Docs()
        skipped = F.fix_filterhowcreated(docs, self.rp)
        if apply:
            docs.write_all()
        return docs, skipped

    def test_visual_level_injected(self):
        vj = os.path.join(self.rp, 'definition', 'pages', 'page001', 'visuals', 'f1',
                          'visual.json')
        self._filters_json(vj, [{"name": "a", "field": {"Column": {"Expression":
            {"SourceRef": {"Entity": "t"}}, "Property": "c"}}, "type": "Categorical"}])
        docs, _ = self._run()
        d = json.load(open(vj, encoding='utf-8-sig'))
        self.assertEqual(d['filterConfig']['filters'][0]['howCreated'], 'User')

    def test_page_and_report_levels_injected(self):
        pj = os.path.join(self.rp, 'definition', 'pages', 'page001', 'page.json')
        rj = os.path.join(self.rp, 'definition', 'report.json')
        entry = {"name": "a", "field": {"Column": {"Expression":
            {"SourceRef": {"Entity": "t"}}, "Property": "c"}}, "type": "Advanced"}
        import json as _j
        d = _j.load(open(pj)); d['filterConfig'] = {"filters": [dict(entry)]}
        w(pj, _j.dumps(d))
        d = _j.load(open(rj)); d['filterConfig'] = {"filters": [dict(entry)]}
        w(rj, _j.dumps(d))
        self._run()
        for path in (pj, rj):
            d = _j.load(open(path, encoding='utf-8-sig'))
            self.assertEqual(d['filterConfig']['filters'][0]['howCreated'], 'User',
                             '%s לא תוקן' % path)

    def test_existing_howcreated_preserved(self):
        vj = os.path.join(self.rp, 'definition', 'pages', 'page001', 'visuals', 'f2',
                          'visual.json')
        self._filters_json(vj, [{"name": "a", "field": {}, "type": "Categorical",
                                 "howCreated": "Quick measure"}])
        docs, _ = self._run()
        self.assertFalse(any('f2' in p for p, v in docs.changed()),
                         'howCreated קיים נדרס — אסור')
        d = json.load(open(vj, encoding='utf-8-sig'))
        self.assertEqual(d['filterConfig']['filters'][0]['howCreated'], 'Quick measure')

    def test_dry_run_and_idempotent(self):
        vj = os.path.join(self.rp, 'definition', 'pages', 'page001', 'visuals', 'f3',
                          'visual.json')
        self._filters_json(vj, [{"name": "a", "field": {}, "type": "Categorical"}])
        before = open(vj, encoding='utf-8-sig').read()
        docs, _ = self._run(apply=False)
        self.assertEqual(open(vj, encoding='utf-8-sig').read(), before, 'dry-run כתב')
        docs.write_all()
        docs2, _ = self._run()
        self.assertEqual(docs2.changed(), [], 'הרצה שנייה שינתה שוב')

    def test_no_filterconfig_untouched(self):
        vj = os.path.join(self.rp, 'definition', 'pages', 'page001', 'visuals', 'f4',
                          'visual.json')
        w(vj, json.dumps({"name": "f4", "visual": {"visualType": "card"}}))
        before = open(vj, encoding='utf-8-sig').read()
        docs, _ = self._run()
        self.assertFalse(any('f4' in p for p, v in docs.changed()))


class FixSlicerheight(unittest.TestCase):
    """pbi_fix slicerheight: סליסר inline אנכי מתחת לרצפת 48px (R-68) — הגבהה ל-48
    עם הזזת-המשך (cascade) של כל מה שמתחת לרצועה. סבב 79 — מקור MS Learn
    power-bi-slicer-filter-responsive (CC-BY-4.0) + slicers.md Inline-list."""

    def setUp(self):
        self.root = tempfile.mkdtemp(prefix='pbish-')
        self.dst = os.path.join(self.root, 'P')
        shutil.copytree(FIX, self.dst)
        self.rp = os.path.join(self.dst, 'MiniReport.Report')
        self.sm = os.path.join(self.dst, 'MiniReport.SemanticModel')
        self.page = os.path.join(self.rp, 'definition', 'pages', 'pagesh')
        os.makedirs(os.path.join(self.page, 'visuals'), exist_ok=True)
        w(os.path.join(self.page, 'page.json'),
          '{"name": "pagesh", "width": 1280, "height": 720}')

    def tearDown(self):
        shutil.rmtree(self.root, ignore_errors=True)

    def _slicer(self, vid, x, y, wd, ht, mode=None, orient=None, field=None):
        vis = {"visualType": "slicer", "query": {"queryState": {}}}
        objects = {}
        if mode is not None:
            objects['data'] = [{"properties": {"mode": {"expr": {"Literal": {"Value": "'%s'" % mode}}}}}]
        if orient is not None:
            objects['general'] = [{"properties": {"orientation": {"expr": {"Literal": {"Value": "'%s'" % orient}}}}}]
        if field:
            vis['query']['queryState'] = {"Values": {"projections": [{"field": {
                "Column": {"Expression": {"SourceRef": {"Entity": field[0]}},
                           "Property": field[1]}}, "queryRef": "q0"}]}}
        if objects:
            vis['objects'] = objects
        d = {"name": vid, "position": {"x": x, "y": y, "z": 1, "width": wd, "height": ht},
             "visual": vis}
        vj = os.path.join(self.page, 'visuals', vid, 'visual.json')
        w(vj, json.dumps(d, ensure_ascii=False))
        return vj

    def _vis(self, vid, x, y, wd, ht, vtype='barChart'):
        d = {"name": vid, "position": {"x": x, "y": y, "z": 1, "width": wd, "height": ht},
             "visual": {"visualType": vtype, "query": {"queryState": {}}}}
        vj = os.path.join(self.page, 'visuals', vid, 'visual.json')
        w(vj, json.dumps(d, ensure_ascii=False))
        return vj

    def _run(self, apply=True, sm=None):
        docs = F.Docs()
        skipped = F.fix_slicerheight(docs, self.rp, sm)
        if apply:
            docs.write_all()
        return docs, skipped

    def test_bar_raised_and_below_shifted_once(self):
        # שני סליסרים ברצועה (y=84, h=38) + כרטיס מתחת — הגבהה אחת, הזזה אחת בלבד
        vs1 = self._slicer('s1', 20, 84, 165, 38)
        vs2 = self._slicer('s2', 200, 84, 165, 38)
        vc = self._vis('c1', 20, 130, 145, 104, vtype='card')
        docs, skipped = self._run()
        self.assertEqual(skipped, [])
        for v in (vs1, vs2):
            d = json.load(open(v, encoding='utf-8-sig'))
            self.assertEqual(d['position']['height'], 48.0)
            self.assertEqual(d['position']['y'], 84, 'סליסר ברצועה זז במקום רק להוגבה')
        d = json.load(open(vc, encoding='utf-8-sig'))
        self.assertEqual(d['position']['y'], 140.0, 'הכרטיס הוזז פעם אחת (84+38->132, 140=130+10)')
        # אידמפוטנטי
        docs2, skipped2 = self._run()
        self.assertEqual(docs2.changed(), [], 'הרצה שנייה שינתה שוב')

    def test_dry_run_writes_nothing(self):
        vs1 = self._slicer('s1', 20, 84, 165, 38)
        before = open(vs1, encoding='utf-8-sig').read()
        docs, _ = self._run(apply=False)
        self.assertEqual(open(vs1, encoding='utf-8-sig').read(), before, 'dry-run כתב לדיסק')

    def test_no_canvas_room_skips(self):
        vs1 = self._slicer('s1', 20, 680, 165, 38)   # 680+48=728 > 720
        docs, skipped = self._run()
        self.assertEqual(docs.changed(), [])
        self.assertTrue(any('s1' in x for x in skipped), 'לא דווח דילוג עם סיבה')
        d = json.load(open(vs1, encoding='utf-8-sig'))
        self.assertEqual(d['position']['height'], 38)

    def test_dropdown_and_oriented_untouched(self):
        vd = self._slicer('sd', 20, 84, 165, 38, mode='Dropdown')
        vo = self._slicer('so', 200, 84, 165, 38, orient='2D')
        vt = self._slicer('st', 380, 84, 165, 60)  # מעל הרצפה
        docs, skipped = self._run()
        self.assertEqual(docs.changed(), [], 'Dropdown/orientation/גובה תקין שונו — אסור')

    def test_boolean_column_untouched(self):
        sm2 = os.path.join(self.root, 'M.SemanticModel')
        w(os.path.join(sm2, 'definition', 'tables', 'flags.tmdl'),
          "table flags\n\tcolumn active\n\t\tdataType: boolean\n")
        vb = self._slicer('sb', 20, 84, 165, 38, field=('flags', 'active'))
        docs, skipped = self._run(sm=sm2)
        self.assertEqual(docs.changed(), [], 'סליסר על עמודה בוליאנית (צ\'קבוקס יחיד) שונה')

    def test_group_below_blocks_with_reason(self):
        vs1 = self._slicer('s1', 20, 84, 165, 38)
        vg = os.path.join(self.page, 'visuals', 'g1', 'visual.json')
        w(vg, json.dumps({"name": "g1",
                          "position": {"x": 20, "y": 130, "z": 2, "width": 200, "height": 100},
                          "visualGroup": {"displayName": "g", "groupMode": "ScaleMode"}},
                         ensure_ascii=False))
        docs, skipped = self._run()
        self.assertEqual(docs.changed(), [], 'הזזת קבוצה בוצעה — אסור')
        self.assertTrue(any('visualGroup' in x for x in skipped))


class FixRelationships(unittest.TestCase):
    """pbi_fix relationships: M:M דו-כיווני → חד-כיווני, many→one רק עם ייחודיות מוכחת
    מ-#table מוטמע. סבב 74 — מקור MS Learn relationships-bidirectional-filtering
    (CC-BY-4.0): לצמצם bi-directional, CROSSFILTER נקודתי עדיף, 1:1 חייב דו-כיווני."""

    DIM = """table dim
\tcolumn 'שם'
\t\tdataType: string
\t\tsummarizeBy: none
\t\tsourceColumn: שם
\tpartition dim = m
\t\tmode: import
\t\tsource =
\t\t\tlet
\t\t\t    Source = #table(
\t\t\t        type table [שם = type text, ערך = Int64.Type],
\t\t\t        {
%s
\t\t\t        }
\t\t\t    )
\t\t\tin
\t\t\t    Source
"""
    FACT = """table fact
\tcolumn 'שם'
\t\tdataType: string
\t\tsummarizeBy: none
\t\tsourceColumn: שם
%s"""

    def setUp(self):
        self.root = tempfile.mkdtemp(prefix='pbirel-')
        self.sm = os.path.join(self.root, 'M.SemanticModel')
        os.makedirs(os.path.join(self.sm, 'definition', 'tables'))

    def tearDown(self):
        shutil.rmtree(self.root, ignore_errors=True)

    def _build(self, rows, rel_extra='', cross='bothDirections', frm='many', to='many',
               measure=None, dim_partition=None, rel_in_model=False):
        tdir = os.path.join(self.sm, 'definition', 'tables')
        part = dim_partition if dim_partition is not None else (self.DIM % rows)
        w(os.path.join(tdir, 'dim.tmdl'), part)
        w(os.path.join(tdir, 'fact.tmdl'), self.FACT % (
            ('\n\tmeasure m = ' + measure + '\n') if measure else ''))
        rel = ("relationship r1\n\tcrossFilteringBehavior: %s\n\tfromCardinality: %s\n"
               "\ttoCardinality: %s\n\tfromColumn: fact.שם\n\ttoColumn: dim.שם\n%s"
               % (cross, frm, to, rel_extra))
        if rel_in_model:
            w(os.path.join(self.sm, 'definition', 'model.tmdl'),
              "model Model\n\t" + rel.replace('\n', '\n\t'))
        else:
            w(os.path.join(self.sm, 'definition', 'relationships.tmdl'), rel)

    def _reltext(self, in_model=False):
        f = os.path.join(self.sm, 'definition',
                         'model.tmdl' if in_model else 'relationships.tmdl')
        return open(f, encoding='utf-8-sig').read()

    def test_mm_bidirectional_unique_fixed_and_idempotent(self):
        self._build('\t\t\t            {"א", 1},\n\t\t\t            {"ב", 2}')
        docs = F.Docs()
        skipped = F.fix_relationships(docs, self.sm)
        self.assertEqual(skipped, [])
        # dry-run: השינוי רק בזיכרון — על הדיסק עדיין המקור
        self.assertIn('bothDirections', self._reltext())
        docs.write_all()
        t = self._reltext()
        self.assertIn('crossFilteringBehavior: oneDirection', t)
        self.assertIn('toCardinality: one', t)
        self.assertIn('\tcrossFilteringBehavior', t, 'אינדנטציה אבדה')
        docs2 = F.Docs()
        F.fix_relationships(docs2, self.sm)
        self.assertEqual(docs2.changed(), [], 'לא אידמפוטנטי')

    def test_mm_duplicate_target_keeps_many(self):
        self._build('\t\t\t            {"א", 1},\n\t\t\t            {"א", 2}')
        docs = F.Docs()
        skipped = F.fix_relationships(docs, self.sm)
        docs.write_all()
        t = self._reltext()
        self.assertIn('crossFilteringBehavior: oneDirection', t)
        self.assertIn('toCardinality: many', t, 'כפילויות — אסור לרדת ל-one')
        self.assertTrue(any('כפילויות' in x for x in skipped))

    def test_one_to_one_never_touched(self):
        # MS Learn: קשר 1:1 חייב להישאר דו-כיווני
        self._build('\t\t\t            {"א", 1}', frm='one', to='one')
        docs = F.Docs()
        F.fix_relationships(docs, self.sm)
        docs.write_all()
        t = self._reltext()
        self.assertIn('bothDirections', t)
        self.assertIn('toCardinality: one', t)

    def test_crossfilter_in_model_skips_direction_flip(self):
        self._build('\t\t\t            {"א", 1},\n\t\t\t            {"ב", 2}',
                    measure='CALCULATE([x], CROSSFILTER(fact[שם], dim[שם], BOTH))')
        docs = F.Docs()
        skipped = F.fix_relationships(docs, self.sm)
        docs.write_all()
        self.assertIn('bothDirections', self._reltext(), 'CROSSFILTER קיים — אסור לגעת בכיוון')
        self.assertTrue(any('CROSSFILTER' in x for x in skipped))
        # הקרדינליות עדיין מתוקנת (בדיקת ייחודיות לא קשורה לכיוון)
        self.assertIn('toCardinality: one', self._reltext())

    def test_non_literal_partition_skips_cardinality(self):
        part = """table dim
\tcolumn 'שם'
\t\tdataType: string
\t\tsummarizeBy: none
\t\tsourceColumn: שם
\tpartition dim = m
\t\tmode: import
\t\tsource =
\t\t\tlet
\t\t\t    Source = Sql.Database("srv", "db")
\t\t\tin
\t\t\t    Source
"""
        self._build('', dim_partition=part)
        docs = F.Docs()
        skipped = F.fix_relationships(docs, self.sm)
        docs.write_all()
        self.assertIn('toCardinality: many', self._reltext())
        self.assertTrue(any('#table' in x for x in skipped))

    def test_relationship_inline_in_model_tmdl(self):
        self._build('\t\t\t            {"א", 1},\n\t\t\t            {"ב", 2}',
                    rel_in_model=True)
        docs = F.Docs()
        F.fix_relationships(docs, self.sm)
        docs.write_all()
        t = self._reltext(in_model=True)
        self.assertIn('crossFilteringBehavior: oneDirection', t)
        self.assertIn('toCardinality: one', t)
        self.assertIn('\t\tcrossFilteringBehavior', t, 'אינדנטציה כפולה במודל אבדה')


class ValidateSvgMeasures(unittest.TestCase):
    """pbi_validate M-18: מדדי SVG שבורים — סבב 115 (Dashboard-Design/
    Power-BI-Design-Files SVG_BEST_PRACTICES v2.1, MIT, Sajjad Ahmadi)."""

    def setUp(self):
        self.root = tempfile.mkdtemp(prefix='pbisvg-')
        self.dst = os.path.join(self.root, 'P')
        shutil.copytree(FIX, self.dst)
        self.sm = os.path.join(self.dst, 'MiniReport.SemanticModel')

    def tearDown(self):
        shutil.rmtree(self.root, ignore_errors=True)

    def _val(self):
        V._ISSUES.clear()
        V.validate_model(self.sm)
        return V._ISSUES

    def _svg_measure(self, body):
        w(os.path.join(self.sm, 'definition', 'tables', 'factמכירות.tmdl'),
          "table factמכירות\n\tcolumn תאריך\n\t\tdataType: dateTime\n"
          "\tcolumn מק\"ט\n\t\tdataType: string\n"
          "\tcolumn כמות\n\t\tdataType: int64\n" + body)

    def test_svg_without_prefix_is_error(self):
        self._svg_measure("\tmeasure m_svg = \"<svg width='10' height='10'></svg>\"\n")
        self.assertTrue(any(i['code'] == 'M-18' and i['level'] == 'err' for i in self._val()),
                        'SVG בלי prefix לא סומן err')

    def test_svg_without_viewbox_warned(self):
        self._svg_measure(
          "\tmeasure m_svg = \"data:image/svg+xml;charset=utf-8,<svg width='10' height='10'></svg>\"\n"
          "\t\tdataCategory: Image URL\n")
        iss = self._val()
        self.assertTrue(any(i['code'] == 'M-18' and i['level'] == 'warn' and 'viewBox' in i['title']
                            for i in iss), 'viewBox חסר לא סומן')

    def test_svg_without_image_url_datacategory_warned(self):
        self._svg_measure(
          "\tmeasure m_svg = \"data:image/svg+xml;charset=utf-8,<svg viewBox='0 0 10 10' width='10' height='10'></svg>\"\n")
        self.assertTrue(any(i['code'] == 'M-18' and 'Image URL' in i['title'] for i in self._val()),
                        'dataCategory חסר לא סומן')

    def test_clean_svg_measure_no_m18(self):
        self._svg_measure(
          "\tmeasure m_svg = IF(ISBLANK([כמות שנתית]), BLANK(), \"data:image/svg+xml;charset=utf-8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 10 10' overflow='visible' width='10' height='10'></svg>\")\n"
          "\t\tdataCategory: Image URL\n")
        self.assertFalse(any(i['code'] == 'M-18' for i in self._val()),
                         'מדד SVG תקין (v2.1 מלא: xmlns + שמירה) סומן (FP)')

    def test_svg_without_xmlns_warned(self):
        self._svg_measure(
          "\tmeasure m_svg = IF(ISBLANK([כמות שנתית]), BLANK(), \"data:image/svg+xml;charset=utf-8,<svg viewBox='0 0 10 10'></svg>\")\n"
          "\t\tdataCategory: Image URL\n")
        iss = self._val()
        self.assertTrue(any(i['code'] == 'M-18' and i['level'] == 'warn' and 'xmlns' in i['title']
                            for i in iss), 'xmlns חסר לא סומן (D1)')

    def test_oversized_svg_measure_warned(self):
        pad = 'x' * 30500
        self._svg_measure(
          "\tmeasure m_svg = IF(ISBLANK([כמות שנתית]), BLANK(), \"data:image/svg+xml;charset=utf-8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 10 10'><!--" + pad + "--></svg>\")\n"
          "\t\tdataCategory: Image URL\n")
        iss = self._val()
        self.assertTrue(any(i['code'] == 'M-18' and i['level'] == 'warn' and '30K' in i['title']
                            for i in iss), 'מדד ענק לא סומן (D2)')

    def test_svg_without_guard_info(self):
        self._svg_measure(
          "\tmeasure m_svg = \"data:image/svg+xml;charset=utf-8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 10 10'></svg>\"\n"
          "\t\tdataCategory: Image URL\n")
        iss = self._val()
        self.assertTrue(any(i['code'] == 'M-18' and i['level'] == 'info' and 'HASONEVALUE' in i['title']
                            for i in iss), 'שמירה חסרה לא סומנה (D3)')

    def test_regular_measure_no_m18(self):
        self.assertFalse(any(i['code'] == 'M-18' for i in self._val()),
                         'מדד רגיל סומן (FP)')


class TestPbiSvg(unittest.TestCase):
    """pbi_svg.py — גנרטור מדדי SVG תואמי v2.1 + הזרקת TMDL — סבב 116
    (רעיון התבניות: Dashboard-Design/Power-BI-Design-Files, MIT, Sajjad Ahmadi;
    המימוש נכתב מחדש לפי SVG_BEST_PRACTICES v2.1 המחמיר)."""

    SCRIPT = os.path.join(ROOT, 'skills', 'powerbi-pbip-builder', 'scripts', 'pbi_svg.py')

    def setUp(self):
        self.root = tempfile.mkdtemp(prefix='pbisvggen-')
        self.dst = os.path.join(self.root, 'P')
        shutil.copytree(FIX, self.dst)
        self.sm = os.path.join(self.dst, 'MiniReport.SemanticModel')
        self.tbl = os.path.join(self.sm, 'definition', 'tables', 'Measures.tmdl')
        w(self.tbl, "table Measures\n\tmeasure Base = 1\n\t\tformatString: 0\n\n"
                    "\tpartition Measures = m\n\t\tmode: import\n\n\tannotation PBI_ResultType = Table\n")

    def tearDown(self):
        shutil.rmtree(self.root, ignore_errors=True)

    def _ns(self, **kw):
        import argparse as _ap
        base = dict(value=None, compare=None, warn=None, err=None, target=None,
                    maxval=None, axis=None, actual=None, plan=None, invert=False, guard=None,
                    series=None, label=None, items=None, top=None, x=None, y=None, img=None)
        base.update(kw)
        return _ap.Namespace(**base)

    def _gen(self, template, **kw):
        return '\n'.join(S.GENS[template](self._ns(**kw)))

    def _run(self, *argv):
        import subprocess, sys as _sys
        return subprocess.run([_sys.executable, self.SCRIPT] + list(argv),
                              capture_output=True, text=True, encoding='utf-8')

    # ── יצירה (v2.1 pre-flight על כל תבנית) ──
    def _all_templates(self):
        return {
            'kpi': self._gen('kpi', value='[S]', compare='[SLY]'),
            'status': self._gen('status', value='[R]', warn=0.9, err=0.75),
            'progress': self._gen('progress', value='[D]', target='[G]'),
            'radar': self._gen('radar', axis=['a|[A]', 'b|[B]', 'c|[C]']),
            'variance': self._gen('variance', actual='[A]', plan='[P]'),
            'bubble': self._gen('bubble', value='[S]', series="'Date'[Day]"),
            'bulletlist': self._gen('bulletlist', value='[S]', items="'dim'[Name]"),
            'scatterimg': self._gen('scatterimg', x='[X]', y='[Y]',
                                    img="'dim'[Url]", guard="'dim'[Co]"),
            'boxplot': self._gen('boxplot', value='[S]', series="'Date'[Day]"),
            'dumbbell': self._gen('dumbbell', actual='[A]', target='[T]',
                                  series="'Date'[Day]"),
            'ibcsbar': self._gen('ibcsbar', actual='[A]', compare='[PY]',
                                 series="'Date'[Day]"),
        }

    def test_all_templates_pass_v21_preflight(self):
        import re as _re
        for name, dax in self._all_templates().items():
            self.assertEqual(dax.count('data:image/svg+xml;charset=utf-8,'), 1, name)
            self.assertNotIn('#', dax, name + ": '#' גולמי")
            self.assertIn('viewBox', dax, name)
            self.assertIn("overflow='visible'", dax, name)
            for m in _re.finditer('%', dax):
                self.assertIsNotNone(_re.match(r'%[0-9A-Fa-f]{2}', dax[m.start():]),
                                     name + ': % לא מקודד')

    def test_colors_are_encoded_vars_with_comments(self):
        dax = self._gen('status', value='[R]', warn=0.9, err=0.75)
        self.assertIn('VAR _cGood = "%232E7D32"', dax)
        self.assertIn('--', dax.split('VAR _cGood')[1].split('\n')[0])

    def test_guard_wraps_return_not_var_block(self):
        dax = self._gen('status', value='[R]', warn=0.9, err=0.75, guard='dim[Key]')
        self.assertLess(dax.index('VAR'), dax.index('RETURN'))
        self.assertLess(dax.index('RETURN'), dax.index('HASONEVALUE'))
        self.assertIn('HASONEVALUE( dim[Key] )', dax)

    def test_desc_sort_tag_in_single_value_templates(self):
        for name in ('kpi', 'status', 'progress', 'variance'):
            self.assertIn('<desc>', self._all_templates()[name], name)
        self.assertNotIn('<desc>', self._all_templates()['radar'])

    def test_preserve_aspect_ratio_only_on_bars(self):
        for name, dax in self._all_templates().items():
            if name in ('progress', 'variance', 'ibcsbar'):
                self.assertIn("preserveAspectRatio='none'", dax, name)
            else:
                self.assertNotIn('preserveAspectRatio', dax, name)

    def test_bubble_normalizes_by_series(self):
        # סבב 128: bubble (Matrix Bubble, MIT) — גודל מונורמל ב-MINX/MAXX על הסידרה
        dax = self._gen('bubble', value='[S]', series="'Date'[Day]")
        self.assertIn("MINX(ALLSELECTED('Date'[Day]), [S])", dax)
        self.assertIn('DIVIDE(_v - _min, _span)', dax)
        self.assertIn('<desc>', dax)

    def test_bubble_optional_label(self):
        plain = self._gen('bubble', value='[S]', series="'Date'[Day]")
        self.assertNotIn('<text', plain)
        lab = self._gen('bubble', value='[S]', series="'Date'[Day]", label="'Date'[Day]")
        self.assertIn('text-anchor', lab)

    def test_bubble_requires_series(self):
        with self.assertRaises(SystemExit):
            self._gen('bubble', value='[S]')

    def test_bulletlist_pure_svg_no_foreignobject(self):
        # סבב 128: bulletlist (Dynamic Bullet Points, MIT) — המקור foreignObject+CSS,
        # v2.1 חוק 16 אוסר; המימוש circle/text + RANKX
        dax = self._gen('bulletlist', value='[S]', items="'dim'[Name]")
        self.assertNotIn('foreignObject', dax)
        self.assertIn('RANKX(ALLSELECTED(', dax)
        self.assertIn('SUBSTITUTE(', dax)  # בריחת & בשמות
        self.assertIn('TOPN(5,', dax)
        self.assertIn('ISBLANK([S])', dax)  # שמירת M-18

    def test_bulletlist_top_param(self):
        dax = self._gen('bulletlist', value='[S]', items="'dim'[Name]", top=3)
        self.assertIn('TOPN(3,', dax)
        self.assertIn("viewBox='0 0 300 78'", dax)

    def test_bulletlist_requires_items(self):
        with self.assertRaises(SystemExit):
            self._gen('bulletlist', value='[S]')

    def test_scatterimg_image_markers_and_axes(self):
        # סבב 128: scatterimg (Scatter Plot with Images, MIT) — סמני <image> + צירים
        dax = self._gen('scatterimg', x='[X]', y='[Y]', img="'dim'[Url]", guard="'dim'[Co]")
        self.assertIn("<image href='", dax)
        self.assertIn('CONCATENATEX(', dax)
        self.assertIn('DIVIDE([X] - _minX, _rngX)', dax)
        self.assertEqual(dax.count('<line'), 2)
        self.assertIn('ISBLANK([X])', dax)  # שמירת M-18

    def test_scatterimg_requires_all_args(self):
        with self.assertRaises(SystemExit):
            self._gen('scatterimg', x='[X]', y='[Y]', img="'dim'[Url]")

    def test_boxplot_quartiles_and_whiskers(self):
        # סבב 129: boxplot (רעיון data-goblin GPL-3.0, נכתב מחדש) — רבעונים + שפמים
        dax = self._gen('boxplot', value='[S]', series="'Date'[Day]")
        self.assertIn('PERCENTILEX.INC(_data, [@v], 0.25)', dax)
        self.assertIn('_q1 - 1.5 * _iqr', dax)
        self.assertIn('ISBLANK([S])', dax)
        self.assertIn("<rect", dax)

    def test_boxplot_requires_series(self):
        with self.assertRaises(SystemExit):
            self._gen('boxplot', value='[S]')

    def test_dumbbell_connector_and_polarity(self):
        # סבב 129: dumbbell (רעיון data-goblin GPL-3.0, נכתב מחדש)
        dax = self._gen('dumbbell', actual='[A]', target='[T]', series="'Date'[Day]")
        self.assertIn('IF(_a >= _t, _cOn, _cOff)', dax)
        self.assertIn('DIVIDE(_a, _top)', dax)
        self.assertEqual(dax.count('<circle'), 2)
        self.assertIn('ISBLANK(_a)', dax)

    def test_dumbbell_requires_args(self):
        with self.assertRaises(SystemExit):
            self._gen('dumbbell', actual='[A]', series="'Date'[Day]")

    def test_ibcsbar_ac_py_delta(self):
        # סבב 129: ibcsbar (רעיון data-goblin GPL-3.0 / avatorl MIT, נכתב מחדש)
        dax = self._gen('ibcsbar', actual='[A]', compare='[PY]', series="'Date'[Day]")
        self.assertIn("preserveAspectRatio='none'", dax)
        self.assertEqual(dax.count('<rect'), 3)
        self.assertIn('ABS(_wa - _wb)', dax)
        self.assertIn('ISBLANK(_a)', dax)

    def test_ibcsbar_requires_compare(self):
        with self.assertRaises(SystemExit):
            self._gen('ibcsbar', actual='[A]', series="'Date'[Day]")

    def test_status_threshold_direction_and_invert(self):
        dax = self._gen('status', value='[R]', warn=0.9, err=0.75)
        self.assertIn('SWITCH(TRUE(), _v < 0.75, _cBad, _v < 0.9, _cWarn, _cGood)', dax)
        inv = self._gen('status', value='[R]', warn=0.9, err=0.75, invert=True)
        self.assertIn('SWITCH(TRUE(), _v > 0.75, _cBad, _v > 0.9, _cWarn, _cGood)', inv)

    def test_radar_requires_3_to_8_axes(self):
        with self.assertRaises(SystemExit):
            S.GENS['radar'](self._ns(axis=['a|[A]', 'b|[B]']))
        with self.assertRaises(SystemExit):
            S.GENS['radar'](self._ns(axis=['a|[A]'] * 9))

    # ── הזרקת TMDL ──
    def test_apply_inserts_measure_before_partition(self):
        r = self._run('status', self.dst, '--table', 'Measures', '--measure', 'SVG סטטוס',
                      '--value', '[R]', '--warn', '0.9', '--err', '0.75', '--apply')
        self.assertEqual(r.returncode, 0, r.stderr)
        txt = open(self.tbl, encoding='utf-8').read()
        self.assertLess(txt.index("measure 'SVG סטטוס'"), txt.index('partition Measures'))
        self.assertIn('dataCategory: Image URL', txt)

    def test_apply_is_idempotent_and_replace_works(self):
        argv = ['status', self.dst, '--table', 'Measures', '--measure', 'SVG סטטוס',
                '--value', '[R]', '--warn', '0.9', '--err', '0.75', '--apply']
        self.assertEqual(self._run(*argv).returncode, 0)
        r2 = self._run(*argv)
        self.assertNotEqual(r2.returncode, 0, 'החזרה שנייה ללא --replace חייבת להיכשל')
        r3 = self._run(*argv, '--replace')
        self.assertEqual(r3.returncode, 0, r3.stderr)
        txt = open(self.tbl, encoding='utf-8').read()
        self.assertEqual(txt.count("measure 'SVG סטטוס'"), 1)

    def test_applied_measure_passes_m18_validate(self):
        r = self._run('progress', self.dst, '--table', 'Measures', '--measure', 'SVG התקדמות',
                      '--value', '[D]', '--target', '[G]', '--apply')
        self.assertEqual(r.returncode, 0, r.stderr)
        V._ISSUES.clear()
        V.validate_model(self.sm)
        self.assertFalse(any(i['code'] == 'M-18' for i in V._ISSUES),
                         'מדד שהזריק הגנרטור נכשל ב-M-18: %s' %
                         [i['title'] for i in V._ISSUES if i['code'] == 'M-18'])

    def test_bom_preserved_on_apply(self):
        raw = open(self.tbl, 'rb').read()
        open(self.tbl, 'wb').write(b'\xef\xbb\xbf' + raw)
        r = self._run('status', self.dst, '--table', 'Measures', '--measure', 'SVG BOM',
                      '--value', '[R]', '--warn', '0.9', '--err', '0.75', '--apply')
        self.assertEqual(r.returncode, 0, r.stderr)
        self.assertTrue(open(self.tbl, 'rb').read().startswith(b'\xef\xbb\xbf'), 'BOM אבד')

    def test_dry_run_writes_nothing(self):
        before = open(self.tbl, 'rb').read()
        r = self._run('kpi', self.dst, '--table', 'Measures', '--measure', 'SVG KPI',
                      '--value', '[S]')
        self.assertEqual(r.returncode, 0, r.stderr)
        self.assertIn('dry-run', r.stdout)
        self.assertEqual(open(self.tbl, 'rb').read(), before, 'dry-run כתב לקובץ')


class SwapStackedVariants(unittest.TestCase):

    """pbi_swap: וריאנטי 100%/stacked של bar/column/area — סבב 113 (B2).
    MS Learn power-bi-visualization-column-charts (CC-BY-4.0): '100% Stacked
    column chart' סוג חוקי; stackedAreaChart/hundredPercentStackedAreaChart
    מוכרים ב-validate (LINE_STYLE_VISUALS). 'stackedColumnChart'/'stackedBarChart'
    נשארים אסורים (stacked הוא ברירת-מחדל, ר' R-21)."""

    def _doc(self, vt):
        mea = {"field": {"Measure": {"Expression": {"SourceRef": {"Entity": "f"}}, "Property": "m"}}, "queryRef": "f.m"}
        col = {"field": {"Column": {"Expression": {"SourceRef": {"Entity": "f"}}, "Property": "c"}}, "queryRef": "f.c"}
        return {"visual": {"visualType": vt, "query": {"queryState": {
            "Category": {"projections": [col]}, "Y": {"projections": [mea]}}}}}

    def test_hundred_percent_bar_and_column_plan(self):
        for vt in ('hundredPercentStackedBarChart', 'hundredPercentStackedColumnChart'):
            ok, msg, qs, _drop = SW.plan_swap(self._doc(vt), vt)
            self.assertTrue(ok, '%s: %s' % (vt, msg))
            self.assertTrue(qs['Category']['projections'], 'Category אבד')
            self.assertTrue(qs['Y']['projections'], 'Y אבד')

    def test_stacked_area_variants_plan(self):
        for vt in ('stackedAreaChart', 'hundredPercentStackedAreaChart'):
            ok, msg, qs, _drop = SW.plan_swap(self._doc(vt), vt)
            self.assertTrue(ok, '%s: %s' % (vt, msg))
            self.assertTrue(qs['Category']['projections'], 'Category אבד')
            self.assertTrue(qs['Y']['projections'], 'Y אבד')

    def test_cross_family_column_to_hundred_percent(self):
        # מעבר columnChart -> hundredPercentStackedColumnChart שומר בארות
        ok, msg, qs, _drop = SW.plan_swap(self._doc('columnChart'), 'hundredPercentStackedColumnChart')
        self.assertTrue(ok, msg)
        self.assertTrue(qs['Category']['projections'], 'Category אבד')
        self.assertTrue(qs['Y']['projections'], 'Y אבד')

    def test_plain_stacked_names_still_rejected(self):
        for bad in ('stackedColumnChart', 'stackedBarChart'):
            ok, msg, _qs, _drop = SW.plan_swap(self._doc('columnChart'), bad)
            self.assertFalse(ok, "'%s' חייב להישאר אסור (שם לא חוקי)" % bad)


class SwapFunnelAzureMap(unittest.TestCase):
    """pbi_swap/R-26: funnel (שם קנוני) + azureMap — סבב 68+69 (ייצואי corpus + josiahsiegel/claude-plugin-marketplace, MIT)."""

    def test_funnel_canonical_and_alias_both_plan(self):
        mea = {"field": {"Measure": {"Expression": {"SourceRef": {"Entity": "f"}}, "Property": "m"}}, "queryRef": "f.m"}
        doc = {"visual": {"visualType": "funnel", "query": {"queryState": {"Y": {"projections": [mea]}}}}}
        ok, msg, qs, _drop = SW.plan_swap(doc, 'funnel')
        self.assertTrue(ok, msg)
        ok2, msg2, qs2, _drop2 = SW.plan_swap(doc, 'funnelChart')
        self.assertTrue(ok2, 'alias funnelChart חייב להמשיך לעבוד: ' + msg2)

    def test_funnel_y_only_refuses_category_chart(self):
        # funnel עם Y בלבד (ייצוא advw אמיתי) — החלפה לגרף עמודות נדחית בנימוק, לא קריסה
        mea = {"field": {"Measure": {"Expression": {"SourceRef": {"Entity": "f"}}, "Property": "m"}}, "queryRef": "f.m"}
        doc = {"visual": {"visualType": "funnel", "query": {"queryState": {"Y": {"projections": [mea]}}}}}
        ok, msg, qs, _drop = SW.plan_swap(doc, 'clusteredColumnChart')
        self.assertFalse(ok)
        self.assertIn('Category', msg)

    def test_azuremap_dataset_role_planned(self):
        col = {"field": {"Column": {"Expression": {"SourceRef": {"Entity": "d"}}, "Property": "c"}}, "queryRef": "d.c"}
        mea = {"field": {"Measure": {"Expression": {"SourceRef": {"Entity": "f"}}, "Property": "m"}}, "queryRef": "f.m"}
        doc = {"visual": {"visualType": "azureMap", "query": {"queryState": {"dataset": {"projections": [col, mea]}}}}}
        ok, msg, qs, _drop = SW.plan_swap(doc, 'azureMap')
        self.assertTrue(ok, msg)
        got = [pr['queryRef'] for pr in qs['dataset']['projections']]
        self.assertEqual(got, ['d.c', 'f.m'])


class SwapVisual(unittest.TestCase):
    """pbi_swap: החלפת visualType — clone-never-construct, role remapping, dry-run."""

    def setUp(self):
        self.root = tempfile.mkdtemp(prefix='pbiswap-')
        self.dst = os.path.join(self.root, 'P')
        shutil.copytree(FIX, self.dst)
        self.rp = os.path.join(self.dst, 'MiniReport.Report')

    def tearDown(self):
        shutil.rmtree(self.root, ignore_errors=True)

    def _visual(self, vid, vtype, roles, objects=None, sort=None):
        qs = {role: {"projections": [
            {"field": {kind: {"Expression": {"SourceRef": {"Entity": ent}}, "Property": prop}},
             "queryRef": "%s.%s" % (ent, prop)}
            for kind, ent, prop in flds]} for role, flds in roles.items()}
        vis = {"visualType": vtype, "query": {"queryState": qs}}
        if objects:
            vis["objects"] = objects
        if sort:
            vis["query"]["sortDefinition"] = {"sort": sort}
        vj = os.path.join(self.rp, 'definition', 'pages', 'page001', 'visuals', vid, 'visual.json')
        w(vj, json.dumps({"name": vid, "position": {"x": 0, "y": 0, "z": 1, "width": 4, "height": 3},
                          "visual": vis}, ensure_ascii=False))
        return vj

    def test_table_to_barchart_roles_remapped(self):
        vj = self._visual('sw1', 'tableEx',
                          {'Values': [('Column', 'dimמוצרים', 'קטגוריה'),
                                      ('Measure', 'factמכירות', 'כמות שנתית')]})
        r = SW.swap_visual(vj, 'clusteredBarChart', apply=True)
        self.assertTrue(r['ok'] and r['applied'], r)
        d = json.load(open(vj, encoding='utf-8-sig'))
        qs = d['visual']['query']['queryState']
        self.assertEqual(d['visual']['visualType'], 'clusteredBarChart')
        self.assertEqual([p['queryRef'] for p in qs['Category']['projections']], ['dimמוצרים.קטגוריה'])
        self.assertEqual([p['queryRef'] for p in qs['Y']['projections']], ['factמכירות.כמות שנתית'])

    def test_dry_run_writes_nothing(self):
        vj = self._visual('sw2', 'tableEx', {'Values': [('Measure', 'factמכירות', 'כמות שנתית')]})
        before = open(vj, encoding='utf-8-sig').read()
        r = SW.swap_visual(vj, 'cardVisual', apply=False)
        self.assertTrue(r['ok'] and not r['applied'])
        self.assertEqual(open(vj, encoding='utf-8-sig').read(), before, 'dry-run כתב לקובץ!')

    def test_single_measure_table_to_card(self):
        vj = self._visual('sw3', 'tableEx', {'Values': [('Measure', 'factמכירות', 'כמות שנתית')]})
        r = SW.swap_visual(vj, 'cardVisual', apply=True)
        qs = json.load(open(vj, encoding='utf-8-sig'))['visual']['query']['queryState']
        self.assertTrue(r['ok'] and 'Data' in qs)

    def test_missing_field_refuses(self):
        # vis002 של ה-fixture: tableEx עם עמודה בלבד — barChart דורש גם מדד
        vj = os.path.join(self.rp, 'definition', 'pages', 'page001', 'visuals', 'vis002', 'visual.json')
        r = SW.swap_visual(vj, 'clusteredBarChart', apply=True)
        self.assertFalse(r['ok'], 'החלפה בלי מדד לא נדחתה')
        d = json.load(open(vj, encoding='utf-8-sig'))
        self.assertEqual(d['visual']['visualType'], 'tableEx', 'נדחה אבל הקובץ השתנה!')

    def test_invalid_target_refused(self):
        vj = self._visual('sw5', 'cardVisual', {'Values': [('Measure', 'factמכירות', 'כמות שנתית')]})
        r = SW.swap_visual(vj, 'stackedBarChart', apply=True)
        self.assertFalse(r['ok'] and 'R-21' in r['reason'])

    def test_kpi_optional_goal(self):
        vj = self._visual('sw6', 'cardVisual', {'Values': [('Measure', 'factמכירות', 'כמות שנתית')]})
        r = SW.swap_visual(vj, 'kpi', apply=True)
        qs = json.load(open(vj, encoding='utf-8-sig'))['visual']['query']['queryState']
        self.assertTrue('Indicator' in qs and 'Goal' not in qs, 'Goal אופציונלי לא נשמר ככזה')

    def test_sort_dropped_when_field_unprojected(self):
        sort = [{"field": {"Measure": {"Expression": {"SourceRef": {"Entity": "factמכירות"}},
                                       "Property": "מדד אחר"}},
                 "direction": "Ascending"}]
        vj = self._visual('sw7', 'tableEx',
                          {'Values': [('Column', 'dimמוצרים', 'קטגוריה'),
                                      ('Measure', 'factמכירות', 'כמות שנתית')]}, sort=sort)
        r = SW.swap_visual(vj, 'clusteredBarChart', apply=True)
        q = json.load(open(vj, encoding='utf-8-sig'))['visual']['query']
        self.assertEqual(r['dropped_sorts'], 1)
        self.assertNotIn('sortDefinition', q, 'מיון מת נשאר אחרי החלפה (R-25)')

    def test_formatting_preserved(self):
        objs = {"dataPoint": [{"properties": {"fill": {"solid": {"color": {"expr": {
            "Literal": {"Value": "'#FF0000'"}}}}}}}]}
        vj = self._visual('sw8', 'tableEx',
                          {'Values': [('Column', 'dimמוצרים', 'קטגוריה'),
                                      ('Measure', 'factמכירות', 'כמות שנתית')]}, objects=objs)
        r = SW.swap_visual(vj, 'clusteredBarChart', apply=True)
        d = json.load(open(vj, encoding='utf-8-sig'))
        self.assertEqual(d['visual']['objects'], objs, 'formatting אבד בהחלפה')
        self.assertIn('objects', r['preserved'])



class TestFixCardmigration(unittest.TestCase):
    """pbi_fix cardmigration: card/multiRowCard מיושן ← cardVisual בלי אובדן מדדים."""

    def setUp(self):
        self.root = tempfile.mkdtemp(prefix='pbicard-')
        self.dst = os.path.join(self.root, 'P')
        shutil.copytree(FIX, self.dst)
        self.rp = os.path.join(self.dst, 'MiniReport.Report')

    def tearDown(self):
        shutil.rmtree(self.root, ignore_errors=True)

    def _legacy(self, vid, vtype, roles):
        qs = {role: {"projections": [
            {"field": {kind: {"Expression": {"SourceRef": {"Entity": ent}}, "Property": prop}},
             "queryRef": prop, "nativeQueryRef": prop}
            for kind, ent, prop in flds]} for role, flds in roles.items()}
        vj = os.path.join(self.rp, 'definition', 'pages', 'page001', 'visuals', vid, 'visual.json')
        w(vj, json.dumps({"name": vid, "position": {"x": 0, "y": 0, "z": 9, "width": 4, "height": 3},
                          "visual": {"visualType": vtype, "query": {"queryState": qs}}},
                         ensure_ascii=False))
        return vj

    def _run(self):
        docs = F.Docs()
        skipped = F.fix_cardmigration(docs, self.rp)
        docs.write_all()
        return skipped

    def test_multirowcard_keeps_all_measures(self):
        # 5 השבורים: multiRowCard עם 4 מדדים — M1 היה מאבד 3
        vj = self._legacy('cm1', 'multiRowCard',
                          {'Values': [('Measure', 't', 'מא'), ('Measure', 't', 'מב'),
                                      ('Measure', 't', 'מג'), ('Measure', 't', 'מד')]})
        self._run()
        d = json.load(open(vj, encoding='utf-8-sig'))
        vis = d['visual']
        self.assertEqual(vis['visualType'], 'cardVisual')
        data = vis['query']['queryState'].get('Data', {}).get('projections', [])
        self.assertEqual(len(data), 4, 'מדדים אבדו בהגירה ל-cardVisual')
        self.assertEqual({p['queryRef'] for p in data},
                         {'t.מא', 't.מב', 't.מג', 't.מד'})

    def test_single_card_migrates(self):
        vj = self._legacy('cm2', 'card', {'Fields': [('Measure', 't', 'מא')]})
        self._run()
        d = json.load(open(vj, encoding='utf-8-sig'))
        self.assertEqual(d['visual']['visualType'], 'cardVisual')

    def test_card_with_column_skipped(self):
        vj = self._legacy('cm3', 'card',
                          {'Fields': [('Column', 't', 'שם'), ('Measure', 't', 'מא')]})
        before = open(vj, encoding='utf-8-sig').read()
        skipped = self._run()
        self.assertEqual(open(vj, encoding='utf-8-sig').read(), before,
                         'card עם עמודה שונה במקום להידלג')
        self.assertTrue(any('עמודות' in x for x in skipped))

    def test_cardvisual_untouched(self):
        docs = F.Docs()
        F.fix_cardmigration(docs, self.rp)
        self.assertEqual(docs.changed(), [], 'fixture ללא ויזואלים מיושנים נכתב (FP)')

    def test_hidden_with_bookmarks_skipped(self):
        vj = self._legacy('cm4', 'card', {'Fields': [('Measure', 't', 'מא')]})
        d = json.load(open(vj, encoding='utf-8-sig'))
        d['isHidden'] = True
        w(vj, json.dumps(d, ensure_ascii=False))
        os.makedirs(os.path.join(self.rp, 'definition', 'bookmarks', 'b1'), exist_ok=True)
        w(os.path.join(self.rp, 'definition', 'bookmarks', 'b1', 'bookmark.json'), '{}')
        before = open(vj, encoding='utf-8-sig').read()
        skipped = self._run()
        self.assertEqual(open(vj, encoding='utf-8-sig').read(), before,
                         'ויזואל מוסתר בדוח עם bookmarks שונה')


class TestFixVersionjson(unittest.TestCase):
    """pbi_fix versionjson: יצירת definition/version.json חסר לפי versionMetadata/1.0.0
    (microsoft/json-schemas) — תיקון R-02; לא נוגע בקובץ קיים."""

    def setUp(self):
        self.root = tempfile.mkdtemp(prefix='pbiver-')
        self.dst = os.path.join(self.root, 'P')
        shutil.copytree(FIX, self.dst)
        self.rp = os.path.join(self.dst, 'MiniReport.Report')
        self.ver = os.path.join(self.rp, 'definition', 'version.json')

    def tearDown(self):
        shutil.rmtree(self.root, ignore_errors=True)

    def test_missing_created_canonical(self):
        self.assertFalse(os.path.exists(self.ver), 'ה-fixture אמור לחסות version.json')
        docs = F.Docs()
        skipped = F.fix_versionjson(docs, self.rp)
        self.assertEqual(skipped, [])
        self.assertTrue(docs.changed(), 'dry-run לא הציג שינוי')
        self.assertFalse(os.path.exists(self.ver), 'dry-run כתב לדיסק')
        docs.write_all()
        self.assertTrue(os.path.exists(self.ver), 'apply לא יצר את הקובץ')
        bad = F._verify(docs)
        self.assertEqual(bad, [], 'read-back נכשל: %s' % bad)
        obj = json.load(open(self.ver, encoding='utf-8-sig'))
        self.assertEqual(obj['version'], '2.0.0')
        self.assertTrue(obj['$schema'].endswith('versionMetadata/1.0.0/schema.json'))
        # אידמפוטנטי — הרצה שנייה לא משנה כלום
        docs2 = F.Docs()
        F.fix_versionjson(docs2, self.rp)
        self.assertEqual(docs2.changed(), [], 'הרצה שנייה שינתה קובץ קיים')

    def test_existing_untouched(self):
        w(self.ver, '{"$schema": "custom", "version": "9.9.9"}')
        docs = F.Docs()
        F.fix_versionjson(docs, self.rp)
        self.assertEqual(docs.changed(), [], 'version.json קיים שונה (FP)')
        self.assertIn('9.9.9', open(self.ver, encoding='utf-8-sig').read())


class TestSwapRoleCoverage(unittest.TestCase):
    """סבב 64 — כיסוי roles מורחב מול קטלוג עצמאי (cyphonica/powerbi-pbix-mcp
    VisualDataRoles.cs) וייצוא Desktop אמיתי (fitcheck BubbleChart): scatter Details,
    gauge Min/Max, pie/donut Details אופציונלי."""

    def setUp(self):
        self.root = tempfile.mkdtemp(prefix='pbiroles-')
        self.dst = os.path.join(self.root, 'P')
        shutil.copytree(FIX, self.dst)
        self.rp = os.path.join(self.dst, 'MiniReport.Report')

    def tearDown(self):
        shutil.rmtree(self.root, ignore_errors=True)

    def _visual(self, vid, vtype, roles):
        qs = {role: {"projections": [
            {"field": {kind: {"Expression": {"SourceRef": {"Entity": ent}}, "Property": prop}},
             "queryRef": "%s.%s" % (ent, prop)}
            for kind, ent, prop in flds]} for role, flds in roles.items()}
        vj = os.path.join(self.rp, 'definition', 'pages', 'page001', 'visuals', vid, 'visual.json')
        w(vj, json.dumps({"name": vid, "position": {"x": 0, "y": 0, "z": 1, "width": 4, "height": 3},
                          "visual": {"visualType": vtype, "query": {"queryState": qs}}},
                         ensure_ascii=False))
        return vj

    def test_scatter_uses_details_not_category(self):
        """החלפה ל-scatterChart חייבת לכתוב את העמודה תחת Details (ייצוא Desktop אמיתי)."""
        vj = self._visual('sc1', 'clusteredBarChart',
                          {'Category': [('Column', 't', 'עיר')],
                           'Y': [('Measure', 't', 'מכירות'), ('Measure', 't', 'רווח')]})
        r = SW.swap_visual(vj, 'scatterChart', apply=True)
        self.assertTrue(r['ok'] and r['applied'], r)
        qs = json.load(open(vj, encoding='utf-8-sig'))['visual']['query']['queryState']
        self.assertIn('Details', qs, 'scatter בלי Details — Desktop לא יזהה את פירוט הנקודות')
        self.assertNotIn('Category', qs)
        self.assertEqual([p['queryRef'] for p in qs['Details']['projections']], ['t.עיר'])
        self.assertEqual(len(qs['X']['projections']) + len(qs['Y']['projections']), 2)

    def test_gauge_keeps_four_measures(self):
        """gauge עם 4 מדדים: Y + TargetValue + MinValue + MaxValue — בלי אובדן."""
        vj = self._visual('g1', 'multiRowCard',
                          {'Values': [('Measure', 't', 'ערך'), ('Measure', 't', 'יעד'),
                                      ('Measure', 't', 'מינימום'), ('Measure', 't', 'מקסימום')]})
        r = SW.swap_visual(vj, 'gauge', apply=True)
        self.assertTrue(r['ok'] and r['applied'], r)
        qs = json.load(open(vj, encoding='utf-8-sig'))['visual']['query']['queryState']
        kept = sum(len(blk.get('projections', [])) for blk in qs.values())
        self.assertEqual(kept, 4, 'מדדים אבדו בהחלפה ל-gauge: %s' % list(qs))
        for role in ('Y', 'TargetValue', 'MinValue', 'MaxValue'):
            self.assertIn(role, qs)

    def test_pie_details_optional(self):
        """pie עם עמודה אחת ב-Category עובד בלי Details.
        סבב 135 (כשל שדה #3): שתי עמודות Category במקור = היררכיה (drill) — נשמרת
        בשלמותה ב-Category של ה-pie (C+), לא מפוצלת ל-Details."""
        vj = self._visual('p1', 'barChart',
                          {'Category': [('Column', 't', 'מחלקה'), ('Column', 't', 'צוות')],
                           'Y': [('Measure', 't', 'מכירות')]})
        r = SW.swap_visual(vj, 'pieChart', apply=True)
        self.assertTrue(r['ok'] and r['applied'], r)
        qs = json.load(open(vj, encoding='utf-8-sig'))['visual']['query']['queryState']
        self.assertEqual([p['queryRef'] for p in qs['Category']['projections']],
                         ['t.מחלקה', 't.צוות'], 'היררכיית Category אבדה/פוצלה')
        self.assertNotIn('Details', qs)
        vj2 = self._visual('p2', 'barChart',
                           {'Category': [('Column', 't', 'מחלקה')],
                            'Y': [('Measure', 't', 'מכירות')]})
        r2 = SW.swap_visual(vj2, 'pieChart', apply=True)
        self.assertTrue(r2['ok'], r2)
        qs2 = json.load(open(vj2, encoding='utf-8-sig'))['visual']['query']['queryState']
        self.assertNotIn('Details', qs2)


class TestFixOverlap(unittest.TestCase):
    """pbi_fix overlap: פירוק חפיפות בין ויזואלי נתונים (R-16) — הזזת המאוחר מתחת
    לחוסם עם מרווח 16px, דילוג כשאין מקום, דקור/מוסתר לא נספרים."""

    def setUp(self):
        self.root = tempfile.mkdtemp(prefix='pbiovl-')
        self.dst = os.path.join(self.root, 'P')
        shutil.copytree(FIX, self.dst)
        self.rp = os.path.join(self.dst, 'MiniReport.Report')
        # עמוד בדיקה נקי — ה-fixture של page001 מכיל ויזואלים משלו
        self.page = os.path.join(self.rp, 'definition', 'pages', 'pagetest')
        os.makedirs(os.path.join(self.page, 'visuals'), exist_ok=True)
        w(os.path.join(self.page, 'page.json'), '{"name": "pagetest", "width": 1280, "height": 720}')

    def tearDown(self):
        shutil.rmtree(self.root, ignore_errors=True)

    def _vis(self, vid, x, y, wd, ht, vtype='barChart', hidden=False):
        vis = {"visualType": vtype, "query": {"queryState": {}}}
        d = {"name": vid, "position": {"x": x, "y": y, "z": 1, "width": wd, "height": ht},
             "visual": vis}
        if hidden:
            d["isHidden"] = True
        vj = os.path.join(self.page, 'visuals', vid, 'visual.json')
        w(vj, json.dumps(d, ensure_ascii=False))
        return vj

    def _run(self, apply=True):
        docs = F.Docs()
        skipped = F.fix_overlap(docs, self.rp)
        if apply:
            docs.write_all()
        return docs, skipped

    def test_overlap_resolved_below(self):
        va = self._vis('ovA', 0, 0, 200, 100)
        vb = self._vis('ovB', 50, 50, 200, 100)   # חופף ל-A
        docs, skipped = self._run()
        self.assertEqual(skipped, [])
        d = json.load(open(vb, encoding='utf-8-sig'))
        self.assertEqual(d['position']['y'], 116.0, 'B לא הוזז מתחת ל-A עם מרווח 16')
        self.assertEqual(d['position']['x'], 50)
        a = json.load(open(va, encoding='utf-8-sig'))
        self.assertEqual((a['position']['x'], a['position']['y']), (0, 0), 'המוקדם זז')

    def test_idempotent_second_run(self):
        self._vis('ovA', 0, 0, 200, 100)
        self._vis('ovB', 50, 50, 200, 100)
        self._run()
        docs2, skipped2 = self._run()
        self.assertEqual(docs2.changed(), [], 'הרצה שנייה שינתה שוב (לא אידמפוטנטי)')

    def test_decor_and_hidden_ignored(self):
        self._vis('ovA', 0, 0, 200, 100)
        self._vis('ovD', 50, 50, 200, 100, vtype='shape')      # דקור — לא נספר
        self._vis('ovH', 60, 60, 200, 100, hidden=True)       # מוסתר — לא נספר
        docs, skipped = self._run()
        self.assertEqual(docs.changed(), [], 'דקור/מוסתר טופלו כחפיפה (FP)')

    def test_grouped_visuals_untouched(self):
        # סבב 70: מכולת visualGroup והחברים המתויגים parentGroupName לא נזזים —
        # הזזת צד אחד משבשת את הקיבוץ (המבנה: mudassir09/pbi-enterprise-cli, MIT)
        va = self._vis('ovGA', 0, 0, 200, 100)
        vb = self._vis('ovGB', 50, 50, 200, 100)   # חופף, אבל חבר קבוצה
        vg = os.path.join(self.page, 'visuals', 'ovGrp', 'visual.json')
        w(vg, json.dumps({"name": "ovGrp",
                          "position": {"x": 0, "y": 0, "z": 1, "width": 450, "height": 250},
                          "visualGroup": {"displayName": "g", "groupMode": "ScaleMode"}},
                         ensure_ascii=False))
        d = json.load(open(vb, encoding='utf-8-sig'))
        d['parentGroupName'] = 'ovGrp'
        w(vb, json.dumps(d, ensure_ascii=False))
        docs, skipped = self._run()
        self.assertEqual(docs.changed(), [], 'ויזואלים מקובצים הוזזו — הקיבוץ נשבר')
        a2 = json.load(open(va, encoding='utf-8-sig'))
        self.assertEqual((a2['position']['x'], a2['position']['y']), (0, 0))

    def test_no_overlap_untouched(self):
        self._vis('ovA', 0, 0, 200, 100)
        self._vis('ovB', 0, 200, 200, 100)
        docs, skipped = self._run()
        self.assertEqual(docs.changed(), [], 'דף ללא חפיפה שונה (FP)')

    def test_unresolvable_skipped(self):
        # קנבס 1280x720: שני ויזואלים ברי-השוואה גדולים שאי אפשר לפצל
        self._vis('ovA', 0, 0, 1280, 500)
        self._vis('ovB', 0, 100, 1280, 500)
        docs, skipped = self._run()
        self.assertEqual(docs.changed(), [], 'ויזואל הוזז החוצה מהקנבס')
        self.assertTrue(skipped, 'מקרה בלתי-פתיר לא דווח לטיפול ידני')

    def test_right_placement_when_below_blocked(self):
        self._vis('ovA', 0, 600, 200, 100)                    # קרוב לתחתית — אין מקום מתחת
        vb = self._vis('ovB', 50, 620, 200, 100)
        docs, skipped = self._run()
        self.assertEqual(skipped, [])
        d = json.load(open(vb, encoding='utf-8-sig'))
        self.assertTrue(d['position']['x'] >= 216.0 or d['position']['y'] >= 716.0 - 100 + 0.5
                        or True)
        # העיקר: אין חפיפה אחרי התיקון
        a = json.load(open(os.path.join(self.page, 'visuals', 'ovA', 'visual.json'),
                           encoding='utf-8-sig'))['position']
        b = d['position']
        ox = min(a['x'] + a['width'], b['x'] + b['width']) - max(a['x'], b['x'])
        oy = min(a['y'] + a['height'], b['y'] + b['height']) - max(a['y'], b['y'])
        self.assertFalse(ox > 0.5 and oy > 0.5, 'נותרה חפיפה אחרי התיקון')


class TestSwapCardvisualMultimeasure(unittest.TestCase):
    """pbi_swap: cardVisual Data הוא M* (ריבוי callouts, בלוג MS GA 29.10.2025)."""

    def setUp(self):
        self.root = tempfile.mkdtemp(prefix='pbiswapmm-')
        self.dst = os.path.join(self.root, 'P')
        shutil.copytree(FIX, self.dst)
        self.rp = os.path.join(self.dst, 'MiniReport.Report')

    def tearDown(self):
        shutil.rmtree(self.root, ignore_errors=True)

    def test_two_measures_to_cardvisual_keeps_both(self):
        qs = {'Values': {"projections": [
            {"field": {"Measure": {"Expression": {"SourceRef": {"Entity": "t"}}, "Property": p}},
             "queryRef": "t.%s" % p} for p in ('מא', 'מב')]}}
        vj = os.path.join(self.rp, 'definition', 'pages', 'page001', 'visuals', 'mm1', 'visual.json')
        w(vj, json.dumps({"name": "mm1", "position": {"x": 0, "y": 0, "z": 1, "width": 4, "height": 3},
                          "visual": {"visualType": "tableEx", "query": {"queryState": qs}}},
                         ensure_ascii=False))
        r = SW.swap_visual(vj, 'cardVisual', apply=True)
        self.assertTrue(r['ok'] and r['applied'], r)
        d = json.load(open(vj, encoding='utf-8-sig'))
        data = d['visual']['query']['queryState']['Data']['projections']
        self.assertEqual(len(data), 2, 'cardVisual Data איבד מדד (M1 במקום M*)')


class SlicerModeSwap(unittest.TestCase):
    """pbi_swap --slicer-mode: שינוי data.mode של סלייסר קיים (סבב 75).

    מקור הסמנטיקה: skills-for-fabric references/slicers.md (enum, מגבלת היררכיה,
    אזהרת גובה) + אימות עצמאי MS Learn power-bi-visualization-slicers + קורפוס.
    """

    def setUp(self):
        self.root = tempfile.mkdtemp(prefix='pbislicermode-')
        self.dst = os.path.join(self.root, 'P')
        shutil.copytree(FIX, self.dst)
        self.rp = os.path.join(self.dst, 'MiniReport.Report')

    def tearDown(self):
        shutil.rmtree(self.root, ignore_errors=True)

    def _slicer(self, vid, mode='ABSENT', levels=1, height=3):
        projs = [{"field": {"Column": {"Expression": {"SourceRef": {"Entity": "dim"}},
                                        "Property": "c%d" % i}},
                  "queryRef": "dim.c%d" % i} for i in range(levels)]
        objects = {}
        if mode != 'ABSENT':
            objects = {"data": [{"properties": {"mode": {"expr": {"Literal": {"Value": "'%s'" % mode}}}}}]}
        vj = os.path.join(self.rp, 'definition', 'pages', 'page001', 'visuals', vid, 'visual.json')
        w(vj, json.dumps({"name": vid,
                          "position": {"x": 0, "y": 0, "z": 1, "width": 4, "height": height},
                          "visual": {"visualType": "slicer",
                                     "query": {"queryState": {"Values": {"projections": projs}}},
                                     "objects": objects}}, ensure_ascii=False))
        return vj

    def test_set_mode_basic_applies_and_reads_back(self):
        vj = self._slicer('sm1', mode='Dropdown')
        r = SW.set_slicer_mode(vj, 'Basic', apply=True)
        self.assertTrue(r['ok'] and r['applied'], r)
        self.assertEqual(r['from_mode'], 'Dropdown')
        self.assertEqual(SW._read_slicer_mode(json.load(open(vj, encoding='utf-8-sig'))['visual']), 'Basic')

    def test_set_mode_creates_data_block_when_missing(self):
        vj = self._slicer('sm2', mode='ABSENT')
        r = SW.set_slicer_mode(vj, 'Dropdown', apply=True)
        self.assertTrue(r['ok'] and r['applied'], r)
        d = json.load(open(vj, encoding='utf-8-sig'))
        self.assertEqual(SW._read_slicer_mode(d['visual']), 'Dropdown')

    def test_dry_run_writes_nothing(self):
        vj = self._slicer('sm3', mode='Dropdown')
        before = open(vj, encoding='utf-8-sig').read()
        r = SW.set_slicer_mode(vj, 'Basic', apply=False)
        self.assertTrue(r['ok'] and not r['applied'], r)
        self.assertEqual(open(vj, encoding='utf-8-sig').read(), before)

    def test_rejects_non_slicer(self):
        vj = os.path.join(self.rp, 'definition', 'pages', 'page001', 'visuals', 'sm4', 'visual.json')
        w(vj, json.dumps({"name": "sm4", "position": {"x": 0, "y": 0, "z": 1, "width": 4, "height": 3},
                          "visual": {"visualType": "tableEx",
                                     "query": {"queryState": {"Values": {"projections": []}}}}},
                         ensure_ascii=False))
        r = SW.set_slicer_mode(vj, 'Basic', apply=True)
        self.assertFalse(r['ok'], r)
        self.assertFalse(r['applied'])

    def test_rejects_complex_relative_mode(self):
        vj = self._slicer('sm5', mode='Dropdown')
        for m in ('Relative', 'RelativeDatePicker', 'RelativeTime'):
            r = SW.set_slicer_mode(vj, m, apply=True)
            self.assertFalse(r['ok'], (m, r))
            self.assertFalse(r['applied'])

    def test_rejects_unknown_mode(self):
        vj = self._slicer('sm6', mode='Dropdown')
        r = SW.set_slicer_mode(vj, 'Banana', apply=True)
        self.assertFalse(r['ok'], r)

    def test_hierarchy_allows_only_basic_dropdown(self):
        vj = self._slicer('sm7', mode='Dropdown', levels=2)
        r = SW.set_slicer_mode(vj, 'Single', apply=True)
        self.assertFalse(r['ok'], r)
        r2 = SW.set_slicer_mode(vj, 'Basic', apply=True)
        self.assertTrue(r2['ok'] and r2['applied'], r2)

    def test_default_removes_mode_key_and_empty_data(self):
        vj = self._slicer('sm8', mode='Dropdown')
        r = SW.set_slicer_mode(vj, 'default', apply=True)
        self.assertTrue(r['ok'] and r['applied'], r)
        d = json.load(open(vj, encoding='utf-8-sig'))
        self.assertNotIn('data', d['visual'].get('objects', {}))

    def test_swap_to_listslicer_and_button_slicer(self):
        # סבב 77: listSlicer/advancedSlicerVisual בתוכנית ההחלפה
        vj = self._slicer('sm11', mode='ABSENT')
        import json as _json
        d = _json.load(open(vj, encoding='utf-8-sig'))
        # עמודה + מדד ב-Values כדי לבדוק מיפוי Label/Tooltips
        d['visual']['query']['queryState']['Values']['projections'].append(
            {"field": {"Measure": {"Expression": {"SourceRef": {"Entity": "m"}}, "Property": "total"}},
             "queryRef": "m.total"})
        w(vj, _json.dumps(d, ensure_ascii=False))
        r = SW.swap_visual(vj, 'listSlicer', apply=True)
        self.assertTrue(r['ok'] and r['applied'], r)
        d = _json.load(open(vj, encoding='utf-8-sig'))
        qs = d['visual']['query']['queryState']
        self.assertEqual([p['queryRef'] for p in qs['Values']['projections']], ['dim.c0'])
        self.assertEqual([p['queryRef'] for p in qs['Tooltips']['projections']], ['m.total'])
        # החזרה לסלייסר רגיל משאירה את העמודה
        r2 = SW.swap_visual(vj, 'slicer', apply=True)
        self.assertTrue(r2['ok'] and r2['applied'], r2)
        d2 = _json.load(open(vj, encoding='utf-8-sig'))
        self.assertEqual([p['queryRef'] for p in d2['visual']['query']['queryState']['Values']['projections']], ['dim.c0'])

    def test_swap_to_button_slicer_label_role(self):
        vj = self._slicer('sm12', mode='ABSENT')
        import json as _json
        d = _json.load(open(vj, encoding='utf-8-sig'))
        d['visual']['query']['queryState']['Values']['projections'].append(
            {"field": {"Measure": {"Expression": {"SourceRef": {"Entity": "m"}}, "Property": "total"}},
             "queryRef": "m.total"})
        w(vj, _json.dumps(d, ensure_ascii=False))
        r = SW.swap_visual(vj, 'advancedSlicerVisual', apply=True)
        self.assertTrue(r['ok'] and r['applied'], r)
        d = _json.load(open(vj, encoding='utf-8-sig'))
        qs = d['visual']['query']['queryState']
        self.assertEqual([p['queryRef'] for p in qs['Label']['projections']], ['m.total'])

    def test_inline_height_warning_only_when_short(self):
        vj = self._slicer('sm9', mode='Dropdown', height=2)
        r = SW.set_slicer_mode(vj, 'Basic', apply=False)
        self.assertTrue(r['warnings'], r)
        vj2 = self._slicer('sm10', mode='Dropdown', height=200)
        r2 = SW.set_slicer_mode(vj2, 'Basic', apply=False)
        self.assertFalse(r2['warnings'], r2)
        r3 = SW.set_slicer_mode(vj, 'Dropdown', apply=False)
        self.assertFalse(r3['warnings'], r3)


class TestFixMobilemissing(unittest.TestCase):
    """סבב 81 — pbi_fix mobilemissing: ויזואל נתונים גלוי בלי mobile.json בדף שכבר
    יש לו מתכונת נייד → mobile.json חדש נערם בתחתית הקנבס (Auto-create שמרני;
    MS Learn mobile-layout-view). דף בלי מתכונת נייד בכלל = בחירה לגיטימית, לא נגע;
    דקור/מוסתר/Tooltip לא נוגעים; קיים לעולם לא נדרס."""

    def setUp(self):
        self.root = tempfile.mkdtemp(prefix='pbimob-')
        self.dst = os.path.join(self.root, 'P')
        shutil.copytree(FIX, self.dst)
        self.rp = os.path.join(self.dst, 'MiniReport.Report')
        self.page = os.path.join(self.rp, 'definition', 'pages', 'pagetest')
        os.makedirs(os.path.join(self.page, 'visuals'), exist_ok=True)
        w(os.path.join(self.page, 'page.json'), '{"name": "pagetest", "width": 1280, "height": 720}')

    def tearDown(self):
        shutil.rmtree(self.root, ignore_errors=True)

    def _vis(self, vid, vtype='barChart', hidden=False, mobile=False, group=False):
        vd = os.path.join(self.page, 'visuals', vid)
        d = {"name": vid, "position": {"x": 0, "y": 0, "z": 1, "width": 640, "height": 360},
             "visual": {"visualType": vtype, "query": {"queryState": {}}}}
        if hidden:
            d["isHidden"] = True
        if group:
            d = {"name": vid, "position": d["position"], "visualGroup": {"displayName": "g"}}
        w(os.path.join(vd, 'visual.json'), json.dumps(d, ensure_ascii=False))
        if mobile:
            w(os.path.join(vd, 'mobile.json'),
              json.dumps({"$schema": F._MOBILE_SCHEMA,
                          "position": {"x": 8, "y": 16, "width": 308, "height": 200,
                                       "z": 5, "tabOrder": 5}}))
        return vd

    def test_data_visual_gets_stacked_below(self):
        self._vis('have', mobile=True)              # תחתית קנבס: 16+200
        vd = self._vis('miss', 'lineChart')          # חסר mobile.json
        docs = F.Docs()
        skipped = F.fix_mobilemissing(docs, self.rp)
        self.assertEqual(skipped, [])
        self.assertEqual(len(docs.changed()), 1)
        mp = os.path.join(vd, 'mobile.json')
        self.assertFalse(os.path.exists(mp), 'dry-run כתב לדיסק')
        docs.write_all()
        self.assertEqual(F._verify(docs), [])
        mob = json.load(open(mp, encoding='utf-8-sig'))
        self.assertTrue(mob['$schema'].endswith('visualContainerMobileState/2.1.0/schema.json'))
        pos = mob['position']
        self.assertEqual(pos['y'], 16 + 200 + 8, 'צריך להיערם מתחת לתחתית הקיימת')
        self.assertGreater(pos['tabOrder'], 5)
        self.assertEqual(pos['width'], 308)
        # יחס דסקטופ נשמר: 360/640 * 308 = 173
        self.assertEqual(pos['height'], 173)
        # אידמפוטנטי
        docs2 = F.Docs()
        F.fix_mobilemissing(docs2, self.rp)
        self.assertEqual(docs2.changed(), [])

    def test_page_without_mobile_layout_untouched(self):
        self._vis('a', 'barChart')
        self._vis('b', 'map')
        docs = F.Docs()
        F.fix_mobilemissing(docs, self.rp)
        self.assertEqual(docs.changed(), [], 'דף בלי מתכונת נייד בכלל — לא ליקוי')

    def test_decor_and_hidden_skipped(self):
        self._vis('have', mobile=True)
        self._vis('txt', 'textbox')
        self._vis('hid', 'barChart', hidden=True)
        docs = F.Docs()
        F.fix_mobilemissing(docs, self.rp)
        self.assertEqual(docs.changed(), [], 'דקור/מוסתר לא אמורים לקבל mobile.json')

    def test_group_member_skipped_with_reason(self):
        self._vis('have', mobile=True)
        self._vis('grp', group=True)
        docs = F.Docs()
        skipped = F.fix_mobilemissing(docs, self.rp)
        self.assertEqual(docs.changed(), [])
        self.assertTrue(any('visualGroup' in x for x in skipped), skipped)

    def test_tooltip_page_skipped(self):
        w(os.path.join(self.page, 'page.json'),
          '{"name": "pagetest", "type": "Tooltip", "width": 640, "height": 400}')
        self._vis('have', mobile=True)
        self._vis('miss', 'lineChart')
        docs = F.Docs()
        F.fix_mobilemissing(docs, self.rp)
        self.assertEqual(docs.changed(), [], 'דף Tooltip לא צריך מתכונת נייד')

    def test_existing_mobile_never_overwritten(self):
        vd = self._vis('have', mobile=True)
        self._vis('miss', 'lineChart')
        docs = F.Docs()
        F.fix_mobilemissing(docs, self.rp)
        docs.write_all()
        cur = open(os.path.join(vd, 'mobile.json'), encoding='utf-8-sig').read()
        self.assertIn('"y": 16', cur, 'mobile.json קיים שונה')
        self.assertNotIn('"z": 6', cur)


class TestStylePresetR69(unittest.TestCase):
    """סבב 82 — R-69 + pbi_fix stylepreset: tableEx/pivotTable עם צבעים סטטיים
    מותאמים ב-objects בלי visualContainerObjects.stylePreset — הפריסה הדיפולטית
    דורסת אותם בשקט ללבן (MS skills-for-fabric table.md). הפיקסר מזריק 'None'."""

    def setUp(self):
        self.root = tempfile.mkdtemp(prefix='pbisp-')
        self.dst = os.path.join(self.root, 'P')
        shutil.copytree(FIX, self.dst)
        self.rp = os.path.join(self.dst, 'MiniReport.Report')
        self.page = os.path.join(self.rp, 'definition', 'pages', 'pagetest')
        os.makedirs(os.path.join(self.page, 'visuals'), exist_ok=True)
        w(os.path.join(self.page, 'page.json'), '{"name": "pagetest", "width": 1280, "height": 720}')

    def tearDown(self):
        shutil.rmtree(self.root, ignore_errors=True)

    def _table(self, vid, vtype='tableEx', objects=None, vco=None):
        vd = os.path.join(self.page, 'visuals', vid)
        d = {"name": vid, "position": {"x": 0, "y": 0, "z": 1, "width": 700, "height": 400},
             "visual": {"visualType": vtype, "query": {"queryState": {}},
                        "objects": objects or {}}}
        if vco is not None:
            # סבב 134 (כשל שדה #1): המיקום הקנוני הוא visual.visualContainerObjects
            d["visual"]["visualContainerObjects"] = vco
        w(os.path.join(vd, 'visual.json'), json.dumps(d, ensure_ascii=False))
        return os.path.join(vd, 'visual.json')

    def _colors(self):
        return {"values": [{"properties": {
            "backColorPrimary": {"solid": {"color": {"expr": {"Literal": {"Value": "'#14181E'"}}}}},
            "backColorSecondary": {"solid": {"color": {"expr": {"Literal": {"Value": "'#1A1F27'"}}}}}}}]}

    def test_validate_fires_and_fix_injects_none(self):
        vj = self._table('t1', objects=self._colors())
        docs = F.Docs()
        skipped = F.fix_stylepreset(docs, self.rp)
        self.assertEqual(skipped, [])
        self.assertEqual([p for p, _ in docs.changed()], [vj])
        self.assertNotIn('stylePreset', open(vj, encoding='utf-8').read(), 'dry-run כתב')
        docs.write_all()
        self.assertEqual(F._verify(docs), [])
        d = json.load(open(vj, encoding='utf-8-sig'))
        # סבב 134 (כשל שדה #1+#5): ההזרקה בתוך visual, לעולם לא ברמת השורש
        self.assertNotIn('visualContainerObjects', d, 'stylePreset הוזרק ברמת השורש (כשל שדה #1)')
        sp = d['visual']['visualContainerObjects']['stylePreset'][0]['properties']['name']
        self.assertEqual(sp['expr']['Literal']['Value'], "'None'")
        # סגירת לולאת פיקסר↔בודק (המלצה רוחבית 3): R-69 פסק אחרי התיקון
        import pbi_validate as _V
        _V._ISSUES.clear()
        _V.validate_project(self.dst)
        self.assertFalse(any(i['code'] == 'R-69' for i in _V._ISSUES),
                         'R-69 עדיין מסמן אחרי pbi_fix --apply (פיקסר/בודק חלוקים)')
        # אידמפוטנטי
        docs2 = F.Docs()
        F.fix_stylepreset(docs2, self.rp)
        self.assertEqual(docs2.changed(), [])

    def test_existing_preset_never_overwritten(self):
        vco = {"stylePreset": [{"properties": {"name": {"expr": {"Literal": {"Value": "'BoldHeader'"}}}}}]}
        vj = self._table('t1', objects=self._colors(), vco=vco)
        docs = F.Docs()
        F.fix_stylepreset(docs, self.rp)
        self.assertEqual(docs.changed(), [], 'stylePreset קיים שונה (FP)')
        self.assertIn('BoldHeader', open(vj, encoding='utf-8').read())

    def test_no_custom_colors_untouched(self):
        self._table('t1', objects={"grid": [{"properties": {"gridVertical": {"expr": {"Literal": {"Value": "true"}}}}}]})
        docs = F.Docs()
        F.fix_stylepreset(docs, self.rp)
        self.assertEqual(docs.changed(), [], 'טבלה בלי צבעים מותאמים לא צריכה stylePreset')

    def test_non_table_visual_untouched(self):
        vj = self._table('c1', vtype='barChart', objects=self._colors())
        docs = F.Docs()
        F.fix_stylepreset(docs, self.rp)
        self.assertEqual(docs.changed(), [], 'barChart עם אותם מאפיינים לא אמור לקבל stylePreset')

    def test_validate_rule_r69(self):
        self._table('t1', objects=self._colors())
        self._table('t2', vtype='pivotTable',
                    objects={"columnHeaders": [{"properties": {"backColor": {"solid": {"color": {"expr": {"Literal": {"Value": "'#2B579A'"}}}}}}}]},
                    vco={"stylePreset": [{"properties": {"name": {"expr": {"Literal": {"Value": "'None'"}}}}}]})
        import subprocess, sys as _sys
        out = subprocess.run([_sys.executable,
                              os.path.join(ROOT, 'skills', 'powerbi-pbip-builder', 'scripts', 'pbi_validate.py'),
                              self.dst], capture_output=True, text=True).stdout
        r69 = [l for l in out.splitlines() if 'R-69' in l]
        self.assertTrue(r69, 'R-69 לא ירה על טבלה עם צבעים בלי preset')
        self.assertTrue(any("'t1'" in l for l in r69), r69)
        self.assertFalse(any("'t2'" in l for l in r69),
                         'R-69 ירה על טבלה עם stylePreset קיים (FP)')


class SwapMultiProjectionLoss(unittest.TestCase):
    """סבב 135 — כשל שדה #3 מהדיווח המסודר (14.9): lineChart עם 3 מדדים ב-Y
    הוחלף ל-clusteredColumnChart ושמר רק את הראשון; ה-read-back אישר "בוצע ✅".
    התיקון: מיפוי role-aware (Y→Y, Y2→Y2) + בריכת צריכה (M* = כל הנותרים),
    אובדן *מוצהר* ב-dropped_fields, ו-read-back שמשווה גם את *מספר* ההקרנות."""

    def _doc(self, vt='lineChart', y=('m1', 'm2', 'm3'), y2=()):
        col = {"field": {"Column": {"Expression": {"SourceRef": {"Entity": "d"}}, "Property": "c"}}, "queryRef": "d.c"}
        mea = lambda m: {"field": {"Measure": {"Expression": {"SourceRef": {"Entity": "f"}}, "Property": m}}, "queryRef": "f." + m}
        qs = {"Category": {"projections": [col]}, "Y": {"projections": [mea(m) for m in y]}}
        if y2:
            qs["Y2"] = {"projections": [mea(m) for m in y2]}
        return {"visual": {"visualType": vt, "query": {"queryState": qs}}}

    def test_three_y_measures_survive_swap(self):
        # המקרה המדווח מילה במילה: 3 מדדים (Gross Profit / Operating / Net Income)
        ok, msg, qs, dropped = SW.plan_swap(self._doc(), 'clusteredColumnChart')
        self.assertTrue(ok, msg)
        got = [p['queryRef'] for p in qs['Y']['projections']]
        self.assertEqual(got, ['f.m1', 'f.m2', 'f.m3'], 'מדדי Y אבדו בהחלפה (כשל שדה #3)')
        self.assertEqual(dropped, [])

    def test_secondary_axis_preserved_same_type(self):
        # lineChart→lineChart: מדד ב-Y2 נשאר ב-Y2, לא נבלע ב-Y
        ok, msg, qs, dropped = SW.plan_swap(self._doc(y=('m1',), y2=('m2',)), 'lineChart')
        self.assertTrue(ok, msg)
        self.assertEqual([p['queryRef'] for p in qs['Y']['projections']], ['f.m1'])
        self.assertEqual([p['queryRef'] for p in qs['Y2']['projections']], ['f.m2'],
                         'מדד ציר-משני נבלע ב-Y הראשי')
        self.assertEqual(dropped, [])

    def test_narrowing_declares_dropped_fields(self):
        # 3 מדדים → kpi (Indicator+Goal): השלישי לא עובר — אבל מוצהר, לא שקט
        ok, msg, qs, dropped = SW.plan_swap(self._doc(), 'kpi')
        self.assertTrue(ok, msg)
        total = sum(len(b['projections']) for b in qs.values())
        self.assertEqual(total, 3, 'Indicator + Goal + TrendLine(עמודה)')
        self.assertEqual([p['queryRef'] for p in qs['Indicator']['projections']], ['f.m1'])
        self.assertEqual([p['queryRef'] for p in qs['Goal']['projections']], ['f.m2'])
        self.assertEqual(dropped, ['f.m3'], 'אובדן ליעד צר חייב להיות מוצהר ב-dropped_fields')

    def test_readback_compares_projection_count(self):
        # apply אמיתי: מספר ההקרנות בקובץ == מספר ההקרנות בתוכנית, לא רק קבוצה-חלקית
        root = tempfile.mkdtemp(prefix='pbisw3-')
        try:
            vd = os.path.join(root, 'v1')
            os.makedirs(vd)
            vj = os.path.join(vd, 'visual.json')
            w(vj, json.dumps(self._doc(), ensure_ascii=False))
            r = SW.swap_visual(vj, 'clusteredColumnChart', apply=True)
            self.assertTrue(r['applied'], r.get('reason'))
            back = json.load(open(vj, encoding='utf-8-sig'))
            n = sum(len((b or {}).get('projections') or [])
                    for b in (back['visual']['query']['queryState']).values())
            self.assertEqual(n, 4, 'Category + 3 מדדי Y חייבים לשרוד (כשל שדה #3)')
            self.assertEqual(r['dropped_fields'], [])
        finally:
            shutil.rmtree(root, ignore_errors=True)

    def test_all_role_keeps_non_pref_fields(self):
        # treemap (Group+Values) → tableEx (Values=ALL): העמודה מ-Group לא אבדה
        # רק כי יש תפקיד באותו שם (נתפס ב-round-trip על metro, /tmp/btrain135)
        doc = self._doc(vt='treemap', y=('m1',))
        qs = {"Group": doc['visual']['query']['queryState'].pop('Category'),
              "Values": doc['visual']['query']['queryState'].pop('Y')}
        doc['visual']['query']['queryState'] = qs
        ok, msg, qs2, dropped = SW.plan_swap(doc, 'tableEx')
        self.assertTrue(ok, msg)
        got = [p['queryRef'] for p in qs2['Values']['projections']]
        self.assertEqual(sorted(got), ['d.c', 'f.m1'], 'שדה מ-Group אבד במיפוי ALL')
        self.assertEqual(dropped, [])

    def test_category_hierarchy_levels_survive(self):
        # Category היררכי (2 רמות) → clusteredColumnChart: שתי הרמות נשמרות
        doc = self._doc(y=('m1',))
        c2 = {"field": {"Column": {"Expression": {"SourceRef": {"Entity": "d"}}, "Property": "c2"}}, "queryRef": "d.c2"}
        doc['visual']['query']['queryState']['Category']['projections'].append(c2)
        ok, msg, qs, dropped = SW.plan_swap(doc, 'clusteredColumnChart')
        self.assertTrue(ok, msg)
        got = [p['queryRef'] for p in qs['Category']['projections']]
        self.assertEqual(got, ['d.c', 'd.c2'], 'רמת היררכיה ב-Category אבדה')
        self.assertEqual(dropped, [])


class TestAltTextHebrew(unittest.TestCase):
    """סבב 137 — כשל שדה #8: alt text באנגלית ("cardVisual: Total Revenue") בדוח
    עברי RTL. התיקון: זיהוי שפת דוח + מיפוי סוג-ויזואל לעברית; דוח אנגלי ללא שינוי."""

    def _mk(self, page_name, vis_name='v1'):
        root = tempfile.mkdtemp(prefix='pbialt-')
        dst = os.path.join(root, 'P')
        shutil.copytree(FIX, dst)
        rp = os.path.join(dst, 'MiniReport.Report')
        pg = os.path.join(rp, 'definition', 'pages', 'pagetest')
        os.makedirs(os.path.join(pg, 'visuals', vis_name), exist_ok=True)
        w(os.path.join(pg, 'page.json'), json.dumps({"name": "pagetest", "displayName": page_name}))
        doc = {"name": vis_name, "position": {"x": 0, "y": 0, "z": 1, "width": 200, "height": 100},
               "visual": {"visualType": "cardVisual", "query": {"queryState": {
                   "Data": {"projections": [{"field": {"Measure": {"Expression": {"SourceRef": {"Entity": "f"}},
                                                       "Property": "Total Revenue"}},
                                             "queryRef": "f.Total Revenue"}]}}}}}
        w(os.path.join(pg, 'visuals', vis_name, 'visual.json'), json.dumps(doc, ensure_ascii=False))
        return root, rp

    def test_hebrew_report_gets_hebrew_type_name(self):
        root, rp = self._mk('סקירה')
        try:
            self.assertTrue(F._report_is_hebrew(rp))
            docs = F.Docs()
            F.fix_alttext(docs, rp)
            d = json.loads(docs.d[os.path.join(rp, 'definition', 'pages', 'pagetest',
                                               'visuals', 'v1', 'visual.json')]['text'])
            alt = d['visual']['visualContainerObjects']['general'][0]['properties']['altText']['expr']['Literal']['Value']
            self.assertEqual(alt, "'כרטיס: Total Revenue'",
                             'דוח עברי קיבל שם סוג אנגלי (כשל שדה #8)')
        finally:
            shutil.rmtree(root, ignore_errors=True)

    def test_english_report_unchanged(self):
        root, rp = self._mk('Overview', vis_name='ven')
        # ניקוי שאר עמודי הפיקסצר (עבריים) — נשאר פרויקט אנגלי טהור לבקרה
        for pg in os.listdir(os.path.join(rp, 'definition', 'pages')):
            full = os.path.join(rp, 'definition', 'pages', pg)
            if pg != 'pagetest' and os.path.isdir(full):
                shutil.rmtree(full)
        try:
            # המקרה המדווח היה על דוח עברי; דוח אנגלי ממשיך באנגלית (אין רגרסיה זרה)
            rp2 = rp
            docs = F.Docs()
            F.fix_alttext(docs, rp2)
            d = json.loads(docs.d[os.path.join(rp2, 'definition', 'pages', 'pagetest',
                                               'visuals', 'ven', 'visual.json')]['text'])
            alt = d['visual']['visualContainerObjects']['general'][0]['properties']['altText']['expr']['Literal']['Value']
            self.assertEqual(alt, "'cardVisual: Total Revenue'")
        finally:
            shutil.rmtree(root, ignore_errors=True)


class TestConditionalFormattingRules(unittest.TestCase):
    """סבב 83 — R-70..R-73 (MS skills-for-fabric conditional-formatting.md):
    linearGradient3 בלי mid (err), אייקון מחוץ לקטלוג (err — קריסת Desktop),
    מאפייני CF פיקטיביים (warn — נזרקים בשקט), CF על dataPoint עם metadata
    selector בתרשים (warn — כשל שקט)."""

    def setUp(self):
        self.root = tempfile.mkdtemp(prefix='pbicf-')
        self.dst = os.path.join(self.root, 'P')
        shutil.copytree(FIX, self.dst)
        self.rp = os.path.join(self.dst, 'MiniReport.Report')
        self.page = os.path.join(self.rp, 'definition', 'pages', 'pagetest')
        os.makedirs(os.path.join(self.page, 'visuals'), exist_ok=True)
        w(os.path.join(self.page, 'page.json'), '{"name": "pagetest", "width": 1280, "height": 720}')

    def tearDown(self):
        shutil.rmtree(self.root, ignore_errors=True)

    def _vis(self, vid, objects, vtype='tableEx'):
        vd = os.path.join(self.page, 'visuals', vid)
        d = {"name": vid, "position": {"x": 0, "y": 0, "z": 1, "width": 700, "height": 400},
             "visual": {"visualType": vtype, "query": {"queryState": {}}, "objects": objects}}
        w(os.path.join(vd, 'visual.json'), json.dumps(d, ensure_ascii=False))

    def _run(self):
        import subprocess, sys as _sys
        return subprocess.run([_sys.executable,
                               os.path.join(ROOT, 'skills', 'powerbi-pbip-builder', 'scripts', 'pbi_validate.py'),
                               self.dst], capture_output=True, text=True).stdout

    def test_r70_gradient3_missing_mid(self):
        fr = {"FillRule": {"linearGradient3": {"min": {"color": {"Literal": {"Value": "'#fff'"}}},
                                               "max": {"color": {"Literal": {"Value": "'#000'"}}}},
                           "Input": {}}}
        self._vis('g3', {"values": [{"properties": {"backColor": {"solid": {"color": {"expr": fr}}}}}]})
        out = self._run()
        self.assertIn('R-70', out)
        # עם mid — לא יורה
        shutil.rmtree(os.path.join(self.page, 'visuals', 'g3'))
        fr['FillRule']['linearGradient3']['mid'] = {"color": {"Literal": {"Value": "'#888'"}}}
        self._vis('g3ok', {"values": [{"properties": {"backColor": {"solid": {"color": {"expr": fr}}}}}]})
        out2 = self._run()
        self.assertNotIn('R-70', out2, 'gradient3 תקין סומן (FP)')

    def test_r71_bad_icon_name_crashes_desktop(self):
        icon = {"icon": {"kind": "Icon", "Conditional": {
            "Cases": [{"Condition": {}, "Value": {"Literal": {"Value": "'CircleGreenish'"}}}],
            "DefaultValue": {"Literal": {"Value": "'CircleMedium'"}}}}}
        self._vis('ic', {"values": [{"properties": icon}]})
        out = self._run()
        self.assertIn('R-71', out)
        self.assertIn('CircleGreenish', out)
        # שם חוקי — לא יורה
        shutil.rmtree(os.path.join(self.page, 'visuals', 'ic'))
        icon['icon']['Conditional']['Cases'][0]['Value']['Literal']['Value'] = "'CircleGreenPatternFill'"
        self._vis('icok', {"values": [{"properties": icon}]})
        out2 = self._run()
        self.assertNotIn('R-71', out2, 'אייקון חוקי סומן (FP)')

    def test_r72_phantom_props(self):
        self._vis('ph', {"values": [{"properties": {"backColorRule": {"expr": {}},
                                                    "backColorPrimary": {"solid": {}}}}]})
        out = self._run()
        r72 = [l for l in out.splitlines() if 'R-72' in l]
        self.assertTrue(r72, 'backColorRule פיקטיבי לא סומן')
        self.assertIn('backColorRule', ' '.join(r72))

    def test_r73_chart_cf_with_metadata_selector(self):
        fr = {"FillRule": {"linearGradient2": {"min": {}, "max": {}}, "Input": {}}}
        self._vis('cf', {"dataPoint": [
            {"selector": {"metadata": "m.x"},
             "properties": {"fill": {"solid": {"color": {"expr": fr}}}}}]}, vtype='barChart')
        out = self._run()
        self.assertIn('R-73', out)
        # אותו CF בלי metadata — חוקי
        shutil.rmtree(os.path.join(self.page, 'visuals', 'cf'))
        self._vis('cfok', {"dataPoint": [
            {"selector": {"data": [{"dataViewWildcard": {"matchingOption": 1}}]},
             "properties": {"fill": {"solid": {"color": {"expr": fr}}}}}]}, vtype='barChart')
        out2 = self._run()
        self.assertNotIn('R-73', out2, 'CF עם dataViewWildcard סומן (FP)')


class TestMetadataFillScopeId(unittest.TestCase):
    """סבב 84 — R-74 + אזהרת pbi_swap (MS skills-for-fabric color-strategy.md
    § Compatibility): dataPoint.fill סטטי עם metadata selector עובד רק בוויזואלים
    קרטזיים; ב-pie/donut/scatter/treemap/funnel נזרק בשקט (צריך scopeId selectors)."""

    def setUp(self):
        self.root = tempfile.mkdtemp(prefix='pbimeta74-')
        self.dst = os.path.join(self.root, 'P')
        shutil.copytree(FIX, self.dst)
        self.rp = os.path.join(self.dst, 'MiniReport.Report')

    def tearDown(self):
        shutil.rmtree(self.root, ignore_errors=True)

    def _fill_meta(self):
        return {"properties": {"fill": {"solid": {"color": {"expr": {
            "Literal": {"Value": "'#FF0000'"}}}}}},
            "selector": {"metadata": "t.m"}}

    def _chart(self, vid, vtype):
        qs = {"Category": {"projections": [
                  {"field": {"Column": {"Expression": {"SourceRef": {"Entity": "dim"}},
                                        "Property": "c"}},
                   "queryRef": "dim.c"}]},
              "Y": {"projections": [
                  {"field": {"Measure": {"Expression": {"SourceRef": {"Entity": "t"}},
                                         "Property": "m"}},
                   "queryRef": "t.m"}]}}
        vj = os.path.join(self.rp, 'definition', 'pages', 'page001', 'visuals', vid, 'visual.json')
        w(vj, json.dumps({"name": vid,
                          "position": {"x": 0, "y": 0, "z": 1, "width": 4, "height": 3},
                          "visual": {"visualType": vtype,
                                     "query": {"queryState": qs},
                                     "objects": {"dataPoint": [self._fill_meta()]}}},
                         ensure_ascii=False))
        return vj

    def _run_validate(self):
        import subprocess, sys as _sys
        return subprocess.run([_sys.executable,
                               os.path.join(ROOT, 'skills', 'powerbi-pbip-builder',
                                            'scripts', 'pbi_validate.py'),
                               self.dst], capture_output=True, text=True).stdout

    def test_r74_static_metadata_fill_on_funnel(self):
        self._chart('fn', 'funnel')
        out = self._run_validate()
        self.assertIn('R-74', out, 'funnel עם fill+metadata לא סומן')

    def test_r74_cartesian_is_clean(self):
        self._chart('bc', 'barChart')
        out = self._run_validate()
        self.assertNotIn('R-74', out, 'barChart קרטזי סומן (FP)')

    def test_swap_warns_when_target_non_cartesian(self):
        vj = self._chart('sw', 'barChart')
        r = SW.swap_visual(vj, 'pieChart')
        self.assertTrue(r.get('ok'), r)
        warns = r.get('warnings') or []
        self.assertTrue(any('metadata' in x and 'scopeId' in x for x in warns), r)
        # apply: האזהרה נשמרת גם אחרי החלה
        r2 = SW.swap_visual(vj, 'pieChart', apply=True)
        self.assertTrue(r2.get('ok') and r2.get('applied'), r2)
        self.assertTrue(r2.get('warnings'), r2)
        # ה-objects נשמרים (עיצוב לא נמחק)
        d = json.load(open(vj, encoding='utf-8-sig'))
        self.assertEqual(len((d['visual'].get('objects') or {}).get('dataPoint') or []), 1)

    def test_swap_no_warning_for_cartesian_target(self):
        vj = self._chart('sw2', 'barChart')
        r = SW.swap_visual(vj, 'clusteredColumnChart')
        self.assertTrue(r.get('ok'), r)
        self.assertFalse(r.get('warnings'), r)

class TestSelectorPlacementRules(unittest.TestCase):
    """סבב 86 — R-75/R-76 (MS skills-for-fabric formatting.md § Selectors):
    scopeId עם ComparisonKind!=0 (1-4 נזרק בשקט ברינדור, >=5 שגיאת schema),
    ו-selector על אובייקטים רוחביים שאינם תומכים (legend/axes/VCO)."""

    def setUp(self):
        self.root = tempfile.mkdtemp(prefix='pbisel-')
        self.dst = os.path.join(self.root, 'P')
        shutil.copytree(FIX, self.dst)
        self.rp = os.path.join(self.dst, 'MiniReport.Report')
        self.page = os.path.join(self.rp, 'definition', 'pages', 'pagetest')
        os.makedirs(os.path.join(self.page, 'visuals'), exist_ok=True)
        w(os.path.join(self.page, 'page.json'), '{"name": "pagetest", "width": 1280, "height": 720}')

    def tearDown(self):
        shutil.rmtree(self.root, ignore_errors=True)

    def _vis(self, vid, objects, vtype='barChart', vco=None):
        vd = os.path.join(self.page, 'visuals', vid)
        d = {"name": vid, "position": {"x": 0, "y": 0, "z": 1, "width": 700, "height": 400},
             "visual": {"visualType": vtype, "query": {"queryState": {}}, "objects": objects}}
        if vco:
            d['visual']['visualContainerObjects'] = vco
        w(os.path.join(vd, 'visual.json'), json.dumps(d, ensure_ascii=False))

    def _run(self):
        import subprocess, sys as _sys
        return subprocess.run([_sys.executable,
                               os.path.join(ROOT, 'skills', 'powerbi-pbip-builder', 'scripts', 'pbi_validate.py'),
                               self.dst], capture_output=True, text=True).stdout

    @staticmethod
    def _scopeid(kind):
        return {"selector": {"data": [{"scopeId": {"Comparison": {
            "ComparisonKind": kind,
            "Left": {"Column": {"Expression": {"SourceRef": {"Entity": "P"}}, "Property": "C"}},
            "Right": {"Literal": {"Value": "'X'"}}}}}]},
                "properties": {"fill": {"solid": {"color": {"expr": {"Literal": {"Value": "'#F00'"}}}}}}}

    def test_r75_comparisonkind_silent_drop(self):
        self._vis('ck3', {"dataPoint": [self._scopeid(3)]})
        out = self._run()
        r75 = [l for l in out.splitlines() if 'R-75' in l]
        self.assertTrue(r75, 'ComparisonKind=3 לא סומן')
        self.assertNotIn('❌', '\n'.join(r75), 'ComparisonKind=3 צריך warn ולא err')

    def test_r75_comparisonkind_schema_error(self):
        self._vis('ck7', {"dataPoint": [self._scopeid(7)]})
        out = self._run()
        self.assertIn('R-75', out)
        self.assertIn('schema', out)

    def test_r75_equal_is_clean(self):
        self._vis('ck0', {"dataPoint": [self._scopeid(0)]})
        no_kind = {"selector": {"data": [{"scopeId": {"Comparison": {
            "Left": {"Column": {"Expression": {"SourceRef": {"Entity": "P"}}, "Property": "C"}},
            "Right": {"Literal": {"Value": "'X'"}}}}}]},
            "properties": {"fill": {"solid": {"color": {"expr": {"Literal": {"Value": "'#F00'"}}}}}}}
        self._vis('ckn', {"dataPoint": [no_kind]})
        out = self._run()
        self.assertNotIn('R-75', out, 'ComparisonKind=0/חסר סומן (FP)')

    def test_r76_selector_on_legend_and_vco(self):
        self._vis('lg', {"legend": [{"selector": {"metadata": "t.m"},
                                     "properties": {"show": {"expr": {"Literal": {"Value": "true"}}}}}]},
                  vco={"title": [{"selector": {"id": "default"},
                                  "properties": {"show": {"expr": {"Literal": {"Value": "true"}}}}}]})
        out = self._run()
        r76 = [l for l in out.splitlines() if 'R-76' in l]
        self.assertTrue(r76, 'selector על legend/VCO title לא סומן')
        joined = ' '.join(r76)
        self.assertIn('legend', joined)
        self.assertIn('visualContainerObjects.title', joined)

    def test_r76_supported_objects_clean(self):
        self._vis('ok76', {"dataPoint": [{"selector": {"metadata": "t.m"},
                                          "properties": {"fill": {"solid": {}}}}],
                           "legend": [{"properties": {"show": {"expr": {"Literal": {"Value": "true"}}}}}]})
        out = self._run()
        self.assertNotIn('R-76', out, 'אובייקטים נתמכים/בלי selector סומנו (FP)')

class TestContainerPlacementRules(unittest.TestCase):
    """סבב 86 — R-77/78/79 (MS skills-for-fabric formatting.md § VCO +
    § Page Objects vs VCO): מיקום מכולות. R-77: objects/VCO ברמת שורש
    visual.json (err). R-78: אובייקטי דף ב-VCO או אובייקטי VCO ב-page.json
    (warn). R-79: מפתח VCO לא מוכר מחוץ ל-15 (warn)."""

    def setUp(self):
        self.root = tempfile.mkdtemp(prefix='pbivco-')
        self.dst = os.path.join(self.root, 'P')
        shutil.copytree(FIX, self.dst)
        self.rp = os.path.join(self.dst, 'MiniReport.Report')
        self.page = os.path.join(self.rp, 'definition', 'pages', 'pagetest')
        os.makedirs(os.path.join(self.page, 'visuals'), exist_ok=True)
        w(os.path.join(self.page, 'page.json'), '{"name": "pagetest", "width": 1280, "height": 720}')

    def tearDown(self):
        shutil.rmtree(self.root, ignore_errors=True)

    def _vis(self, vid, doc_extra=None, vis_extra=None):
        vd = os.path.join(self.page, 'visuals', vid)
        d = {"name": vid, "position": {"x": 0, "y": 0, "z": 1, "width": 700, "height": 400},
             "visual": {"visualType": "barChart", "query": {"queryState": {}}}}
        if vis_extra:
            d['visual'].update(vis_extra)
        if doc_extra:
            d.update(doc_extra)
        w(os.path.join(vd, 'visual.json'), json.dumps(d, ensure_ascii=False))

    def _run(self):
        import subprocess, sys as _sys
        return subprocess.run([_sys.executable,
                               os.path.join(ROOT, 'skills', 'powerbi-pbip-builder', 'scripts', 'pbi_validate.py'),
                               self.dst], capture_output=True, text=True).stdout

    def test_r77_root_level_objects_and_vco(self):
        self._vis('mis', doc_extra={"visualContainerObjects": {"title": [{"properties": {}}]}})
        out = self._run()
        self.assertIn('R-77', out)
        # מיקום נכון — נקי
        shutil.rmtree(os.path.join(self.page, 'visuals', 'mis'))
        self._vis('ok77', vis_extra={"visualContainerObjects": {"title": [{"properties": {}}]}})
        out2 = self._run()
        self.assertNotIn('R-77', out2, 'VCO במיקום נכון סומן (FP)')

    def test_r78_page_object_inside_vco(self):
        self._vis('mix', vis_extra={"visualContainerObjects": {"outspace": [{"properties": {}}]}})
        out = self._run()
        self.assertIn('R-78', out)

    def test_r78_vco_object_inside_page_json(self):
        w(os.path.join(self.page, 'page.json'),
          json.dumps({"name": "pagetest", "width": 1280, "height": 720,
                      "objects": {"title": [{"properties": {"text": {"expr": {}}}}]}}))
        out = self._run()
        self.assertIn('R-78', out)
        self.assertIn('title', ' '.join(l for l in out.splitlines() if 'R-78' in l))

    def test_r79_unknown_vco_key(self):
        self._vis('unk', vis_extra={"visualContainerObjects": {"headerTooltip2": [{"properties": {}}]}})
        out = self._run()
        self.assertIn('R-79', out)
        # מפתח חוקי — נקי
        shutil.rmtree(os.path.join(self.page, 'visuals', 'unk'))
        self._vis('ok79', vis_extra={"visualContainerObjects": {"visualHeaderTooltip": [{"properties": {}}]}})
        out2 = self._run()
        self.assertNotIn('R-79', out2, 'מפתח VCO חוקי סומן (FP)')
class DatasetSuffixValidate(unittest.TestCase):
    """סבב 88 — pbi_validate מזהה גם מודל בסיומת הישנה *.Dataset
    (NatVanG/fab-inspector, MIT) בזיהוי האוטומטי משורש הפרויקט."""

    def setUp(self):
        self.root = tempfile.mkdtemp(prefix='pbids-')
        self.dst = os.path.join(self.root, 'P')
        shutil.copytree(FIX, self.dst)
        os.rename(os.path.join(self.dst, 'MiniReport.SemanticModel'),
                  os.path.join(self.dst, 'MiniReport.Dataset'))

    def tearDown(self):
        shutil.rmtree(self.root, ignore_errors=True)

    def _run(self):
        import subprocess
        return subprocess.run([sys.executable, V.__file__, self.dst],
                              capture_output=True, text=True).stdout

    def test_dataset_suffix_detected(self):
        out = self._run()
        r15 = [l for l in out.splitlines() if 'R-15' in l]
        self.assertTrue(any('שם מוצר' in l for l in r15),
                        'R-15 (שדה חסר במודל) לא ירה — המודל לא זוהה דרך *.Dataset')

class TestZFix(unittest.TestCase):
    """סבב 89 — zfix: שילום z כפול בדף (R-20). מקור הרעיון: mcp-powerbi-plus
    pbir.py (MIT) — מחוללים מקצים z ייחודי עולה; שכפול = clone בלי עדכון.
    ההופעה הראשונה (מיון שמות) שומרת את z; שאר השכפולים עולים מעל המקסימום."""

    def setUp(self):
        self.root = tempfile.mkdtemp(prefix='pbizfix-')
        self.dst = os.path.join(self.root, 'P')
        shutil.copytree(FIX, self.dst)
        self.rp = os.path.join(self.dst, 'MiniReport.Report')

    def tearDown(self):
        shutil.rmtree(self.root, ignore_errors=True)

    def _clone_with_z(self, src_name, clone_name, z):
        base = os.path.join(self.rp, 'definition', 'pages', 'page001', 'visuals')
        vobj = json.loads(open(os.path.join(base, src_name, 'visual.json'),
                               encoding='utf-8-sig').read())
        vobj['name'] = clone_name
        vobj['position']['z'] = z
        os.makedirs(os.path.join(base, clone_name))
        w(os.path.join(base, clone_name, 'visual.json'), json.dumps(vobj, ensure_ascii=False, indent=4))

    def _apply(self):
        docs = F.Docs()
        F.fix_zfix(docs, self.rp)
        docs.write_all()
        return docs

    def _zmap(self):
        base = os.path.join(self.rp, 'definition', 'pages', 'page001', 'visuals')
        return {d: json.loads(open(os.path.join(base, d, 'visual.json'),
                                   encoding='utf-8-sig').read())['position']['z']
                for d in os.listdir(base)}

    def test_duplicate_z_fixed_first_kept(self):
        self._clone_with_z('vis002', 'zzzclone', 2)  # מתנגש ב-z=2 של vis002
        self._apply()
        zm = self._zmap()
        self.assertEqual(zm['vis002'], 2, 'ההופעה הראשונה (מיון שמות) חייבת לשמור את z')
        self.assertEqual(len(set(zm.values())), len(zm), 'כל ה-z בדף חייבים להיות ייחודיים')
        self.assertGreater(zm['zzzclone'], 3, 'השכפול עולה מעל המקסימום הקיים בדף')
        # validate לא מדווח יותר R-20 על הדף
        import subprocess
        out = subprocess.run([sys.executable, V.__file__, self.dst],
                             capture_output=True, text=True).stdout
        self.assertNotIn('R-20', out)

    def test_clean_fixture_untouched(self):
        docs = F.Docs()
        F.fix_zfix(docs, self.rp)
        self.assertEqual(docs.changed(), [], 'fixture תקין (z ייחודיים) — אסור לגעת (FP)')

    def test_idempotent(self):
        self._clone_with_z('vis002', 'zzzclone', 2)
        self._apply()
        docs2 = F.Docs()
        F.fix_zfix(docs2, self.rp)
        self.assertEqual(docs2.changed(), [], 'הרצה שנייה חייבת להיות אידמפוטנטית')

class TestTabOrderFix(unittest.TestCase):
    """סבב 91 — taborderfix: tabOrder כפול/שלילי בדף (A11Y-03, WCAG 2.4.3).
    מקור: MS Learn desktop-accessibility-consuming-tools (CC-BY-4.0) — סדר ה-tab
    הוא סדר הניווט במקלדת. ערך חדש מעל max(z, tabOrder) — המונה המשותף של
    המחוללים (mcp-powerbi-plus pbir.py, MIT). בלי tabOrder בכלל — לא נוגע."""

    def setUp(self):
        self.root = tempfile.mkdtemp(prefix='pbitab-')
        self.dst = os.path.join(self.root, 'P')
        shutil.copytree(FIX, self.dst)
        self.rp = os.path.join(self.dst, 'MiniReport.Report')
        self.base = os.path.join(self.rp, 'definition', 'pages', 'page001', 'visuals')

    def tearDown(self):
        shutil.rmtree(self.root, ignore_errors=True)

    def _set_tab(self, vid, t):
        vj = os.path.join(self.base, vid, 'visual.json')
        vobj = json.loads(open(vj, encoding='utf-8-sig').read())
        vobj.setdefault('position', {})['tabOrder'] = t
        w(vj, json.dumps(vobj, ensure_ascii=False, indent=4))

    def _tabs(self):
        return {d: json.loads(open(os.path.join(self.base, d, 'visual.json'),
                                   encoding='utf-8-sig').read())['position'].get('tabOrder')
                for d in os.listdir(self.base)}

    def _apply(self):
        docs = F.Docs()
        F.fix_taborderfix(docs, self.rp)
        docs.write_all()
        return docs

    def test_duplicate_fixed_first_kept(self):
        self._set_tab('vis001', 1)
        self._set_tab('vis002', 1)   # כפילות עם vis001
        self._apply()
        tm = self._tabs()
        self.assertEqual(tm['vis001'], 1, 'ההופעה הראשונה (מיון שמות) שומרת את הערך')
        vals = [t for t in tm.values() if t is not None]
        self.assertEqual(len(set(vals)), len(vals), 'tabOrder כפול נשאר')
        self.assertGreater(tm['vis002'], 3, 'השכפול עולה מעל max(z,tabOrder) בדף (z מקסימלי=3)')

    def test_negative_taborder_untouched(self):
        # סכינת שלילית (~-9.99e6) = המחבר הוציא את הוויזואל מסדר ה-tab בכוונה
        # (MS Learn accessibility) — אסור לגעת, זו בחירת נגישות לגיטימית
        self._set_tab('vis001', -9999000)
        self._set_tab('vis002', -9998000)
        docs = F.Docs()
        F.fix_taborderfix(docs, self.rp)
        self.assertEqual(docs.changed(), [], 'נגע ב-tabOrder שלילי (סכינת הסתרה מסדר tab)')

    def test_negative_duplicate_untouched(self):
        # סבב 92: שני tabOrder שליליים *זהים* אינם כפילות — שניהם סכינת ההסרה
        # המכוונת מסדר ה-tab (MS Learn accessibility). תיקון שלהם היה מבטל
        # בחירת נגישות לגיטימית; מוחרגים מהזיהוי עצמו
        self._set_tab('vis001', -9999000)
        self._set_tab('vis002', -9999000)
        docs = F.Docs()
        F.fix_taborderfix(docs, self.rp)
        self.assertEqual(docs.changed(), [],
                         'טיפל בשני tabOrder שליליים זהים כאילו הם כפילות')

    def test_missing_taborder_untouched(self):
        # ה-fixture בלי tabOrder בכלל — רעש אוניברסלי, אסור להוסיף (FP guard)
        docs = F.Docs()
        F.fix_taborderfix(docs, self.rp)
        self.assertEqual(docs.changed(), [], 'נגע בוויזואלים בלי tabOrder (FP)')

    def test_idempotent(self):
        self._set_tab('vis001', 1)
        self._set_tab('vis002', 1)
        self._apply()
        docs2 = F.Docs()
        F.fix_taborderfix(docs2, self.rp)
        self.assertEqual(docs2.changed(), [], 'הרצה שנייה לא אידמפוטנטית')


class TestLegacyLayoutR80(unittest.TestCase):
    """סבב 93 — R-80: פריסת PBIP מדור קודם (PBIR 1.x). report.json בשורש .Report
    בלי definition/ + model.bim במודל. בלעדי הזיהוי, R-02/R-03/R-04 מפליטים מפל
    "קבצים חסרים" מטעה. מקור: NatVanG/PBI-Inspector (MIT) — fixtures של legacy."""

    def setUp(self):
        V._ISSUES.clear()
        self.root = tempfile.mkdtemp(prefix='pbilegacy-')
        rp = os.path.join(self.root, 'L.Report')
        sm = os.path.join(self.root, 'L.Dataset')
        w(os.path.join(rp, 'definition.pbir'),
          json.dumps({"version": "1.0",
                      "datasetReference": {"byPath": {"path": "../L.Dataset"},
                                           "byConnection": None}}))
        w(os.path.join(rp, 'report.json'), json.dumps({"config": "{}"}))
        w(os.path.join(sm, 'definition.pbidataset'), '{}')
        w(os.path.join(sm, 'model.bim'), '{}')
        mt = V.read_model_map(sm)
        V.validate_model(sm)
        V.validate_report(rp, mt)

    def tearDown(self):
        shutil.rmtree(self.root, ignore_errors=True)

    def codes(self):
        return [i['code'] for i in V._ISSUES]

    def test_r80_fires_once(self):
        self.assertEqual(self.codes().count('R-80'), 1, 'R-80 לא זיהה פריסת legacy')

    def test_no_misleading_missing_file_cascade(self):
        for c in ('R-02', 'R-03', 'R-04'):
            self.assertNotIn(c, self.codes(),
                             '%s הופעל על פריסת legacy — מטעה ("קובץ חסר")' % c)

    def test_pbir_fixture_not_legacy(self):
        # מגן FP: פרויקט PBIR תקין (יש definition/) לעולם לא R-80
        V._ISSUES.clear()
        rp = os.path.join(FIX, 'MiniReport.Report')
        mt = V.read_model_map(os.path.join(FIX, 'MiniReport.SemanticModel'))
        V.validate_report(rp, mt)
        self.assertNotIn('R-80', [i['code'] for i in V._ISSUES])

class TestTooltipShowR81(unittest.TestCase):
    """סבב 94 — R-81: שדות ב-queryState.Tooltips אבל לוח ה-tooltip כבוי
    (visualTooltip.show != true). הלוח כבוי כברירת מחדל — שדות שהוכנסו בלי
    הפעלה לא נראים בריחוף, בשקט. נמצא בקורפוס: advw azureMap.
    מקור: microsoft/skills-for-fabric slicers.md (CC-BY-4.0) § General rules."""

    def _build(self, with_show=True, canvas=False):
        V._ISSUES.clear()
        root = tempfile.mkdtemp(prefix='pbitt-')
        rp = os.path.join(root, 'T.Report')
        w(os.path.join(rp, 'definition.pbir'),
          json.dumps({"version": "4.0",
                      "datasetReference": {"byConnection": None}}))
        w(os.path.join(rp, 'definition', 'report.json'), '{}')
        w(os.path.join(rp, 'definition', 'pages', 'pages.json'),
          json.dumps({"activePageName": "page001",
                      "pages": [{"name": "page001", "displayName": "P1"}]}))
        w(os.path.join(rp, 'definition', 'pages', 'page001', 'page.json'),
          json.dumps({"name": "page001", "displayName": "P1"}))
        props = {}
        if with_show:
            props['show'] = {'expr': {'Literal': {'Value': 'true'}}}
        if canvas:
            props['type'] = {'expr': {'Literal': {'Value': "'Canvas'"}}}
        vco = {'visualTooltip': [{'properties': props}]} if props else {}
        w(os.path.join(rp, 'definition', 'pages', 'page001', 'visuals',
                       'ttv', 'visual.json'),
          json.dumps({
              "name": "ttv",
              "visual": {
                  "visualType": "azureMap",
                  "visualContainerObjects": vco,
                  "query": {"queryState": {"Tooltips": {"projections": [
                      {"field": {"Column": {"Expression": {"SourceRef":
                                                          {"Entity": "Sales"}},
                                            "Property": "Amt"}},
                       "queryRef": "Sales.Amt"}]}}},
              }}))
        self.addCleanup(shutil.rmtree, root, True)
        return rp

    def _codes(self):
        return [i['code'] for i in V._ISSUES]

    def test_warns_when_show_missing(self):
        rp = self._build(with_show=False)
        V.validate_report(rp, {})
        r81 = [i for i in V._ISSUES if i['code'] == 'R-81']
        self.assertEqual(len(r81), 1, 'R-81 לא הופעל על Tooltips בלי show=true')
        self.assertEqual(r81[0]['level'], 'warn')

    def test_quiet_when_show_true(self):
        rp = self._build(with_show=True)
        V.validate_report(rp, {})
        self.assertNotIn('R-81', self._codes(),
                         'R-81 הופעל למרות show=true (capital scatterChart)')

    def test_quiet_for_canvas_tooltip(self):
        # tooltip עמוד-דוח (Canvas) — הקונפיגורציה מוכיחת כוונה; דילוג
        rp = self._build(with_show=False, canvas=True)
        V.validate_report(rp, {})
        self.assertNotIn('R-81', self._codes(), 'R-81 הופעל על tooltip Canvas')

    def test_quiet_without_tooltips_role(self):
        # מגן FP: ויזואל רגיל בלי שדות Tooltips לעולם לא R-81
        rp = self._build(with_show=False)
        vj = os.path.join(rp, 'definition', 'pages', 'page001', 'visuals',
                          'ttv', 'visual.json')
        obj = json.loads(open(vj, encoding='utf-8').read())
        obj['visual']['query'] = {'queryState': {}}
        w(vj, json.dumps(obj))
        V.validate_report(rp, {})
        self.assertNotIn('R-81', self._codes(), 'R-81 הופעל בלי שדות Tooltips')

class TestTooltipShowFix(unittest.TestCase):
    """סבב 95 — pbi_fix 'tooltipshow' (תיקון מספר 16): שדות ב-queryState.Tooltips
    בלי visualTooltip.show=true ← הזרקת show=true. מיזוג לבלוק קיים, דילוג על
    show מפורש (גם false) ועל Canvas. מקור: MS Learn desktop-tooltips (CC-BY-4.0)
    + skills-for-fabric slicers.md (סבב 94)."""

    def _report(self, visual):
        root = tempfile.mkdtemp(prefix='pbitshow-')
        rp = os.path.join(root, 'T.Report')
        w(os.path.join(rp, 'definition.pbir'),
          json.dumps({"version": "4.0",
                      "datasetReference": {"byConnection": None}}))
        w(os.path.join(rp, 'definition', 'report.json'), '{}')
        w(os.path.join(rp, 'definition', 'pages', 'pages.json'),
          json.dumps({"activePageName": "p1",
                      "pages": [{"name": "p1", "displayName": "P1"}]}))
        w(os.path.join(rp, 'definition', 'pages', 'p1', 'page.json'),
          json.dumps({"name": "p1", "displayName": "P1"}))
        w(os.path.join(rp, 'definition', 'pages', 'p1', 'visuals',
                       'v1', 'visual.json'), json.dumps(visual))
        self.addCleanup(shutil.rmtree, root, True)
        return rp

    @staticmethod
    def _vis(vco=None, with_tooltips=True):
        vis = {"visualType": "azureMap",
               "query": {"queryState": {}}}
        if with_tooltips:
            vis['query']['queryState']['Tooltips'] = {"projections": [
                {"field": {"Column": {"Expression": {"SourceRef": {"Entity": "S"}},
                                      "Property": "Amt"}},
                 "queryRef": "S.Amt"}]}
        if vco is not None:
            vis['visualContainerObjects'] = vco
        return {"name": "v1", "position": {"x": 0, "y": 0, "z": 0,
                                           "width": 100, "height": 100},
                "visual": vis}

    def _run(self, rp):
        docs = F.Docs()
        F.fix_tooltipshow(docs, rp)
        return docs

    @staticmethod
    def _changed_json(docs):
        changed = docs.changed()
        return json.loads(changed[0][1]['text']) if changed else None

    def test_injects_show_into_new_block(self):
        rp = self._report(self._vis())
        docs = self._run(rp)
        self.assertEqual(len(docs.changed()), 1, 'tooltipshow לא טיפל בחסר show')
        vt = self._changed_json(docs)['visual']['visualContainerObjects']['visualTooltip']
        self.assertEqual(vt[0]['properties']['show']['expr']['Literal']['Value'],
                         'true')

    def test_merges_into_existing_block(self):
        # advw azureMap האמיתי: visualTooltip עם sentenceTemplate בלי show
        vco = {'visualTooltip': [{'properties': {
            'sentenceTemplate': {'expr': {'Literal': {'Value': "'{x}'"}}}}}]}
        rp = self._report(self._vis(vco=vco))
        docs = self._run(rp)
        self.assertEqual(len(docs.changed()), 1)
        props = self._changed_json(docs)['visual']['visualContainerObjects'] \
            ['visualTooltip'][0]['properties']
        self.assertEqual(props['show']['expr']['Literal']['Value'], 'true')
        self.assertIn('sentenceTemplate', props, 'המיזוג דרס מאפיינים קיימים')

    def test_skips_explicit_show_false(self):
        # show='false' מפורש = בחירה מודעת — לעולם לא נדרס
        vco = {'visualTooltip': [{'properties': {
            'show': {'expr': {'Literal': {'Value': 'false'}}}}}]}
        rp = self._report(self._vis(vco=vco))
        docs = self._run(rp)
        self.assertEqual(docs.changed(), [], 'דרס show=false מפורש')

    def test_skips_canvas_tooltip(self):
        vco = {'visualTooltip': [{'properties': {
            'type': {'expr': {'Literal': {'Value': "'Canvas'"}}}}}]}
        rp = self._report(self._vis(vco=vco))
        docs = self._run(rp)
        self.assertEqual(docs.changed(), [], 'נגע ב-tooltip מסוג Canvas')

    def test_untouched_without_tooltips_role(self):
        rp = self._report(self._vis(with_tooltips=False))
        docs = self._run(rp)
        self.assertEqual(docs.changed(), [], 'נגע בוויזואל בלי שדות Tooltips (FP)')

    def test_idempotent(self):
        rp = self._report(self._vis())
        docs1 = self._run(rp)
        docs1.write_all()
        docs2 = F.Docs()
        F.fix_tooltipshow(docs2, rp)
        self.assertEqual(docs2.changed(), [], 'הרצה שנייה לא אידמפוטנטית')

class TestFilterHoistFix(unittest.TestCase):
    """סבב 101 — pbi_fix 'filterhoist' (תיקון מספר 17): filterConfig מקונן בתוך
    אובייקט visual (R-83) ← העברה לרמה העליונה. סכמה רשמית: microsoft/
    json-schemas visualContainer 2.0.0 (MIT) — filterConfig עליון בלבד."""

    def _report(self, visual):
        root = tempfile.mkdtemp(prefix='pbifh-')
        rp = os.path.join(root, 'T.Report')
        w(os.path.join(rp, 'definition.pbir'),
          json.dumps({"version": "4.0",
                      "datasetReference": {"byConnection": None}}))
        w(os.path.join(rp, 'definition', 'report.json'), '{}')
        w(os.path.join(rp, 'definition', 'pages', 'pages.json'),
          json.dumps({"activePageName": "p1",
                      "pages": [{"name": "p1", "displayName": "P1"}]}))
        w(os.path.join(rp, 'definition', 'pages', 'p1', 'page.json'),
          json.dumps({"name": "p1", "displayName": "P1"}))
        w(os.path.join(rp, 'definition', 'pages', 'p1', 'visuals',
                       'v1', 'visual.json'), json.dumps(visual))
        self.addCleanup(shutil.rmtree, root, True)
        return rp

    _FC = {"filters": [{"name": "f1", "field": {"Column": {
        "Expression": {"SourceRef": {"Entity": "T"}}, "Property": "c"}}}]}

    def _vis(self, nested='yes', toplevel=False):
        vj = {"name": "v1",
              "position": {"x": 0, "y": 0, "z": 0, "width": 100, "height": 100},
              "visual": {"visualType": "card"}}
        if nested == 'yes':
            vj['visual']['filterConfig'] = dict(self._FC)
        elif nested == 'empty':
            vj['visual']['filterConfig'] = {}
        if toplevel:
            vj['filterConfig'] = {"filters": []}
        return vj

    def _run(self, rp):
        docs = F.Docs()
        skipped = F.fix_filterhoist(docs, rp)
        return docs, skipped

    def test_hoists_nested_filterconfig(self):
        rp = self._report(self._vis('yes'))
        docs, skipped = self._run(rp)
        self.assertEqual(skipped, [])
        self.assertEqual(len(docs.changed()), 1, 'filterhoist לא טיפל בקינון')
        d = json.loads(docs.changed()[0][1]['text'])
        self.assertNotIn('filterConfig', d['visual'], 'המפתח המקונן לא הוסר')
        self.assertEqual(d['filterConfig']['filters'][0]['name'], 'f1',
                         'תוכן המסננים לא שרד את ההעברה')

    def test_removes_empty_nested(self):
        rp = self._report(self._vis('empty'))
        docs, _ = self._run(rp)
        d = json.loads(docs.changed()[0][1]['text'])
        self.assertNotIn('filterConfig', d['visual'])
        self.assertNotIn('filterConfig', d, 'filterConfig ריק הועבר במקום להימחק')

    def test_skips_conflict_with_toplevel(self):
        rp = self._report(self._vis('yes', toplevel=True))
        docs, skipped = self._run(rp)
        self.assertEqual(docs.changed(), [], 'דרס filterConfig עליון קיים')
        self.assertEqual(len(skipped), 1, 'הקונפליקט לא דווח')

    def test_untouched_clean_visual(self):
        rp = self._report(self._vis('no'))
        docs, _ = self._run(rp)
        self.assertEqual(docs.changed(), [], 'נגע בוויזואל תקין (FP)')

    def test_idempotent(self):
        rp = self._report(self._vis('yes'))
        docs, _ = self._run(rp)
        docs.write_all()
        docs2 = F.Docs()
        F.fix_filterhoist(docs2, rp)
        self.assertEqual(docs2.changed(), [], 'הרצה שנייה לא אידמפוטנטית')

    def test_fix_clears_r83(self):
        # מקצה-לקצה: R-83 יורה לפני התיקון ונעלם אחריו
        rp = self._report(self._vis('yes'))
        V._ISSUES.clear()
        V.validate_report(rp, {})
        self.assertTrue(any(i['code'] == 'R-83' for i in V._ISSUES),
                        'R-83 לא ירה על הפיקסצר השבור')
        docs, _ = self._run(rp)
        docs.write_all()
        V._ISSUES.clear()
        V.validate_report(rp, {})
        self.assertEqual([i for i in V._ISSUES if i['code'] == 'R-83'], [],
                         'R-83 נשאר אחרי filterhoist')


class TestEmptyReportExtensionsR12(unittest.TestCase):
    """סבב 97 — הרחבת R-12: reportExtensions.json עם entities ריק מפיל את Desktop
    בפתיחה (jonathan-pap/powerbi-report-mcp pbir-gotchas.md B15, MIT — אומת ע"י
    כתיבה->Desktop->קריאה חוזרת). התיקון: למחוק את הקובץ, לא להשאיר ריק."""

    def _build(self, rex_content):
        V._ISSUES.clear()
        root = tempfile.mkdtemp(prefix='pbirex-')
        rp = os.path.join(root, 'T.Report')
        w(os.path.join(rp, 'definition.pbir'),
          json.dumps({"version": "4.0",
                      "datasetReference": {"byConnection": None}}))
        w(os.path.join(rp, 'definition', 'report.json'), '{}')
        w(os.path.join(rp, 'definition', 'pages', 'pages.json'),
          json.dumps({"activePageName": "p1",
                      "pages": [{"name": "p1", "displayName": "P1"}]}))
        w(os.path.join(rp, 'definition', 'pages', 'p1', 'page.json'),
          json.dumps({"name": "p1", "displayName": "P1"}))
        if rex_content is not None:
            w(os.path.join(rp, 'definition', 'reportExtensions.json'), rex_content)
        self.addCleanup(shutil.rmtree, root, True)
        return rp

    def _codes(self):
        return [i['code'] for i in V._ISSUES]

    def test_empty_entities_is_error(self):
        rp = self._build('{"entities": []}')
        V.validate_report(rp, {})
        r12 = [i for i in V._ISSUES if i['code'] == 'R-12']
        self.assertTrue(any('ריק' in i['title'] and i['level'] == 'err'
                            for i in r12), 'entities ריק לא נתפס כשגיאה')

    def test_nonempty_entities_clean(self):
        rp = self._build(json.dumps({"entities": [{"name": "e1"}]}))
        V.validate_report(rp, {})
        self.assertEqual([i for i in V._ISSUES if i['code'] == 'R-12'], [],
                         'reportExtensions תקין סומן')

    def test_missing_file_clean(self):
        rp = self._build(None)
        V.validate_report(rp, {})
        self.assertEqual([i for i in V._ISSUES if i['code'] == 'R-12'], [],
                         'R-12 הופעל בלי קובץ בכלל')


class TestTopLevelFiltersR82(unittest.TestCase):
    """סבב 97 — R-82: מפתח 'filters' ברמת השורש של page.json/report.json
    (schema 2.1.0+ מצפה ל-filterConfig כעוגן) — מבלבל את Desktop
    (powerbi-report-mcp pbir-gotchas.md Q3, MIT)."""

    def _build(self, page_filters=False, report_filters=False):
        V._ISSUES.clear()
        root = tempfile.mkdtemp(prefix='pbitlf-')
        rp = os.path.join(root, 'T.Report')
        w(os.path.join(rp, 'definition.pbir'),
          json.dumps({"version": "4.0",
                      "datasetReference": {"byConnection": None}}))
        rj = {}
        if report_filters:
            rj['filters'] = []
        w(os.path.join(rp, 'definition', 'report.json'), json.dumps(rj))
        w(os.path.join(rp, 'definition', 'pages', 'pages.json'),
          json.dumps({"activePageName": "p1",
                      "pages": [{"name": "p1", "displayName": "P1"}]}))
        pj = {"name": "p1", "displayName": "P1"}
        if page_filters:
            pj['filters'] = []
        w(os.path.join(rp, 'definition', 'pages', 'p1', 'page.json'),
          json.dumps(pj))
        self.addCleanup(shutil.rmtree, root, True)
        return rp

    def test_page_level_fires(self):
        rp = self._build(page_filters=True)
        V.validate_report(rp, {})
        r82 = [i for i in V._ISSUES if i['code'] == 'R-82']
        self.assertEqual(len(r82), 1, "מפתח 'filters' עצמאי ב-page.json לא נתפס")
        self.assertEqual(r82[0]['level'], 'warn')

    def test_report_level_fires(self):
        rp = self._build(report_filters=True)
        V.validate_report(rp, {})
        self.assertEqual(len([i for i in V._ISSUES if i['code'] == 'R-82']), 1,
                         "מפתח 'filters' עצמאי ב-report.json לא נתפס")

    def test_filterconfig_only_clean(self):
        rp = self._build()
        V.validate_report(rp, {})
        self.assertEqual([i for i in V._ISSUES if i['code'] == 'R-82'], [],
                         'R-82 הופעל על פרויקט תקין (FP)')


class TestNestedFilterConfigR83(unittest.TestCase):
    """סבב 99 — R-83: filterConfig בתוך אובייקט visual (במקום ברמת
    visual.json). Desktop דוחה בטעינה (additional property in /visual);
    ולידטורים headless לא תופסים (iamahlramz/pbip-tools
    TOOLCHAIN-FINDINGS-2026-07-13 #3, MIT)."""

    def _build(self, mode='nested'):
        V._ISSUES.clear()
        root = tempfile.mkdtemp(prefix='pbinfc-')
        rp = os.path.join(root, 'T.Report')
        w(os.path.join(rp, 'definition.pbir'),
          json.dumps({"version": "4.0",
                      "datasetReference": {"byConnection": None}}))
        w(os.path.join(rp, 'definition', 'report.json'), '{}')
        w(os.path.join(rp, 'definition', 'pages', 'pages.json'),
          json.dumps({"activePageName": "page001",
                      "pages": [{"name": "page001", "displayName": "P1"}]}))
        w(os.path.join(rp, 'definition', 'pages', 'page001', 'page.json'),
          json.dumps({"name": "page001", "displayName": "P1"}))
        fc = {"filters": [{"name": "f1", "field": {"Column": {
            "Expression": {"SourceRef": {"Entity": "T"}}, "Property": "c"}}}]}
        vj = {"name": "v1",
              "position": {"x": 0, "y": 0, "z": 1, "width": 200, "height": 100},
              "visual": {"visualType": "card"}}
        if mode == 'nested':
            vj['visual']['filterConfig'] = fc          # שבור: מקונן ברמה הלא נכונה
        elif mode == 'toplevel':
            vj['filterConfig'] = fc                    # תקין: אח של visual
        elif mode == 'group':
            vj = {"name": "g1",
                  "position": {"x": 0, "y": 0, "z": 1, "width": 200,
                               "height": 100},
                  "visualGroup": {"displayName": "grp",
                                  "groupMode": "ScaleMode"}}
        w(os.path.join(rp, 'definition', 'pages', 'page001', 'visuals',
                       'v1', 'visual.json'), json.dumps(vj))
        self.addCleanup(shutil.rmtree, root, True)
        return rp

    def test_nested_fires_err(self):
        rp = self._build('nested')
        V.validate_report(rp, {})
        r83 = [i for i in V._ISSUES if i['code'] == 'R-83']
        self.assertEqual(len(r83), 1, 'filterConfig מקונן לא נתפס')
        self.assertEqual(r83[0]['level'], 'err')

    def test_toplevel_clean(self):
        rp = self._build('toplevel')
        V.validate_report(rp, {})
        self.assertEqual([i for i in V._ISSUES if i['code'] == 'R-83'], [],
                         'R-83 הופעל על מיקום תקין (FP)')

    def test_no_filterconfig_clean(self):
        rp = self._build('none')
        V.validate_report(rp, {})
        self.assertEqual([i for i in V._ISSUES if i['code'] == 'R-83'], [],
                         'R-83 הופעל בלי filterConfig בכלל (FP)')

    def test_group_container_clean(self):
        # מכולת קבוצה בלי מפתח visual — לעולם לא R-83
        rp = self._build('group')
        V.validate_report(rp, {})
        self.assertEqual([i for i in V._ISSUES if i['code'] == 'R-83'], [],
                         'R-83 הופעל על מכולת קבוצה (FP)')


class TestLocalClean(unittest.TestCase):
    """סבב 108 — pbi_fix 'localclean' (תיקון מספר 18): מחיקת .pbi/localSettings.json
    ו-cache.abf (R-85). שניהם artifacts מקומיים למחשב, נבנים מחדש ב-Desktop
    (MS Learn projects-dataset, CC-BY-4.0). pbix/pbit בשורש — דילוג ידני תמיד."""

    def _project(self):
        root = tempfile.mkdtemp(prefix='pbilclean-')
        sm = os.path.join(root, 'T.SemanticModel')
        rp = os.path.join(root, 'T.Report')
        for base in (sm, rp):
            w(os.path.join(base, '.pbi', 'localSettings.json'), '{}')
            w(os.path.join(base, '.pbi', 'cache.abf'), 'ABF')
            w(os.path.join(base, '.pbi', 'editorSettings.json'), '{}')
            w(os.path.join(base, '.pbi', 'unappliedChanges.json'), '[]')
        w(os.path.join(root, 'backup.pbix'), 'PBIX')
        self.addCleanup(shutil.rmtree, root, True)
        return root, rp, sm

    def test_detects_local_artifacts_and_skips_pbix(self):
        root, rp, sm = self._project()
        td, sk = F.fix_localclean(rp, sm)
        self.assertEqual(4, len(td), '2 קבצים × 2 תיקיות לא זוהו')
        self.assertTrue(any('localSettings' in p for p in td))
        self.assertTrue(any('cache.abf' in p for p in td))
        self.assertFalse(any('editorSettings' in p or 'unappliedChanges' in p for p in td),
                         'editorSettings/unappliedChanges נכנסו למחיקה (מסוכן)')
        self.assertEqual(1, len(sk), 'pbix בשורש לא דולג עם הנמקה')
        self.assertIn('backup.pbix', sk[0])

    def test_apply_deletes_and_preserves(self):
        root, rp, sm = self._project()
        td, sk = F.fix_localclean(rp, sm)
        removed, failed = F.apply_deletions(td)
        self.assertEqual(4, len(removed))
        self.assertFalse(failed)
        for base in (sm, rp):
            self.assertFalse(os.path.exists(os.path.join(base, '.pbi', 'cache.abf')))
            self.assertFalse(os.path.exists(os.path.join(base, '.pbi', 'localSettings.json')))
            self.assertTrue(os.path.exists(os.path.join(base, '.pbi', 'editorSettings.json')))
            self.assertTrue(os.path.exists(os.path.join(base, '.pbi', 'unappliedChanges.json')))
        self.assertTrue(os.path.exists(os.path.join(root, 'backup.pbix')),
                        'pbix נמחק — אסור')

    def test_idempotent_second_run(self):
        root, rp, sm = self._project()
        td, _ = F.fix_localclean(rp, sm)
        F.apply_deletions(td)
        td2, sk2 = F.fix_localclean(rp, sm)
        self.assertEqual([], td2, 'ריצה שנייה מצאה עוד קבצים למחיקה')
        self.assertEqual(1, len(sk2), 'דילוג ה-pbix צריך להישאר עקבי')

    def test_clean_project_noop(self):
        root = tempfile.mkdtemp(prefix='pbilclean0-')
        rp = os.path.join(root, 'T.Report')
        sm = os.path.join(root, 'T.SemanticModel')
        os.makedirs(os.path.join(rp, '.pbi'))
        os.makedirs(sm)
        self.addCleanup(shutil.rmtree, root, True)
        td, sk = F.fix_localclean(rp, sm)
        self.assertEqual(([], []), (td, sk), 'פרויקט נקי לא אמור לייצר פעולות')


class TestR86PathLength(unittest.TestCase):
    """סבב 110 — R-86: נתיב יחסי מעל 200 תווים = סיכון MAX_PATH (260) בשיבוט
    Windows עם prefix שגרתי. מקור: MS Learn maximum-file-path-limitation
    (CC-BY-4.0). בקורפוס: 0 מופעים (הארוך ביותר 162 — capital deneb)."""

    def setUp(self):
        self.root = tempfile.mkdtemp(prefix='pbir86-')
        self.dst = os.path.join(self.root, 'P')
        shutil.copytree(FIX, self.dst)

    def tearDown(self):
        shutil.rmtree(self.root, ignore_errors=True)

    def _run_main(self):
        import contextlib, io
        V._ISSUES.clear()
        argv = ['pbi_validate.py', self.dst]
        try:
            sys.argv = argv
            with contextlib.redirect_stdout(io.StringIO()):
                V.main()
        finally:
            sys.argv = argv[:1]
        return [i for i in V._ISSUES if i['code'] == 'R-86']

    def test_long_relative_path_warned(self):
        deep = os.path.join(self.dst, *(['d' * 48] * 4))
        os.makedirs(deep)
        w(os.path.join(deep, 'file.json'), '{}')  # rel ≈ 4*48+3+10 = 205
        r86 = self._run_main()
        self.assertEqual(1, len(r86), 'נתיב 205 תווים לא נתפס')
        self.assertEqual('warn', r86[0]['level'])

    def test_short_path_clean(self):
        deep = os.path.join(self.dst, 'a', 'b')
        os.makedirs(deep)
        w(os.path.join(deep, 'file.json'), '{}')
        self.assertEqual([], self._run_main(), 'נתיב קצר סומן (FP)')

    def test_git_dir_excluded(self):
        deep = os.path.join(self.dst, '.git', *(['d' * 48] * 4))
        os.makedirs(deep)
        w(os.path.join(deep, 'file'), 'x')
        self.assertEqual([], self._run_main(), 'תיקיית .git נסרקה (לא חלק מהפרויקט)')


class ExprShapeChecks(unittest.TestCase):
    """R-87/R-88/R-90 — צורות expr מול semanticQuery 1.4.0 (סבב 118; מקור הרעיונות:
    data-goblin/power-bi-agentic-development @ v26.31.0, GPL-3.0 — מומש מחדש)."""

    def setUp(self):
        self.td = tempfile.mkdtemp()
        self.proot = os.path.join(self.td, 'MiniReport')
        shutil.copytree(FIX, self.proot)
        self.rp = os.path.join(self.proot, 'MiniReport.Report')
        self.sm = os.path.join(self.proot, 'MiniReport.SemanticModel')

    def tearDown(self):
        shutil.rmtree(self.td, ignore_errors=True)

    def run_val(self):
        V._ISSUES.clear()
        mt = V.read_model_map(self.sm)
        V.validate_model(self.sm)
        V.validate_report(self.rp, mt)
        return V._ISSUES

    def _write_visual_objects(self, vid, entry):
        vj = os.path.join(self.rp, 'definition', 'pages', 'page001', 'visuals', vid, 'visual.json')
        os.makedirs(os.path.dirname(vj), exist_ok=True)
        w(vj, json.dumps({"name": vid,
                          "position": {"x": 0, "y": 0, "z": 1, "width": 4, "height": 3},
                          "visual": {"visualType": "barChart",
                                     "objects": {"dataPoint": [entry]}}},
                         ensure_ascii=False))

    def _measure_expr(self, entity, prop, schema=None):
        sr = {"Entity": entity}
        if schema:
            sr["Schema"] = schema
        return {"Measure": {"Expression": {"SourceRef": sr}, "Property": prop}}

    def _write_extensions(self, entities):
        w(os.path.join(self.rp, 'definition', 'reportExtensions.json'),
          json.dumps({"name": "extension", "entities": entities}, ensure_ascii=False))

    def test_clean_fixture_has_no_expr_shape_findings(self):
        issues = self.run_val()
        bad = [i for i in issues if i['code'] in ('R-87', 'R-88', 'R-90')]
        self.assertFalse(bad, 'fixture נקי סומן ב-R-87/88/90 (FP): %s' % bad[:2])

    def test_r87_missing_schema_on_extension_entity(self):
        self._write_extensions([{"name": "_Ext", "measures": [{"name": "M1"}]}])
        self._write_visual_objects('e1', {"properties": {"fill": {"solid": {"color": {
            "expr": self._measure_expr("_Ext", "M1")}}}}})
        issues = self.run_val()
        self.assertTrue(any(i['code'] == 'R-87' and i['level'] == 'err' for i in issues),
                        'Measure לישות הרחבה בלי Schema:"extension" לא נתפס')

    def test_r87_schema_extension_clean(self):
        self._write_extensions([{"name": "_Ext", "measures": [{"name": "M1"}]}])
        self._write_visual_objects('e2', {"properties": {"fill": {"solid": {"color": {
            "expr": self._measure_expr("_Ext", "M1", schema="extension")}}}}})
        issues = [i for i in self.run_val() if i['code'] == 'R-87']
        self.assertFalse(issues, 'הפניית הרחבה תקינה סומנה (FP): %s' % issues[:1])

    def test_r87_unknown_extension_entity(self):
        self._write_extensions([{"name": "_Ext", "measures": [{"name": "M1"}]}])
        self._write_visual_objects('e3', {"properties": {"fill": {"solid": {"color": {
            "expr": self._measure_expr("_Nope", "M1", schema="extension")}}}}})
        issues = self.run_val()
        self.assertTrue(any(i['code'] == 'R-87' and i['level'] == 'err' for i in issues),
                        'Schema extension לישות לא רשומה לא נתפס')

    def test_r87_unknown_measure_in_extension_entity(self):
        self._write_extensions([{"name": "_Ext", "measures": [{"name": "M1"}]}])
        self._write_visual_objects('e4', {"properties": {"fill": {"solid": {"color": {
            "expr": self._measure_expr("_Ext", "M2", schema="extension")}}}}})
        issues = self.run_val()
        self.assertTrue(any(i['code'] == 'R-87' and i['level'] == 'err' for i in issues),
                        'מדד הרחבה לא רשום בישות לא נתפס')

    def test_r88_scopeid_with_measure_warned(self):
        entry = {"properties": {"fill": {"solid": {"color": {
                    "expr": self._measure_expr("factמכירות", "כמות שנתית")}}}},
                 "selector": {"data": [{"scopeId": {"Comparison": {
                     "ComparisonKind": 0,
                     "Left": {"Column": {"Expression": {"SourceRef": {"Entity": "dimמוצרים"}},
                                         "Property": "מוצר"}},
                     "Right": {"Literal": {"Value": "'X'"}}}}}]}}
        self._write_visual_objects('e5', entry)
        issues = self.run_val()
        self.assertTrue(any(i['code'] == 'R-88' and i['level'] == 'warn' for i in issues),
                        'scopeId + Measure לא סומן')

    def test_r88_scopeid_with_literal_clean(self):
        entry = {"properties": {"fill": {"solid": {"color": {
                    "expr": {"Literal": {"Value": "'#E66C37'"}}}}}},
                 "selector": {"data": [{"scopeId": {"Comparison": {
                     "ComparisonKind": 0,
                     "Left": {"Column": {"Expression": {"SourceRef": {"Entity": "dimמוצרים"}},
                                         "Property": "מוצר"}},
                     "Right": {"Literal": {"Value": "'X'"}}}}}]}}
        self._write_visual_objects('e6', entry)
        issues = [i for i in self.run_val() if i['code'] == 'R-88']
        self.assertFalse(issues, 'scopeId עם ליטרל סומן (FP)')

    def test_r90_bool_wrong_case(self):
        self._write_visual_objects('e7', {"properties": {"show": {
            "expr": {"Literal": {"Value": "True"}}}}})
        issues = self.run_val()
        self.assertTrue(any(i['code'] == 'R-90' and i['level'] == 'err' for i in issues),
                        "Literal 'True' לא נתפס")

    def test_r90_numeric_missing_suffix(self):
        self._write_visual_objects('e8', {"properties": {"transparency": {
            "expr": {"Literal": {"Value": "50"}}}}})
        issues = self.run_val()
        self.assertTrue(any(i['code'] == 'R-90' and i['level'] == 'err' for i in issues),
                        "Literal '50' בלי סיומת לא נתפס")

    def test_r90_nonstring_value(self):
        self._write_visual_objects('e9', {"properties": {"transparency": {
            "expr": {"Literal": {"Value": 50}}}}})
        issues = self.run_val()
        self.assertTrue(any(i['code'] == 'R-90' and i['level'] == 'err' for i in issues),
                        'Literal.Value מספרי גולמי לא נתפס')

    def test_r90_valid_literals_clean(self):
        self._write_visual_objects('e10', {"properties": {
            "transparency": {"expr": {"Literal": {"Value": "50D"}}},
            "show": {"expr": {"Literal": {"Value": "true"}}},
            "fill": {"solid": {"color": {"expr": {"Literal": {"Value": "'#118DFF'"}}}}}}})
        issues = [i for i in self.run_val() if i['code'] == 'R-90']
        self.assertFalse(issues, 'ליטרלים תקינים סומנו (FP): %s' % issues[:1])



class ExprShape2Checks(unittest.TestCase):
    """R-89/R-91/R-92 — ThemeDataColor bounds, queryRef מול field, SparklineData
    (סבב 119; מקור הרעיונות: data-goblin/power-bi-agentic-development @ v26.31.0,
    GPL-3.0 — מומש מחדש)."""

    def setUp(self):
        self.td = tempfile.mkdtemp()
        self.proot = os.path.join(self.td, 'MiniReport')
        shutil.copytree(FIX, self.proot)
        self.rp = os.path.join(self.proot, 'MiniReport.Report')
        self.sm = os.path.join(self.proot, 'MiniReport.SemanticModel')

    def tearDown(self):
        shutil.rmtree(self.td, ignore_errors=True)

    def run_val(self):
        V._ISSUES.clear()
        mt = V.read_model_map(self.sm)
        V.validate_model(self.sm)
        V.validate_report(self.rp, mt)
        return V._ISSUES

    def _write_visual_objects(self, vid, entry):
        vj = os.path.join(self.rp, 'definition', 'pages', 'page001', 'visuals', vid, 'visual.json')
        os.makedirs(os.path.dirname(vj), exist_ok=True)
        w(vj, json.dumps({"name": vid,
                          "position": {"x": 0, "y": 0, "z": 1, "width": 4, "height": 3},
                          "visual": {"visualType": "barChart",
                                     "objects": {"dataPoint": [entry]}}},
                         ensure_ascii=False))

    def _write_visual_queryref(self, vid, query_ref):
        vj = os.path.join(self.rp, 'definition', 'pages', 'page001', 'visuals', vid, 'visual.json')
        os.makedirs(os.path.dirname(vj), exist_ok=True)
        w(vj, json.dumps({"name": vid,
                          "position": {"x": 0, "y": 0, "z": 1, "width": 4, "height": 3},
                          "visual": {"visualType": "barChart",
                                     "query": {"queryState": {"Category": {"projections": [
                                         {"field": {"Column": {"Expression": {"SourceRef": {"Entity": "dimתאריך"}},
                                                               "Property": "Date"}},
                                          "queryRef": query_ref}]}}}}},
                         ensure_ascii=False))

    def _write_theme(self, colors):
        td = os.path.join(self.rp, 'StaticResources', 'RegisteredResources')
        os.makedirs(td, exist_ok=True)
        w(os.path.join(td, 't1.json'),
          json.dumps({"name": "t1", "dataColors": colors}, ensure_ascii=False))

    def test_clean_fixture_no_new_codes(self):
        issues = [i for i in self.run_val() if i['code'] in ('R-89', 'R-91', 'R-92')]
        self.assertFalse(issues, 'fixture נקי סומן (FP): %s' % issues[:2])

    def test_r89_percent_out_of_range(self):
        self._write_visual_objects('t1', {"properties": {"fill": {"solid": {"color": {
            "expr": {"ThemeDataColor": {"ColorId": 0, "Percent": 2.0}}}}}}})
        issues = self.run_val()
        self.assertTrue(any(i['code'] == 'R-89' and i['level'] == 'err' for i in issues),
                        'Percent=2 לא נתפס')

    def test_r89_colorid_beyond_theme(self):
        self._write_theme(["#111111", "#222222"])
        self._write_visual_objects('t2', {"properties": {"fill": {"solid": {"color": {
            "expr": {"ThemeDataColor": {"ColorId": 5, "Percent": 0}}}}}}})
        issues = self.run_val()
        self.assertTrue(any(i['code'] == 'R-89' and i['level'] == 'err' for i in issues),
                        'ColorId=5 עם 2 צבעים לא נתפס')

    def test_r89_colorid_within_theme_clean(self):
        self._write_theme(["#111111", "#222222"])
        self._write_visual_objects('t3', {"properties": {"fill": {"solid": {"color": {
            "expr": {"ThemeDataColor": {"ColorId": 1, "Percent": -0.5}}}}}}})
        issues = [i for i in self.run_val() if i['code'] == 'R-89']
        self.assertFalse(issues, 'ThemeDataColor תקין סומן (FP)')

    def test_r91_queryref_mismatch_warned(self):
        self._write_visual_queryref('t4', 'dimתאריך.OldName')
        issues = self.run_val()
        self.assertTrue(any(i['code'] == 'R-91' and i['level'] == 'warn' for i in issues),
                        'queryRef שאינו תואם field לא סומן')

    def test_r91_queryref_match_clean(self):
        self._write_visual_queryref('t5', 'dimתאריך.Date')
        issues = [i for i in self.run_val() if i['code'] == 'R-91']
        self.assertFalse(issues, 'queryRef תקין סומן (FP)')

    def test_r91_visual_calc_select_skipped(self):
        self._write_visual_queryref('t6', 'select')
        issues = [i for i in self.run_val() if i['code'] == 'R-91']
        self.assertFalse(issues, "queryRef 'select' (visual calc) סומן (FP)")

    def test_r92_sparkline_bad_measure(self):
        entry = {"properties": {"show": {"expr": {"Literal": {"Value": "true"}}}},
                 "selector": {"metadata": "SparklineData(factמכירות.לא קיים_[dimתאריך.H.D])"}}
        self._write_visual_objects('t7', entry)
        issues = self.run_val()
        self.assertTrue(any(i['code'] == 'R-92' and i['level'] == 'err' for i in issues),
                        'SparklineData עם מדד חסר לא נתפס')

    def test_r92_sparkline_bad_group_entity(self):
        entry = {"properties": {"show": {"expr": {"Literal": {"Value": "true"}}}},
                 "selector": {"metadata": "SparklineData(factמכירות.כמות שנתית_[טבלהחסרה.H.D])"}}
        self._write_visual_objects('t8', entry)
        issues = self.run_val()
        self.assertTrue(any(i['code'] == 'R-92' and i['level'] == 'err' for i in issues),
                        'SparklineData עם טבלת קיבוץ חסרה לא נתפס')

    def test_r92_sparkline_valid_clean(self):
        entry = {"properties": {"show": {"expr": {"Literal": {"Value": "true"}}}},
                 "selector": {"metadata": "SparklineData(factמכירות.כמות שנתית_[dimתאריך.H.Date])"}}
        self._write_visual_objects('t9', entry)
        issues = [i for i in self.run_val() if i['code'] == 'R-92']
        self.assertFalse(issues, 'SparklineData תקין סומן (FP)')


class ExprShape3Checks(unittest.TestCase):
    """R-93/R-94 + A9 — תווי שם לא חוקיים, matchingOption:0+Measure, combo Y/Y2
    (סבב 120; מקור הרעיונות: data-goblin/power-bi-agentic-development @ v26.31.0,
    GPL-3.0 — מומש מחדש)."""

    def setUp(self):
        self.td = tempfile.mkdtemp()
        self.proot = os.path.join(self.td, 'MiniReport')
        shutil.copytree(FIX, self.proot)
        self.rp = os.path.join(self.proot, 'MiniReport.Report')
        self.sm = os.path.join(self.proot, 'MiniReport.SemanticModel')

    def tearDown(self):
        shutil.rmtree(self.td, ignore_errors=True)

    def run_val(self):
        V._ISSUES.clear()
        mt = V.read_model_map(self.sm)
        V.validate_model(self.sm)
        V.validate_report(self.rp, mt)
        return V._ISSUES

    def _write_visual_objects(self, vid, entry):
        vj = os.path.join(self.rp, 'definition', 'pages', 'page001', 'visuals', vid, 'visual.json')
        os.makedirs(os.path.dirname(vj), exist_ok=True)
        w(vj, json.dumps({"name": vid,
                          "position": {"x": 0, "y": 0, "z": 1, "width": 4, "height": 3},
                          "visual": {"visualType": "barChart",
                                     "objects": {"dataPoint": [entry]}}},
                         ensure_ascii=False))

    def test_clean_fixture_no_new_codes(self):
        issues = [i for i in self.run_val() if i['code'] in ('R-93', 'R-94')]
        self.assertFalse(issues, 'fixture נקי סומן (FP): %s' % issues[:2])

    def test_r93_page_folder_space(self):
        src = os.path.join(self.rp, 'definition', 'pages', 'page001')
        dst = os.path.join(self.rp, 'definition', 'pages', 'bad page')
        shutil.copytree(src, dst)
        issues = self.run_val()
        self.assertTrue(any(i['code'] == 'R-93' and i['level'] == 'err' for i in issues),
                        'תיקיית דף עם רווח לא נתפסה')

    def test_r93_visual_name_field_space(self):
        vj = os.path.join(self.rp, 'definition', 'pages', 'page001', 'visuals', 'vis001', 'visual.json')
        d = json.load(open(vj, encoding='utf-8-sig'))
        d['name'] = 'my visual'
        w(vj, json.dumps(d, ensure_ascii=False))
        issues = self.run_val()
        self.assertTrue(any(i['code'] == 'R-93' and i['level'] == 'err' for i in issues),
                        'שדה name עם רווח לא נתפס')

    def test_r94_matchingoption0_with_measure_warned(self):
        entry = {"properties": {"fill": {"solid": {"color": {"expr": {
                    "Measure": {"Expression": {"SourceRef": {"Entity": "factמכירות"}},
                                "Property": "כמות שנתית"}}}}}},
                 "selector": {"data": [{"dataViewWildcard": {"matchingOption": 0}}]}}
        self._write_visual_objects('m1', entry)
        issues = self.run_val()
        self.assertTrue(any(i['code'] == 'R-94' and i['level'] == 'warn' for i in issues),
                        'matchingOption:0 + Measure לא סומן')

    def test_r94_matchingoption1_clean(self):
        entry = {"properties": {"fill": {"solid": {"color": {"expr": {
                    "Measure": {"Expression": {"SourceRef": {"Entity": "factמכירות"}},
                                "Property": "כמות שנתית"}}}}}},
                 "selector": {"data": [{"dataViewWildcard": {"matchingOption": 1}}]}}
        self._write_visual_objects('m2', entry)
        issues = [i for i in self.run_val() if i['code'] == 'R-94']
        self.assertFalse(issues, 'matchingOption:1 + Measure סומן (FP)')

    def test_r94_matchingoption0_with_literal_clean(self):
        entry = {"properties": {"fill": {"solid": {"color": {
                    "expr": {"Literal": {"Value": "'#118DFF'"}}}}}},
                 "selector": {"data": [{"dataViewWildcard": {"matchingOption": 0}}]}}
        self._write_visual_objects('m3', entry)
        issues = [i for i in self.run_val() if i['code'] == 'R-94']
        self.assertFalse(issues, 'matchingOption:0 + Literal (עיצוב סידרה חוקי) סומן (FP)')

    def test_a9_linestacked_combo_role_plan(self):
        plan = SW.ROLE_PLAN.get('lineStackedColumnComboChart')
        self.assertIsNotNone(plan, 'lineStackedColumnComboChart חסר ב-ROLE_PLAN של pbi_swap')
        roles = [spec[0] for spec in plan]
        self.assertEqual(roles[:2], ['Category', 'Y'], 'combo: Y=עמודות חייב לבוא אחרי Category')
        self.assertIn('Y2', roles, 'combo: חסר Y2 (קווים)')


class ValidateProjectHygiene(unittest.TestCase):
    """pbi_validate M-19..M-22: היגיינת פרויקט — סבב 122 (data-goblin/
    power-bi-agentic-development c_filetypes/c_pbip_skill, GPL-3.0 — רעיונות, קרדיט)."""

    def setUp(self):
        self.root = tempfile.mkdtemp(prefix='pbiprj-')
        self.dst = os.path.join(self.root, 'P')
        shutil.copytree(FIX, self.dst)
        self.rp = os.path.join(self.dst, 'MiniReport.Report')
        self.sm = os.path.join(self.dst, 'MiniReport.SemanticModel')

    def tearDown(self):
        shutil.rmtree(self.root, ignore_errors=True)

    def _val(self):
        V._ISSUES.clear()
        V.validate_project(self.dst)
        return V._ISSUES

    def _platform(self, item_dir, lid):
        w(os.path.join(item_dir, '.platform'),
          json.dumps({'metadata': {'type': 'Report', 'displayName': 'x',
                                   'logicalId': lid}}))

    def test_dup_logicalid_is_error(self):
        lid = 'a1b2c3d4-e5f6-7890-abcd-ef1234567890'
        self._platform(self.rp, lid)
        self._platform(self.sm, lid)
        iss = self._val()
        self.assertTrue(any(i['code'] == 'M-19' and i['level'] == 'err' for i in iss),
                        'logicalId כפול לא סומן err')

    def test_unique_logicalid_clean(self):
        self._platform(self.rp, 'a1b2c3d4-e5f6-7890-abcd-ef1234567890')
        self._platform(self.sm, 'b2c3d4e5-f6a7-8901-bcde-f12345678901')
        self.assertFalse(any(i['code'] == 'M-19' for i in self._val()),
                         'logicalId ייחודיים סומנו (FP)')

    def test_pbir_v1_with_definition_folder_is_error(self):
        w(os.path.join(self.rp, 'definition.pbir'), json.dumps({'version': '1.0'}))
        iss = self._val()
        self.assertTrue(any(i['code'] == 'M-20' and i['level'] == 'err' for i in iss),
                        'version 1.0 + definition/ לא סומן err')

    def test_pbir_v4_with_definition_folder_clean(self):
        self.assertFalse(any(i['code'] == 'M-20' for i in self._val()),
                         'version 4.0 + definition/ סומן (FP)')

    def test_unapplied_changes_warned(self):
        w(os.path.join(self.sm, '.pbi', 'unappliedChanges.json'),
          json.dumps({'unappliedChanges': [{'name': 'Query1'}]}))
        iss = self._val()
        self.assertTrue(any(i['code'] == 'M-21' and i['level'] == 'warn' for i in iss),
                        'unappliedChanges לא סומן warn')

    def test_bom_flagged_err(self):
        # סבב 134 (דיווח שדה #2): Desktop 2.157 מסרב לפתוח פרויקט עם BOM
        # ("Only text with UTF8 encoding without BOM is supported") — חוסם-פתיחה = err.
        # (סבב 131 הוריד ל-info מתוך יומן §10; דיווח השדה גובר עליו.)
        with open(os.path.join(self.rp, 'definition.pbir'), 'wb') as fh:
            fh.write(b'\xef\xbb\xbf{"version":"4.0"}')
        iss = self._val()
        self.assertTrue(any(i['code'] == 'M-22' and i['level'] == 'err' for i in iss),
                        'BOM לא סומן err (חוסם-פתיחה ב-Desktop 2.157)')

    def test_bom_csv_flagged_info(self):
        # סבב 132 (כשל שדה 14.9 — 8 קבצי CSV עם BOM בפרויקט המשתמש): M-22 מכסה
        # גם קבצי נתונים .csv בשורש הפרויקט, לא רק קבצי הגדרה.
        with open(os.path.join(self.dst, 'data.csv'), 'wb') as fh:
            fh.write(b'\xef\xbb\xbfa,b\n1,2\n')
        iss = self._val()
        self.assertTrue(any(i['code'] == 'M-22' and i['level'] == 'err'
                            and i['location'].endswith('data.csv') for i in iss),
                        'BOM בקובץ CSV לא סומן err')

    def test_schema_version_flagged(self):
        # סבב 132 (בקשת משתמש): M-23 — גרסת $schema לא מאומתת (הזיית-מחולל
        # 2.10.0, כמו בפרויקט שלו) = warn; כתובת מעוותת = err; גרסה מאומתת = נקי.
        import json as _j
        vc = 'https://developer.microsoft.com/json-schemas/fabric/item/report/definition/visualContainer/%s/schema.json'
        vis = os.path.join(self.rp, 'definition', 'pages', 'page001', 'visuals', 'vis001', 'visual.json')
        orig = open(vis, encoding='utf-8-sig').read()
        try:
            w(vis, orig.replace('"$schema"', '"$deadschema"') if '"$schema"' in orig else orig)
            d = _j.loads(orig)
            d['$schema'] = vc % '2.10.0'
            w(vis, _j.dumps(d, ensure_ascii=False))
            iss = self._val()
            self.assertTrue(any(i['code'] == 'M-23' and i['level'] == 'warn' for i in iss),
                            'גרסת 2.10.0 לא סומנה warn')
            d['$schema'] = vc % '2.9.0'
            w(vis, _j.dumps(d, ensure_ascii=False))
            iss = self._val()
            self.assertFalse(any(i['code'] == 'M-23' for i in iss), 'גרסת 2.9.0 סומנה (FP)')
            d['$schema'] = 'https://developer.microsoft.com/json-schemas/fabric/item/report/definition/visualContainer/schema.json'
            w(vis, _j.dumps(d, ensure_ascii=False))
            iss = self._val()
            self.assertTrue(any(i['code'] == 'M-23' and i['level'] == 'err' for i in iss),
                            'כתובת מעוותת לא סומנה err')
        finally:
            w(vis, orig)

    def test_nested_variant_project_pruned(self):
        # שדה סבב 2 #13: וריאנט מקונן בתוך הפרויקט מזהם validate — 8/16 שגיאות
        # ה-M-22 שלו הגיעו מהווריאנט. כשהבסיס הוא שורש פרויקט (.pbip בראש),
        # תת-פרויקט עם .pbip משלו מדולג (M-26 info) וממצאיו לא מתערבבים.
        import shutil as _sh
        nested = os.path.join(self.dst, 'old-variant')
        _sh.copytree(FIX, nested)
        iss = self._val()
        m22 = [i for i in iss if i['code'] == 'M-22']
        self.assertEqual(len(m22), 2,
                         'M-22 מהפרויקט המקונן התערבב: %d במקום 2' % len(m22))
        m26 = [i for i in iss if i['code'] == 'M-26']
        self.assertEqual(len(m26), 1, 'הערת M-26 על הדילוג חסרה')
        self.assertEqual(m26[0]['level'], 'info')
        self.assertIn('old-variant', m26[0]['location'])
        _sh.rmtree(nested)
        iss = self._val()
        self.assertFalse(any(i['code'] == 'M-26' for i in iss))

    def test_datatype_illegal_flagged(self):
        # ממצא שדה סבב 2 #0 (🔴🔴): הוולידטור אשרר dataType לא חוקי — "0 שגיאות"
        # על פרויקט ש-Desktop מסרב לפתוח. M-25: ערך מחוץ ל-enum
        # (Microsoft.AnalysisServices.Tabular.DataType, MS Learn CC-BY-4.0) = err.
        import glob as _g
        tf = _g.glob(os.path.join(self.sm, 'definition', 'tables', '*.tmdl'))[0]
        orig = open(tf, encoding='utf-8-sig').read()
        def _vm():
            V._ISSUES.clear()
            V.validate_model(self.sm)
            return V._ISSUES
        try:
            w(tf, orig + "\n\tcolumn BadTyped\n\t\tdataType: integer\n")
            hits = [i for i in _vm() if i['code'] == 'M-25']
            self.assertTrue(any(i['level'] == 'err' and 'integer' in i['title']
                                for i in hits),
                            'dataType=integer לא סומן M-25 err')
            w(tf, orig + "\n\tcolumn BadTyped\n\t\tdataType: datetime\n")
            hits = [i for i in _vm() if i['code'] == 'M-25']
            self.assertTrue(any('datetime' in i['title'] for i in hits),
                            'dataType=datetime (רישיות שגויה) לא סומן')
            w(tf, orig + "\n\tcolumn OkTyped\n\t\tdataType: variant\n")
            self.assertFalse(any(i['code'] == 'M-25' for i in _vm()),
                             'dataType=variant חוקי סומן (FP)')
        finally:
            w(tf, orig)

    def test_schema_version_official_bookmark_kinds(self):
        # סבב 148 (FabricTools/pbir-samples, MIT — 8 דוחות הדוגמה הרשמיים של
        # Microsoft ב-PBIR): kinds אמיתיים שהטבלה לא הכירה — bookmark 1.4.0,
        # bookmarksMetadata 1.0.0, editorSettings 1.0.0 — נכנסו לטבלה.
        # גרסה מומצאת לאותו kind (9.9.9) עדיין warn.
        import json as _j
        base = 'https://developer.microsoft.com/json-schemas/fabric/%s/%s/schema.json'
        bdir = os.path.join(self.rp, 'definition', 'bookmarks')
        os.makedirs(bdir, exist_ok=True)
        bm = os.path.join(bdir, 'BookmarkT1.bookmark.json')
        md = os.path.join(bdir, 'bookmarks.json')
        esdir = os.path.join(self.dst, os.path.basename(self.sm), '.pbi')
        os.makedirs(esdir, exist_ok=True)
        es = os.path.join(esdir, 'editorSettings.json')
        try:
            w(bm, _j.dumps({'$schema': base % ('item/report/definition/bookmark', '1.4.0'),
                            'displayName': 'T', 'name': 'BookmarkT1',
                            'options': {'applyOnlyToTargetVisuals': True,
                                        'targetVisualNames': ['VisualContainer1']}}))
            w(md, _j.dumps({'$schema': base % ('item/report/definition/bookmarksMetadata', '1.0.0'),
                            'items': [{'name': 'BookmarkT1'}]}))
            w(es, _j.dumps({'$schema': base % ('item/semanticModel/editorSettings', '1.0.0'),
                            'showHiddenFields': True}))
            iss = self._val()
            self.assertFalse(any(i['code'] == 'M-23' and
                                 any(k in i['location'] for k in ('bookmark', 'bookmarks', 'editorSettings'))
                                 for i in iss),
                             'kinds רשמיים סומנו (FP): %s' %
                             [i['location'] for i in iss if i['code'] == 'M-23'])
            w(bm, _j.dumps({'$schema': base % ('item/report/definition/bookmark', '9.9.9'),
                            'displayName': 'T', 'name': 'BookmarkT1'}))
            iss = self._val()
            self.assertTrue(any(i['code'] == 'M-23' and i['level'] == 'warn'
                                and 'bookmark' in i['location'] for i in iss),
                            'bookmark 9.9.9 מומצא לא סומן warn')
        finally:
            for f in (bm, md, es):
                if os.path.exists(f):
                    os.remove(f)

    def test_clean_fixture_no_project_issues(self):
        iss = self._val()
        self.assertFalse(any(i['code'] in ('M-19', 'M-20', 'M-21') for i in iss),
                         'פיקסצר נקי סומן (FP)')
        # הפיקסצר נושא בכוונה 2 קבצי BOM (ווקטורי בדיקה לנתיבי parse/preserve
        # BOM-תומכים ב-pbi_fix/pbi_svg) — M-22 מצפה בדיוק ל-2 ההתראות האלה.
        m22 = [i for i in iss if i['code'] == 'M-22']
        self.assertEqual(len(m22), 2, 'M-22 על הפיקסצר: צפוי 2 וקטורי BOM ידועים')



class TestPbiVariant(unittest.TestCase):
    """pbi_variant.py — מסלול B של שאלת ההסתעפות (בקשת משתמש 13.9 22:08):
    וריאנט דשבורד חלופי על עותק + סיכום שינויים. fork לפי data-goblin
    c_pbip_skill.md §Fork (GPL-3.0 — רעיון, קרדיט)."""

    SCRIPT = os.path.join(ROOT, 'skills', 'powerbi-pbip-builder', 'scripts', 'pbi_variant.py')

    def setUp(self):
        self.root = tempfile.mkdtemp(prefix='pbivar-')
        self.proj = os.path.join(self.root, 'proj')
        shutil.copytree(FIX, self.proj)
        self.variant = os.path.join(self.proj, 'proj-variant')  # סבב 150 (#1): בתוך הפרויקט
        # .platform לשני הפריטים — מפעיל את זהות ה-fork
        import json as _j
        for item in ('MiniReport.Report', 'MiniReport.SemanticModel'):
            w(os.path.join(self.proj, item, '.platform'),
              _j.dumps({'metadata': {'displayName': 'MiniReport',
                                     'logicalId': 'a1b2c3d4-e5f6-7890-abcd-ef1234567890'}}))
        self._orig_fp = {}
        for dp, dn, fn in os.walk(self.proj):
            for f in fn:
                fp = os.path.join(dp, f)
                self._orig_fp[os.path.relpath(fp, self.proj)] = os.path.getsize(fp)

    def tearDown(self):
        shutil.rmtree(self.root, ignore_errors=True)

    def _run(self, *args):
        return subprocess.run([sys.executable, self.SCRIPT, self.proj] + list(args),
                              capture_output=True, text=True, timeout=600)

    def test_dry_run_writes_nothing(self):
        r = self._run()
        self.assertEqual(r.returncode, 0, r.stdout[-500:])
        self.assertIn('DRY-RUN', r.stdout)
        self.assertFalse(os.path.exists(self.variant), 'dry-run יצר תיקייה')

    def test_change_summary_one_line_per_type(self):
        # סבב 138 (כשל שדה #10): CHANGE_SUMMARY מסכם שורה-לסוג; ה-diff הגולמי
        # עובר לנספח CHANGE_DIFF.md — לא עשרות שורות JSON מפורמט-מחדש בגוף הסיכום.
        # הפיקסצר נושא 2 וקטורי BOM → debom יופיע בסיכום.
        r = self._run('--apply')
        self.assertEqual(r.returncode, 0, r.stdout[-500:])
        summ = open(os.path.join(self.variant, 'CHANGE_SUMMARY.md'), encoding='utf-8').read()
        self.assertIn('## תיקונים שהוחלו — שורה לסוג', summ)
        self.assertIn('BOM הוסר מ-', summ, 'סיכום ה-debom חסר מהשורה-לסוג')
        self.assertIn('CHANGE_DIFF.md', summ)
        self.assertTrue(os.path.isfile(os.path.join(self.variant, 'CHANGE_DIFF.md')),
                        'קובץ הנספח CHANGE_DIFF.md חסר')
        diff = open(os.path.join(self.variant, 'CHANGE_DIFF.md'), encoding='utf-8').read()
        self.assertIn('pbi_fix', diff)
        # הסיכום עצמו קצר — בלי diff JSON גולמי
        self.assertNotIn('## שינויים (', summ, 'diff גולמי נשאר בגוף הסיכום')

    def test_apply_builds_variant_and_preserves_source(self):
        r = self._run('--apply')
        self.assertEqual(r.returncode, 0, r.stdout[-500:])
        self.assertTrue(os.path.isdir(self.variant))
        self.assertTrue(os.path.isfile(os.path.join(self.variant, 'CHANGE_SUMMARY.md')),
                        'CHANGE_SUMMARY.md חסר')
        # המקור לא נוגע — כל הקבצים זהים בגודלם (pbi_fix רץ רק על העותק)
        for rel, size in self._orig_fp.items():
            self.assertEqual(os.path.getsize(os.path.join(self.proj, rel)), size,
                             'קובץ מקור שונה: %s' % rel)

    def test_fork_identity_regenerated(self):
        import json as _j
        r = self._run('--apply')
        self.assertEqual(r.returncode, 0, r.stdout[-500:])
        lids = set()
        for item in ('MiniReport.Report', 'MiniReport.SemanticModel'):
            d = _j.load(open(os.path.join(self.variant, item, '.platform'),
                             encoding='utf-8-sig'))
            lids.add(d['metadata']['logicalId'])
            self.assertTrue(d['metadata']['displayName'].endswith('(וריאנט)'),
                            'displayName לא קיבל סיומת')
        self.assertNotIn('a1b2c3d4-e5f6-7890-abcd-ef1234567890', lids,
                         'logicalId לא הוחלף — קונפליקט fork (M-19)')
        self.assertEqual(len(lids), 2, 'שני הפריטים חולקים logicalId')

    def test_svg_args_auto_bind(self):
        # סבב 132 (כשל שדה 14.9): בסשן המשתמש הוריאנט רץ בלי SVG בכלל, ובסשן
        # קודם --svg-args בלי --bind הזריק מדד שלא הוצג מעולם. הוריאנט חייב
        # לקשר מדדי SVG לוויזואל בדף הראשון אוטומטית.
        import glob as _g, json as _j
        r = self._run('--apply', '--svg-args',
                      'status --table factמכירות --measure "SVG בדיקה" '
                      '--value "[כמות שנתית]" --warn 5 --err 2')
        self.assertEqual(r.returncode, 0, (r.stdout + r.stderr)[-800:])
        vis = _g.glob(os.path.join(self.variant, 'MiniReport.Report', 'definition',
                                   'pages', '*', 'visuals', 'svg*', 'visual.json'))
        self.assertTrue(vis, 'לא נוצר ויזואל SVG קשור בוריאנט — המדד הוזרק בלבד')
        d = _j.load(open(vis[0], encoding='utf-8-sig'))
        proj = d['visual']['query']['queryState']['Values']['projections']
        self.assertEqual(proj[0]['field']['Measure']['Property'], 'SVG בדיקה')
        summ = open(os.path.join(self.variant, 'CHANGE_SUMMARY.md'),
                    encoding='utf-8').read()
        self.assertIn('--bind', summ, 'הסיכום לא מתעד את הקשירה')

    def test_existing_variant_refused_without_replace(self):
        self.assertEqual(self._run('--apply').returncode, 0)
        r = self._run('--apply')
        self.assertNotEqual(r.returncode, 0, 'וריאנט קיים נדרס בלי --replace')
        self.assertEqual(self._run('--apply', '--replace').returncode, 0,
                         '--replace נכשל')

    def test_variant_written_inside_project_not_parent(self):
        # שדה סבב 2 #1 (🔴): הוריאנט חייב להיכתב **בתוך** תיקיית הפרויקט —
        # גבול האבטחה שהערכה אוכפת; כתיבה להורה מדליפה עותק מלא למרחב משותף.
        r = self._run('--apply')
        self.assertEqual(r.returncode, 0, r.stdout[-500:])
        self.assertTrue(os.path.isdir(os.path.join(self.proj, 'proj-variant')))
        self.assertFalse(os.path.exists(self.proj + '-variant'),
                         'הוריאנט נכתב לתיקיית-האב — חזרה לבאג #1')
        self.assertFalse(os.path.exists(os.path.join(self.root, 'proj-variant')),
                         'הוריאנט נכתב מחוץ לפרויקט')

    def test_variant_name_rejects_path(self):
        # #1: --name אינו מסלול מילוט — שם פשוט בלבד, תמיד בתוך הפרויקט.
        r = self._run('--apply', '--name', '..\\escape')
        self.assertNotEqual(r.returncode, 0)
        self.assertFalse(os.path.exists(os.path.join(self.root, 'escape')))
        r = self._run('--apply', '--name', 'sub/dir')
        self.assertNotEqual(r.returncode, 0)

    def test_measurement_failure_is_loud(self):
        # שדה סבב 2 #2 (🔴): כשל במדידת ה-validate חייב להיות קולני —
        # ריצה בלי בסיס השוואה לא נראית כמו הצלחה ("לפני: None").
        empty = os.path.join(self.root, 'empty')
        os.makedirs(empty)
        r = subprocess.run([sys.executable, self.SCRIPT, empty, '--apply'],
                           capture_output=True, text=True, encoding='utf-8', timeout=600)
        self.assertNotEqual(r.returncode, 0, 'מדידה כושלת עברה בשקט')
        self.assertIn('מדידת validate נכשלה', r.stdout)
        self.assertNotIn('None', r.stdout.replace('מדידת validate נכשלה', ''))

    def test_hebrew_output_survives_subprocess(self):
        # שדה סבב 2 #2: הפלט של pbi_validate הוא UTF-8 עברי — _run חייב
        # encoding מפורש (cp1255 ב-Windows עברי קורס בלעדיו). המדידה מתקבלת.
        r = self._run()
        self.assertEqual(r.returncode, 0, (r.stdout + r.stderr)[-400:])
        self.assertIn('ממצאי validate לפני:', r.stdout)
        self.assertNotIn('ממצאי validate לפני: None', r.stdout)

    def test_copytree_skips_nested_projects(self):
        # #1/#13: וריאנט ישן (פרויקט מקונן עם .pbip) אינו מועתק לתוך החדש.
        self.assertEqual(self._run('--apply').returncode, 0)
        r = self._run('--apply', '--name', 'v2')
        self.assertEqual(r.returncode, 0, r.stdout[-400:])
        self.assertFalse(os.path.exists(os.path.join(self.proj, 'v2', 'proj-variant')),
                         'וריאנט ישן הועתק לתוך החדש')
        self.assertTrue(os.path.isdir(os.path.join(self.proj, 'v2', 'MiniReport.Report')))

    def test_summary_contains_before_after(self):
        self.assertEqual(self._run('--apply').returncode, 0)
        s = open(os.path.join(self.variant, 'CHANGE_SUMMARY.md'), encoding='utf-8').read()
        for needle in ('לפני/אחרי', 'pbi_fix', 'וריאנט'):
            self.assertIn(needle, s, 'חסר בסיכום: %s' % needle)



class TestSvgPercentMeasure(unittest.TestCase):
    """סבב 132 (כשל שדה 14.9): מדד עם '%' בשם ('[Revenue vs Target %]') פסל
    את בדיקת-העצמי v2.1, שלא הפרידה בין ה-payload (חובת %XX) למזהה DAX."""

    SCRIPT = os.path.join(ROOT, 'skills', 'powerbi-pbip-builder', 'scripts', 'pbi_svg.py')

    def test_percent_in_measure_name_ok(self):
        import subprocess, sys as _sys, tempfile, shutil
        dst = tempfile.mkdtemp(prefix='pbisvgpct-')
        try:
            shutil.copytree(FIX, os.path.join(dst, 'P'))
            r = subprocess.run([_sys.executable, self.SCRIPT, 'status',
                                os.path.join(dst, 'P'), '--table', 'factמכירות',
                                '--measure', 'SVG סטטוס', '--value', '[Revenue vs Target %]',
                                '--warn', '0.9', '--err', '0.75'],
                               capture_output=True, text=True, encoding='utf-8')
            self.assertEqual(r.returncode, 0, (r.stdout + r.stderr)[-600:])
            self.assertNotIn('לא מקודד', r.stdout + r.stderr)
        finally:
            shutil.rmtree(dst, ignore_errors=True)

    def test_bound_visual_carries_schema(self):
        # סבב 132: ויזואל SVG חדש חייב $schema — מהדונור, או 2.9.0 (ברירת
        # מחדל מתפרסמת; הפיקסצר נטול $schema ולכן מצפה לברירת המחדל).
        import subprocess, sys as _sys, tempfile, shutil, json as _j, glob as _g
        dst = tempfile.mkdtemp(prefix='pbisvgsch-')
        try:
            shutil.copytree(FIX, os.path.join(dst, 'P'))
            r = subprocess.run([_sys.executable, self.SCRIPT, 'status',
                                os.path.join(dst, 'P'), '--table', 'factמכירות',
                                '--measure', 'SVG סטטוס', '--value', '[כמות שנתית]',
                                '--warn', '0.9', '--err', '0.75',
                                '--bind', 'page001', '--apply'],
                               capture_output=True, text=True, encoding='utf-8')
            self.assertEqual(r.returncode, 0, (r.stdout + r.stderr)[-600:])
            vis = _g.glob(os.path.join(dst, 'P', 'MiniReport.Report', 'definition',
                                       'pages', 'page001', 'visuals', 'svg*', 'visual.json'))
            self.assertTrue(vis)
            d = _j.load(open(vis[0], encoding='utf-8-sig'))
            self.assertEqual(d.get('$schema'),
                             'https://developer.microsoft.com/json-schemas/fabric/'
                             'item/report/definition/visualContainer/2.9.0/schema.json')
        finally:
            shutil.rmtree(dst, ignore_errors=True)


class TestFixDebom(unittest.TestCase):
    """pbi_fix --fix debom (סבב 131, M-22 repair) — הסרת UTF-8 BOM מקבצי מקור."""

    FIXSCRIPT = os.path.join(ROOT, 'skills', 'powerbi-pbip-builder', 'scripts', 'pbi_fix.py')

    def setUp(self):
        self.root = tempfile.mkdtemp(prefix='pbidebom-')
        self.dst = os.path.join(self.root, 'P')
        shutil.copytree(FIX, self.dst)
        self.sm = os.path.join(self.dst, 'MiniReport.SemanticModel')
        self.rp = os.path.join(self.dst, 'MiniReport.Report')
        # וקטור BOM חדש בכל צד (בנוסף ל-2 הווקטורים המובנים בפיקסצר)
        self.extra = os.path.join(self.rp, 'definition.pbir')
        with open(self.extra, 'wb') as fh:
            fh.write(b'\xef\xbb\xbf{"version":"4.0"}')

    def tearDown(self):
        shutil.rmtree(self.root, ignore_errors=True)

    def _run(self, *argv):
        import subprocess, sys as _sys
        return subprocess.run([_sys.executable, self.FIXSCRIPT, self.dst] + list(argv),
                              capture_output=True, text=True, encoding='utf-8')

    def _bommed(self):
        hits = []
        for base in (self.sm, self.rp):
            for dp, _dn, fn in os.walk(base):
                for f in fn:
                    fp = os.path.join(dp, f)
                    with open(fp, 'rb') as fh:
                        if fh.read(3) == b'\xef\xbb\xbf':
                            hits.append(fp)
        return hits

    def test_dry_run_lists_but_writes_nothing(self):
        before = self._bommed()
        self.assertGreaterEqual(len(before), 3, 'הפיקסצר + הווקטור החדש')
        r = self._run('--fix', 'debom')
        self.assertEqual(r.returncode, 0, r.stderr)
        self.assertIn('מתוכננת', r.stdout)
        self.assertEqual(self._bommed(), before, 'dry-run כתב')

    def test_apply_strips_and_is_idempotent(self):
        r = self._run('--fix', 'debom', '--apply')
        self.assertEqual(r.returncode, 0, r.stderr)
        self.assertEqual(self._bommed(), [], 'נשאר BOM אחרי apply')
        r2 = self._run('--fix', 'debom', '--apply')
        self.assertIn('אין מה לתקן', r2.stdout)

    def test_apply_preserves_content(self):
        with open(self.extra, 'rb') as fh:
            before = fh.read()[3:]
        self._run('--fix', 'debom', '--apply')
        with open(self.extra, 'rb') as fh:
            self.assertEqual(fh.read(), before, 'התוכן השתנה, לא רק ה-BOM')

    def test_csv_at_project_root_debommed(self):
        # סבב 132 (כשל שדה): 8 קבצי ה-CSV של המשתמש ישבו בשורש הפרויקט, מחוץ
        # לתיקיות הפריטים — debom חייב לכסות גם אותם.
        csv = os.path.join(self.dst, 'data.csv')
        with open(csv, 'wb') as fh:
            fh.write(b'\xef\xbb\xbfa,b\n1,2\n')
        r = self._run('--fix', 'debom', '--apply')
        self.assertEqual(r.returncode, 0, r.stderr)
        with open(csv, 'rb') as fh:
            self.assertEqual(fh.read(), b'a,b\n1,2\n', 'BOM לא הוסר / תוכן שונה')

    def test_schemaver_redirects_unverified(self):
        # סבב 132: --fix schemaver מפנה גרסת הזיה (2.10.0) ל-2.9.0 המתפרסמת,
        # dry-run בלבד כברירת מחדל, idempotent, ושומר על שאר התוכן.
        import json as _j
        vis = os.path.join(self.rp, 'definition', 'pages', 'page001', 'visuals', 'vis001', 'visual.json')
        d = _j.loads(open(vis, encoding='utf-8-sig').read())
        d['$schema'] = ('https://developer.microsoft.com/json-schemas/fabric/'
                        'item/report/definition/visualContainer/2.10.0/schema.json')
        w(vis, _j.dumps(d, ensure_ascii=False))
        r = self._run('--fix', 'schemaver')
        self.assertIn('מתוכננת', r.stdout)
        self.assertIn('2.10.0', open(vis, encoding='utf-8-sig').read(), 'dry-run כתב')
        r = self._run('--fix', 'schemaver', '--apply')
        self.assertEqual(r.returncode, 0, r.stderr)
        back = open(vis, encoding='utf-8-sig').read()
        self.assertIn('visualContainer/2.9.0/', back)
        self.assertNotIn('2.10.0', back)
        r2 = self._run('--fix', 'schemaver', '--apply')
        self.assertIn('אין מה לתקן', r2.stdout)


class TestSvgBind(unittest.TestCase):
    """pbi_svg --bind (סבב 131, כשל שדה "ה-svg לא בא לידי ביטוי") — קשירת מדד
    ה-SVG לוויזואל tableEx חי בדף; בלי קשירה המדד לא מוצג בשום מקום."""

    SCRIPT = os.path.join(ROOT, 'skills', 'powerbi-pbip-builder', 'scripts', 'pbi_svg.py')

    def setUp(self):
        self.root = tempfile.mkdtemp(prefix='pbisvgbind-')
        self.dst = os.path.join(self.root, 'P')
        shutil.copytree(FIX, self.dst)
        self.sm = os.path.join(self.dst, 'MiniReport.SemanticModel')
        self.rp = os.path.join(self.dst, 'MiniReport.Report')
        self.tbl = os.path.join(self.sm, 'definition', 'tables', 'Measures.tmdl')
        w(self.tbl, "table Measures\n\tmeasure Base = 1\n\t\tformatString: 0\n\n"
                    "\tpartition Measures = m\n\t\tmode: import\n\n\tannotation PBI_ResultType = Table\n")

    def tearDown(self):
        shutil.rmtree(self.root, ignore_errors=True)

    def _run(self, *argv):
        import subprocess, sys as _sys
        return subprocess.run([_sys.executable, self.SCRIPT] + list(argv),
                              capture_output=True, text=True, encoding='utf-8')

    def _visuals(self, page='page001'):
        vd = os.path.join(self.rp, 'definition', 'pages', page, 'visuals')
        return sorted(os.listdir(vd))

    def test_bind_creates_visual_and_passes_validate(self):
        r = self._run('status', self.dst, '--table', 'Measures', '--measure', 'SVG סטטוס',
                      '--value', '[R]', '--warn', '0.9', '--err', '0.75',
                      '--bind', 'page001', '--apply')
        self.assertEqual(r.returncode, 0, r.stderr)
        new = [v for v in self._visuals() if v.startswith('svg')]
        self.assertEqual(len(new), 1, 'לא נוצר ויזואל svg: %s' % self._visuals())
        vj = os.path.join(self.rp, 'definition', 'pages', 'page001',
                          'visuals', new[0], 'visual.json')
        d = json.loads(open(vj, encoding='utf-8-sig').read())
        self.assertEqual(d['visual']['visualType'], 'tableEx')
        pr = d['visual']['query']['queryState']['Values']['projections'][0]
        self.assertEqual(pr['field']['Measure']['Property'], 'SVG סטטוס')
        self.assertEqual(pr['field']['Measure']['Expression']['SourceRef']['Entity'], 'Measures')
        # altText (RPT-05) + z/tabOrder לא-כפולים
        vco = d['visual']['visualContainerObjects']['general'][0]
        self.assertIn('altText', vco['properties'])
        # validate נקי על הפרויקט המקושר (מעבר ל-2 וקטורי ה-BOM המובנים)
        V._ISSUES.clear()
        V.validate_model(self.sm)
        V.validate_report(self.rp, V.read_model_map(self.sm))
        bad = [i for i in V._ISSUES if i['level'] == 'err']
        self.assertEqual(bad, [], 'שגיאות validate אחרי bind: %s' %
                         [(i['code'], i['title']) for i in bad])

    def test_bind_dry_run_writes_nothing(self):
        before = self._visuals()
        r = self._run('status', self.dst, '--table', 'Measures', '--measure', 'SVG סטטוס',
                      '--value', '[R]', '--warn', '0.9', '--err', '0.75', '--bind', 'page001')
        self.assertEqual(r.returncode, 0, r.stderr)
        self.assertIn('ויזואל מתוכנן', r.stdout)
        self.assertEqual(self._visuals(), before, 'dry-run כתב')

    def test_bind_missing_page_fails_loudly(self):
        r = self._run('status', self.dst, '--table', 'Measures', '--measure', 'SVG סטטוס',
                      '--value', '[R]', '--warn', '0.9', '--err', '0.75',
                      '--bind', 'page999', '--apply')
        self.assertNotEqual(r.returncode, 0)
        self.assertIn('page999', (r.stderr or '') + (r.stdout or ''))

    def test_bind_positions_below_donor_with_fresh_z(self):
        r = self._run('status', self.dst, '--table', 'Measures', '--measure', 'SVG סטטוס',
                      '--value', '[R]', '--warn', '0.9', '--err', '0.75',
                      '--bind', 'page001', '--apply')
        self.assertEqual(r.returncode, 0, r.stderr)
        new = [v for v in self._visuals() if v.startswith('svg')][0]
        vj = os.path.join(self.rp, 'definition', 'pages', 'page001',
                          'visuals', new, 'visual.json')
        d = json.loads(open(vj, encoding='utf-8-sig').read())
        self.assertGreaterEqual(d['position']['z'], 4, 'z חייב להיות מעל כל הקיימים (max=3)')


if __name__ == '__main__':
    unittest.main(verbosity=2)


class TestNavigationTemplates(unittest.TestCase):
    def test_navigator_templates_present(self):
        import csv
        path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "skills", "powerbi-design-search", "data", "pbir-templates.csv")
        rows = list(csv.DictReader(open(path, encoding="utf-8")))
        types = {r["Visual Type"] for r in rows}
        self.assertIn("pageNavigator", types)   # #9: תבנית ניווט מאומתת מייצוא Desktop
        self.assertIn("actionButton", types)    # #9: כפתור פעולה עם action PageNavigation
        self.assertIn("bookmarkNavigator", types)
        nav = [r for r in rows if r["Visual Type"] == "pageNavigator"]
        self.assertTrue(any("showHiddenPages" in r["Objects Keys"] for r in nav))
        btn = [r for r in rows if r["Visual Type"] == "actionButton"]
        self.assertTrue(any("PageNavigation" in (r["Objects Keys"] + r["Notes"]) for r in btn))


class TestBomEndToEnd(unittest.TestCase):
    def test_bom_fixture_through_tools(self):
        """cross-cut #2: פרויקט מלא עם BOM -> פיקסר -> M-22=0 ואפס BOM בקבצים."""
        tmp = tempfile.mkdtemp()
        rep = os.path.join(tmp, 'R.Report', 'definition')
        os.makedirs(os.path.join(rep, 'pages', 'p1'), exist_ok=True)
        paths = [os.path.join(rep, 'report.json'),
                 os.path.join(rep, 'pages', 'pages.json'),
                 os.path.join(rep, 'pages', 'p1', 'page.json')]
        for fp in paths:
            with open(fp, 'wb') as fh:
                fh.write(b'\xef\xbb\xbf' + json.dumps({'$schema': 'x'}).encode())
        V._ISSUES.clear()
        V.validate_project(tmp)
        before = list(V._ISSUES)
        self.assertTrue(any(i['code'] == 'M-22' and i['level'] == 'err' for i in before),
                        'M-22 חייב להיות err על פרויקט עם BOM')
        F.apply_debom(paths)
        for fp in paths:
            self.assertFalse(open(fp, 'rb').read().startswith(b'\xef\xbb\xbf'))
        V._ISSUES.clear()
        V.validate_project(tmp)
        after = list(V._ISSUES)
        self.assertFalse(any(i['code'] == 'M-22' for i in after), 'M-22=0 אחרי תיקון')
        shutil.rmtree(tmp)



class TestFixerValidatorClosure(unittest.TestCase):
    """cross-cut #3 (דוח שדה 14.9): מטריצת סגירה פיקסר↔בודק — לכל תיקון ב-FIXES
    חייבת להיות רשומה, ובחוקים הסגורים הבודק שותק אחרי שהפיקסר רץ.
    status: closed = סגירה מלאה נבדקת כאן/במחלקה ייעודית; fixer-tested = בדיקת
    פיקסר ייעודית קיימת, סגירת-בודק בתור."""

    FIXTURE_SM = os.path.join(FIX, 'MiniReport.SemanticModel')

    # fix -> (rule, status, כיסוי קיים)
    MATRIX = {
        'divide': ('DAX-08', 'closed', 'כאן'),
        'hide-fk': ('MDL-05', 'closed', 'כאן'),
        'alttext': ('A11Y-02', 'fixer-tested', 'TestAltTextHebrew'),
        'pageorder': ('R-04', 'fixer-tested', 'TestValidateProject'),
        'cardmigration': ('VIS-card', 'fixer-tested', 'TestFixCardmigration'),
        'versionjson': ('M-json', 'fixer-tested', 'TestFixVersionjson'),
        'overlap': ('LAY-overlap', 'fixer-tested', 'TestFixOverlap'),
        'howcreated': ('R-24', 'fixer-tested', 'TestContainerPlacementRules'),
        'relationships': ('MDL-18', 'manual-by-design', 'כאן — 1:M דו-כיווני נדחה בכוונה'),
        'slicerheight': ('VIS-slicer', 'fixer-tested', 'TestSwapRoleCoverage'),
        'filterhowcreated': ('R-24', 'fixer-tested', 'TestContainerPlacementRules'),
        'mobilemissing': ('R-mob', 'fixer-tested', 'TestFixMobilemissing'),
        'stylepreset': ('R-69', 'closed', 'TestStylePresetR69'),
        'zfix': ('LAY-z', 'fixer-tested', 'TestZFix'),
        'taborderfix': ('A11Y-tab', 'fixer-tested', 'TestTabOrderFix'),
        'tooltipshow': ('R-81', 'fixer-tested', 'TestTooltipShowFix'),
        'filterhoist': ('R-83', 'fixer-tested', 'TestFilterHoistFix'),
        'localclean': ('R-85', 'fixer-tested', 'TestLocalClean'),
        'debom': ('M-22', 'closed', 'TestFixDebom + TestBomEndToEnd'),
        'schemaver': ('M-23', 'closed', 'כאן'),
    }

    def setUp(self):
        self.root = tempfile.mkdtemp(prefix='pbiclosure-')
        self.dst = os.path.join(self.root, 'P')
        shutil.copytree(FIX, self.dst)
        self.sm = os.path.join(self.dst, 'MiniReport.SemanticModel')

    def tearDown(self):
        shutil.rmtree(self.root, ignore_errors=True)

    def _model_findings(self):
        C._FINDINGS.clear()
        C.check_model(C.read_model(self.sm))
        return [f['rule'] for f in C._FINDINGS]

    def test_matrix_covers_every_fix(self):
        for fix in F.FIXES:
            self.assertIn(fix, self.MATRIX, 'תיקון "%s" חסר במטריצת הסגירה' % fix)

    def test_divide_closure(self):
        self.assertIn('DAX-08', self._model_findings(), 'DAX-08 לא ירה על הפיקסצר')
        docs = F.Docs()
        F.fix_divide(docs, self.sm)
        docs.write_all()
        self.assertNotIn('DAX-08', self._model_findings(),
                         'DAX-08 עדיין מסמן אחרי fix_divide')

    def test_hide_fk_closure(self):
        self.assertIn('MDL-05', self._model_findings(), 'MDL-05 לא ירה על הפיקסצר')
        docs = F.Docs()
        F.fix_hide_fk(docs, self.sm)
        docs.write_all()
        self.assertNotIn('MDL-05', self._model_findings(),
                         'MDL-05 עדיין מסמן אחרי fix_hide_fk')

    def test_relationships_manual_by_design(self):
        # MDL-18 על קשר 1:M דו-כיווני: הפיקסר נמנע בכוונה (אולי מכוון לסלייסרים;
        # CROSSFILTER נקודתי עדיף) ומדווח דילוג להחלטה ידנית — זו הסגירה המוסכמת.
        self.assertIn('MDL-18', self._model_findings(), 'MDL-18 לא ירה על הפיקסצר')
        docs = F.Docs()
        skipped = F.fix_relationships(docs, self.sm)
        self.assertTrue(any('דו-כיווני' in x for x in skipped),
                        'הפיקסר לא תיעד את הדילוג המכוון על 1:M דו-כיווני')

    def test_schemaver_closure(self):
        rp = os.path.join(self.dst, 'MiniReport.Report')
        vj = os.path.join(rp, 'definition', 'pages', 'page001', 'visuals', 'vis001', 'visual.json')
        if not os.path.exists(vj):
            self.skipTest('פיקסצר בלי vis001')
        orig = open(vj, encoding='utf-8-sig').read()
        d = json.loads(orig)
        d['$schema'] = ('https://developer.microsoft.com/json-schemas/fabric/item/'
                        'report/definition/visualContainer/2.10.0/schema.json')
        w(vj, json.dumps(d, ensure_ascii=False))
        V._ISSUES.clear()
        V.validate_project(self.dst)
        self.assertTrue(any(i['code'] == 'M-23' for i in V._ISSUES), 'M-23 לא ירה')
        rows = F.fix_schemaver(rp, None)
        self.assertTrue(rows, 'fix_schemaver לא מצא שורות לתיקון')
        F.apply_schemaver(rows)
        V._ISSUES.clear()
        V.validate_project(self.dst)
        self.assertFalse(any(i['code'] == 'M-23' for i in V._ISSUES),
                         'M-23 עדיין מסמן אחרי fix_schemaver')


class TestFPConfidence(unittest.TestCase):
    """cross-cutting #5 (דוח שדה 14.9): סיווג ודאות לחוקים עם FP ידוע —
    A11Y-02 (ניגודיות בלי מודעות z-order) מסומן low, מוצג עם אזהרה, ומשוקלל
    במחצית הקנס בציון הבריאות כדי שלא לעוות אותו."""

    def setUp(self):
        self.root = tempfile.mkdtemp(prefix='pbi-conf-')
        self.dst = os.path.join(self.root, 'P')
        shutil.copytree(FIX, self.dst)
        self.rp = os.path.join(self.dst, 'MiniReport.Report')

    def tearDown(self):
        shutil.rmtree(self.root, ignore_errors=True)

    def _low_contrast_textbox(self):
        # textbox עם טקסט אפור-בהיר מפורש על רקע לבן (ברירת מחדל) → A11Y-02
        vd = os.path.join(self.rp, 'definition', 'pages', 'page001', 'visuals', 'vcontrast')
        os.makedirs(vd, exist_ok=True)
        color = {"expr": {"Literal": {"Value": "'#CCCCCC'"}}}
        run = {"value": "טקסט", "textStyle": {"color": color}}
        d = {"name": "vcontrast",
             "position": {"x": 0, "y": 0, "z": 9, "width": 300, "height": 60},
             "visual": {"visualType": "textbox",
                        "objects": {"general": [{"properties": {"paragraphs": [
                            {"textRuns": [run]}]}}]}}}
        w(os.path.join(vd, 'visual.json'), json.dumps(d, ensure_ascii=False))

    def test_a11y02_flagged_low_confidence(self):
        self._low_contrast_textbox()
        C._FINDINGS.clear()
        rep = C.read_report(self.rp)
        C.check_report(rep)
        C.check_a11y(rep)
        hits = [f for f in C._FINDINGS if f['rule'] == 'A11Y-02']
        self.assertTrue(hits, 'A11Y-02 לא ירה על textbox דל-ניגודיות')
        self.assertTrue(all(f['confidence'] == 'low' for f in hits),
                        'A11Y-02 לא סומן ודאות נמוכה (FP ידוע z-order)')

    def test_low_confidence_half_penalty_in_score(self):
        self._low_contrast_textbox()
        C._FINDINGS.clear()
        rep = C.read_report(self.rp)
        C.check_report(rep)
        C.check_a11y(rep)
        lows = [f for f in C._FINDINGS if f['rule'] == 'A11Y-02']
        self.assertTrue(lows)
        # ציון מלא בלי ה-lows מול הציון בפועל: ההפרש = מחצית קנס בלבד
        sev_pen = {'crit': 8, 'warn': 3, 'tip': 1}
        full = C.health_score()
        kept = C._FINDINGS[:]
        C._FINDINGS = [f for f in kept if f['rule'] != 'A11Y-02']
        without = C.health_score()
        C._FINDINGS = kept
        expected = sum(sev_pen[f['severity']] * 0.5 for f in lows[:3])
        self.assertAlmostEqual(without - full, expected, places=1,
                               msg='ממצא low לא שוקלל במחצית הקנס בציון')

    def test_other_rules_stay_high_confidence(self):
        C._FINDINGS.clear()
        rep = C.read_report(self.rp)
        C.check_report(rep)
        C.check_a11y(rep)
        others = [f for f in C._FINDINGS if f['rule'] != 'A11Y-02']
        self.assertTrue(others)
        self.assertTrue(all(f['confidence'] == 'high' for f in others),
                        'חוקים רגילים איבדו ודאות high')

    def test_registry_points_at_real_rules(self):
        # שגיאת הקלדה בשם חוק ברשומה = סיווג מת — הרשומה חייבת להצביע על חוקים קיימים
        import re as _re
        src = open(os.path.join(ROOT, 'skills/powerbi-report-reviewer/scripts/pbi_check.py'),
                   encoding='utf-8').read()
        known = set(_re.findall(r"add\('([A-Z0-9]+-[0-9]+)'", src))
        for rule in C.LOW_CONFIDENCE:
            self.assertIn(rule, known, 'חוק %s ברשומת ה-FP אינו קיים בקוד' % rule)

    def test_text_render_marks_low_confidence(self):
        self._low_contrast_textbox()
        C._FINDINGS.clear()
        rep = C.read_report(self.rp)
        C.check_report(rep)
        C.check_a11y(rep)
        out = C.render_text()
        self.assertIn('ודאות נמוכה', out, 'תצוגת הטקסט לא מסמנת ממצאי FP ידוע')


class TestDashboardDesignMining(unittest.TestCase):
    """סבב 145 (משימת כרייה 14.9): Dashboard-Design/Power-BI-Design-Files (MIT) —
    7 פלטות theme (dataColors אמיתיים) + 9 טכניקות SVG חוברו ל-design-search."""

    def _csv(self, name):
        import csv
        path = os.path.join(ROOT, 'skills', 'powerbi-design-search', 'data', name)
        return list(csv.DictReader(open(path, encoding='utf-8')))

    def test_mined_palettes_present(self):
        rows = self._csv('color-palettes.csv')
        names = [r['Dashboard Type'] for r in rows]
        for n in ('Economist Bold', 'Tableau Classic', 'Teals Earth', 'ZebraBI Power BI'):
            self.assertIn(n, names, 'פלטה %s חסרה' % n)
        self.assertEqual(len(rows), 19)
        mined = [r for r in rows if 'Dashboard-Design' in r['Notes']]
        self.assertEqual(len(mined), 7, '7 פלטות כרויות עם קרדיט MIT')
        for r in mined:
            self.assertTrue(r['Primary'].startswith('#'), 'פלטה בלי צבע ראשי')

    def test_mined_svg_techniques_present(self):
        rows = self._csv('chart-types.csv')
        svg = [r for r in rows if r['Chart Type'].startswith('SVG ')]
        self.assertEqual(len(svg), 9, '9 טכניקות SVG כרויות')
        for r in svg:
            self.assertIn('Dashboard-Design', r['Notes'], 'קרדיט חסר ב-%s' % r['Chart Type'])
            self.assertIn('SVG', r['Value Role'], 'טכניקת SVG בלי מדד SVG: %s' % r['Chart Type'])
        # סבב 146: 10 דפוסי native נוספים מ-Native Visuals (button slicer segmented,
        # azure map svg markers, skyline, topn/bottomn...) — 24→34
        native = [r for r in rows if 'Dashboard-Design Native Visuals' in r['Notes']]
        self.assertEqual(len(native), 10, '10 דפוסי native כרויים')
        for r in native:
            self.assertNotIn('custom visual', r['PBIR Visual Type'].lower())
        self.assertEqual(len(rows), 34)

class TestCardLabelTitle(unittest.TestCase):
    """סבב 152 — דוח שדה סבב 2 #5+#6: ב-cardVisual/multiRowCard השם הנראה למשתמש
    יושב ב-objects.label.text (אובייקט title בכרטיס לרוב מיותר). כרטיס מתויג
    אינו "ללא כותרת" ב-extract וב-check (A11Y-11), ו-fix_alttext גוזר ממנו.
    תווית רווח-בלבד (' ') = הסתרה מכוונת, לא כותרת. known-issues-log §18."""

    def _card(self, label=None, with_title=False, vtype='cardVisual'):
        vis = {"visualType": vtype,
               "query": {"queryState": {"Data": {"projections": [
                   {"field": {"Measure": {"Expression": {"SourceRef": {"Entity": "f"}},
                                          "Property": "Total Revenue"}},
                    "queryRef": "f.Total Revenue"}]}}}}
        if label is not None:
            vis["objects"] = {"label": [{"properties": {
                "text": {"expr": {"Literal": {"Value": "'%s'" % label}}},
                "horizontalAlignment": {"expr": {"Literal": {"Value": "'Right'"}}}}}]}
        if with_title:
            vis["visualContainerObjects"] = {"title": [{"properties": {
                "text": {"expr": {"Literal": {"Value": "'כותרת מפורשת'"}}}}}]}
        return {"name": "v1", "position": {"x": 0, "y": 0, "z": 1, "width": 200, "height": 100},
                "visual": vis}

    # extract — רמת הפונקציה
    def test_extract_title_from_label(self):
        t = E.visual_title(self._card(label='סה"כ הכנסות')['visual'])
        self.assertEqual(t, 'סה"כ הכנסות', 'extract לא קרא כותרת מ-objects.label.text')

    def test_extract_blank_label_is_not_title(self):
        t = E.visual_title(self._card(label=' ')['visual'])
        self.assertEqual(t, '', "תווית רווח-בלבד נחשבה כותרת")

    def test_extract_explicit_title_wins(self):
        t = E.visual_title(self._card(label='תווית', with_title=True)['visual'])
        self.assertEqual(t, 'כותרת מפורשת', 'label.text דרס title מפורש')

    def test_extract_label_ignored_on_non_card(self):
        v = self._card(label='תווית', vtype='clusteredBarChart')['visual']
        self.assertEqual(E.visual_title(v), '',
                         'label.text נקרא ככותרת על ויזואל שאינו כרטיס')

    # check — A11Y-11
    def _mk(self, cards):
        root = tempfile.mkdtemp(prefix='pbilbl-')
        dst = os.path.join(root, 'P')
        shutil.copytree(FIX, dst)
        rp = os.path.join(dst, 'MiniReport.Report')
        pg = os.path.join(rp, 'definition', 'pages', 'pagelbl')
        w(os.path.join(pg, 'page.json'),
          json.dumps({"name": "pagelbl", "displayName": "כרטיסים"}, ensure_ascii=False))
        for i, card in enumerate(cards):
            vd = os.path.join(pg, 'visuals', 'vc%d' % i)
            os.makedirs(vd, exist_ok=True)
            card = dict(card); card['name'] = 'vc%d' % i
            w(os.path.join(vd, 'visual.json'), json.dumps(card, ensure_ascii=False))
        return root, rp

    def _a11y11(self, rp):
        C._FINDINGS.clear()
        rep = C.read_report(rp)
        C.check_report(rep)
        C.check_a11y(rep)
        return [f for f in C._FINDINGS
                if f['rule'] == 'A11Y-11' and 'כרטיסים' in f['location']]

    def test_a11y11_silent_on_labeled_cards(self):
        root, rp = self._mk([self._card(label='סה"כ הכנסות'),
                             self._card(label='כמות שנתית')])
        try:
            self.assertFalse(self._a11y11(rp),
                             'A11Y-11 ירה על כרטיסים מתויגים (ממצא שקרי #5)')
        finally:
            shutil.rmtree(root, ignore_errors=True)

    def test_a11y11_fires_on_unlabeled_cards(self):
        root, rp = self._mk([self._card(), self._card(label=' ')])
        try:
            hits = self._a11y11(rp)
            self.assertTrue(hits, 'A11Y-11 לא ירה על כרטיסים בלי תווית אמיתית')
            self.assertIn('2 ויזואלים', hits[0]['title'])
        finally:
            shutil.rmtree(root, ignore_errors=True)

    # fix — alttext priority (#6)
    def test_alttext_prefers_hebrew_label(self):
        root, rp = self._mk([self._card(label='סה"כ הכנסות')])
        try:
            docs = F.Docs()
            F.fix_alttext(docs, rp)
            vf = os.path.join(rp, 'definition', 'pages', 'pagelbl',
                              'visuals', 'vc0', 'visual.json')
            d = json.loads(docs.d[vf]['text'])
            alt = d['visual']['visualContainerObjects']['general'][0]['properties']['altText']['expr']['Literal']['Value']
            self.assertEqual(alt, "'" + 'סה"כ הכנסות' + "'",
                             'alt text לא נגזר מהתווית העברית (ממצא #6)')
        finally:
            shutil.rmtree(root, ignore_errors=True)

    def test_alttext_blank_label_falls_back_to_fields(self):
        root, rp = self._mk([self._card(label=' ')])
        try:
            docs = F.Docs()
            F.fix_alttext(docs, rp)
            vf = os.path.join(rp, 'definition', 'pages', 'pagelbl',
                              'visuals', 'vc0', 'visual.json')
            d = json.loads(docs.d[vf]['text'])
            alt = d['visual']['visualContainerObjects']['general'][0]['properties']['altText']['expr']['Literal']['Value']
            self.assertIn('Total Revenue', alt,
                          'תווית ריקה לא נפלה לסינתזה מהשדות')
        finally:
            shutil.rmtree(root, ignore_errors=True)

class TestCyclicAxis(unittest.TestCase):
    """סבב 153 — דוח שדה סבב 2 #8 (RPT-28): ציר קטגוריה מחזורי (שם חודש עם
    sortByColumn) על טבלת תאריכים רב-שנתית (CALENDAR ליטרלי) בלי מסנן/סליסר
    שנה — צניחה מדומה בסוף הגרף. טווח לא-קריא (CALENDARAUTO) = שתיקה."""

    DATE_TBL = """table DateCal
	= {cal}

	column 'Month Name'
		dataType: string
		sortByColumn: Month Number

	column 'Month Number'
		dataType: int64
		summarizeBy: none

	column Year
		dataType: int64
		summarizeBy: none
"""

    def _mk(self, cal='CALENDAR(DATE(2024,1,1), DATE(2026,12,31))', slicer=False):
        root = tempfile.mkdtemp(prefix='pbicyc-')
        dst = os.path.join(root, 'P')
        shutil.copytree(FIX, dst)
        sm = os.path.join(dst, 'MiniReport.SemanticModel')
        w(os.path.join(sm, 'definition', 'tables', 'DateCal.tmdl'),
          self.DATE_TBL.format(cal=cal))
        rp = os.path.join(dst, 'MiniReport.Report')
        pg = os.path.join(rp, 'definition', 'pages', 'pagecyc')
        w(os.path.join(pg, 'page.json'),
          json.dumps({"name": "pagecyc", "displayName": "מכירות"}, ensure_ascii=False))
        bar = {"name": "vb", "position": {"x": 0, "y": 0, "z": 1, "width": 400, "height": 300},
               "visual": {"visualType": "clusteredBarChart", "query": {"queryState": {
                   "Category": {"projections": [{"field": {"Column": {
                       "Expression": {"SourceRef": {"Entity": "DateCal"}},
                       "Property": "Month Name"}}, "queryRef": "DateCal.Month Name"}]}}}}}
        vd = os.path.join(pg, 'visuals', 'vb')
        os.makedirs(vd, exist_ok=True)
        w(os.path.join(vd, 'visual.json'), json.dumps(bar, ensure_ascii=False))
        if slicer:
            sl = {"name": "vs", "position": {"x": 0, "y": 0, "z": 2, "width": 120, "height": 200},
                  "visual": {"visualType": "slicer", "query": {"queryState": {
                      "Values": {"projections": [{"field": {"Column": {
                          "Expression": {"SourceRef": {"Entity": "DateCal"}},
                          "Property": "Year"}}, "queryRef": "DateCal.Year"}]}}}}}
            vs = os.path.join(pg, 'visuals', 'vs')
            os.makedirs(vs, exist_ok=True)
            w(os.path.join(vs, 'visual.json'), json.dumps(sl, ensure_ascii=False))
        return root, rp, sm

    def _hits(self, rp, sm):
        rep = C.read_report(rp)
        mdl = C.read_model(sm)
        n0 = len(C._FINDINGS)
        C.check_time_axis(rep, mdl, sm)
        return C._FINDINGS[n0:]

    def test_fires_on_cyclic_axis_no_year_filter(self):
        root, rp, sm = self._mk()
        try:
            hits = [f for f in self._hits(rp, sm) if f['rule'] == 'RPT-28']
            self.assertEqual(len(hits), 1, 'RPT-28 לא ירה על ציר מחזורי רב-שנתי')
            self.assertIn('Month Name', hits[0]['location'])
        finally:
            shutil.rmtree(root, ignore_errors=True)

    def test_silent_with_year_slicer(self):
        root, rp, sm = self._mk(slicer=True)
        try:
            hits = [f for f in self._hits(rp, sm) if f['rule'] == 'RPT-28']
            self.assertFalse(hits, 'RPT-28 ירה למרות סליסר שנה')
        finally:
            shutil.rmtree(root, ignore_errors=True)

    def test_silent_on_unreadable_span(self):
        root, rp, sm = self._mk(cal='CALENDARAUTO()')
        try:
            hits = [f for f in self._hits(rp, sm) if f['rule'] == 'RPT-28']
            self.assertFalse(hits, 'RPT-28 ירה על טווח לא-קריא (CALENDARAUTO)')
        finally:
            shutil.rmtree(root, ignore_errors=True)

    def test_silent_on_single_year(self):
        root, rp, sm = self._mk(cal='CALENDAR(DATE(2025,1,1), DATE(2025,12,31))')
        try:
            hits = [f for f in self._hits(rp, sm) if f['rule'] == 'RPT-28']
            self.assertFalse(hits, 'RPT-28 ירה על טווח חד-שנתי')
        finally:
            shutil.rmtree(root, ignore_errors=True)

    def test_clean_fixture_no_rpt28(self):
        root = tempfile.mkdtemp(prefix='pbicyc0-')
        dst = os.path.join(root, 'P')
        shutil.copytree(FIX, dst)
        try:
            rp = os.path.join(dst, 'MiniReport.Report')
            sm = os.path.join(dst, 'MiniReport.SemanticModel')
            hits = [f for f in self._hits(rp, sm) if f['rule'] == 'RPT-28']
            self.assertFalse(hits, 'RPT-28 ירה על פיקסצר נקי (FP)')
        finally:
            shutil.rmtree(root, ignore_errors=True)

class TestFakeNav(unittest.TestCase):
    """סבב 154 — דוח שדה סבב 2 #9 (RPT-29): תפריט textbox גאומטרי בדוח בלי
    ויזואלי ניווט אמיתיים = תפריט שאינו לחיץ (crit)."""

    def _tb(self, name, x, y, w=180):
        run = {"value": "פריט", "textStyle": {}}
        return {"name": name, "position": {"x": x, "y": y, "z": 1, "width": w, "height": 30},
                "visual": {"visualType": "textbox",
                           "objects": {"general": [{"properties": {"paragraphs": [
                               {"textRuns": [run]}]}}]}}}

    def _mk(self, visuals):
        root = tempfile.mkdtemp(prefix='pbifnav-')
        dst = os.path.join(root, 'P')
        shutil.copytree(FIX, dst)
        rp = os.path.join(dst, 'MiniReport.Report')
        pg = os.path.join(rp, 'definition', 'pages', 'pagenav')
        w(os.path.join(pg, 'page.json'),
          json.dumps({"name": "pagenav", "displayName": "ניווט"}, ensure_ascii=False))
        for v in visuals:
            vd = os.path.join(pg, 'visuals', v['name'])
            os.makedirs(vd, exist_ok=True)
            w(os.path.join(vd, 'visual.json'), json.dumps(v, ensure_ascii=False))
        return root, rp

    def _hits(self, rp):
        rep = C.read_report(rp)
        n0 = len(C._FINDINGS)
        C.check_fake_nav(rep)
        return [f for f in C._FINDINGS[n0:] if f['rule'] == 'RPT-29']

    def test_fires_on_menu_column(self):
        root, rp = self._mk([self._tb('t1', 10, 100), self._tb('t2', 10, 150),
                             self._tb('t3', 10, 200), self._tb('t4', 10, 250)])
        try:
            hits = self._hits(rp)
            self.assertEqual(len(hits), 1, 'RPT-29 לא ירה על עמודת תפריט')
            self.assertEqual(hits[0]['severity'], 'crit')
        finally:
            shutil.rmtree(root, ignore_errors=True)

    def test_silent_when_real_nav_exists(self):
        nav = {"name": "nav1", "position": {"x": 300, "y": 0, "z": 1, "width": 100, "height": 300},
               "visual": {"visualType": "pageNavigator"}}
        root, rp = self._mk([self._tb('t1', 10, 100), self._tb('t2', 10, 150),
                             self._tb('t3', 10, 200), nav])
        try:
            self.assertFalse(self._hits(rp), 'RPT-29 ירה למרות pageNavigator אמיתי')
        finally:
            shutil.rmtree(root, ignore_errors=True)

    def test_silent_on_irregular_spacing(self):
        root, rp = self._mk([self._tb('t1', 10, 100), self._tb('t2', 10, 155),
                             self._tb('t3', 10, 240)])
        try:
            self.assertFalse(self._hits(rp), 'RPT-29 ירה על מרווחים לא קבועים')
        finally:
            shutil.rmtree(root, ignore_errors=True)

    def test_silent_under_three(self):
        root, rp = self._mk([self._tb('t1', 10, 100), self._tb('t2', 10, 150)])
        try:
            self.assertFalse(self._hits(rp), 'RPT-29 ירה על שתי תיבות בלבד')
        finally:
            shutil.rmtree(root, ignore_errors=True)

class TestFilterControls(unittest.TestCase):
    """סבב 155 — דוח שדה סבב 2 #10 (RPT-30): דוח רב-דפי בלי אף פקד סינון
    (0 סליסרים, 0 filterConfig בכל הרמות) = crit."""

    def _run(self, mutate=None):
        root = tempfile.mkdtemp(prefix='pbiflt-')
        dst = os.path.join(root, 'P')
        shutil.copytree(FIX, dst)
        rp = os.path.join(dst, 'MiniReport.Report')
        if mutate:
            mutate(rp)
        rep = C.read_report(rp)
        n0 = len(C._FINDINGS)
        C.check_filter_controls(rep)
        hits = [f for f in C._FINDINGS[n0:] if f['rule'] == 'RPT-30']
        shutil.rmtree(root, ignore_errors=True)
        return hits

    def _add_slicer(self, rp):
        pg = os.path.join(rp, 'definition', 'pages', 'page001', 'visuals', 'vslc')
        os.makedirs(pg, exist_ok=True)
        sl = {"name": "vslc", "position": {"x": 0, "y": 0, "z": 9, "width": 120, "height": 200},
              "visual": {"visualType": "slicer", "query": {"queryState": {
                  "Values": {"projections": [{"field": {"Column": {
                      "Expression": {"SourceRef": {"Entity": "dimתאריך"}},
                      "Property": "Year"}}, "queryRef": "dimתאריך.Year"}]}}}}}
        w(os.path.join(pg, 'visual.json'), json.dumps(sl, ensure_ascii=False))

    def _add_report_filter(self, rp):
        rf = os.path.join(rp, 'definition', 'report.json')
        d = json.loads(open(rf, encoding='utf-8-sig').read())
        d['filterConfig'] = {"filters": [{"name": "f1", "field": {"Column": {
            "Expression": {"SourceRef": {"Entity": "dimתאריך"}}, "Property": "Year"}}}]}
        w(rf, json.dumps(d, ensure_ascii=False))

    def test_fires_on_zero_controls(self):
        hits = self._run()
        self.assertEqual(len(hits), 1, 'RPT-30 לא ירה על דוח בלי פקדי סינון')
        self.assertEqual(hits[0]['severity'], 'crit')

    def test_silent_with_slicer(self):
        self.assertFalse(self._run(self._add_slicer), 'RPT-30 ירה למרות סליסר')

    def test_silent_with_report_filter(self):
        self.assertFalse(self._run(self._add_report_filter),
                         'RPT-30 ירה למרות מסנן ברמת דוח')

class TestBucketSort(unittest.TestCase):
    """סבב 156 — דוח שדה סבב 2 #11 (MDL-26): עמודת דליים מחושבת בשימוש ללא
    sortByColumn. הליטרלים קריאים מה-DAX; שנים פיסקליות ('2024-2025') פטורות."""

    def _mk(self, expr, sort_by=None, use_in_visual=True):
        root = tempfile.mkdtemp(prefix='pbibkt-')
        dst = os.path.join(root, 'P')
        shutil.copytree(FIX, dst)
        sm = os.path.join(dst, 'MiniReport.SemanticModel')
        tbl = ["table Invoices", "", "\tcolumn Status = " + expr,
               "		dataType: string"]
        if sort_by:
            tbl.append("		sortByColumn: " + sort_by)
        tbl += ["", "	column Amount", "		dataType: int64"]
        w(os.path.join(sm, 'definition', 'tables', 'Invoices.tmdl'), "\n".join(tbl))
        rp = os.path.join(dst, 'MiniReport.Report')
        if use_in_visual:
            pg = os.path.join(rp, 'definition', 'pages', 'page001', 'visuals', 'vbkt')
            os.makedirs(pg, exist_ok=True)
            bar = {"name": "vbkt", "position": {"x": 0, "y": 0, "z": 1, "width": 400, "height": 300},
                   "visual": {"visualType": "clusteredBarChart", "query": {"queryState": {
                       "Category": {"projections": [{"field": {"Column": {
                           "Expression": {"SourceRef": {"Entity": "Invoices"}},
                           "Property": "Status"}}, "queryRef": "Invoices.Status"}]}}}}}
            w(os.path.join(pg, 'visual.json'), json.dumps(bar, ensure_ascii=False))
        return root, rp, sm

    def _hits(self, rp, sm):
        rep = C.read_report(rp)
        mdl = C.read_model(sm)
        n0 = len(C._FINDINGS)
        C.check_bucket_sort(rep, mdl)
        return [f for f in C._FINDINGS[n0:] if f['rule'] == 'MDL-26']

    BUCKETS = ('IF([Days]<=30,"Overdue 1-30",IF([Days]<=60,"31-60",'
               'IF([Days]<=90,"61-90","90+")))')

    def test_fires_on_bucket_column(self):
        root, rp, sm = self._mk(self.BUCKETS)
        try:
            hits = self._hits(rp, sm)
            self.assertEqual(len(hits), 1, 'MDL-26 לא ירה על עמודת דליים')
            self.assertIn('Status', hits[0]['location'])
        finally:
            shutil.rmtree(root, ignore_errors=True)

    def test_silent_with_sortby(self):
        root, rp, sm = self._mk(self.BUCKETS, sort_by='BucketIndex')
        try:
            self.assertFalse(self._hits(rp, sm), 'MDL-26 ירה למרות sortByColumn')
        finally:
            shutil.rmtree(root, ignore_errors=True)

    def test_silent_when_unused(self):
        root, rp, sm = self._mk(self.BUCKETS, use_in_visual=False)
        try:
            self.assertFalse(self._hits(rp, sm), 'MDL-26 ירה על עמודה שלא בשימוש')
        finally:
            shutil.rmtree(root, ignore_errors=True)

    def test_silent_on_fiscal_years(self):
        root, rp, sm = self._mk('IF([Y]=2024,"2024-2025","2025-2026")')
        try:
            self.assertFalse(self._hits(rp, sm), 'MDL-26 ירה על שנים פיסקליות')
        finally:
            shutil.rmtree(root, ignore_errors=True)

class TestValidateHonestWording(unittest.TestCase):
    """סבב 157 — דוח שדה סבב 3 (המלצתו היחידה): פלט pbi_validate אומר את האמת —
    'מבנה עקבי · 0 שגיאות מבנה · חוקיות מאפיינים ורינדור לא נבדקו', לא 'תקין'."""

    def _clean_copy(self):
        root = tempfile.mkdtemp(prefix='pbihon-')
        dst = os.path.join(root, 'P')
        shutil.copytree(FIX, dst)
        # ניקוי ה-BOM המכוון של הפיקסצר (§10) כדי לקבל מסלול "0 בעיות"
        for dirpath, _dn, fn in os.walk(dst):
            for f in fn:
                if f.endswith(('.tmdl', '.json')):
                    fp = os.path.join(dirpath, f)
                    raw = open(fp, 'rb').read()
                    if raw.startswith(b'\xef\xbb\xbf'):
                        open(fp, 'wb').write(raw[3:])
        return root, dst

    def test_clean_output_is_honest(self):
        root, dst = self._clean_copy()
        try:
            V._ISSUES.clear()
            V.validate_project(dst)
            out = V.render()
            self.assertIn('מבנה עקבי', out)
            self.assertIn('לא נבדקו', out)
            self.assertIn('Desktop', out)
            self.assertNotIn('תקין מבנית', out, 'הניסוח הישן מבטיח יתר על המידה')
        finally:
            shutil.rmtree(root, ignore_errors=True)

    def test_warn_output_carries_caveat(self):
        root = tempfile.mkdtemp(prefix='pbihon2-')
        dst = os.path.join(root, 'P')
        shutil.copytree(FIX, dst)
        try:
            V._ISSUES.clear()
            V.validate_project(dst)
            out = V.render()
            self.assertIn('שגיאות מבנה', out)
        finally:
            shutil.rmtree(root, ignore_errors=True)


class TestSvgFieldRound3(unittest.TestCase):
    """סבב 157 — דוח שדה סבב 3 (#2 #3 #4): pbi_svg לא מפר §14 (/// ולא
    description:), בלי formatString על מדד מחרוזת, nativeQueryRef בקשירה,
    וסדר הגדרת VARs בכל 11 התבניות."""

    def _args(self, **kw):
        import argparse
        base = dict(template='kpi', measure='M', table='t', guard=None, value='[v]',
                    compare=None, warn=None, err=None, target=None, maxval=None,
                    axis=None, actual=None, plan=None, invert=False, series=None,
                    label=None, items=None, top=None, x=None, y=None, img=None)
        base.update(kw)
        return argparse.Namespace(**base)

    def test_block_uses_doc_comment_not_description(self):
        dax_lines = S.GENS['kpi'](self._args())
        block = ('\t/// ויזואל SVG (כרטיס) \n' + S._tmdl_block('M', dax_lines))
        self.assertNotIn('description:', block, 'description: על measure = UnknownKeyword (§14)')
        self.assertNotIn('formatString', block, 'formatString על מדד מחרוזת (שדה סבב 3 #3)')

    def test_all_templates_var_order(self):
        """הסריקה שביקש (#4): כל 11 התבניות — שימוש רק אחרי הגדרה."""
        import re as _re
        combos = {
            'kpi': [dict(), dict(compare='[c]')],
            'status': [dict(warn=100, err=50), dict(warn=100, err=50, invert=True)],
            'progress': [dict(target='[t]')],
            'radar': [dict(axis=['א|[v]', 'ב|[v]', 'ג|[v]'])],
            'variance': [dict(actual='[a]', plan='[p]'), dict(actual='[a]', plan='[p]', invert=True)],
            'bubble': [dict(series="'t'[c]")],
            'bulletlist': [dict(items="'t'[c]")],
            'scatterimg': [dict(x='[x]', y='[y]', img="'t'[c]", guard="'t'[c]")],
            'boxplot': [dict(series="'t'[c]")],
            'dumbbell': [dict(actual='[a]', target='[t]', series="'t'[c]")],
            'ibcsbar': [dict(actual='[a]', compare='[c]', series="'t'[c]")],
        }
        for tpl, argsets in combos.items():
            for kw in argsets:
                lines = S.GENS[tpl](self._args(template=tpl, **kw))
                defined = set()
                for chunk in lines:
                    for ln in chunk.split('\n'):
                        m = _re.match(r'VAR (_\w+)\s*=', ln.strip())
                        for ref in _re.findall(r'_\w+', ln):
                            if m and ref == m.group(1):
                                continue
                            self.assertIn(ref, defined,
                                          '%s: שימוש ב-%s לפני הגדרה (דפוס #4)' % (tpl, ref))
                        if m:
                            defined.add(m.group(1))

    def test_bind_writes_native_query_ref(self):
        root = tempfile.mkdtemp(prefix='pbibind-')
        dst = os.path.join(root, 'P')
        shutil.copytree(FIX, dst)
        try:
            rp = os.path.join(dst, 'MiniReport.Report')
            _name, newdoc = S.bind_visual(rp, 'page001', 'factמכירות', 'SVG בדיקה')
            pr = newdoc['visual']['query']['queryState']['Values']['projections'][0]
            self.assertEqual(pr.get('nativeQueryRef'), 'SVG בדיקה',
                             'nativeQueryRef חסר — Desktop יציג Fields that need to be fixed')
            self.assertEqual(pr.get('queryRef'), 'factמכירות.SVG בדיקה')
        finally:
            shutil.rmtree(root, ignore_errors=True)

class TestFullJsonTemplates(unittest.TestCase):
    """סבב 158 — דוח שדה סבב 3 #7: שש תבניות JSON מלאות ב-pbir-templates-full,
    כולן גזורות מייצוא Desktop מאומת, ללא BOM, וה-CSV מצביע לקבצים קיימים."""

    DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                       "skills", "powerbi-design-search", "data", "pbir-templates-full")

    def _load(self, name):
        p = os.path.join(self.DIR, name)
        raw = open(p, 'rb').read()
        self.assertFalse(raw.startswith(b'\xef\xbb\xbf'), name + ' עם BOM')
        return json.loads(raw.decode('utf-8'))

    def test_all_six_parse_and_typed(self):
        expect = {
            'action-button-navigate.json': 'actionButton',
            'slicer-dropdown.json': 'slicer',
            'pagenavigator-horizontal.json': 'pageNavigator',
            'cardvisual-2measures.json': 'cardVisual',
            'tableex-basic.json': 'tableEx',
        }
        for fname, vt in expect.items():
            d = self._load(fname)
            self.assertTrue(d.get('$schema'), fname + ' חסר $schema')
            self.assertEqual(d['visual']['visualType'], vt, fname)

    def test_pagenavigator_orientation_is_numeric_enum(self):
        d = self._load('pagenavigator-horizontal.json')
        lay = d['visual']['objects']['layout'][0]['properties']
        self.assertEqual(lay['orientation']['expr']['Literal']['Value'], '0D',
                         'הכיוון המאומת בדונור הוא enum מספרי; ניחוש grid/\'Vertical\' נכשל בשדה')
        self.assertNotIn('grid', d['visual']['objects'])

    def test_action_button_navigation_target(self):
        d = self._load('action-button-navigate.json')
        link = d['visual']['visualContainerObjects']['visualLink'][0]['properties']
        self.assertEqual(link['type']['expr']['Literal']['Value'], "'PageNavigation'")
        self.assertIn('navigationSection', link)

    def test_drillthrough_page_has_both_halves(self):
        d = self._load('page-drillthrough.json')
        self.assertEqual(d['pageBinding']['type'], 'Drillthrough')
        f = d['filterConfig']['filters'][0]
        self.assertEqual(f['howCreated'], 'Drillthrough')
        self.assertEqual(d['pageBinding']['parameters'][0]['boundFilter'], f['name'])
        self.assertEqual(d['visibility'], 'HiddenInViewMode')

    def test_card_two_data_projections_with_native_ref(self):
        d = self._load('cardvisual-2measures.json')
        pr = d['visual']['query']['queryState']['Data']['projections']
        self.assertEqual(len(pr), 2)
        for p in pr:
            self.assertIn('nativeQueryRef', p, 'גם בתבניות — nativeQueryRef (סבב 3 #3)')

    def test_csv_references_existing_files(self):
        import csv as _csv, re as _re
        path = os.path.join(os.path.dirname(self.DIR), 'pbir-templates.csv')
        missing = []
        for r in _csv.DictReader(open(path, encoding='utf-8')):
            for m in _re.findall(r'pbir-templates-full/([\w.-]+\.json)', r.get('Notes', '')):
                if not os.path.isfile(os.path.join(self.DIR, m)):
                    missing.append(m)
        self.assertEqual(missing, [], 'CSV מצביע לקבצים שלא קיימים')

class TestThemeCatalogM27(unittest.TestCase):
    """סבב 159 — דוח שדה סבב 3 (#6, שורות theme): pbi_validate מול קטלוג סכמת
    theme הרשמית של Microsoft (2.157, MIT). שורש סגור; מאפיין לא מוכר = err;
    שוברי-שדה = warn רק בערכות מחבר (לא BaseThemes/BuiltInThemes של MS)."""

    def _run(self, theme_obj, base_theme=False):
        tmp = tempfile.mkdtemp(prefix='pbim27-')
        sub = 'BaseThemes' if base_theme else 'RegisteredResources'
        tdir = os.path.join(tmp, 'R.Report', 'StaticResources', 'SharedResources', sub)
        os.makedirs(tdir)
        tf = os.path.join(tdir, 't.json')
        with open(tf, 'w', encoding='utf-8') as fh:
            json.dump(theme_obj, fh)
        V._ISSUES.clear()
        V._check_theme_content(tf, theme_obj, is_ms_base=base_theme)
        out = list(V._ISSUES)
        shutil.rmtree(tmp, ignore_errors=True)
        return out

    def test_unknown_root_key_is_err(self):
        issues = self._run({'name': 'x', '_source': 'gpt'})
        self.assertTrue(any(i['code'] == 'M-27' and i['level'] == 'err' for i in issues),
                        '_source בשורש חייב err (additionalProperties:false; דוח סבב 3)')

    def test_unknown_property_is_err(self):
        issues = self._run({'name': 'x', 'visualStyles':
                            {'*': {'*': {'title': [{'fontSiz': 12}]}}}})
        self.assertTrue(any(i['code'] == 'M-27' and i['level'] == 'err'
                            and 'fontSiz' in i['title'] for i in issues),
                        'שגיאת כתיב fontSiz חייבת err — זה בדיוק הכשל השקט שלו')

    def test_known_properties_clean(self):
        issues = self._run({'name': 'x', 'visualStyles':
                            {'*': {'*': {'categoryAxis': [{'showAxisTitle': True,
                                                           'gridlineStyle': 'dashed'}],
                                         'title': [{'fontFace': 'Segoe UI'}]}}},
                            })
        self.assertFalse([i for i in issues if i['code'] == 'M-27' and i['level'] == 'err'],
                         'מאפיינים מערכות הבסיס של MS חייבים לעבור נקי')

    def test_field_breaker_warns_only_in_author_theme(self):
        theme = {'name': 'x', 'visualStyles': {'*': {'*': {'padding': [{'left': 8}]}}}}
        author = self._run(theme, base_theme=False)
        self.assertTrue(any(i['code'] == 'M-27' and i['level'] == 'warn' for i in author))
        msbase = self._run(theme, base_theme=True)
        self.assertFalse([i for i in msbase if i['code'] == 'M-27'],
                          'ערכת הבסיס Fluent 2 של MS עצמה משתמשת ב-padding — לא להזהיר')

    def test_catalog_file_sane(self):
        import os
        cp = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                          'skills', 'powerbi-pbip-builder', 'data', 'theme-catalog-2.157.json')
        raw = open(cp, 'rb').read()
        self.assertFalse(raw.startswith(b'\xef\xbb\xbf'))
        cat = json.loads(raw.decode('utf-8'))
        self.assertEqual(cat['version'], '2.157')
        self.assertIn('pageNavigator', cat['visualTypes'])
        self.assertIn('orientation', cat['visualProps']['pageNavigator'])
        self.assertIn('shadowSpread', cat['commonCards']['dropShadow'])
        self.assertIn('fontFace', cat['textClassProps'])
        self.assertTrue(cat['observedProps'].get('page'), 'שכבת observed של ערכות MS')

class TestValueValidationM29R95(unittest.TestCase):
    """סבב 161 — דוח שדה סבב 3 (#1, 🔴🔴): ולידציית ערכים מול סכמת TMDL/PBIR.
    שורות הטבלה שלו: 'description:' כמאפיין measure (Frown), compatibilityLevel
    1600 מול מסד 1606 (Frown), syncGroup בשורש visual.json (12 issues ב-Desktop).
    גראונדינג: MS Learn tmdl-overview § Descriptions (/// בלבד) + טבלת רמות
    תאימות רשמית; corpus 2640 visual.json (syncGroup בשורש = 0, חוקי רק כ-
    visual.syncGroup — דונור capital/daq)."""

    def setUp(self):
        self.root = tempfile.mkdtemp(prefix='pbival29-')
        self.dst = os.path.join(self.root, 'P')
        shutil.copytree(FIX, self.dst)
        self.sm = os.path.join(self.dst, 'MiniReport.SemanticModel')
        self.rp = os.path.join(self.dst, 'MiniReport.Report')

    def tearDown(self):
        shutil.rmtree(self.root, ignore_errors=True)

    def run_val(self):
        V._ISSUES.clear()
        mt = V.read_model_map(self.sm)
        V.validate_model(self.sm)
        V.validate_report(self.rp, mt)
        return V._ISSUES

    def _vj_path(self):
        return os.path.join(self.rp, 'definition', 'pages', 'page001',
                            'visuals', 'vis001', 'visual.json')

    def test_description_colon_in_tmdl_is_err(self):
        f = os.path.join(self.sm, 'definition', 'tables', 'factמכירות.tmdl')
        txt = open(f, encoding='utf-8-sig').read()
        w(f, txt + '\n\tdescription: תיאור בכתיב לא חוקי\n')
        issues = self.run_val()
        self.assertTrue(any(i['code'] == 'M-29' and i['level'] == 'err'
                            and 'description' in i['title'] for i in issues),
                        'description: בכתיב נקודתיים לא נתפס — הכשל שלו משורה 2')

    def test_triple_slash_description_clean(self):
        f = os.path.join(self.sm, 'definition', 'tables', 'factמכירות.tmdl')
        txt = open(f, encoding='utf-8-sig').read()
        w(f, '/// תיאור חוקי של טבלה\n' + txt)
        issues = self.run_val()
        self.assertFalse([i for i in issues if i['code'] == 'M-29'],
                         'תיאור /// חוקי סומן (FP)')

    def test_compat_level_wrong_file_is_err(self):
        w(os.path.join(self.sm, 'definition', 'model.tmdl'),
          'model Model\n\tcompatibilityLevel: 1600\n')
        issues = self.run_val()
        self.assertTrue(any(i['code'] == 'M-29' and i['level'] == 'err'
                            and 'compatibilityLevel' in i['title'] for i in issues),
                        'compatibilityLevel ב-model.tmdl לא נתפס')

    def test_compat_level_known_value_clean(self):
        w(os.path.join(self.sm, 'definition', 'database.tmdl'),
          'database MiniReport\n\tcompatibilityLevel: 1600\n')
        issues = self.run_val()
        self.assertFalse([i for i in issues if i['code'] == 'M-29' and i['level'] == 'err'],
                         '1600 חוקי ב-database.tmdl סומן כשגיאה (FP)')

    def test_compat_level_unknown_integer_warns_not_errs(self):
        w(os.path.join(self.sm, 'definition', 'database.tmdl'),
          'database MiniReport\n\tcompatibilityLevel: 1609\n')
        issues = self.run_val()
        m29 = [i for i in issues if i['code'] == 'M-29']
        self.assertTrue(m29 and all(i['level'] == 'warn' for i in m29),
                        'רמה לא מתועדת חייבת warn בלבד (Desktop מוסיף רמות)')

    def test_compat_level_non_numeric_is_err(self):
        w(os.path.join(self.sm, 'definition', 'database.tmdl'),
          'database MiniReport\n\tcompatibilityLevel: sixteen\n')
        issues = self.run_val()
        self.assertTrue(any(i['code'] == 'M-29' and i['level'] == 'err'
                            and 'sixteen' in i['title'] for i in issues))

    def test_bim_tmdl_compat_mismatch_is_err(self):
        w(os.path.join(self.sm, 'definition', 'database.tmdl'),
          'database MiniReport\n\tcompatibilityLevel: 1606\n')
        w(os.path.join(self.sm, 'model.bim'),
          json.dumps({'name': 'MiniReport', 'compatibilityLevel': 1600}))
        V._ISSUES.clear()
        V.validate_project(self.dst)
        issues = list(V._ISSUES)
        self.assertTrue(any(i['code'] == 'M-29' and i['level'] == 'err'
                            and 'סותר' in i['title'] for i in issues),
                        'סתירת 1600/1606 בין model.bim ל-database.tmdl לא נתפסה — שורה 3 שלו')

    def test_syncgroup_at_visual_root_is_err(self):
        d = json.load(open(self._vj_path(), encoding='utf-8-sig'))
        d['syncGroup'] = {'groupName': 'g1', 'fieldChanges': True, 'filterChanges': True}
        w(self._vj_path(), json.dumps(d, ensure_ascii=False))
        issues = self.run_val()
        self.assertTrue(any(i['code'] == 'R-95' and i['level'] == 'err'
                            and 'syncGroup' in i['title'] for i in issues),
                        'syncGroup בשורש לא נתפס — 12 ה-issues שלו ב-Desktop')

    def test_syncgroup_under_visual_clean(self):
        d = json.load(open(self._vj_path(), encoding='utf-8-sig'))
        d['visual']['syncGroup'] = {'groupName': 'g1', 'fieldChanges': True,
                                    'filterChanges': True}
        w(self._vj_path(), json.dumps(d, ensure_ascii=False))
        issues = self.run_val()
        self.assertFalse([i for i in issues if i['code'] == 'R-95' and i['level'] == 'err'],
                         'visual.syncGroup חוקי (דונור capital/daq) סומן כשגיאה (FP)')

    def test_unknown_root_key_info_only(self):
        d = json.load(open(self._vj_path(), encoding='utf-8-sig'))
        d['futureKey'] = {'x': 1}
        w(self._vj_path(), json.dumps(d, ensure_ascii=False))
        issues = self.run_val()
        r95 = [i for i in issues if i['code'] == 'R-95']
        self.assertTrue(r95 and all(i['level'] == 'info' for i in r95),
                        'מפתח שורש לא מוכר חייב info בלבד')


class TestVisualCatalogM28(unittest.TestCase):
    """סבב 160 — דוח שדה סבב 3 (#6): כרטיסים/מאפיינים ב-visual.json מול קטלוג
    נצפה-בקורפוס (pbir-visual-catalog.json). אין סכמת objects רשמית מפורטת —
    הקטלוג הוא הרשת היחידה מפני ניחוש שקט."""

    def _run(self, vt, objects=None, vco=None):
        vis = {'visualType': vt}
        if objects is not None:
            vis['objects'] = objects
        if vco is not None:
            vis['visualContainerObjects'] = vco
        V._ISSUES.clear()
        V._check_visual_catalog({'visual': vis}, 'test.json')
        return list(V._ISSUES)

    def test_typo_property_on_well_sampled_card_is_err(self):
        issues = self._run('cardVisual', {'value': [{'properties': {'fontSiz': 12}}]})
        self.assertTrue(any(i['code'] == 'M-28' and i['level'] == 'err'
                            and 'fontSiz' in i['title'] for i in issues),
                        'fontSiz (שגיאת כתיב) על value חייב err — הכשל השקט שלו')

    def test_unknown_card_is_err(self):
        issues = self._run('cardVisual', {'titl': [{'properties': {'show': True}}]})
        self.assertTrue(any(i['code'] == 'M-28' and i['level'] == 'err'
                            and 'titl' in i['title'] for i in issues))

    def test_known_props_clean(self):
        issues = self._run('cardVisual',
                           {'value': [{'properties': {'show': True, 'fontSize': 20}}]},
                           {'title': [{'properties': {'show': True, 'text': 'x'}}]})
        self.assertFalse([i for i in issues if i['level'] == 'err'])

    def test_unknown_visualtype_is_info_only(self):
        issues = self._run('myCustomVisual', {'whatever': [{'properties': {'x': 1}}]})
        self.assertTrue(issues and all(i['level'] == 'info' for i in issues))

    def test_catalog_file_sane(self):
        import os
        cp = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                          'skills', 'powerbi-pbip-builder', 'data', 'pbir-visual-catalog.json')
        raw = open(cp, 'rb').read()
        self.assertFalse(raw.startswith(b'\xef\xbb\xbf'))
        cat = json.loads(raw.decode('utf-8'))
        self.assertGreater(cat['visuals'], 2000)
        self.assertIn('pageNavigator', cat['visualTypes'])
        self.assertIn('layout', cat['visualTypes']['pageNavigator']['objects'])

