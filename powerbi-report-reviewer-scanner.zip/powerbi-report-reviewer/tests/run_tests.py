#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
run_tests.py — בדיקות רגרסיה לסקריפטים של הערכה, מול פרויקט PBIP סינתטי זעיר.

למה: הסקריפטים הם עמוד השדרה של "אמת מהקוד", וכל תקלה בהם היא ממצא שגוי בדוח של
משתמש. ה-fixture נועד לנעול את המלכודות המתועדות ב-known-issues-log:
  §10 — קובץ עם BOM (vis003 + טבלת factמכירות) חייב להיקרא ב-utf-8-sig.
  §12 — שם מדד עם גרש ('אחוז מהמלאי -מתחת למינ'') חייב לחזור זהה משני הנתיבים
        (pbi_analyze ו-pbi_doc) — "שני נתיבי קריאה שונים חייבים להחזיר את אותו מספר".
  §1  — כותרת נקראת גם מ-visualContainerObjects וגם מ-objects.

מריצים:  python tests/run_tests.py        (stdlib בלבד, בלי pip, בלי רשת)
"""
import io, os, sys, unittest, contextlib, importlib.util
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
FIX = Path(__file__).resolve().parent / 'fixture'
REPORT = FIX / 'MiniReport.Report'
MODEL = FIX / 'MiniReport.SemanticModel'


def load(mod_name, script):
    spec = importlib.util.spec_from_file_location(mod_name, script)
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


EX = load('pbi_extract', ROOT / 'skills/powerbi-report-reviewer/scripts/pbi_extract.py')
AN = load('pbi_analyze', ROOT / 'skills/powerbi-report-reviewer/scripts/pbi_analyze.py')
DOC = load('pbi_doc', ROOT / 'skills/powerbi-report-reviewer/scripts/pbi_doc.py')
DS = load('core', ROOT / 'skills/powerbi-design-search/scripts/core.py')


class TestExtract(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.pages = EX.read_report(str(REPORT))

    def test_pages_and_visuals_found(self):
        self.assertEqual(len(self.pages), 2)
        self.assertEqual(sum(len(p['visuals']) for p in self.pages), 4)

    def test_bom_visual_json_parsed(self):
        # vis003 נכתב עם BOM. בלי utf-8-sig הקריאה קורסת לרשומת error (§10).
        p1 = self.pages[0]
        errs = [v for v in p1['visuals'] if 'error' in v]
        self.assertEqual(errs, [], 'קובץ BOM לא נקרא — ראה known-issues §10')

    def test_title_from_both_locations(self):
        # §1: כותרת יושבת ב-visualContainerObjects או ב-objects — לבדוק את שניהם.
        vis = {v['id']: v for p in self.pages for v in p['visuals']}
        self.assertEqual(vis['vis001']['title'], 'כמות שנתית')
        self.assertEqual(vis['vis003']['title'], 'כמות לפי מוצר')

    def test_cross_checks(self):
        p1 = self.pages[0]
        c = EX.cross_checks(p1)
        self.assertTrue(any(s['w'] == 150 for s in c['small_cards']), 'כרטיס קטן לא סומן (§22)')
        self.assertIn('tableEx', c['no_title'])
        self.assertEqual(len(c['tables']), 1, 'tableEx לא זוהה כמועמד ל-HTML Content')

    def test_duplicate_title_different_content(self):
        p2 = self.pages[1]
        p1 = self.pages[0]
        found = []
        for p in (p1, p2):
            found += EX.cross_checks(p)['dup_titles']
        # הכפילות בין vis001 (דף 1) ל-vis004 (דף 2) — נתפסת לפחות בדף שמכיל אחת מהן
        # (הבדיקה היא ברמת דף; כאן מדובר באותו דף? לא — שתי דפים, לכן הבדיקה היא
        #  שכל דף בנפרד לא מדווח שקר, והסוכן משווה בין דפים מהטבלה).
        self.assertEqual(found, [])

    def test_detect_format(self):
        self.assertEqual(EX.detect_format(str(REPORT)), 'pbir')
        self.assertEqual(EX.detect_format(str(FIX)), 'unknown')


class TestAnalyze(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tables, cls.rel_cols, cls.rels_raw = AN.load_model(str(MODEL))

    def test_bom_tmdl_table_name(self):
        # בלי utf-8-sig שורת ה-table הראשונה מזוהה כ-"\ufefftable" והשם נופל לשם הקובץ.
        names = {t['name'] for t in self.tables}
        self.assertIn('factמכירות', names)

    def test_skip_auto_tables(self):
        names = {t['name'] for t in self.tables}
        self.assertNotIn('LocalDateTable_9f8', names)

    def test_quoted_measure_name(self):
        # §12: גרש בתוך שם נכתב פעמיים ב-TMDL ומוחזר כגרש בודד.
        fact = next(t for t in self.tables if t['name'] == 'factמכירות')
        self.assertIn("אחוז מהמלאי -מתחת למינ'", fact['measures'])
        self.assertEqual(len(fact['measures']), 5)

    def test_model_checks(self):
        chk = AN.model_checks(self.tables, self.rels_raw)
        self.assertEqual(len(chk['both_dir']), 1)
        self.assertIn('סכום ללא הגנה', chk['raw_division'])
        self.assertNotIn("אחוז מהמלאי -מתחת למינ'", chk['raw_division'], 'DIVIDE סומן בטעות כחלוקה גולמית')
        self.assertIn('אשתקד', chk['spl_unguarded'])
        self.assertIn('סכום ללא הגנה', chk['no_format'])
        self.assertNotIn('כמות שנתית', chk['no_format'])

    def test_unused_and_deps(self):
        used_names = AN.report_refs(str(REPORT))
        self.assertIn('כמות שנתית', used_names)
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            sys.argv = ['pbi_analyze.py', str(MODEL), str(REPORT)]
            AN.main()
        out = buf.getvalue()
        self.assertIn('אשתקד', out)  # מדד שלא בשימוש בדוח


class TestDoc(unittest.TestCase):
    def test_measure_count_matches_analyze(self):
        # known-issues §12: שני נתיבי קריאה שונים חייבים להחזיר את אותו מספר.
        model = DOC.read_model(str(MODEL))
        tables, _, _ = AN.load_model(str(MODEL))
        n_doc = len(model['measures'])
        n_an = sum(len(t['measures']) for t in tables)
        self.assertEqual(n_doc, n_an, f'pbi_doc={n_doc} אך pbi_analyze={n_an}')
        names_doc = {m['name'] for m in model['measures']}
        self.assertIn("אחוז מהמלאי -מתחת למינ'", names_doc)


class TestDesignSearch(unittest.TestCase):
    def test_hebrew_query_finds_color_domain(self):
        r = DS.search('פלטת צבע')
        self.assertEqual(r['domain'], 'color')
        self.assertTrue(r['results'])

    def test_no_hint_searches_all_domains(self):
        self.assertIsNone(DS.detect_domain('zqxx'))
        r = DS.search('zqxx inventory')
        self.assertEqual(r['domain'], 'all')
        self.assertTrue(r['results'])

    def test_english_still_works(self):
        r = DS.search('waterfall comparison', domain='chart', max_results=1)
        self.assertEqual(r['results'][0]['Chart Type'], 'Waterfall')



class TestCliJson(unittest.TestCase):
    """--json של pbi_doc (drift) ו-pbi_analyze מחזיר JSON תקין לצריכה תכנותית."""

    def _run_json(self, mod, argv):
        import contextlib
        old = sys.argv
        sys.argv = argv
        buf = io.StringIO()
        try:
            with contextlib.redirect_stdout(buf):
                mod.main()
        finally:
            sys.argv = old
        import json as js
        return js.loads(buf.getvalue())

    def test_doc_drift_json(self):
        out = self._run_json(DOC, ['pbi_doc.py', str(REPORT), str(MODEL),
                                   '--drift-only', '--json'])
        for k in ('added', 'removed', 'changed', 'undocumented', 'total_measures'):
            self.assertIn(k, out)
        self.assertGreater(out['total_measures'], 0)

    def test_analyze_json(self):
        out = self._run_json(AN, ['pbi_analyze.py', str(MODEL), str(REPORT), '--json'])
        self.assertIn('unused_measures', out)
        self.assertIn('orphan_tables', out)
        self.assertIn('dependencies', out)
        self.assertGreater(out['counts']['measures'], 0)

if __name__ == '__main__':
    unittest.main(verbosity=2)
