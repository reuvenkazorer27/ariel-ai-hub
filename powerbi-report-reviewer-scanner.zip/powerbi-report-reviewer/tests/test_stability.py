#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""test_stability.py — mutation sweep (known-issues §16, "JSON בצורה לא צפויה").

היומן מתעד: visual.json שהוא [] / מחרוזת / אובייקט עם visual:"x" / position.x:"abc"
הפיל סריקה שלמה ב-AttributeError; הפתרון נכתב ככלל אבל לא נאכף בבדיקה — ונכשל בשדה
(cross-cutting #4 בדוח השדה 14.9). הסוויפ הזה הוא האכיפה: 6 מוטציות × 4 קבצי-מפתח ×
3 קוראים (pbi_extract / pbi_map / pbi_check) חייב להסתיים בלי חריגה לא-מטופלת,
והקבצים הפגומים חייבים להופיע כ-RPT-22 (קריטי) ב-pbi_check — לא דילוג שקט.
"""
import json, os, shutil, subprocess, sys, tempfile, unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SCRIPTS = os.path.join(ROOT, 'skills', 'powerbi-report-reviewer', 'scripts')
FIX = os.path.join(ROOT, 'tests', 'fixture')

TOOLS = ('pbi_extract.py', 'pbi_map.py', 'pbi_check.py')

# 6 מוטציות מהיומן: מערך, מחרוזת, visual כסקלר, position.x לא-מספרי, name מספרי, JSON קטוע
MUTATIONS = {
    'array': '[]',
    'string': '"just a string"',
    'visual_scalar': '{"name": "v", "visual": "x"}',
    'position_text': '{"name": "v", "position": {"x": "abc", "y": 0, "width": 10, "height": 10}}',
    'name_number': '{"name": 5, "position": {"x": 0, "y": 0, "width": 1, "height": 1}}',
    'truncated': '{"name": "v", "position":',
}


class TestStabilitySweep(unittest.TestCase):
    def setUp(self):
        self.root = tempfile.mkdtemp(prefix='pbistab-')
        self.dst = os.path.join(self.root, 'P')
        shutil.copytree(FIX, self.dst)
        self.rp = os.path.join(self.dst, 'MiniReport.Report')
        self.files = {
            'visual.json': os.path.join(self.rp, 'definition', 'pages', 'page001',
                                        'visuals', 'vis001', 'visual.json'),
            'page.json': os.path.join(self.rp, 'definition', 'pages', 'page001', 'page.json'),
            'pages.json': os.path.join(self.rp, 'definition', 'pages', 'pages.json'),
            'report.json': os.path.join(self.rp, 'definition', 'report.json'),
        }
        self.orig = {k: open(v, 'rb').read() for k, v in self.files.items()}

    def tearDown(self):
        shutil.rmtree(self.root, ignore_errors=True)

    def _run(self, tool):
        r = subprocess.run([sys.executable, os.path.join(SCRIPTS, tool), self.rp],
                           capture_output=True, text=True, timeout=120)
        return r

    def _restore(self, fname):
        open(self.files[fname], 'wb').write(self.orig[fname])

    def test_mutation_sweep_no_crash(self):
        """6 מוטציות × 4 קבצים × 3 קוראים — אסורה חריגה לא-מטופלת (Traceback)."""
        crashes = []
        runs = 0
        for fname, fpath in self.files.items():
            for mname, payload in MUTATIONS.items():
                open(fpath, 'w', encoding='utf-8').write(payload)
                for tool in TOOLS:
                    runs += 1
                    r = self._run(tool)
                    if 'Traceback' in r.stderr:
                        crashes.append('%s × %s × %s' % (fname, mname, tool))
                self._restore(fname)
        self.assertEqual(crashes, [],
                         'חריגות לא-מטופלות בסוויפ (%d הרצות): %s' % (runs, crashes))

    def test_broken_files_surface_as_rpt22(self):
        """קובץ שבור = ממצא RPT-22 קריטי ב-pbi_check, לא דילוג שקט."""
        for fname, fpath in self.files.items():
            open(fpath, 'w', encoding='utf-8').write(MUTATIONS['truncated'])
            r = subprocess.run([sys.executable, os.path.join(SCRIPTS, 'pbi_check.py'),
                                self.rp, '--json'], capture_output=True, text=True, timeout=120)
            self.assertIn('RPT-22', r.stdout,
                          '%s קטוע לא דווח כ-RPT-22 (דילוג שקט = עיוורון בביקורת)' % fname)
            self._restore(fname)


if __name__ == '__main__':
    unittest.main()
