#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
בדיקות יחידה ל-pbi_map.py — מפת המבנה הצולבת (הבנה עיוורת מהקוד).

ה-fixture הסטטי נושא מלכודות מכוונות שהמפה חייבת לחשוף בלי לפתוח דוח:
  • vis002 מקושר ל-dimמוצרים[שם מוצר] שלא נמצא (מקביל R-15) — הפניה "שבורה".
  • vis004 נושא כותרת "כמות שנתית" אבל שואב את המדד "כמות חודשית" — רק הצלבת
    כותרת מול שדות חושפת את זה בלי רינדור.
  • מדדים יתומים ('אשתקד', 'סכום ללא הגנה', 'אחוז מהמלאי...') ועמודת Year יתומה.
  • קשר r1 דו-כיווני.
בנוסף — עותקים זמניים עם מלכודות מבניות: דף מחוץ ל-pageOrder, סימנייה בלי קובץ.

הרצה:  python tests/test_pbi_map.py      (stdlib בלבד, בלי רשת)
"""
import json, os, shutil, sys, tempfile, unittest, importlib.util

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FIX = os.path.join(ROOT, 'tests', 'fixture')
REPORT = os.path.join(FIX, 'MiniReport.Report')
MODEL = os.path.join(FIX, 'MiniReport.SemanticModel')


def load(mod_name, script):
    spec = importlib.util.spec_from_file_location(mod_name, script)
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


MAP = load('pbi_map', os.path.join(ROOT, 'skills/powerbi-report-reviewer/scripts/pbi_map.py'))


class MapOnFixture(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.m = MAP.build_map(REPORT, MODEL)

    def test_pages_in_pageorder(self):
        self.assertEqual([p['id'] for p in self.m['pages']], ['page001', 'page002'])
        self.assertEqual(self.m['active_page'], 'page001')
        self.assertEqual(self.m['dirs_missing_from_order'], [])

    def test_visual_fields_with_roles(self):
        p1 = self.m['pages'][0]
        vis = {v['id']: v for v in p1['visuals']}
        f = vis['vis001']['fields']
        self.assertEqual(len(f), 1)
        self.assertEqual((f[0]['role'], f[0]['kind'], f[0]['entity'], f[0]['property']),
                         ('Data', 'Measure', 'factמכירות', 'כמות שנתית'))

    def test_measure_usage_traced_to_visuals(self):
        uses = self.m['measure_uses']['כמות שנתית']
        self.assertIn('page001/vis001:Data', uses)
        self.assertIn('page001/vis003:Y', uses)
        self.assertIn('page002/vis004:Data', self.m['measure_uses']['כמות חודשית'])

    def test_measure_dependency_chain(self):
        # עקבה עיוורת: vis004 ← כמות חודשית ← כמות שנתית ← factמכירות[כמות]
        self.assertIn('כמות שנתית', self.m['measure_deps']['כמות חודשית']['measures'])
        self.assertIn(('factמכירות', 'כמות'), self.m['measure_deps']['כמות שנתית']['columns'])

    def test_title_field_mismatch_is_visible(self):
        # המפה מציגה כותרת ושדה זה-לצד-זה: vis004 "כמות שנתית" ← כמות חודשית
        v4 = [v for v in self.m['pages'][1]['visuals'] if v['id'] == 'vis004'][0]
        self.assertEqual(v4['title'], 'כמות שנתית')
        self.assertEqual(v4['fields'][0]['property'], 'כמות חודשית')

    def test_broken_ref_detected(self):
        locs = [(u['location'], u['entity'], u['property']) for u in self.m['unresolved_refs']]
        self.assertIn(('page001/vis002:Values', 'dimמוצרים', 'שם מוצר'), locs)

    def test_unused_measures_and_columns(self):
        for mn in ('אשתקד', 'סכום ללא הגנה', 'אחוז מהמלאי -מתחת למינ\''):
            self.assertIn(mn, self.m['unused_measures'])
        self.assertNotIn('כמות שנתית', self.m['unused_measures'])
        self.assertIn('dimמוצרים[שם]', self.m['unused_columns'])
        # Year בשימוש ע"י vis003 (ציר Category אחרי יישור ה-fixture לצורת ייצוא אמיתית)
        self.assertNotIn('dimתאריך[Year]', self.m['unused_columns'])
        # עמודה שנשאבת ע"י מדד בשימוש אינה יתומה
        self.assertNotIn('factמכירות[כמות]', self.m['unused_columns'])

    def test_relationships_structured(self):
        rels = {r['name']: r for r in self.m['model']['relationships']}
        self.assertTrue(rels['r1']['both'])
        self.assertFalse(rels['r2']['both'])
        self.assertEqual(rels['r1']['from'], 'factמכירות.תאריך')

    def test_auto_date_tables_skipped(self):
        self.assertEqual(self.m['model']['auto_tables'], ['LocalDateTable_9f8.tmdl'])
        names = [t['name'] for t in self.m['model']['tables']]
        self.assertNotIn('LocalDateTable_9f8', names)

    def test_measure_attributes(self):
        t = [t for t in self.m['model']['tables'] if t['name'] == 'factמכירות'][0]
        self.assertEqual(t['measures']['כמות שנתית']['format_string'], '"#,0"')
        self.assertIsNone(t['measures']['אשתקד']['format_string'])

    def test_render_text_compact_and_hebrew(self):
        txt = MAP.render_text(self.m)
        self.assertIn('מפת מבנה צולבת', txt)
        self.assertIn('vis004', txt)
        self.assertIn('דו-כיווני', txt)
        # קומפקטי: מעבר קריאה אחד גם על fixture קטן
        self.assertLess(len(txt), 8000)


class MapMeasureTotal(unittest.TestCase):
    """שדה סבב 2 #3: כותרת המפה ספרה 25 במקום 27 — מדדים שבשימוש עקיף בלבד
    (דרך מדד אחר, לא דרך ויזואל) נפלו בין uses ל-unused. הסהכ = כל המדדים."""

    def test_indirectly_used_measure_counted(self):
        import shutil, tempfile, re, glob as _g
        tmp = tempfile.mkdtemp(prefix='pbimap-')
        try:
            dst = os.path.join(tmp, 'P')
            shutil.copytree(FIX, dst)
            sm = os.path.join(dst, 'MiniReport.SemanticModel')
            rp = os.path.join(dst, 'MiniReport.Report')
            tmdl = None
            for dp, dn, fn in os.walk(os.path.join(sm, 'definition', 'tables')):
                for f in fn:
                    if f.endswith('.tmdl'):
                        tmdl = os.path.join(dp, f)
                        break
                if tmdl:
                    break
            with open(tmdl, 'a', encoding='utf-8') as fh:
                # BaseOnly — רק דרך DerivedUsed (עקיף); DerivedUsed — בוויזואל
                fh.write("\n\tmeasure BaseOnly = 42\n\tmeasure DerivedUsed = [BaseOnly] + 1\n")
            vis = _g.glob(os.path.join(rp, 'definition', 'pages', '*', 'visuals',
                                       '*', 'visual.json'))
            swapped = False
            for v in vis:
                txt = open(v, encoding='utf-8-sig').read()
                if 'כמות שנתית' in txt:
                    open(v, 'w', encoding='utf-8').write(txt.replace('כמות שנתית', 'DerivedUsed'))
                    swapped = True
            self.assertTrue(swapped, 'לא נמצא ויזואל עם כמות שנתית להחלפה')
            m = MAP.build_map(rp, sm)
            self.assertIn('DerivedUsed', m['measure_uses'])
            self.assertNotIn('BaseOnly', m['unused_measures'],
                             'מדד עקיף סומן כלא-בשימוש')
            self.assertNotIn('BaseOnly', m['measure_uses'],
                             'מדד עקיף אינו שימוש ישיר — זו בדיוק הנקודה')
            txt = MAP.render_text(m)
            head = txt.splitlines()[1]
            n = int(re.search(r'מדדים: (\d+)', head).group(1))
            self.assertEqual(n, m['measure_total'],
                             'הכותרת (%d) != סהכ המדדים (%d) — הבאג של #3' % (n, m['measure_total']))
        finally:
            shutil.rmtree(tmp, ignore_errors=True)


class MapMobile(unittest.TestCase):
    """מתכונת נייד (mobile.json, visualContainerMobileState) במפה — סבב 73.
    מקור: microsoft/powerbi-models (NOASSERTION, עובדות פורמט בלבד):
    IVisualLayout {x,y,z,width,height}, mobilePortraitLayout."""

    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        self.addCleanup(shutil.rmtree, self.tmp, True)
        for item in os.listdir(FIX):
            src = os.path.join(FIX, item)
            if os.path.isdir(src):
                shutil.copytree(src, os.path.join(self.tmp, item))
        self.rp = os.path.join(self.tmp, 'MiniReport.Report')
        self.sm = os.path.join(self.tmp, 'MiniReport.SemanticModel')
        v1 = os.path.join(self.rp, 'definition', 'pages', 'page001', 'visuals', 'vis001')
        with open(os.path.join(v1, 'mobile.json'), 'w', encoding='utf-8') as fh:
            json.dump({'$schema': 's',
                       'position': {'x': 8, 'y': 16, 'width': 300, 'height': 200,
                                    'z': 5, 'tabOrder': 3}}, fh)

    def test_mobile_position_read(self):
        m = MAP.build_map(self.rp, self.sm)
        v1 = [v for v in m['pages'][0]['visuals'] if v['id'] == 'vis001'][0]
        self.assertEqual(v1['mobile'], {'x': 8, 'y': 16, 'w': 300, 'h': 200, 'z': 5, 'tab': 3})
        v2 = [v for v in m['pages'][0]['visuals'] if v['id'] == 'vis002'][0]
        self.assertNotIn('mobile', v2)

    def test_mobile_coverage_line_in_render(self):
        m = MAP.build_map(self.rp, self.sm)
        txt = MAP.render_text(m)
        self.assertIn('נייד 1/', txt)

    def test_mobile_mode_sorts_by_tab_and_marks_missing(self):
        m = MAP.build_map(self.rp, self.sm)
        txt = MAP.render_text(m, mobile=True)
        self.assertIn('tab3 vis001', txt)
        self.assertIn('לא בנייד', txt)

    def test_broken_mobile_json_recorded_not_raised(self):
        v2 = os.path.join(self.rp, 'definition', 'pages', 'page001', 'visuals', 'vis002')
        with open(os.path.join(v2, 'mobile.json'), 'w', encoding='utf-8') as fh:
            fh.write('{broken')
        m = MAP.build_map(self.rp, self.sm)
        v = [v for v in m['pages'][0]['visuals'] if v['id'] == 'vis002'][0]
        self.assertIn('mobile_error', v)
        txt = MAP.render_text(m, mobile=True)
        self.assertIn('mobile.json שבור', txt)


class MapStructuralTraps(unittest.TestCase):
    """מלכודות שדורשות שינוי ב-fixture — עותק זמני, לא נוגעים במקור."""

    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        self.addCleanup(shutil.rmtree, self.tmp, True)
        for item in os.listdir(FIX):
            s = os.path.join(FIX, item)
            d = os.path.join(self.tmp, item)
            if os.path.isdir(s):
                shutil.copytree(s, d)
        self.rp = os.path.join(self.tmp, 'MiniReport.Report')
        self.sm = os.path.join(self.tmp, 'MiniReport.SemanticModel')

    def test_page_missing_from_pageorder(self):
        pj = os.path.join(self.rp, 'definition', 'pages', 'pages.json')
        with open(pj, 'w', encoding='utf-8') as fh:
            json.dump({'activePageName': 'page001', 'pageOrder': ['page001']}, fh)
        m = MAP.build_map(self.rp, self.sm)
        self.assertEqual(m['dirs_missing_from_order'], ['page002'])
        # הדף עדיין מופיע במפה (בסוף), עם הדגל
        self.assertEqual([p['id'] for p in m['pages']], ['page001', 'page002'])
        txt = MAP.render_text(m)
        self.assertIn('לא ב-pageOrder', txt)

    def test_orphan_table_detected(self):
        # ניתוק dimמוצרים: מוחקים את הקשר ואת הוויזואל שמשתמש בעמודות שלה
        with open(os.path.join(self.sm, 'definition', 'relationships.tmdl'),
                  'w', encoding='utf-8') as fh:
            fh.write('relationship r1\n\tfromColumn: factמכירות.תאריך\n\ttoColumn: dimתאריך.Date\n')
        shutil.rmtree(os.path.join(self.rp, 'definition', 'pages', 'page001', 'visuals', 'vis002'))
        m = MAP.build_map(self.rp, self.sm)
        self.assertIn('dimמוצרים', m['orphan_tables'])
        self.assertNotIn('factמכירות', m['orphan_tables'])

    def test_bookmark_without_file_and_targets(self):
        bm_dir = os.path.join(self.rp, 'definition', 'bookmarks')
        os.makedirs(bm_dir)
        with open(os.path.join(bm_dir, 'bookmarks.json'), 'w', encoding='utf-8') as fh:
            json.dump({'name': 'bookmarks', 'items': [
                {'name': 'bm1', 'displayName': 'מבט ראשי'},
                {'name': 'bm_missing', 'displayName': 'שבור'}]}, fh)
        with open(os.path.join(bm_dir, 'bm1.bookmark.json'), 'w', encoding='utf-8') as fh:
            json.dump({'name': 'bm1', 'explorationState': {'activeSection': 'page001'},
                       'targetVisualNames': ['vis003']}, fh)
        m = MAP.build_map(self.rp, self.sm)
        bms = {b['id']: b for b in m['bookmarks']}
        self.assertEqual(bms['bm1']['pages'], ['page001'])
        self.assertEqual(bms['bm1']['visuals'], ['vis003'])
        self.assertIn('bm_missing', m['stale_bookmarks'])

    def test_json_mode_serializable(self):
        m = MAP.build_map(self.rp, self.sm)
        s = json.dumps(m, ensure_ascii=False)
        back = json.loads(s)
        self.assertEqual(back['active_page'], 'page001')

    def test_map_without_model_no_false_broken(self):
        # בלי מודל אין הצלבה — אסור לסמן "שבור" על דעת עצמו
        m = MAP.build_map(self.rp, None)
        self.assertEqual(m['unresolved_refs'], [])
        self.assertIsNone(m['model'])


if __name__ == '__main__':
    unittest.main(verbosity=2)
