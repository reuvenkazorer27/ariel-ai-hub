---
name: powerbi-design-search
description: >
  מנוע חיפוש (BM25) על מאגר ידע עיצובי ל-Power BI — פלטות צבע, כרטיסי KPI, סוגי גרפים עם מיפוי
  PBIR visualType, דפוסי פריסה עם מיקומי פיקסלים, תבניות DAX, סגנונות פורמט, תבניות PBIR JSON,
  והנחיות UX. מחזיר את הרשומות המדויקות ביותר עם ערכים מוכנים להעתקה. Use this skill to look up a
  color palette, choose a chart type, get a DAX pattern, find a PBIR/visual.json template, a layout
  with pixel positions, KPI card design, formatting preset, or a UX guideline for Power BI — or when
  the reviewer/builder skills need a concrete, sourced design recommendation.
metadata:
  version: "1.3.0"
  author: "Ruby"
  language: "he"
---

> ⛔ **גבול קשיח**: הסקיל קורא **רק** את קובצי ה-CSV שבתוך `data/` של הערכה — וזו
> קריאה בלבד. אין לו סיבה לגשת לקבצים של המשתמש, ואין לכתוב לשום מקום.
> ראה `../powerbi-report-reviewer/references/scope-and-safety.md`.

# חיפוש ידע עיצובי ל-Power BI (BM25)

מנוע חיפוש מדורג על 8 מאגרי CSV מובנים. במקום לקרוא קטלוג שלם — שלח שאילתה וקבל את הרשומות
הרלוונטיות ביותר עם השדות המדויקים (hex, `visualType`, format string, מיקומי פיקסלים, נוסחת DAX,
"מתי להשתמש", "מלכודות"). Python בלבד (stdlib), בלי תלויות.

## איך מריצים — מסלול ראשי (יש Python)

```bash
python3 "${CLAUDE_PLUGIN_ROOT}/skills/powerbi-design-search/scripts/search.py" "<query>" --domain <domain> -n <max>
```

- אם `${CLAUDE_PLUGIN_ROOT}` לא זמין, השתמש בנתיב היחסי לתיקיית ה-skill הזה: `scripts/search.py`.
  ה-CSV נמצאים ב-`data/` לצד הסקריפט וה-path נפתר יחסית לקובץ, כך שאפשר להריץ מכל cwd.
- ב-Windows השתמש ב-`python` במקום `python3`.
- בלי `--domain` — המנוע מזהה תחום אוטומטית מהשאילתה.

## ★ מסלול נפילה — אין Python (עבוד ישירות מול ה-CSV)

אם `python`/`python3` לא זמין (בדוק: `python3 --version || python --version`) — **אל תיכשל**. הנתונים
הם אותם קובצי CSV, קטנים וקריאים. פשוט **קרא את קובץ ה-CSV של התחום ישירות** (Read/‏`cat`) ובצע את
"החיפוש" בעצמך: פצל לשורות, השווה את מילות השאילתה מול עמודת `Keywords` (וגם שם/תיאור), בחר את
1–3 השורות עם ההתאמה הטובה ביותר, והחזר את השדות המדויקים (hex/visualType/נוסחה/מיקומים) בדיוק כמו
שהמנוע היה מחזיר. זה נותן את אותה תוצאה בלי Python.

## התחומים — `--domain` וקובץ ה-CSV (למסלול הנפילה)

| domain | קובץ (`data/…`) | מה מחזיר | שדות מפתח |
|--------|-----------------|----------|-----------|
| `color` | `color-palettes.csv` | 19 פלטות לפי נושא/תעשייה | Primary/Accent/Background + KPI Positive/Negative (hex) |
| `chart` | `chart-types.csv` | 34 סוגי גרפים (כולל 9 טכניקות SVG + 10 דפוסי native מהקהילה) | **PBIR Visual Type**, Best For, When NOT to Use |
| `kpi` | `kpi-cards.csv` | 8 דפוסי כרטיסי KPI | Layout, DAX, סגנון |
| `layout` | `layout-patterns.csv` | 8 דפוסי פריסה | מיקומי פיקסלים (x/y/width/height) |
| `dax` | `dax-patterns.csv` | 16 תבניות DAX | נוסחה, Format String, מלכודות נפוצות |
| `formatting` | `formatting-styles.csv` | 8 presets פורמט | גופנים, מסגרות, צללים |
| `template` | `pbir-templates.csv` | 32 תבניות PBIR (6 עם **JSON מלא** ב-`pbir-templates-full/`: actionButton, slicer, pageNavigator, cardVisual, tableEx, עמוד drill-through — כולן גזורות מייצוא Desktop מאומת) | מבנה `visual.json` להעתקה |
| `ux` | `ux-guidelines.csv` | 18 הנחיות UX | Do/Don't + Severity |

## תבניות JSON מלאות (`pbir-templates-full/`)

שש תבניות הדגל (דוח שדה סבב 3 #7) קיימות כ-**JSON שלם ומאומת** תחת
`data/pbir-templates-full/` — מועתקות כמות שהן ל-`visuals/<שם>/visual.json`, מחליפים
פלייסהולדרי `<...>`, ומאמתים ב-Desktop. ה-CSV מצביע אליהן מהעמודה Notes.
**אין בתיקייה אף מאפיין שלא נצפה בדונור אמיתי** (רשימת הדונורים והפרטים הקריטיים —
ב-README של התיקייה). כשאין דונור — לא ממציאים: מחפשים בקורפוס, ואם אין, אומרים שלא מאומת.

## מתי להשתמש — לפי סקיל

**עם הסוקר (`powerbi-report-reviewer`)** — לבסס המלצות בנתונים, לא בכללי אצבע:
- סעיף צבעים → `--domain color` לפי נושא הדוח (למשל "inventory logistics").
- פער ויזואל → `--domain chart` כדי לקבל את ה-`visualType` המדויק.
- פריסה/נגישות → `--domain ux` כשכבת צ'קליסט עם דירוג חומרה.
- בדיקת DAX → `--domain dax` להשוואה מול תבניות ומלכודות.
- כרטיסי KPI/פורמט → `--domain kpi` / `--domain formatting`.

**עם הבונה** (בברנץ' `full-agent`, `powerbi-pbip-builder` — לא נכלל ב-`main`) — הרווח הגדול בזמן בנייה:
- **`--domain template`** → שלוף תבנית PBIR עובדת לסוג הוויזואל שאתה מוסיף, ואז clone-and-modify
  (תומך ישירות ב-clone-never-construct).
- `--domain layout` → מקם ויזואלים על רשת אמיתית (x/y/width/height) במקום לנחש.
- `--domain color`/`dax`/`chart`/`formatting` → ערכים מוכנים להחלה תוך כדי בנייה.

## הערות
- התוכן באנגלית — כשכותבים פלט למשתמש, תרגם/התאם לעברית ו-RTL (ראה `html-content-visual.md` בסוקר).
- **אפשר לשאול בעברית** — `search.py` מרחיב שאילתה עברית במילות מפתח אנגליות (מילון מובנה ב-
  `core.py`), וכשאין רמז לתחום הוא מחפש בכל התחומים וממזג במקום לנחש.
- זה מוסיף שכבת retrieval ממוקד — לא מחליף את קובצי ה-references, אלא משלים אותם בערכים מדויקים.
