# תבניות PBIR מלאות (JSON שלם, לא מטא-דאטה)

מקור הבעיה: דוח שדה סבב 3 (#7) — `pbir-templates.csv` נותן רשימת מפתחות אבל לא JSON מלא,
ולכן אי אפשר לשכפל ממנו ויזואל בלי ניחושים. כאן JSON מלא לכל תבנית, גזור מייצוא Desktop
אמיתי ומצומצם למינימום הדרוש. **כל מאפיין כאן אומת מול דונור אמיתי** — אין כאן ניחושים.

## איך משתמשים
1. מעתיקים את הקובץ ל-`visuals/<שם-חדש>/visual.json` תחת העמוד.
2. מחליפים את כל פלייסהולדרי `<...>` (טבלה/עמודה/מדד/שם-עמוד) בערכים מהמודל שלך.
3. `name` בקובץ חייב להיות זהה לשם התיקייה.
4. מריצים `pbi_validate` ואז פותחים ב-Desktop לפני מסירה (חוקיות מאפיינים לא נבדקת ע"י הכלים).

## תוכן ומקורות
| קובץ | ויזואל | דונור מאומת |
|---|---|---|
| action-button-navigate.json | actionButton עם מעבר עמוד | DAQ.Report (yasarkocyigit/powerbi-templates, MIT) |
| slicer-dropdown.json | slicer במצב Dropdown + selectAll | Revenue Opportunities (FabricTools/pbir-samples, MIT) |
| pagenavigator-horizontal.json | pageNavigator אופקי | DAQ.Report (yasarkocyigit/powerbi-templates, MIT) |
| cardvisual-2measures.json | cardVisual עם 2 מדדים | AdventureWorks Sales (FabricTools/pbir-samples, MIT) |
| tableex-basic.json | tableEx עם מיון ושם תצוגה | Regional Sales Sample (FabricTools/pbir-samples, MIT) |
| page-drillthrough.json | page.json של עמוד drill-through | Store Sales (FabricTools/pbir-samples, MIT) |

## פרטים קריטיים שנצפו בדונורים (לא לנחש!)
- **pageNavigator**: כיוון נשלט ב-`objects.layout.orientation` כמספר-enum — `"0D"` = אופקי
  (היחיד שנצפה בקורפוס; לאומת ב-Desktop עבור אנכי). **לא** `objects.grid` ו**לא** מחרוזת
  `'Vertical'` (שניהם ניחושים שנכשלו בשקט בשדה). `rowCount`/`columnCount`/`cellPadding` באותו אובייקט.
  הסתרת עמוד ספציפי: רשומת `pages` עם `selector.id = <שם-מכונה של העמוד>` + `showPage: false`.
- **actionButton מעבר עמוד**: `visualContainerObjects.visualLink` עם `type: 'PageNavigation'`
  ו-`navigationSection: '<שם-מכונה של עמוד היעד>'` (שם מכונה, לא displayName).
- **cardVisual רב-מדדי**: הקרנות תחת `queryState.Data`; צבע per-מדד דרך
  `objects.value[].properties.fontColor` עם `selector: {metadata: '<טבלה>.<מדד>'}`.
- **עמוד drill-through**: גם `filterConfig.filters` עם `howCreated: 'Drillthrough'` וגם
  `pageBinding` עם `type: 'Drillthrough'` + `parameters[].boundFilter` שמצביע לשם הפילטר.
  העמוד מסומן `visibility: 'HiddenInViewMode'`.
- slicer היררכי (Date.Fiscal.Year/Month עם expansionStates) קיים בדונור
  `AdventureWorks Sales.Report` ב-pbir-samples — העתק משם אם צריך היררכיה.
