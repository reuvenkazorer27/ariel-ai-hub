#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Power BI Analytics Pro Max Search - BM25 search engine for Power BI dashboard design
Usage: python search.py "<query>" [--domain <domain>] [--max-results 3]

Domains: color, kpi, chart, layout, dax, formatting, template, ux
"""

import argparse
import sys
import io
from core import CSV_CONFIG, MAX_RESULTS, search

if sys.stdout.encoding and sys.stdout.encoding.lower() != 'utf-8':
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
if sys.stderr.encoding and sys.stderr.encoding.lower() != 'utf-8':
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8')

TRUNCATE_AT = 400


def format_output(result):
    if "error" in result:
        return f"Error: {result['error']}"

    output = []
    output.append("## Power BI Analytics Pro Max Results")
    domain_note = result['domain']
    if result.get("auto_detected"):
        domain_note += " (auto-detected)"
    output.append(f"**Domain:** {domain_note} | **Query:** {result['query']}")
    output.append("")

    if not result.get("results"):
        output.append("No matching results found.")
        return "\n".join(output)

    for i, item in enumerate(result["results"], 1):
        score = item.pop("_score", 0)
        first_key = list(item.keys())[0]
        output.append(f"### Result {i} — {item[first_key]} (score: {score})")
        for key, value in item.items():
            if key == first_key:
                continue
            display = value if len(value) <= TRUNCATE_AT else value[:TRUNCATE_AT] + "..."
            output.append(f"- **{key}:** {display}")
        output.append("")

    return "\n".join(output)


def main():
    parser = argparse.ArgumentParser(description="Power BI Analytics Pro Max Search")
    parser.add_argument("query", help="Search query")
    parser.add_argument("--domain", "-d", choices=list(CSV_CONFIG.keys()),
                        help=f"Search domain: {', '.join(CSV_CONFIG.keys())}")
    parser.add_argument("--max-results", "-n", type=int, default=MAX_RESULTS,
                        help=f"Maximum results (default: {MAX_RESULTS})")

    args = parser.parse_args()
    result = search(args.query, domain=args.domain, max_results=args.max_results)
    print(format_output(result))


if __name__ == "__main__":
    main()
