#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Power BI Analytics Pro Max Core - BM25 search engine for Power BI design guides
"""

import csv
import re
from pathlib import Path
from math import log
from collections import defaultdict

DATA_DIR = Path(__file__).parent.parent / "data"
MAX_RESULTS = 3

CSV_CONFIG = {
    "color": {
        "file": "color-palettes.csv",
        "search_cols": ["Dashboard Type", "Keywords", "Notes"],
        "output_cols": ["Dashboard Type", "Primary", "Secondary", "Accent", "Background", "Card", "Foreground", "Muted", "Muted Foreground", "Border", "Success", "Warning", "Destructive", "KPI Positive", "KPI Negative", "Notes"]
    },
    "kpi": {
        "file": "kpi-cards.csv",
        "search_cols": ["Card Style", "Keywords", "Best For", "Layout"],
        "output_cols": ["Card Style", "Keywords", "Layout", "Accent Position", "Value Font Size", "Value Font Weight", "Value Color", "Label Font Size", "Label Color", "Background", "Border", "Border Radius", "Shadow", "Best For", "DAX Pattern", "PBIR Visual Type", "Notes"]
    },
    "chart": {
        "file": "chart-types.csv",
        "search_cols": ["Chart Type", "Keywords", "Best For", "When NOT to Use", "PBIR Visual Type"],
        "output_cols": ["Chart Type", "PBIR Visual Type", "Keywords", "Best For", "When NOT to Use", "Category Role", "Value Role", "Series Role", "Max Categories", "Color Strategy", "Label Position", "Sort Recommendation", "Accessibility Notes", "DAX Considerations", "Notes"]
    },
    "layout": {
        "file": "layout-patterns.csv",
        "search_cols": ["Layout Name", "Keywords", "Best For"],
        "output_cols": ["Layout Name", "Keywords", "Canvas Size", "Header Height", "KPI Row Y", "KPI Row Height", "Chart Row 1 Y", "Chart Row 1 Height", "Chart Row 2 Y", "Chart Row 2 Height", "Margin", "Gap", "KPI Count", "Charts Count", "Grid Columns", "Best For", "Notes"]
    },
    "dax": {
        "file": "dax-patterns.csv",
        "search_cols": ["Pattern Name", "Keywords", "Category", "Description", "When to Use"],
        "output_cols": ["Pattern Name", "Keywords", "Category", "DAX Formula", "Format String", "Description", "When to Use", "Common Pitfalls", "Related Measures", "Notes"]
    },
    "formatting": {
        "file": "formatting-styles.csv",
        "search_cols": ["Style Name", "Keywords", "Visual Types"],
        "output_cols": ["Style Name", "Keywords", "Visual Types", "Background Color", "Border Color", "Border Radius", "Border Width", "Shadow", "Title Font Size", "Title Font Weight", "Title Color", "Label Font Size", "Label Color", "Axis Label Color", "Gridline Color", "Value Font Size", "Value Color", "Padding", "Notes"]
    },
    "template": {
        "file": "pbir-templates.csv",
        "search_cols": ["Template Name", "Keywords", "Visual Type"],
        "output_cols": ["Template Name", "Keywords", "Visual Type", "PBIR Schema Version", "Position Example", "Query Pattern", "Objects Keys", "VCO Keys", "Selector Type", "Sort", "Notes"]
    },
    "ux": {
        "file": "ux-guidelines.csv",
        "search_cols": ["Category", "Guideline", "Keywords"],
        "output_cols": ["Category", "Guideline", "Keywords", "Do", "Don't", "Severity", "Applies To", "Notes"]
    }
}

DOMAIN_KEYWORDS = {
    "color": ["color", "palette", "theme", "scheme", "dark mode", "light mode", "primary", "accent", "background"],
    "kpi": ["kpi", "card", "metric", "indicator", "scorecard", "value", "measure display"],
    "chart": ["chart", "bar", "column", "line", "donut", "pie", "scatter", "treemap", "waterfall", "visual type", "graph"],
    "layout": ["layout", "grid", "position", "placement", "arrange", "canvas", "spacing", "margin", "responsive"],
    "dax": ["dax", "measure", "calculate", "formula", "aggregation", "time intelligence", "filter context", "averagex"],
    "formatting": ["format", "style", "font", "border", "shadow", "radius", "padding", "container", "appearance"],
    "template": ["template", "pbir", "json", "schema", "visual.json", "query", "projection", "role", "selector"],
    "ux": ["ux", "guideline", "best practice", "accessibility", "usability", "navigation", "interaction", "do dont"]
}


def tokenize(text):
    return re.findall(r'\w+', text.lower())


def build_index(rows, search_cols):
    index = defaultdict(lambda: defaultdict(int))
    doc_lengths = []
    for i, row in enumerate(rows):
        text = " ".join(row.get(col, "") for col in search_cols)
        tokens = tokenize(text)
        doc_lengths.append(len(tokens))
        for token in tokens:
            index[token][i] += 1
    return index, doc_lengths


def bm25_score(query_tokens, index, doc_lengths, k1=1.5, b=0.75):
    n = len(doc_lengths)
    if n == 0:
        return []
    avg_dl = sum(doc_lengths) / n
    scores = [0.0] * n
    for token in query_tokens:
        if token not in index:
            continue
        df = len(index[token])
        idf = log((n - df + 0.5) / (df + 0.5) + 1)
        for doc_id, tf in index[token].items():
            dl = doc_lengths[doc_id]
            tf_norm = (tf * (k1 + 1)) / (tf + k1 * (1 - b + b * dl / avg_dl))
            scores[doc_id] += idf * tf_norm
    return scores


# גשר עברית→אנגלית: הסוכן והמשתמש חושבים בעברית, אבל מאגר ה-CSV באנגלית.
# מילון קטן שמרחיב את השאילתה במילות מפתח אנגליות לפני ה-tokenize, כדי שה-BM25
# ימצא התאמות גם על שאילתה עברית טהורה (למשל "פלטת צבע" → color palette).
HEBREW_HINTS = {
    "צבע": "color", "פלטה": "color palette", "פלטת": "color palette",
    "ערכת נושא": "theme color", "רקע": "background",
    "כרטיס": "kpi card", "מדד": "dax measure",
    "גרף": "chart", "עמודות": "bar column chart", "מוטות": "bar chart",
    "עוגה": "pie donut chart", "מפה": "map", "מפל": "waterfall chart",
    "פריסה": "layout grid", "מיקום": "layout position", "רשת": "layout grid",
    "פורמט": "format style", "עיצוב": "formatting style", "גופן": "format font",
    "תבנית": "template pbir", "וויזואל": "template visual",
    "ניווט": "ux navigation", "נגישות": "ux accessibility", "ניגודיות": "ux contrast",
    "חילוק": "divide ratio safe", "אחוז": "percentage ratio divide",
    "אשתקד": "prior year time intelligence", "שנה שעברה": "prior year",
    "כותרת דינמית": "dynamic title", "סליסר": "ux slicer filter",
}


def expand_query(query):
    """מחזיר את השאילתה + מילות המפתח האנגליות המתאימות לה."""
    extra = []
    for he, en in HEBREW_HINTS.items():
        if he in query and en not in query:
            extra.append(en)
    return query + (" " + " ".join(extra) if extra else "")


def detect_domain(query):
    query_lower = query.lower()
    scores = {}
    for domain, keywords in DOMAIN_KEYWORDS.items():
        score = sum(1 for kw in keywords if kw in query_lower)
        if score > 0:
            scores[domain] = score
    if not scores:
        return None   # אין רמז לתחום — החזר None כדי לחפש בכל התחומים
    sorted_domains = sorted(scores.items(), key=lambda x: -x[1])
    return sorted_domains[0][0]


def search(query, domain=None, max_results=MAX_RESULTS):
    query = expand_query(query)
    if not domain:
        domain = detect_domain(query)
        auto_detected = True
    else:
        auto_detected = False

    if domain is None:
        # אין רמז לתחום — חפש בכולם ומזג את התוצאות הטובות (במקום לנחש "chart").
        merged = []
        for dom in CSV_CONFIG:
            r = search(query, domain=dom, max_results=max_results)
            for item in r.get("results", []):
                item["_domain"] = dom
                merged.append(item)
        merged.sort(key=lambda x: -x.get("_score", 0))
        return {"domain": "all", "query": query, "auto_detected": True,
                "results": merged[:max_results],
                "message": "No domain matched - searched all domains."}

    if domain not in CSV_CONFIG:
        return {"error": f"Unknown domain: {domain}. Available: {', '.join(CSV_CONFIG.keys())}"}

    config = CSV_CONFIG[domain]
    csv_path = DATA_DIR / config["file"]

    if not csv_path.exists():
        return {"error": f"Data file not found: {csv_path}"}

    with open(csv_path, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        rows = list(reader)

    if not rows:
        return {"error": f"No data in {config['file']}"}

    index, doc_lengths = build_index(rows, config["search_cols"])
    query_tokens = tokenize(query)
    scores = bm25_score(query_tokens, index, doc_lengths)

    ranked = sorted(enumerate(scores), key=lambda x: -x[1])
    top = [(i, s) for i, s in ranked[:max_results] if s > 0]

    if not top:
        return {"domain": domain, "query": query, "auto_detected": auto_detected, "results": [], "message": "No results found."}

    results = []
    for i, score in top:
        row = rows[i]
        result = {col: row.get(col, "") for col in config["output_cols"] if row.get(col, "")}
        result["_score"] = round(score, 2)
        results.append(result)

    return {"domain": domain, "query": query, "auto_detected": auto_detected, "results": results}
