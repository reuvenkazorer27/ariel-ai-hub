#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ניתוח מודל PBIP אופליין (כתוב מחדש, ללא תלויות) — לסוקר Power BI.
מה הוא מוצא:
  • מדדים / עמודות / טבלאות שאף אחד לא משתמש בהם ("יתומים").
  • מפת תלויות: איזה מדד מפנה לאילו מדדים/עמודות.
קורא TMDL לפי הזחה (לא regex גס) וסורק זהויות DAX במדויק.
שימוש:  python pbi_analyze.py "<path-to-.SemanticModel>" "<path-to-.Report>"
בלי ארגומנטים — מחפש תיקיות *.SemanticModel ו-*.Report מתחת ל-cwd.
Python stdlib בלבד.
"""
import os, re, sys, glob, json

# ---- סריקת זהויות DAX (מדויקת, מתעלמת מהערות/מחרוזות) ----
_CMT_BLOCK = re.compile(r"/\*.*?\*/", re.S)
_CMT_LINE = re.compile(r"//[^\n]*")
_STR = re.compile(r'"(?:[^"]|"")*"')
_Q_QUOTED = re.compile(r"'(?P<t>[^']+)'\s*\[(?P<f>[^\]]+)\]")     # 'טבלה'[שדה]
_Q_BARE = re.compile(r"(?<![\w'\]])(?P<t>[A-Za-z_֐-׿]\w*)\[(?P<f>[^\]]+)\]")  # טבלה[שדה]
_BARE = re.compile(r"(?<![\w'\]])\[(?P<f>[^\]]+)\]")              # [מדד/עמודה]

def strip_noise(dax):
    dax = _CMT_BLOCK.sub(" ", dax or "")
    dax = _CMT_LINE.sub(" ", dax)
    return _STR.sub('""', dax)

def dax_refs(dax):
    t = strip_noise(dax)
    qualified = set()
    for m in _Q_QUOTED.finditer(t): qualified.add((m.group("t").strip(), m.group("f").strip()))
    for m in _Q_BARE.finditer(t):   qualified.add((m.group("t").strip(), m.group("f").strip()))
    bare = {m.group("f").strip() for m in _BARE.finditer(t)}
    return qualified, bare

# ---- קריאת TMDL לפי הזחה ----
def indent(line): return len(line) - len(line.lstrip("\t "))

# שם אובייקט ב-TMDL: מזהה חשוף, או עטוף בגרשים שבתוכם גרש נכתב פעמיים (known-issues §12).
# strip("'") תמים חותך גרש סופי שהוא חלק מהשם — לכן קוראים בתבנית ומחליפים גרש-כפול בגרש.
_TMDL_NAME = re.compile(r"^(?:table|column|measure)\s+(?:'((?:[^']|'')+)'|([^\s=']+))")

def tmdl_name(line):
    m = _TMDL_NAME.match(line.strip())
    if not m:
        return None
    return (m.group(1) or m.group(2) or "").replace("''", "'").strip()


def read_tmdl_table(path):
    """מחזיר {name, columns:[...], measures:{name:expr}}"""
    lines = open(path, encoding="utf-8-sig", errors="ignore").read().splitlines()
    name, cols, meas = None, [], {}
    i = 0
    while i < len(lines):
        ln = lines[i]; s = ln.strip()
        if name is None and s.startswith("table "):
            name = tmdl_name(s)
        elif s.startswith("column "):
            cols.append(tmdl_name(s))
        elif s.startswith("measure "):
            body = s[8:]
            mname = tmdl_name(s)
            base = indent(ln)
            expr = body.split("=",1)[1] if "=" in body else ""
            # אסוף שורות המשך (הזחה עמוקה יותר) — כולל בלוקי ```
            j = i + 1
            while j < len(lines):
                nx = lines[j]
                if nx.strip() and indent(nx) <= base and not nx.strip().startswith(("///","```")):
                    break
                expr += "\n" + nx
                j += 1
            meas[mname] = expr
            i = j; continue
        i += 1
    if name is None:
        name = os.path.splitext(os.path.basename(path))[0]
    return {"name": name, "columns": cols, "measures": meas}

def read_tmdl_table_full(path):
    """גרסה עשירה של read_tmdl_table — הבית המשותף לקוראי TMDL (במקום קורא שלישי):
    columns ← [{name, hidden}], measures ← {name: {expr, format_string,
    display_folder, hidden}}. read_tmdl_table נשאר בדיוק כפי שהוא לצרכיו הקיימים."""
    lines = open(path, encoding="utf-8-sig", errors="ignore").read().splitlines()
    name, cols, meas = None, [], {}
    _ATTR = re.compile(r"^\s*(formatString|displayFolder|lineageTag)\s*:")
    i = 0
    while i < len(lines):
        ln = lines[i]; s = ln.strip()
        if name is None and s.startswith("table "):
            name = tmdl_name(s)
        elif s.startswith("column "):
            cname = tmdl_name(s)
            base = indent(ln)
            hidden = False
            j = i + 1
            while j < len(lines):
                nx = lines[j]
                if nx.strip() and indent(nx) <= base and not nx.strip().startswith(("///", "```")):
                    break
                if nx.strip() == "isHidden":
                    hidden = True
                j += 1
            cols.append({"name": cname, "hidden": hidden})
            i = j; continue
        elif s.startswith("measure "):
            mname = tmdl_name(s)
            base = indent(ln)
            body = s.split("=", 1)[1] if "=" in s else ""
            j = i + 1
            cont = []
            while j < len(lines):
                nx = lines[j]
                if nx.strip() and indent(nx) <= base and not nx.strip().startswith(("///", "```")):
                    break
                cont.append(nx)
                j += 1
            block = "\n".join([body] + cont)
            fmt = re.search(r"^\s*formatString:\s*(.+)$", block, re.M)
            folder = re.search(r"^\s*displayFolder:\s*(.+)$", block, re.M)
            hidden = any(l.strip() == "isHidden" for l in cont)
            expr_lines = [body] + [l for l in cont
                                   if not _ATTR.match(l) and l.strip() != "isHidden"]
            meas[mname] = {"expr": "\n".join(expr_lines).strip(),
                           "format_string": (fmt.group(1).strip() if fmt else None),
                           "display_folder": (folder.group(1).strip() if folder else None),
                           "hidden": hidden}
            i = j; continue
        i += 1
    if name is None:
        name = os.path.splitext(os.path.basename(path))[0]
    return {"name": name, "columns": cols, "measures": meas}

def parse_relationships(sm_dir):
    """קשרים מובנים מ-relationships.tmdl: [{name, from, to, active, both,
    from_card, to_card}]. אותה לוגיקה כמו ב-pbi_check._read_relationships —
    נכתבה כאן כבית משותף לקוראים (pbi_check נשאר עצמאי כפי שהוא)."""
    rels = []
    rf = os.path.join(sm_dir, "definition", "relationships.tmdl")
    if not os.path.exists(rf):
        return rels
    txt = open(rf, encoding="utf-8-sig", errors="ignore").read()
    for blk in re.split(r"\n(?=relationship )", txt):
        if not blk.strip().startswith("relationship"):
            continue
        def _p(prop, _blk=blk):
            m = re.search(r"^\s*" + prop + r":\s*(.+)$", _blk, re.M)
            return m.group(1).strip() if m else ""
        fc, tc = _p("fromColumn"), _p("toColumn")
        if not (fc and tc):
            continue
        first = blk.strip().split("\n")[0].split(None, 1)
        rname = first[1].strip() if len(first) > 1 else ""
        if rname.startswith("'"):
            m2 = re.match(r"^'((?:[^']|'')+)'", rname)
            if m2:
                rname = m2.group(1).replace("''", "'")
        rels.append({
            "name": rname,
            "from": fc, "to": tc,
            "active": _p("isActive").lower() != "false",
            "both": "bothDirections" in _p("crossFilteringBehavior"),
            "from_card": (_p("fromCardinality") or "many").lower(),
            "to_card": (_p("toCardinality") or "one").lower(),
        })
    return rels

def load_model(sm_dir):
    tdir = os.path.join(sm_dir, "definition", "tables")
    tables = []
    for f in sorted(glob.glob(os.path.join(tdir, "*.tmdl"))):
        b = os.path.basename(f)
        if b.startswith(("LocalDateTable", "DateTableTemplate")): continue
        tables.append(read_tmdl_table(f))
    # קשרים
    rel_cols = set()
    rels_raw = ""
    rf = os.path.join(sm_dir, "definition", "relationships.tmdl")
    if os.path.exists(rf):
        rels_raw = open(rf, encoding="utf-8-sig", errors="ignore").read()
        for m in re.finditer(r"(from|to)Column:\s*(.+)", rels_raw):
            ref = m.group(2).strip()
            if "." in ref:
                t, c = ref.rsplit(".", 1)
                rel_cols.add((t.strip().strip("'"), c.strip().strip("'")))
    return tables, rel_cols, rels_raw

# ---- מה הדוח (PBIR) משתמש בו ----
def report_refs(report_dir):
    names = set()
    for f in glob.glob(os.path.join(report_dir, "definition", "pages", "*", "visuals", "*", "visual.json")):
        txt = open(f, encoding="utf-8-sig", errors="ignore").read()
        for m in re.finditer(r'"(?:Property|nativeQueryRef|displayName)"\s*:\s*"([^"]+)"', txt):
            names.add(m.group(1).strip())
    return names


# ---- בדיקות מודל דטרמיניסטיות (צ'קליסט §3/§4) ----
_BARE_DIV = re.compile(r"(?<![/*&|:=<>])(/)(?![/*=])")

def model_checks(tables, rels_raw):
    """דגלים דטרמיניסטיים על המודל — הסקריפט מסמן מועמדים, הסוכן מנסח ממצאים.
    מבוסס על אותם כללים כתובים בצ'קליסט (§3 קשרים דו-כיווניים, §4 חלוקה/אשתקד/פורמט)."""
    both_dir = [blk.splitlines()[0].strip()
                for blk in re.split(r"\n(?=relationship )", rels_raw or "")
                if "bothDirections" in blk]
    div, spl, nofmt = [], [], []
    for t in tables:
        for mn, expr in t["measures"].items():
            clean = strip_noise(expr)
            if _BARE_DIV.search(clean):
                div.append(mn)
            if "SAMEPERIODLASTYEAR" in clean.upper() and "ISBLANK" not in clean.upper():
                spl.append(mn)
            if "formatString:" not in expr:
                nofmt.append(mn)
    return {"both_dir": both_dir, "raw_division": div, "spl_unguarded": spl,
            "no_format": nofmt}

def main():
    args = [a for a in sys.argv[1:]]
    as_json = "--json" in args
    args = [a for a in args if a != "--json"]
    sm = next((a for a in args if a.endswith(".SemanticModel")), None)
    rp = next((a for a in args if a.endswith(".Report")), None)
    if not sm:
        c = glob.glob("**/*.SemanticModel", recursive=True) or \
            glob.glob("**/*.Dataset", recursive=True)  # סבב 88: סיומת ישנה
        sm = c[0] if c else None
    if not rp:
        c = glob.glob("**/*.Report", recursive=True); rp = c[0] if c else None
    if not sm:
        print("לא נמצאה תיקיית *.SemanticModel"); return
    tables, rel_cols, rels_raw = load_model(sm)
    used_names = report_refs(rp) if rp else set()

    all_measures = {}
    for t in tables:
        for mn, expr in t["measures"].items(): all_measures[mn] = (t["name"], expr)
    all_columns = {(t["name"], c) for t in tables for c in t["columns"]}

    # תלות מדדים
    dep = {}
    for mn, (tn, expr) in all_measures.items():
        q, b = dax_refs(expr)
        dep[mn] = {"measures": {x for x in b if x in all_measures and x != mn},
                   "columns": {c for c in q} | {("?", x) for x in b if x not in all_measures}}

    # מדדים בשימוש: מהדוח, או ע"י מדד בשימוש (fixpoint)
    used_meas = {m for m in all_measures if m in used_names}
    changed = True
    while changed:
        changed = False
        for mn in list(used_meas):
            for dm in dep.get(mn, {}).get("measures", ()):
                if dm not in used_meas: used_meas.add(dm); changed = True

    ref_by_meas_cols = set()
    for mn in used_meas:
        for c in dep[mn]["columns"]:
            ref_by_meas_cols.add(c)

    unused_meas = [m for m in all_measures if m not in used_meas]
    def col_used(t, c):
        if c in used_names: return True
        if (t, c) in rel_cols: return True
        for (rt, rc) in ref_by_meas_cols:
            if rc == c and (rt == t or rt == "?"): return True
        return False
    unused_cols = [(t, c) for (t, c) in all_columns if not col_used(t, c)]

    # טבלאות יתומות: אין עמודה/מדד בשימוש ולא בקשר
    def table_used(t):
        if any(m for m, (tn, _) in all_measures.items() if tn == t["name"] and m in used_meas): return True
        if any(col_used(t["name"], c) for c in t["columns"]): return True
        if any(rt == t["name"] for (rt, _) in rel_cols): return True
        return False
    orphan_tables = [t["name"] for t in tables if not table_used(t)]

    chk = model_checks(tables, rels_raw)

    # ---- פלט ----
    if as_json:
        # פלט מובנה לצריכה תכנותית (סוכן/CI) — אותם נתונים כמו הטקסט, בלי קיצורי תצוגה
        print(json.dumps({
            "report": rp, "model": sm,
            "counts": {"tables": len(tables), "measures": len(all_measures),
                       "columns": len(all_columns)},
            "report_refs_found": bool(used_names),
            "unused_measures": unused_meas,
            "unused_columns": ["%s[%s]" % (t, c) for t, c in unused_cols],
            "orphan_tables": orphan_tables,
            "model_checks": chk,
            "dependencies": {mn: sorted(dep[mn]["measures"]) for mn in sorted(dep)
                             if dep[mn]["measures"]},
        }, ensure_ascii=False, indent=1))
        return
    print("## ניתוח שדות לא-בשימוש + תלויות (§21)\n")
    print(f"טבלאות: {len(tables)} · מדדים: {len(all_measures)} · עמודות: {len(all_columns)}")
    if not used_names:
        print("⚠️ לא נמצאו הפניות בדוח (אין .Report?) — 'שימוש' מבוסס רק על תלות בין מדדים.\n")
    print(f"\n### מדדים לא-בשימוש ({len(unused_meas)}):")
    print("\n".join("  • " + m for m in unused_meas) or "  (אין)")
    print(f"\n### עמודות לא-בשימוש ({len(unused_cols)}):")
    print("\n".join(f"  • {t}[{c}]" for t, c in unused_cols[:60]) or "  (אין)")
    if len(unused_cols) > 60: print(f"  … ועוד {len(unused_cols)-60}")
    print(f"\n### טבלאות יתומות ({len(orphan_tables)}):")
    print("\n".join("  • " + t for t in orphan_tables) or "  (אין)")
    print("\n### בדיקות מודל דטרמיניסטיות (§3/§4 — מועמדים, הסוכן מנסח):")
    print(f"  • קשרים דו-כיווניים: {len(chk['both_dir'])}" +
          (f" ({'; '.join(chk['both_dir'][:10])})" if chk['both_dir'] else ""))
    print(f"  • מדדים עם חלוקה ב-'/' ולא DIVIDE (מחוץ למחרוזות/הערות): {len(chk['raw_division'])}")
    for m in chk["raw_division"][:15]: print(f"      - {m}")
    print(f"  • SAMEPERIODLASTYEAR ללא מגן ISBLANK: {len(chk['spl_unguarded'])}")
    for m in chk["spl_unguarded"][:15]: print(f"      - {m}")
    print(f"  • מדדים ללא formatString: {len(chk['no_format'])}")
    for m in chk["no_format"][:15]: print(f"      - {m}")
    print("\n### מפת תלויות (מדד → מדדים שהוא מפנה אליהם):")
    for mn in sorted(dep):
        deps = dep[mn]["measures"]
        if deps: print(f"  {mn} → {', '.join(sorted(deps))}")

if __name__ == "__main__":
    main()
