#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
pbi_doc.py — "תיק דוח": מסמך Word אחד לתיעוד דוח Power BI, בשני אזורים.

    ✍️  אזור אנושי  — רק בני אדם כותבים. הסקריפט לעולם לא דורס אותו, רק נושא אותו
                      קדימה מגרסה לגרסה (מטרה, קהל, בעלים, הגדרות עסקיות, מגבלות).
    🤖  אזור מכונתי — נוצר מחדש בכל הרצה מהמודל ומהדוח. אף אדם לא עורך אותו ידנית
                      (מדדים, נוסחאות, טבלאות, קשרים, תלויות, שדות לא-בשימוש).

זה מה שמונע מהתיעוד להתיישן בשקט: בכל הרצה הסקריפט משווה את המסמך הקודם למודל
בפועל ומדפיס **דוח סטייה** — מה נוסף, מה נמחק, איזו נוסחה השתנתה, ואילו מדדים עדיין
בלי הגדרה עסקית.

שימוש:
    python pbi_doc.py "<.Report>" "<.SemanticModel>" --out "תיק דוח - שם.docx"
    python pbi_doc.py ... --drift-only      # רק דוח סטייה, בלי לכתוב מסמך
    python pbi_doc.py ... --sync-model      # + כותב את ההגדרות העסקיות כ-description ל-TMDL

הקובץ הקודם (אם קיים ב---out) נקרא אוטומטית כדי לשמר את התוכן האנושי.
ללא תלויות חיצוניות — stdlib בלבד. ראה docx_rtl.py.
"""
import os, re, sys, json, glob, argparse, datetime, collections

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import docx_rtl as DX
from docx_rtl import Doc, read_tables

try:
    import pbi_extract as EX
except Exception:
    EX = None

SKIP_PREFIX = ('LocalDateTable_', 'DateTableTemplate_')

# ── השדות של האזור האנושי. (מפתח, תווית, רמז למילוי)
HUMAN_FIELDS = [
    ("owner",     "בעלים של הדוח",
     "מי אחראי על התוכן ועל ההגדרות.  לדוגמה: אבי לוי, מדור רישום"),
    ("contact",   "איש קשר לתקלות",
     "שם + טלפון/מייל.  לדוגמה: אבי לוי · שלוחה 4321"),
    ("dept",      "מחלקה / אגף",
     "היחידה שהדוח שייך לה.  לדוגמה: המנהל האקדמי — מדור רישום"),
    ("purpose",   "מטרת הדוח",
     "למה הוא קיים — במשפט או שניים.  לדוגמה: מעקב אחר סטטוס הסטודנטים בסמסטר "
     "— רישום, נשירה והצלחה בקורסים — לזיהוי מגמות לפני תום תקופת השינויים"),
    ("audience",  "קהל היעד",
     "מי משתמש בו בפועל.  לדוגמה: ראש המנהל האקדמי, רכזות המחלקות וראשי החוגים"),
    ("decisions", "אילו החלטות מתקבלות לפיו",
     "מה עושים אחרת בגלל המספרים.  לדוגמה: לאיזה קורס להקצות מתרגל נוסף, "
     "ולאיזו קבוצת סטודנטים לפנות לשיחת מנע"),
    ("sources",   "מקורות הנתונים",
     "מאיפה מגיעים הנתונים.  לדוגמה: מערכת מכלול (המערכת האקדמית) — "
     "טבלאות סטודנטים, הרשמות לקורסים וציונים"),
    ("refresh",   "תדירות רענון + Gateway",
     "מתי מתעדכן ודרך מה.  לדוגמה: כל לילה ב-02:00 מול מכלול, דרך Gateway ארגוני"),
    ("rls",       "הרשאות ו-RLS",
     "האם נדרש שמשתמשים יראו רק חלק מהנתונים.  לדוגמה: כל ראש חוג רואה רק את "
     "הסטודנטים של החוג שלו — או: לא נדרש, הדוח למנהל האקדמי בלבד"),
    ("limits",    "מגבלות ידועות",
     "מה הדוח *לא* מכסה.  לדוגמה: אינו כולל סטודנטים שהפסיקו לימודים לפני 2023, "
     "ואינו מכסה תלמידי חוץ ותוכניות בין-לאומיות"),
    ("qa",        "אישור בדיקה (QA)",
     "מי ווידא שהמספרים נכונים, מתי, ומול מה.  לדוגמה: מספר הסטודנטים הפעילים "
     "הושווה לדוח הרישום הרשמי ממכלול לסמסטר א׳, בתאריך 12.03.2026"),
    ("versions",  "איפה נשמרות גרסאות",
     "השיטה שבה שומרים עותקים.  לדוגמה: תיקיית \"גרסאות\" בשם+תאריך, "
     "מסונכרנת ל-OneDrive"),
]




MARK_HUMAN = "אזור אנושי — למילוי ידני"
MARK_MACHINE = "אזור מכונתי — נוצר אוטומטית"


# ── קריאת המודל ──────────────────────────────────────────────────────
def read_model(model_dir):
    tables, measures = [], []
    roles_in_tables = []
    tdir = os.path.join(model_dir, 'definition', 'tables')
    for f in sorted(glob.glob(os.path.join(tdir, '*.tmdl'))):
        base = os.path.basename(f)
        if base.startswith(SKIP_PREFIX):
            continue
        txt = open(f, encoding='utf-8-sig').read()
        tname = base[:-5]
        m = re.match(r"\s*table\s+(?:'((?:[^']|'')+)'|(\S+))", txt)
        if m:
            tname = (m.group(1) or m.group(2)).replace("''", "'").strip()
        cols = [(a or b).replace("''", "'") for a, b in
                re.findall(r"^\s*column\s+(?:'((?:[^']|'')+)'|([^\s'\n]+))\s*$", txt, re.M)]
        desc = ''
        dm = re.search(r"^\s*/// (.+)$", txt, re.M)
        if dm:
            desc = dm.group(1).strip()
        tables.append({'name': tname, 'file': base, 'columns': [c.strip() for c in cols],
                       'desc': desc, 'measures': []})
        roles_in_tables += re.findall(r"^\s*role\s+'?([^'\n]+)'?", txt, re.M)
        # שם מדד ב-TMDL: מזהה חשוף, או עטוף בגרשים שבתוכם גרש נכתב פעמיים.
        # regex תמים חותך שם כזה באמצע. ראה known-issues-log.
        for mm in re.finditer(r"^\t*measure\s+(?:'((?:[^']|'')+)'|([^\s=']+))\s*=\s*(.*?)(?=^\t*(?:measure|column|partition|hierarchy|table)\s|\Z)",
                              txt, re.S | re.M):
            name = (mm.group(1) or mm.group(2) or "").replace("''", "'").strip()
            expr = mm.group(3)
            fmt = ''
            fm = re.search(r"formatString:\s*(.+)", expr)
            if fm:
                fmt = fm.group(1).strip()
            d = ''
            dd = re.search(r"^\s*description:\s*(.+)", expr, re.M)
            if dd:
                d = dd.group(1).strip()
            if not d:
                # ב-TMDL התיאור יושב כשורות /// מעל ההצהרה
                head = txt[:mm.start()].rstrip().split('\n')
                acc = []
                for ln in reversed(head):
                    if ln.strip().startswith('///'):
                        acc.insert(0, ln.strip()[3:].strip())
                    else:
                        break
                d = ' '.join(acc).strip()
            body = re.split(r"\n\s*(?:formatString|displayFolder|description|lineageTag|annotation|dataCategory|isHidden)\s*:", expr)[0]
            body = body.replace('```', '').strip()
            body = '\n'.join(ln.strip() for ln in body.split('\n') if ln.strip())
            measures.append({'name': name, 'table': tname, 'expr': body,
                             'format': fmt, 'desc': d})
            tables[-1]['measures'].append(name)
    rels = []
    rf = os.path.join(model_dir, 'definition', 'relationships.tmdl')
    if os.path.exists(rf):
        txt = open(rf, encoding='utf-8-sig').read()
        for blk in re.split(r'\n(?=relationship )', txt):
            fc = re.search(r'fromColumn:\s*(.+)', blk)
            tc = re.search(r'toColumn:\s*(.+)', blk)
            if fc and tc:
                rels.append({'from': fc.group(1).strip(), 'to': tc.group(1).strip(),
                             'both': 'bothDirections' in blk})
    # תפקידי אבטחה: קובצי הטבלאות כבר נסרקו למעלה — אין לקרוא אותם פעם שנייה.
    roles = list(roles_in_tables)
    for f in glob.glob(os.path.join(model_dir, 'definition', '**', '*.tmdl'), recursive=True):
        if os.path.dirname(os.path.abspath(f)) == os.path.abspath(tdir):
            continue
        t = open(f, encoding='utf-8-sig', errors='ignore').read()
        roles += re.findall(r"^\s*role\s+'?([^'\n]+)'?", t, re.M)
    return {'tables': tables, 'measures': measures, 'relationships': rels, 'roles': roles}


# ── סוגי חישוב. למדד שמחשב לא מספיק "מה הוא מודד" — צריך לדעת מונה/מכנה,
# איזו תקופה, ומה לא נכלל. לכל סוג יש שאלת השלמה משלו.
CALC_KINDS = [
    ("יחס / אחוז",
     ("DIVIDE(", "/"),
     "מונה? מכנה? מה לא נכלל בספירה? מה מוצג כשאין נתון?"),
    ("השוואת תקופות",
     ("SAMEPERIODLASTYEAR", "DATEADD", "DATESYTD", "DATESMTD", "DATESQTD",
      "PREVIOUSMONTH", "PREVIOUSYEAR", "PARALLELPERIOD", "TOTALYTD"),
     "איזו תקופה נמדדת? מול איזו תקופה משווים? לפי איזו טבלת תאריכים?"),
    ("תנאי / סיווג",
     ("SWITCH(", "IF("),
     "מה הכלל שמחליט? מה קורה כשאין נתון (ריק ≠ אפס)?"),
    ("ספירה",
     ("DISTINCTCOUNT", "COUNTROWS", "COUNTA", "COUNTX", "COUNT("),
     "מה נספר בדיוק? מה *לא* נספר? האם כפילויות מאוחדות?"),
    ("סכימה משוקללת",
     ("SUMX", "AVERAGEX", "MAXX", "MINX"),
     "לפי מה משוקלל? על איזו טבלה רצה החישוב?"),
    ("סינון מפורש",
     ("CALCULATE(", "FILTER(", "ALL(", "REMOVEFILTERS"),
     "איזה סינון נכפה? האם הוא מבטל את בחירת המשתמש?"),
    ("טקסט",
     ("FORMAT(", '" & ', ' & "'),
     "מה מוצג למשתמש? האם קיים מדד מספרי מקביל?"),
]


def classify(expr):
    """מחזיר (סוג החישוב, שאלת ההשלמה). מדד בסיס = ללא חישוב מיוחד."""
    up = expr.upper()
    hits = []
    for kind, toks, ask in CALC_KINDS:
        for t in toks:
            if t.upper() in up:
                hits.append((kind, ask))
                break
    if not hits:
        return "בסיס", "מה הוא מודד במילים של אדם?"
    kinds = " · ".join(k for k, _ in hits[:2])
    asks = "  ".join(a for _, a in hits[:2])
    return kinds, asks


def measure_deps(measures):
    names = {m['name'] for m in measures}
    dep = {}
    for m in measures:
        found = set(re.findall(r'\[([^\]]+)\]', m['expr'])) & names
        found.discard(m['name'])
        if found:
            dep[m['name']] = sorted(found)
    return dep


def fingerprint(expr):
    """טביעת אצבע של נוסחה — מתעלמת מרווחים והערות, כדי לזהות שינוי אמיתי."""
    s = re.sub(r'--[^\n]*', '', expr)
    s = re.sub(r'\s+', '', s)
    import hashlib
    return hashlib.md5(s.encode('utf-8')).hexdigest()[:10]


# ── שימור התוכן האנושי ────────────────────────────────────────────────
def load_previous(out_path, prev_tables=None):
    """קורא תוכן אנושי + מצב קודם. מעדיף קובץ state, ונופל לקריאה מה-docx.
    prev_tables: טבלאות שכבר חולצו מה-docx הקודם (חוסך פרשנות ZIP/XML כפולה)."""
    prev = {'human': {}, 'defs': {}, 'pages': {}, 'fp': {}, 'date': ''}
    state = out_path + '.state.json'
    if os.path.exists(state):
        try:
            prev.update(json.load(open(state, encoding='utf-8')))
        except Exception:
            pass
    if os.path.exists(out_path):
        try:
            labels = {lbl: key for key, lbl, _ in HUMAN_FIELDS}
            EMPTY = ('— להשלמה —', '')
            for tbl in (prev_tables if prev_tables is not None else read_tables(out_path)):
                if not tbl or not tbl[0]:
                    continue
                head = [c.strip() for c in tbl[0]]
                # רק טבלאות מזוהות נקראות חזרה. בלי הבידוק הזה נשאבות שורות
                # מטבלאות מכונתיות והכיסוי מדווח שקרי. ראה known-issues-log.
                if head[:2] == ['שדה', 'ערך']:
                    for row in tbl[1:]:
                        if len(row) >= 2 and row[0].strip() in labels \
                                and row[1].strip() not in EMPTY:
                            prev['human'][labels[row[0].strip()]] = row[1].strip()
                elif head and head[0] == 'מדד' and len(head) > 1 and head[1].startswith('מה הוא מודד'):
                    for row in tbl[1:]:
                        if len(row) >= 2 and row[0].strip() and row[1].strip() not in EMPTY:
                            prev['defs'][row[0].strip()] = row[1].strip()
                elif head and head[0] == 'דף' and len(head) > 1 and head[1].startswith('מה הוא מציג'):
                    for row in tbl[1:]:
                        if len(row) >= 2 and row[0].strip() and row[1].strip() not in EMPTY:
                            prev['pages'][row[0].strip()] = row[1].strip()
        except Exception as e:
            print('אזהרה: לא הצלחתי לקרוא את המסמך הקודם (%s) — התוכן האנושי לא נשמר.' % e,
                  file=sys.stderr)
    return prev


def save_state(out_path, human, defs, pages, model):
    st = {'human': human, 'defs': defs, 'pages': pages,
          'fp': {m['name']: fingerprint(m['expr']) for m in model['measures']},
          'tables': [t['name'] for t in model['tables']],
          'date': datetime.date.today().isoformat()}
    with open(out_path + '.state.json', 'w', encoding='utf-8') as fh:
        json.dump(st, fh, ensure_ascii=False, indent=1)


# ── דוח סטייה ────────────────────────────────────────────────────────
def drift(prev, model, defs):
    d = {'added': [], 'removed': [], 'changed': [], 'undocumented': [], 'new_tables': [],
         'removed_tables': [], 'since': prev.get('date', '')}
    cur = {m['name']: fingerprint(m['expr']) for m in model['measures']}
    old = prev.get('fp') or {}
    if old:
        d['added'] = sorted(set(cur) - set(old))
        d['removed'] = sorted(set(old) - set(cur))
        d['changed'] = sorted(n for n in set(cur) & set(old) if cur[n] != old[n])
    oldt = set(prev.get('tables') or [])
    curt = {t['name'] for t in model['tables']}
    if oldt:
        d['new_tables'] = sorted(curt - oldt)
        d['removed_tables'] = sorted(oldt - curt)
    d['undocumented'] = sorted(m['name'] for m in model['measures']
                               if not (defs.get(m['name']) or m['desc']))
    return d


def print_drift(d, total):
    print('\n## דוח סטייה — האם התיעוד מעודכן?')
    if d['since']:
        print('הושוואה מול המסמך מ-%s.' % d['since'])
    else:
        print('אין מסמך קודם — זו ההפקה הראשונה, ולכן אין ממה לסטות.')
    any_drift = False
    for key, label, icon in (('added', 'מדדים חדשים במודל שאינם במסמך', '⚠️'),
                             ('removed', 'מדדים שנמחקו מהמודל אך עדיין במסמך', '⚠️'),
                             ('changed', 'מדדים ששינו נוסחה — ההגדרה במסמך אולי כבר לא נכונה', '🔴'),
                             ('new_tables', 'טבלאות חדשות', '⚠️'),
                             ('removed_tables', 'טבלאות שנמחקו', '⚠️')):
        if d[key]:
            any_drift = True
            print('%s %s (%d): %s' % (icon, label, len(d[key]), ', '.join(d[key])))
    if not any_drift and d['since']:
        print('✅ אין סטייה — המסמך תואם למודל.')
    n = len(d['undocumented'])
    print('\n## כיסוי הגדרות עסקיות')
    print('%d מתוך %d מדדים עם הגדרה עסקית (%d%%).'
          % (total - n, total, round(100.0 * (total - n) / max(1, total))))
    if n:
        print('חסרה הגדרה ל-%d מדדים: %s' % (n, ', '.join(d['undocumented'][:15])
                                             + (' …' if n > 15 else '')))


# ── בניית המסמך ──────────────────────────────────────────────────────
def build(report_dir, model_dir, out_path, title=None):
    model = read_model(model_dir)
    # ה-docx הקודם מפוענח פעם אחת בלבד: אותן הטבלאות משמשות גם לשימור התוכן
    # האנושי (load_previous) וגם ליומן השינויים בהמשך. בעבר הוא נקרא פעמיים.
    prev_tables = read_tables(out_path) if os.path.exists(out_path) else None
    prev = load_previous(out_path, prev_tables=prev_tables)
    human = dict(prev.get('human') or {})
    defs = dict(prev.get('defs') or {})
    for m in model['measures']:                       # description במודל מנצח ריק במסמך
        if m['desc'] and not defs.get(m['name']):
            defs[m['name']] = m['desc']
    pages = []
    if EX:
        try:
            pages = EX.read_report(report_dir)
        except Exception as e:
            print('אזהרה: קריאת הדוח נכשלה (%s) — האזור המכונתי יכיל מודל בלבד.' % e,
                  file=sys.stderr)
    page_notes = dict(prev.get('pages') or {})
    name = title or os.path.basename(report_dir).replace('.Report', '')
    today = datetime.date.today().strftime('%d.%m.%Y')
    d = drift(prev, model, defs)

    doc = Doc("תיק דוח — " + name)
    doc.title_page("תיק דוח Power BI · %s · הופק %s" % (name, today))
    doc.rule()
    doc.p("מסמך זה הוא מקור האמת לתיעוד הדוח. הוא בנוי משני אזורים, וההפרדה ביניהם היא "
          "מה שמונע ממנו להתיישן:", sz=21)
    doc.table([
        ["אזור", "מי כותב", "מה קורה בהפקה מחדש"],
        ["✍️ אנושי", "בני אדם בלבד", "נשמר כמו שהוא — לעולם לא נדרס"],
        ["🤖 מכונתי", "הסקריפט בלבד", "נוצר מחדש מהמודל; אל תערכו ידנית"],
    ], widths=[1800, 2600, 4960])
    doc.note("בכל הפקה מחדש מושווה המסמך למודל בפועל, ומודפס דוח סטייה: מה נוסף, מה נמחק, "
             "איזו נוסחה השתנתה, ולאילו מדדים עדיין חסרה הגדרה עסקית. "
             "כך תיעוד שהתיישן הופך לממצא במקום להישאר טעות שקטה.")

    doc.h2("איך ממלאים — 4 שלבים")
    doc.bullet("פותחים ב-Word וממלאים רק את הטבלאות הירוקות (אזור אנושי). "
               "בכל טבלה יש עמודת \"מה למלא כאן\" שמסבירה מה מצופה.")
    doc.bullet("מוחקים את הטקסט \"— להשלמה —\" וכותבים במקומו. מה שלא יודעים — משאירים כמו שהוא.")
    doc.bullet("שומרים. אל תשנו את שמות השדות בעמודה הימנית — לפיהם הסקריפט מזהה מה למלא בחזרה.")
    doc.bullet("בהפקה הבאה כל מה שכתבתם נשמר אוטומטית, והחלק האפור מתעדכן לבד — "
               "בתנאי שהקובץ נשאר באותו שם ובאותו מקום.")
    doc.note("⚠️ שינוי שם הקובץ או העברתו לתיקייה אחרת = ההפקה הבאה לא תמצא את מה שמילאתם "
             "ותתחיל מדף ריק. שמרו על אותו נתיב.", color=DX.C_WARN)
    doc.note("השדה הכי חשוב במסמך הוא \"מה הוא מודד\" במילון המדדים (סעיף 6). זה הידע היחיד "
             "כאן ששום כלי לא יכול לייצר במקומכם — ובלעדיו אף אחד לא ידע בעוד שנה מה המספר אומר.",
             color=DX.C_HUMAN)

    # ── סטייה (למעלה, כדי שלא יפספסו) ─────────────────────────
    if d['since']:
        doc.h1("מצב התיעוד — מה השתנה מאז %s" % d['since'])
        rows = [["מה", "כמות", "פירוט"]]
        for key, label in (('changed', '🔴 מדדים ששינו נוסחה'),
                           ('added', '⚠️ מדדים חדשים שאינם מתועדים'),
                           ('removed', '⚠️ מדדים שנמחקו ועדיין מופיעים'),
                           ('new_tables', '⚠️ טבלאות חדשות'),
                           ('removed_tables', '⚠️ טבלאות שנמחקו')):
            if d[key]:
                rows.append([label, str(len(d[key])), ', '.join(d[key])])
        if len(rows) == 1:
            doc.p("✅ אין סטייה — המסמך תואם למודל בפועל.", bold=True, color=DX.C_HUMAN)
        else:
            doc.table(rows, widths=[3000, 900, 5460])
            doc.p("כל שורה כאן היא משימה: לעדכן את ההגדרה העסקית באזור האנושי.", italic=True)

    total = len(model['measures'])
    covered = total - len(d['undocumented'])
    doc.h2("כיסוי הגדרות עסקיות")
    doc.rich([("%d מתוך %d " % (covered, total), {'bold': True, 'sz': 26,
              'color': DX.C_HUMAN if covered == total else DX.C_WARN}),
              ("מדדים מתועדים (%d%%)" % round(100.0 * covered / max(1, total)), {})])
    if d['undocumented']:
        doc.p("חסרה הגדרה עסקית ל: " + ', '.join(d['undocumented']), sz=20, color=DX.C_MACHINE)

    # ═══ אזור אנושי ═══
    doc.page_break()
    doc.h1("✍️  " + MARK_HUMAN)
    doc.p("החלקים הבאים הם ידע שרק אדם מחזיק. שום כלי לא יכול לייצר אותם. "
          "מלאו אותם פעם אחת — הם ייגררו קדימה לכל הפקה עתידית.", italic=True)

    def block(heading, fields):
        doc.h2(heading)
        rows = [["שדה", "ערך", "מה למלא כאן (עם דוגמה)"]]
        for k, lbl, hint in fields:
            rows.append([lbl, human.get(k, '') or "— להשלמה —", hint])
        doc.table(rows, widths=[2300, 3700, 3360], head_fill=DX.C_HUMAN, sz=19)
    block("1. זהות הדוח", HUMAN_FIELDS[:3])
    block("2. מטרה והקשר", HUMAN_FIELDS[3:6])
    block("3. נתונים, רענון והרשאות", HUMAN_FIELDS[6:9])
    block("4. מגבלות, בדיקה וגרסאות", HUMAN_FIELDS[9:])

    doc.h2("5. מה כל דף מציג")
    doc.p("לדוגמה: \"תמונת מצב סמסטריאלית לראשי חוגים — רישום, נשירה וממוצע ציונים\".",
          italic=True, sz=19, color=DX.C_MACHINE)
    rows = [["דף", "מה הוא מציג ולמי", "ויזואלים"]]
    for p in pages:
        pn = p['name'] or p['id'][:8]
        rows.append([pn, page_notes.get(pn, '— להשלמה —'), str(len(p['visuals']))])
    if len(rows) > 1:
        doc.table(rows, widths=[2200, 6000, 1160], head_fill=DX.C_HUMAN)

    doc.h2("6. מילון מדדים — ההגדרה העסקית")
    doc.p("העמודה האמצעית היא הלב של המסמך: מה המדד מודד במילים של אדם, לא בנוסחה. "
          "זה הדבר היחיד כאן ששום סקריפט לא יכול לכתוב במקומכם.", italic=True, sz=20)
    doc.p("לדוגמה, למדד [סטודנטים פעילים] תכתבו: \"מספר הסטודנטים הרשומים לפחות לקורס אחד "
          "בסמסטר הנוכחי, לא כולל מי שהפסיק לימודים\" — ולא \"ספירה מובחנת של קוד סטודנט\", "
          "שזו הנוסחה ולא המשמעות.", sz=19, color=DX.C_MACHINE)
    doc.note("למדד שמחשב לא מספיק משפט אחד. עמודת \"סוג החישוב\" אומרת לכם מה חסר, "
             "והטקסט האפור בעמודה האמצעית הוא השאלות שצריך לענות עליהן. לדוגמה, ל[אחוז נשירה] "
             "(יחס): \"שיעור הסטודנטים שהפסיקו לימודים מתוך הפעילים בסמסטר. מונה: סטטוס "
             "\u05d4\u05e4\u05e1\u05d9\u05e7 או מושהה. מכנה: כל הרשומים לקורס. לא כולל תלמידי חוץ. "
             "כשאין רשומים — מוצג ריק ולא 0%.\" — ארבעה משפטים שמונעים ארבע פרשנויות שונות.",
             color=DX.C_HUMAN)
    rows = [["מדד", "מה הוא מודד (הגדרה עסקית)", "סוג החישוב"]]
    for m in sorted(model['measures'], key=lambda x: (x['table'], x['name'])):
        kind, ask = classify(m['expr'])
        val = defs.get(m['name'], '')
        rows.append([m['name'], val or ("— להשלמה: " + ask + " —"), kind])
    doc.table(rows, widths=[2600, 5600, 1160], head_fill=DX.C_HUMAN, sz=18)

    # ═══ אזור מכונתי ═══
    doc.page_break()
    doc.h1("🤖  " + MARK_MACHINE)
    doc.note("אל תערכו את החלק הזה ידנית — הוא נוצר מחדש בכל הפקה וכל שינוי ידני יימחק. "
             "אם משהו כאן שגוי, התיקון הוא במודל עצמו.", color=DX.C_MACHINE)
    doc.p("הופק מהמודל ב-%s · %d טבלאות · %d מדדים · %d קשרים"
          % (today, len(model['tables']), total, len(model['relationships'])), sz=20)

    doc.h2("7. טבלאות המודל")
    # ממד מול עובדות נגזר מכיוון הקשרים: צד ה-"to" הוא הממד, צד ה-"from" הוא העובדות.
    from_t, to_t = set(), set()
    for r in model['relationships']:
        from_t.add(r['from'].split('.')[0].strip("'"))
        to_t.add(r['to'].split('.')[0].strip("'"))
    rows = [["טבלה", "עמודות", "מדדים", "סוג"]]
    for t in model['tables']:
        n = t['name']
        if t['measures'] and len(t['columns']) <= 1:
            kind = "טבלת מדדים"
        elif n in to_t and n not in from_t:
            kind = "ממד (dim)"
        elif n in from_t:
            kind = "עובדות (fact)"
        else:
            kind = "לא מחוברת ⚠️"
        rows.append([t['name'], str(len(t['columns'])), str(len(t['measures'])), kind])
    doc.table(rows, widths=[3400, 1500, 1500, 2960], head_fill=DX.C_MACHINE)

    doc.h2("8. קשרים בין הטבלאות")
    rows = [["מ־", "אל", "הערה"]]
    for r in model['relationships']:
        note = "דו-כיווני" if r['both'] else ""
        col = r['from'].split('.')[-1]
        KEYISH = ('id', 'key', 'code', 'guid', 'no', 'num',
                  'מק"ט', 'קוד', 'מזהה', 'מספר', 'תאריך', 'date')
        if not any(k in col.lower() for k in KEYISH):
            note = (note + " · " if note else "") + "⚠️ קשר על טקסט — מומלץ מפתח"
        rows.append([r['from'], r['to'], note])
    doc.table(rows, widths=[3600, 3600, 2160], head_fill=DX.C_MACHINE, sz=18)

    doc.h2("9. מדדים ונוסחאות")
    for m in sorted(model['measures'], key=lambda x: (x['table'], x['name'])):
        kind, _ = classify(m['expr'])
        doc.h3("%s   ·   %s   ·   %s" % (m['name'], m['table'], kind))
        if defs.get(m['name']):
            doc.p(defs[m['name']], sz=20)
        else:
            doc.p("— אין הגדרה עסקית. השלימו בסעיף 6. —", italic=True, color=DX.C_WARN, sz=19)
        if m['format']:
            doc.p("פורמט תצוגה: %s" % m['format'], sz=18, color=DX.C_MACHINE)
        doc.code(m['expr'][:1800])

    dep = measure_deps(model['measures'])
    if dep:
        doc.h2("10. מפת תלויות בין מדדים")
        doc.p("מדד שרבים תלויים בו הוא נקודת סיכון: שינוי בו משנה את כולם.", italic=True, sz=20)
        used_by = collections.Counter()
        for src, tgts in dep.items():
            for t in tgts:
                used_by[t] += 1
        rows = [["מדד", "מפנה אל", "כמה תלויים בו"]]
        for m in sorted(model['measures'], key=lambda x: -used_by[x['name']]):
            if dep.get(m['name']) or used_by[m['name']]:
                rows.append([m['name'], ', '.join(dep.get(m['name'], [])) or "—",
                             str(used_by[m['name']]) or "0"])
        doc.table(rows, widths=[3000, 4800, 1560], head_fill=DX.C_MACHINE, sz=18)

    doc.h2("11. אבטחת שורה (RLS)")
    if model['roles']:
        doc.p("מוגדרים תפקידי אבטחה: " + ', '.join(sorted(set(model['roles']))), bold=True)
    else:
        doc.p("לא מוגדר RLS — כל מי שיש לו גישה לדוח רואה את כל הנתונים.", bold=True,
              color=DX.C_WARN)
        doc.p("ההחלטה אם זה תקין נרשמת באזור האנושי, סעיף 3.", sz=20)

    if pages:
        doc.h2("12. מבנה הדפים והוויזואלים")
        for p in pages:
            doc.h3("דף: %s  (%d ויזואלים)" % (p['name'] or p['id'][:8], len(p['visuals'])))
            rows = [["סוג", "כותרת", "שדות"]]
            for v in p['visuals']:
                if 'error' in v:
                    continue
                rows.append([v['type'], v['title'] or "— ללא —",
                             ', '.join(v['fields'][:3]) + ('…' if len(v['fields']) > 3 else '')])
            doc.table(rows, widths=[2200, 3200, 3960], head_fill=DX.C_MACHINE, sz=17)

    doc.h1("יומן שינויים")
    doc.p("שורה אחת לכל שינוי משמעותי. זה מה שעונה על \"מה השתנה מאז?\" בעוד שנה. "
          "לדוגמה: 03.09.2026 · הוחלף הקשר בין הרשמות לסטודנטים משם מלא לקוד סטודנט · א.ל.",
          italic=True)
    prev_log = []
    for tbl in (prev_tables or []):
        if tbl and tbl[0] and tbl[0][0].strip() == 'תאריך':
            prev_log = [r for r in tbl[1:] if r and r[0].strip() not in ('', 'תאריך')]
    rows = [["תאריך", "מה השתנה", "מי"]]
    auto = []
    if d['changed']:
        auto.append("שינוי נוסחה: " + ', '.join(d['changed']))
    if d['added']:
        auto.append("מדדים חדשים: " + ', '.join(d['added']))
    if d['removed']:
        auto.append("מדדים שנמחקו: " + ', '.join(d['removed']))
    if auto:
        rows.append([today, ' · '.join(auto), "זוהה אוטומטית"])
    rows += [r[:3] for r in prev_log] or [[today, "הפקת תיק הדוח הראשונה", "—"]]
    doc.table(rows, widths=[1600, 6600, 1160], head_fill=DX.C_ACCENT, sz=19)

    doc.save(out_path)
    save_state(out_path, human, defs, page_notes, model)
    return model, d, defs


def sync_descriptions(model_dir, defs):
    """כותב את ההגדרות העסקיות לתוך המודל כתיאור TMDL.

    ב-TMDL תיאור אובייקט נכתב כשורות `/// ` **מעל** הצהרת האובייקט, באותה הזחה —
    לא כמאפיין `description:` מתחתיו. כתיבה במקום הלא-נכון גורמת לתיאור להיצמד
    לאובייקט הבא או להישבר. ראה known-issues-log.
    """
    changed, files_written = 0, 0
    for f in glob.glob(os.path.join(model_dir, 'definition', 'tables', '*.tmdl')):
        if os.path.basename(f).startswith(SKIP_PREFIX):
            continue
        raw = open(f, 'rb').read()
        had_bom = raw.startswith(b'\xef\xbb\xbf')
        original = raw.decode('utf-8-sig')
        lines = original.split('\n')
        out = []
        for idx, ln in enumerate(lines):
            m = re.match(r"^(\t*)measure\s+(?:'((?:[^']|'')+)'|([^\s=']+))\s*=", ln)
            if m:
                nm = (m.group(2) or m.group(3) or '').replace("''", "'").strip()
                dsc = defs.get(nm, '')
                if dsc and not dsc.startswith('— להשלמה'):
                    # הסר תיאור ישן שכבר יושב מעל ההצהרה
                    while out and out[-1].strip().startswith('///'):
                        out.pop()
                    indent = m.group(1)
                    for part in str(dsc).split('\n'):
                        out.append(indent + '/// ' + part.strip())
                    changed += 1
            out.append(ln)
        # נקה מאפייני description: שגויים שנכתבו בגרסאות קודמות
        out = [l for l in out if not re.match(r"^\s*description:\s", l)]
        new_txt = '\n'.join(out)
        # כתיבה רק אם התוכן השתנה באמת. הרצה חוזרת ללא שינוי בהגדרות לא תלכלך
        # את ה-working tree ולא תאפס mtime לכל קובצי המודל.
        if new_txt != original:
            # שמר על BOM אם היה — קובצי TMDL רגישים לו (known-issues-log §10),
            # והכתיבה הקודמת הסירה אותו בשקט מכל קובץ שנגעה בו.
            open(f, 'w', encoding='utf-8-sig' if had_bom else 'utf-8').write(new_txt)
            files_written += 1
    return changed, files_written


def build_blank(out_path, title=None):
    """תבנית ריקה לחלוקה בארגון — לא דורשת פרויקט PBIP."""
    doc = Doc("תיק דוח — תבנית")
    doc.title_page("תבנית ארגונית לתיעוד דוח Power BI")
    doc.rule()
    doc.p("מסמך זה הוא התבנית האחידה לתיעוד דוח Power BI. מלאו אותו פעם אחת לכל דוח, "
          "ושמרו אותו ליד קובץ הדוח. הדוגמאות שלאורך המסמך לקוחות מדוח סטודנטים "
          "המבוסס על מערכת מכלול — החליפו אותן בתוכן של הדוח שלכם.", sz=21)
    doc.h2("איך ממלאים")
    doc.bullet("ממלאים את כל הטבלאות. בכל אחת יש עמודת \"מה למלא כאן\" שמסבירה מה מצופה.")
    doc.bullet("מוחקים את \"— להשלמה —\" וכותבים במקומו. מה שלא יודעים — משאירים.")
    doc.bullet("אל תשנו את שמות השדות בעמודה הימנית, ואל תשנו את שם הקובץ אחרי ההפקה הראשונה.")
    doc.note("אם הדוח שלכם שמור כפרויקט PBIP, אל תמלאו את החלק הטכני ידנית — הריצו את "
             "pbi_doc.py על הפרויקט, והוא ימלא לבד את המדדים, הנוסחאות, הטבלאות, הקשרים "
             "ומפת התלויות. תיק דוח שנוצר כך גם מתריע כשהתיעוד מתיישן.", color=DX.C_HUMAN)
    doc.h1("✍️  " + MARK_HUMAN)
    groups = [("1. זהות הדוח", HUMAN_FIELDS[:3]), ("2. מטרה והקשר", HUMAN_FIELDS[3:6]),
              ("3. נתונים, רענון והרשאות", HUMAN_FIELDS[6:9]),
              ("4. מגבלות, בדיקה וגרסאות", HUMAN_FIELDS[9:])]
    for h, flds in groups:
        doc.h2(h)
        doc.table([["שדה", "ערך", "מה למלא כאן (עם דוגמה)"]] +
                  [[lbl, "— להשלמה —", hint] for _, lbl, hint in flds],
                  widths=[2300, 3700, 3360], head_fill=DX.C_HUMAN, sz=19)
    doc.h2("5. מה כל דף מציג")
    doc.table([["דף", "מה הוא מציג ולמי", "ויזואלים"],
               ["לדוגמה: סטטוס סמסטריאלי",
                "תמונת מצב לראשי חוגים — רישום, נשירה וממוצע ציונים", "14"]] +
              [["— להשלמה —", "— להשלמה —", ""] for _ in range(4)],
              widths=[2200, 6000, 1160], head_fill=DX.C_HUMAN)
    doc.h2("6. מילון מדדים — ההגדרה העסקית")
    doc.p("שורה לכל מדד בדוח. העמודה האמצעית היא הלב: מה המדד מודד במילים של אדם, לא בנוסחה.",
          italic=True, sz=20)
    doc.note("למדד שמחשב לא מספיק משפט אחד — ציינו בעמודה השמאלית את סוג החישוב, וענו "
             "בהתאם: יחס/אחוז → מונה, מכנה, מה לא נכלל, ומה מוצג כשאין נתון · השוואת תקופות → "
             "איזו תקופה ומול מה · תנאי → הכלל ומה קורה כשאין נתון · ספירה → מה נספר ומה לא.",
             color=DX.C_HUMAN)
    doc.table([["מדד", "מה הוא מודד (הגדרה עסקית)", "סוג החישוב"],
               ["לדוגמה: סטודנטים פעילים",
                "מספר הסטודנטים הרשומים לפחות לקורס אחד בסמסטר הנוכחי, "
                "לא כולל מי שהפסיק לימודים", "ספירה"],
               ["לדוגמה: אחוז נשירה",
                "שיעור הנושרים מתוך הפעילים. מונה: סטטוס \"הפסיק\" או \"מושהה\". "
                "מכנה: כל הרשומים לקורס. לא כולל תלמידי חוץ. כשאין רשומים — ריק ולא 0%.",
                "יחס / אחוז"]] +
              [["— להשלמה —", "— להשלמה —", ""] for _ in range(10)],
              widths=[2600, 5600, 1160], head_fill=DX.C_HUMAN, sz=18)
    doc.h1("יומן שינויים")
    doc.table([["תאריך", "מה השתנה", "מי"],
               ["לדוגמה: 03.09.2026",
                "הוחלף הקשר בין הרשמות לסטודנטים משם מלא לקוד סטודנט", "א.ל."]] +
              [["", "", ""] for _ in range(5)],
              widths=[1600, 6600, 1160], head_fill=DX.C_ACCENT, sz=19)
    doc.save(out_path)
    return out_path


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('report', nargs='?', default=None)
    ap.add_argument('model', nargs='?', default=None)
    ap.add_argument('--blank', action='store_true',
                    help='תבנית ריקה לחלוקה — בלי פרויקט PBIP')
    ap.add_argument('--out', default=None)
    ap.add_argument('--title', default=None)
    ap.add_argument('--drift-only', action='store_true')
    ap.add_argument('--sync-model', action='store_true')
    ap.add_argument('--json', dest='as_json', action='store_true',
                    help='דוח הסטייה כ-JSON (לצריכה תכנותית) במקום טקסט')
    a = ap.parse_args()
    if a.blank:
        out = a.out or 'תיק דוח - תבנית ריקה.docx'
        build_blank(out, a.title)
        print('נכתבה תבנית ריקה: %s' % out)
        print('חלקו אותה למי שאין לו פרויקט PBIP. מי שיש לו — יריץ את הסקריפט על הפרויקט,')
        print('והחלק הטכני (מדדים, טבלאות, קשרים, תלויות) ימולא לבד.')
        return
    if not a.report or not a.model:
        print('נדרשים נתיב .Report ונתיב .SemanticModel — או --blank לתבנית ריקה.')
        sys.exit(1)
    name = a.title or os.path.basename(a.report.rstrip('/\\')).replace('.Report', '')
    out = a.out or os.path.join(os.path.dirname(os.path.abspath(a.report)),
                                'תיק דוח - %s.docx' % name)
    if a.drift_only:
        model = read_model(a.model)
        prev = load_previous(out)
        defs = dict(prev.get('defs') or {})
        for m in model['measures']:
            if m['desc']:
                defs.setdefault(m['name'], m['desc'])
        d = drift(prev, model, defs)
        if a.as_json:
            print(json.dumps(dict(d, total_measures=len(model['measures'])),
                             ensure_ascii=False, indent=1))
        else:
            print_drift(d, len(model['measures']))
        return
    model, d, defs = build(a.report, a.model, out, a.title)
    print('נכתב: %s' % out)
    print('טבלאות: %d · מדדים: %d · קשרים: %d'
          % (len(model['tables']), len(model['measures']), len(model['relationships'])))
    if a.as_json:
        print(json.dumps(dict(d, total_measures=len(model['measures'])),
                         ensure_ascii=False, indent=1))
    else:
        print_drift(d, len(model['measures']))
    if a.sync_model:
        n, fw = sync_descriptions(a.model, defs)
        print('\n%s תיאורי description מסונכרנים במודל; נכתבו %d קבצי TMDL בפועל '
              '(יופיעו כטולטיפ ב-Power BI).' % (n, fw))


if __name__ == '__main__':
    main()
