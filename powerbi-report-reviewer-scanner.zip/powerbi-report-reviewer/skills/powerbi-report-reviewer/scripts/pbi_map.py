#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
pbi_map.py — מפת מבנה צולבת של פרויקט PBIP/PBIR: הבנה "עיוורת" מהקוד בלבד.

למה: הביקורת והבנייה רצות בלי לפתוח את הדוח ובלי לראות רינדור. כדי שהסוכן יוכל
להבין מבנה וליישם המלצות מהקוד בלבד, צריך תמונה אחת שמחברת הכול:
דפים ← ויזואלים ← שדות (queryState/מסננים) ← מדדים/עמודות ← טבלאות ← קשרים,
ובתוספת pageOrder, סימניות ומסננים בכל הרמות. הסקריפט מפיק את המפה בקומפקטיות —
נועד להיקרא במעבר אחד — ומסמן אי-התאמות צולבות (הפניה שבורה, דף נעלם, מדד יתום)
כמועמדים לאימות, לא כפסק. הנחת העבודה: מול המפה הזו פועלים לפי
references/blind-structure.md (חשיבה מבנית עיוורת + מיפוי ממצא ← עריכה בבונה).

שימוש:
    python pbi_map.py "<.Report>" [--model "<.SemanticModel>"] [--json]
בלי ארגומנטים — מחפש תיקיות *.Report / *.SemanticModel מתחת ל-cwd.

קריאה-בלבד, stdlib בלבד, אופליין. קוד יציאה תמיד 0 (כלי שירות לסוכן, לא שער CI).
"""
import json, os, sys, glob, argparse, collections

# אותם פותרי TMDL/DAX/JSON כמו שאר הסקריפטים — בית משותף, לא קורא רביעי
# (known-issues §10 BOM, §12 שמות עם גרש).
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import pbi_analyze  # dax_refs, read_tmdl_table_full, parse_relationships, report_refs
import pbi_extract  # load_json, literal, visual_title, DECOR, SKIP_TABLE_PREFIXES


# ── קריאת דוח: דפים, ויזואלים, שדות מובנים, מסננים ──

def _refs_in(obj):
    """כל ההפניות (entity, property, kind) בתוך עץ JSON כלשהו — מסננים, מדרגות,
    tooltip fields. אותה זהות כמו fields_of ב-pbi_extract (known-issues §2),
    אבל מחזיר רשומות במקום מחרוזות."""
    out = []

    def walk(o):
        if isinstance(o, dict):
            for kind in ('Measure', 'Column', 'Aggregation'):
                d = o.get(kind)
                if isinstance(d, dict) and d.get('Property'):
                    ent = ''
                    try:
                        ent = d['Expression']['SourceRef'].get('Entity', '')
                    except Exception:
                        pass
                    out.append({'entity': ent, 'property': str(d['Property']), 'kind': kind})
            for val in o.values():
                walk(val)
        elif isinstance(o, list):
            for val in o:
                walk(val)
    walk(obj)
    return out


def _fields_with_roles(v):
    """שדות לפי תפקיד (role) מתוך queryState — הבסיס למעקב ויזואל ← מדד.
    אם אין projections מובנים — נפילה חזרה לסריקה גנרית על כל ה-query (role='?')."""
    out = []
    qs = ((v.get('query') or {}).get('queryState')) or {}
    for role, robj in qs.items():
        if not isinstance(robj, dict):
            continue
        for proj in robj.get('projections') or []:
            if not isinstance(proj, dict):
                continue
            for ref in _refs_in(proj.get('field') or {}):
                out.append(dict(ref, role=role))
    if not out and v.get('query'):
        out = [dict(r, role='?') for r in _refs_in(v.get('query'))]
    return out


def _filter_refs(filter_config):
    """רשימת ההפניות שמופיעות ב-filterConfig (בכל רמה: דוח/דף/וויזואל)."""
    filters = (filter_config or {}).get('filters') or []
    out = []
    for f in filters:
        if not isinstance(f, dict):
            continue
        refs = _refs_in(f.get('field') or f.get('expression') or {})
        ftype = f.get('type', '')
        how = f.get('howCreated', '')
        for r in refs:
            out.append(dict(r, filter_type=ftype, how_created=how))
    return out


def read_pages(report_dir):
    """דפים לפי סדר pageOrder (ולא לפי שם תיקייה) — דף שלא נרשם ב-pageOrder
    נעלם בשקט ב-Desktop, ולכן הסדר והכיסוי חלק מהמפה (מקביל ל-R-04 ב-pbi_validate)."""
    order, active = [], None
    pj = os.path.join(report_dir, 'definition', 'pages', 'pages.json')
    if os.path.exists(pj):
        try:
            j = pbi_extract.load_json(pj)
            order = j.get('pageOrder') or []
            active = j.get('activePageName')
        except Exception:
            pass
    by_id = {}
    for pd in sorted(glob.glob(os.path.join(report_dir, 'definition', 'pages', '*'))):
        if not os.path.isdir(pd):
            continue
        pid = os.path.basename(pd)
        page = {'id': pid, 'name': '', 'w': None, 'h': None, 'type': '',
                'visibility': '', 'filters': [], 'visuals': []}
        pjson_path = os.path.join(pd, 'page.json')
        if os.path.exists(pjson_path):
            try:
                p = pbi_extract.load_json(pjson_path)
                page['name'] = p.get('displayName', '') or p.get('name', '')
                page['w'] = p.get('width')
                page['h'] = p.get('height')
                page['type'] = p.get('type', '')
                page['visibility'] = p.get('visibility', '')
                page['filters'] = _filter_refs(p.get('filterConfig'))
            except Exception as e:
                page['error'] = 'page.json שבור: %s' % e
        for vf in sorted(glob.glob(os.path.join(pd, 'visuals', '*', 'visual.json'))):
            vid = os.path.basename(os.path.dirname(vf))
            # כל גוף הלולאה בתוך try (§16): ויזואל פגום נרשם כשגיאה ולא מפיל את המפה.
            try:
                d = pbi_extract.load_json(vf)
                if not isinstance(d, dict):
                    raise ValueError('JSON תקין אבל לא אובייקט (%s)' % type(d).__name__)
                v = d.get('visual', {})
                if not isinstance(v, dict):
                    v = {}
                pos = d.get('position', {})
                if not isinstance(pos, dict):
                    pos = {}
                page['visuals'].append({
                    'id': d.get('name', vid),
                    'type': v.get('visualType', 'group' if 'visualGroup' in d else '?'),
                    'x': pbi_extract.safe_int(pos.get('x')), 'y': pbi_extract.safe_int(pos.get('y')),
                    'w': pbi_extract.safe_int(pos.get('width')), 'h': pbi_extract.safe_int(pos.get('height')),
                    'z': pbi_extract.safe_int(pos.get('z')),
                    'title': pbi_extract.visual_title(v),
                    'fields': _fields_with_roles(v),
                    'filters': _filter_refs(d.get('filterConfig')),
                    'hidden': bool(d.get('isHidden', False)),
                    'sync_group': v.get('syncGroup'),
                })
                # mobile.json לצד visual.json — מתכונת הנייד של הוויזואל
                # (visualContainerMobileState; position x/y/z/width/height/tabOrder).
                # ויזואל בלי mobile.json לא מופיע במתכונת הנייד בכלל.
                mj = os.path.join(os.path.dirname(vf), 'mobile.json')
                if os.path.exists(mj):
                    ve = page['visuals'][-1]
                    try:
                        md = pbi_extract.load_json(mj)
                        if not isinstance(md, dict):
                            raise ValueError('JSON תקין אבל לא אובייקט')
                        mpos = md.get('position', {})
                        if not isinstance(mpos, dict):
                            mpos = {}
                        ve['mobile'] = {
                            'x': pbi_extract.safe_int(mpos.get('x')),
                            'y': pbi_extract.safe_int(mpos.get('y')),
                            'w': pbi_extract.safe_int(mpos.get('width')),
                            'h': pbi_extract.safe_int(mpos.get('height')),
                            'z': pbi_extract.safe_int(mpos.get('z')),
                            'tab': pbi_extract.safe_int(mpos.get('tabOrder')),
                        }
                    except Exception as me:
                        page['visuals'][-1]['mobile_error'] = str(me)
            except Exception as e:
                page['visuals'].append({'id': vid, 'error': str(e)})
        by_id[pid] = page
    pages = [by_id[i] for i in order if i in by_id]
    pages += [p for i, p in sorted(by_id.items()) if i not in order]
    return {'pages': pages, 'page_order': order, 'active_page': active,
            'dirs_missing_from_order': [i for i in by_id if i not in order],
            'order_entries_without_dir': [i for i in order if i not in by_id]}


def read_bookmarks(report_dir, page_ids, visual_ids):
    """סימניות: מזהה, שם תצוגה, קובץ קיים?, ועל מה הן פועלות (דפים/ויזואלים
    שמופיעים בקובץ). קריטי להחלטות ניקוי עיוורות: מחיקת ויזואל מוסתר שסימנייה
    מכוונת אליו שוברת ניווט בלי שום אזהרה בקבצים."""
    bm_root = os.path.join(report_dir, 'definition', 'bookmarks')
    bmj = os.path.join(bm_root, 'bookmarks.json')
    out = []
    if not os.path.exists(bmj):
        return out
    try:
        j = pbi_extract.load_json(bmj)
    except Exception:
        return out
    if not isinstance(j, dict):
        return out
    for item in j.get('items') or []:
        if not isinstance(item, dict):
            continue
        bid = item.get('name', '')
        bf = os.path.join(bm_root, '%s.bookmark.json' % bid)
        rec = {'id': bid, 'display_name': item.get('displayName', ''),
               'file_exists': os.path.exists(bf), 'pages': [], 'visuals': []}
        if rec['file_exists']:
            try:
                raw = open(bf, 'rb').read().decode('utf-8-sig')
                rec['pages'] = [p for p in page_ids if ('"%s"' % p) in raw]
                rec['visuals'] = [v for v in visual_ids if ('"%s"' % v) in raw]
            except Exception:
                pass
        out.append(rec)
    return out


# ── קריאת מודל: טבלאות, קשרים, רשימת שדות ──

def read_model(model_dir):
    tables, auto = [], []
    tdir = os.path.join(model_dir, 'definition', 'tables')
    for f in sorted(glob.glob(os.path.join(tdir, '*.tmdl'))):
        base = os.path.basename(f)
        if base.startswith(pbi_extract.SKIP_TABLE_PREFIXES):
            auto.append(base)
            continue
        try:
            tables.append(pbi_analyze.read_tmdl_table_full(f))
        except Exception as e:
            tables.append({'name': os.path.splitext(base)[0], 'columns': [],
                           'measures': {}, 'error': str(e)})
    return {'tables': tables, 'auto_tables': auto,
            'relationships': pbi_analyze.parse_relationships(model_dir)}


# ── הצלבה: מי משתמש במה, ומה שבור ──

def build_map(report_dir, model_dir=None):
    rep = read_pages(report_dir)
    report_filters = []
    rj = os.path.join(report_dir, 'definition', 'report.json')
    if os.path.exists(rj):
        try:
            rj_obj = pbi_extract.load_json(rj)
            if not isinstance(rj_obj, dict):
                raise ValueError('JSON תקין אבל לא אובייקט')
            report_filters = _filter_refs(rj_obj.get('filterConfig'))
        except Exception:
            pass

    model = read_model(model_dir) if model_dir and os.path.isdir(model_dir) else None
    measure_index, column_index, table_names = {}, set(), set()
    if model:
        for t in model['tables']:
            table_names.add(t['name'])
            for c in t['columns']:
                column_index.add((t['name'], c['name']))
            for mn, m in t['measures'].items():
                measure_index[mn] = (t['name'], m)

    # שימושים מובנים: ויזואל ← שדה, ומסננים בכל הרמות
    measure_uses = collections.defaultdict(list)
    column_uses = collections.defaultdict(list)
    unresolved = []

    def register(ref, loc):
        ent, prop = ref['entity'], ref['property']
        if prop in measure_index:
            measure_uses[prop].append(loc)
        elif (ent, prop) in column_index:
            column_uses[(ent, prop)].append(loc)
        elif not model:
            pass  # בלי מודל אין עם מה להצליב — לא מסמנים "שבור"
        else:
            unresolved.append({'location': loc, 'entity': ent, 'property': prop,
                               'kind': ref['kind']})

    for r in report_filters:
        register(r, 'מסנן-דוח')
    for p in rep['pages']:
        for r in p['filters']:
            register(r, 'מסנן-דף %s' % p['id'])
        for v in p['visuals']:
            if 'error' in v:
                continue
            for fref in v['fields']:
                register(fref, '%s/%s:%s' % (p['id'], v['id'], fref['role']))
            for r in v['filters']:
                register(r, 'מסנן %s/%s' % (p['id'], v['id']))

    # תלויות מדדים (DAX) — אותה סריקה כמו pbi_analyze
    deps = {}
    for mn, (tn, m) in measure_index.items():
        q, b = pbi_analyze.dax_refs(m['expr'])
        deps[mn] = {
            'measures': sorted(x for x in b if x in measure_index and x != mn),
            'columns': sorted(list(q) + [('?', x) for x in b if x not in measure_index]),
        }

    # שימוש = מובנה + גולמי (כמו pbi_analyze — מחרוזת Property/displayName בקבצי
    # הדוח), כדי שהמפה ו-pbi_analyze לא יסתרו זה את זה על "יתום".
    raw_names = pbi_analyze.report_refs(report_dir)
    for mn in measure_index:
        if mn in raw_names and not measure_uses[mn]:
            measure_uses[mn].append('(גולמי)')

    used_meas = set(measure_uses)
    changed = True
    while changed:
        changed = False
        for mn in list(used_meas):
            for dm in deps.get(mn, {}).get('measures', ()):
                if dm not in used_meas:
                    used_meas.add(dm)
                    changed = True

    rel_cols = set()
    if model:
        for r in model['relationships']:
            for ep in (r['from'], r['to']):
                if '.' in ep:
                    t, c = ep.rsplit('.', 1)
                    rel_cols.add((t.strip().strip("'"), c.strip().strip("'")))

    dep_cols = set()
    for mn in used_meas:
        dep_cols.update(deps.get(mn, {}).get('columns', ()))

    unused_measures = sorted(mn for mn in measure_index if mn not in used_meas)
    unused_columns, orphan_tables = [], []
    if model:
        for t in model['tables']:
            t_cols_used = False
            for c in t['columns']:
                key = (t['name'], c['name'])
                used = (c['name'] in raw_names or key in column_uses or key in rel_cols
                        or (t['name'], c['name']) in dep_cols or ('?', c['name']) in dep_cols)
                if not used:
                    unused_columns.append('%s[%s]' % key)
                else:
                    t_cols_used = True
            t_meas_used = any(mn in used_meas for tn2, m2 in
                              [(measure_index[mn][0], None) for mn in t['measures']]
                              if tn2 == t['name'])
            t_in_rels = any(rt == t['name'] for (rt, _) in rel_cols)
            if not (t_cols_used or t_meas_used or t_in_rels):
                orphan_tables.append(t['name'])

    visual_ids = [v['id'] for p in rep['pages'] for v in p['visuals']]
    bookmarks = read_bookmarks(report_dir, [p['id'] for p in rep['pages']], visual_ids)
    known_pages = {p['id'] for p in rep['pages']}
    known_visuals = set(visual_ids)
    stale_bookmarks = [
        b['id'] for b in bookmarks
        if any(pg not in known_pages for pg in b['pages']) or not b['file_exists']]

    return {
        'report_dir': report_dir,
        'model_dir': model_dir,
        'pages': rep['pages'],
        'page_order': rep['page_order'],
        'active_page': rep['active_page'],
        'dirs_missing_from_order': rep['dirs_missing_from_order'],
        'order_entries_without_dir': rep['order_entries_without_dir'],
        'report_filters': report_filters,
        'bookmarks': bookmarks,
        'stale_bookmarks': stale_bookmarks,
        'model': model,
        'measure_total': len(measure_index),
        'measure_uses': {k: v for k, v in measure_uses.items()},
        'column_uses': {'%s[%s]' % k: v for k, v in column_uses.items()},
        'measure_deps': deps,
        'unresolved_refs': unresolved,
        'unused_measures': unused_measures,
        'unused_columns': sorted(unused_columns),
        'orphan_tables': orphan_tables,
        'hidden_visuals': ['%s/%s' % (p['id'], v['id']) for p in rep['pages']
                           for v in p['visuals'] if v.get('hidden')],
        'hidden_pages': [p['id'] for p in rep['pages']
                         if p['visibility'].lower() == 'hidden'],
    }


# ── רינדור טקסט קומפקטי (מעבר קריאה אחד) ──

def _fmt_ref(r):
    return '%s[%s]' % (r['entity'], r['property']) if r['entity'] else r['property']


def render_text(m, mobile=False):
    L = []
    A = L.append
    pages, model = m['pages'], m['model']
    nvis = sum(len(p['visuals']) for p in pages)
    nmeas = len(m['measure_uses'])
    ncols = len(m['column_uses'])
    A('# מפת מבנה צולבת — %s' % os.path.basename(m['report_dir'].rstrip('/\\')))
    head = 'דפים: %d · ויזואלים: %d' % (len(pages), nvis)
    if model:
        # סבב 151 (שדה סבב 2 #3): הספירה היתה uses-ישירים + unused — ופספסה
        # בדיוק מדדים שבשימוש *עקיף* בלבד (Total COGS/Total OpEx דרך מדדים
        # אחרים) — הדפוס הנכון במודל בנוי היטב. הסהכ = כל המדדים במודל.
        head += ' · טבלאות: %d · מדדים: %d · קשרים: %d' % (
            len(model['tables']), m.get('measure_total', nmeas + len(m['unused_measures'])),
            len(model['relationships']))
    else:
        head += ' · ⚠️ בלי מודל — אין הצלבת שדות'
    A(head)
    order = ' ← '.join(m['page_order']) if m['page_order'] else '(אין pageOrder)'
    A('סדר דפים: %s · דף פעיל: %s' % (order, m['active_page'] or '—'))
    A('')

    A('## דפים ← ויזואלים ← שדות')
    for p in pages:
        flags = []
        if p['id'] == m['active_page']:
            flags.append('פעיל')
        if p['id'] in m['dirs_missing_from_order']:
            flags.append('⚠️ לא ב-pageOrder — נעלם בשקט')
        if p['visibility'].lower() == 'hidden':
            flags.append('מוסתר')
        if p['type']:
            flags.append('type=%s' % p['type'])
        size = ('%sx%s' % (p['w'], p['h'])) if p['w'] else '?'
        n_mob = sum(1 for v in p['visuals'] if 'mobile' in v)
        if n_mob:
            flags.append('נייד %d/%d' % (n_mob, len(p['visuals'])))
        A('%s "%s" %s%s' % (p['id'], p['name'], size,
                            (' · ' + ' · '.join(flags)) if flags else ''))
        if p.get('error'):
            A('  ⚠️ %s' % p['error'])
        if p['filters']:
            A('  מסנני דף: ' + ', '.join(_fmt_ref(r) for r in p['filters']))
        def _vk(x):
            if mobile:
                mo = x.get('mobile') or {}
                return (0 if 'mobile' in x else 1,
                        mo.get('tab') or 0, mo.get('y') or 0, mo.get('x') or 0)
            return (x.get('z', 0), x.get('y', 0), x.get('x', 0))
        for v in sorted(p['visuals'], key=_vk):
            if 'error' in v:
                A('  ⚠️ %s — visual.json שבור: %s' % (v['id'], v['error']))
                continue
            hidden = ' · מוסתר' if v['hidden'] else ''
            title = ' "%s"' % v['title'] if v['title'] else ''
            if mobile:
                mo = v.get('mobile')
                if mo:
                    A('  tab%d %s %s (%d,%d) %dx%d%s%s' % (
                        mo['tab'], v['id'], v['type'], mo['x'], mo['y'],
                        mo['w'], mo['h'], title, hidden))
                else:
                    A('  — %s %s לא בנייד%s%s' % (v['id'], v['type'], title, hidden))
                if 'mobile_error' in v:
                    A('    ⚠️ mobile.json שבור: %s' % v['mobile_error'])
                continue
            A('  z%d %s %s (%d,%d) %dx%d%s%s' % (
                v['z'], v['id'], v['type'], v['x'], v['y'], v['w'], v['h'], title, hidden))
            if v['fields']:
                A('    שדות: ' + ', '.join('%s→%s' % (f['role'], _fmt_ref(f))
                                           for f in v['fields']))
            if v['filters']:
                A('    מסננים: ' + ', '.join(_fmt_ref(r) for r in v['filters']))
        A('')

    if model:
        A('## מודל ← טבלאות ומדדים')
        for t in model['tables']:
            cols = ', '.join(c['name'] + (' (מוסתר)' if c['hidden'] else '')
                             for c in t['columns']) or '—'
            A('%s — עמודות: %s' % (t['name'], cols))
            for mn, mm in t['measures'].items():
                uses = m['measure_uses'].get(mn) or []
                used_by = ('בשימוש: ' + ', '.join(uses[:8]) +
                           (' …' if len(uses) > 8 else '')) if uses else 'לא בשימוש'
                fmt = ' · fmt ✓' if mm['format_string'] else ' · ⚠️ בלי fmt'
                folder = ' · תיקייה: %s' % mm['display_folder'] if mm['display_folder'] else ''
                expr1 = ' '.join(mm['expr'].split())[:90]
                A('  %s = %s%s%s · %s' % (mn, expr1, fmt, folder, used_by))
                dm = m['measure_deps'].get(mn, {})
                if dm.get('measures'):
                    A('    תלויות: ' + ', '.join(dm['measures']))
        if model['auto_tables']:
            A('(דולגו טבלאות תאריך אוטומטיות: %s)' % ', '.join(model['auto_tables']))
        A('')
        if model['relationships']:
            A('## קשרים')
            for r in model['relationships']:
                extra = []
                if r['both']:
                    extra.append('⚠️ דו-כיווני')
                if not r['active']:
                    extra.append('לא פעיל')
                A('%s: %s → %s (%s:%s)%s' % (
                    r['name'] or '?', r['from'], r['to'], r['from_card'], r['to_card'],
                    (' · ' + ' · '.join(extra)) if extra else ''))
            A('')

    if m['report_filters']:
        A('## מסנני דוח (גלובליים — משמעת מכנה §11)')
        for r in m['report_filters']:
            A('  ' + _fmt_ref(r) + (' · %s' % r['filter_type'] if r['filter_type'] else ''))
        A('')

    if m['bookmarks']:
        A('## סימניות')
        for b in m['bookmarks']:
            tgt = []
            if b['pages']:
                tgt.append('דפים: ' + ', '.join(b['pages']))
            if b['visuals']:
                tgt.append('ויזואלים: ' + ', '.join(b['visuals']))
            A('%s "%s"%s%s' % (b['id'], b['display_name'],
                               ' — ' + ' · '.join(tgt) if tgt else '',
                               '' if b['file_exists'] else ' · ⚠️ קובץ חסר'))
        A('')

    A('## אי-התאמות צולבות (מועמדים לאימות — לא פסק)')
    any_issue = False
    if m['unresolved_refs']:
        any_issue = True
        A('הפניות שלא נמצאו במודל (מועמד שבור בשקט — אם זו עמודה מחושבת ברמת הדוח,')
        A('  להתעלם; מקביל ל-R-15 ב-pbi_validate):')
        for u in m['unresolved_refs']:
            A('  ⚠️ %s ← %s' % (u['location'], _fmt_ref(u)))
    if m['dirs_missing_from_order']:
        any_issue = True
        A('דפים שקיימים כתיקייה אך לא ב-pageOrder: ' + ', '.join(m['dirs_missing_from_order']))
    if m['order_entries_without_dir']:
        any_issue = True
        A('רשומות pageOrder בלי תיקיית דף: ' + ', '.join(m['order_entries_without_dir']))
    if m['unused_measures']:
        any_issue = True
        A('מדדים לא-בשימוש (%d): %s' % (len(m['unused_measures']),
                                        ', '.join(m['unused_measures'])))
    if m['unused_columns']:
        any_issue = True
        A('עמודות לא-בשימוש (%d): %s' % (len(m['unused_columns']),
                                         ', '.join(m['unused_columns'][:30])))
    if m['orphan_tables']:
        any_issue = True
        A('טבלאות יתומות: ' + ', '.join(m['orphan_tables']))
    if m['hidden_visuals']:
        any_issue = True
        A('ויזואלים מוסתרים (לבדוק סימניות/drill לפני ניקוי): ' + ', '.join(m['hidden_visuals']))
    if m['hidden_pages']:
        any_issue = True
        A('דפים מוסתרים (drillthrough/tooltip?): ' + ', '.join(m['hidden_pages']))
    if m['stale_bookmarks']:
        any_issue = True
        A('סימניות עם קובץ חסר או יעד לא מזוהה: ' + ', '.join(m['stale_bookmarks']))
    if not any_issue:
        A('  לא נמצאו אי-התאמות.')
    A('')
    A('להחלטות ניקוי/תיקון מול המפה — references/blind-structure.md; הביצוע בבונה '
      '(pbi_fix dry-run ← --apply ← pbi_validate).')
    return '\n'.join(L)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('report', nargs='?', default=None)
    ap.add_argument('--model', default=None)
    ap.add_argument('--json', dest='as_json', action='store_true')
    ap.add_argument('--mobile', action='store_true',
                    help='תצוגת מתכונת נייד: גאומטריה מ-mobile.json לפי tabOrder')
    a = ap.parse_args()
    rp = a.report
    sm = a.model
    if not rp:
        c = glob.glob('**/*.Report', recursive=True)
        rp = c[0] if c else None
    if not sm:
        c = glob.glob('**/*.SemanticModel', recursive=True) or \
            glob.glob('**/*.Dataset', recursive=True)  # סבב 88: סיומת ישנה
        sm = c[0] if c else None
    if not rp or not os.path.isdir(rp):
        print('לא נמצאה תיקיית .Report — העבר נתיב: python pbi_map.py "<.Report>" --model "<.SemanticModel>"')
        return
    m = build_map(rp, sm)
    if a.as_json:
        print(json.dumps(m, ensure_ascii=False, indent=1))
    else:
        print(render_text(m, mobile=a.mobile))


if __name__ == '__main__':
    main()
