#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
pbi_bench.py — מדידת ביצועים/עומס דטרמיניסטית לצינור הסוקר (extract/analyze/check/map).

למה: כל סבב שיפור מוסיף כללים ושלבים — בלי מדידה אין דרך לדעת שהסוקר נשאר מהיר וקל
("מהירות ועומס" הם דרישת יסוד שלו). הסקריפט מודד זמן קיר וזיכרון-שיא לכל שלב, על פרויקט
אמיתי או על פרויקט סינתטי שהוא מייצר (--synthesize), ומשווה מול baseline שמור כדי לתפוס
רגרסיית ביצועים לפני שהיא נכנסת.

עקרונות: stdlib בלבד. אופליין. קריאה-בלבד על הפרויקט (סינתזה כותבת רק לתיקיית temp).
אין exit codes — רגרסיה מודפסת כאזהרה, לא שוברת CI (עקרון הסוקר).
השראה: airspeed-velocity/asv (baseline + השוואה לאורך חיי הפרויקט) ו-semgrep perf runner —
המימוש כאן עצמאי לחלוטין.

שימוש:
    python pbi_bench.py "<.Report>" --model "<.SemanticModel>" [--rounds 3]
    python pbi_bench.py --synthesize 20x5 [--rounds 3]
    python pbi_bench.py ... --save-baseline bench.json
    python pbi_bench.py ... --check bench.json --tolerance 1.5
"""
import argparse, gc, io, json, os, random, sys, tempfile, time, tracemalloc
import contextlib

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))


# ══════════════════════════ סינתזת פרויקט עומס ══════════════════════════
def synthesize(root, n_pages, n_visuals, n_tables=3, measures_per_table=8, seed=42):
    """יוצר פרויקט PBIP סינתטי דטרמיניסטי (אותו seed = אותם בייטים) לבדיקת עומס."""
    rng = random.Random(seed)
    rep = os.path.join(root, 'Load.Report')
    sm = os.path.join(root, 'Load.SemanticModel')

    os.makedirs(os.path.join(sm, 'definition', 'tables'), exist_ok=True)
    os.makedirs(os.path.join(rep, 'definition', 'pages'), exist_ok=True)

    for t in range(n_tables):
        lines = ['table t%d' % t]
        for c in range(6):
            lines.append('\tcolumn c%d\n\t\tdataType: string\n\t\tsourceColumn: c%d' % (c, c))
        for m in range(measures_per_table):
            if m % 3 == 0:
                expr = 'SUM ( t%d[c0] )' % t
            elif m % 3 == 1:
                expr = 'CALCULATE ( [m%d_%d], FILTER ( t%d, t%d[c1] = "x" ) )' % (t, m - 1, t, t)
            else:
                expr = '[m%d_%d] / [m%d_0]' % (t, m - 1, t)
            lines.append("\tmeasure 'm%d_%d' = %s" % (t, m, expr))
        lines.append('\tpartition t%d = m\n\t\tmode: import\n\t\tsource =\n\t\t\tlet x = 1 in x' % t)
        _w(os.path.join(sm, 'definition', 'tables', 't%d.tmdl' % t), '\n'.join(lines))

    _w(os.path.join(rep, 'definition', 'report.json'), json.dumps({'name': 'load'}))
    for pi in range(n_pages):
        pid = 'p%04d' % pi
        vdir = os.path.join(rep, 'definition', 'pages', pid, 'visuals')
        os.makedirs(vdir, exist_ok=True)
        _w(os.path.join(rep, 'definition', 'pages', pid, 'page.json'),
           json.dumps({'name': pid, 'displayName': 'עמוד %d' % pi, 'width': 1280, 'height': 720}))
        for vi in range(n_visuals):
            vid = 'v%04d' % vi
            t = rng.randrange(n_tables)
            m = rng.randrange(measures_per_table)
            vtype = 'card' if vi % 2 == 0 else 'tableEx'
            doc = {
                'name': vid,
                'position': {'x': 10 + (vi % 5) * 240, 'y': 10 + (vi // 5) * 180,
                             'z': vi, 'width': 220, 'height': 160, 'tabOrder': vi},
                'visual': {
                    'visualType': vtype,
                    'visualContainerObjects': {'general': [{'properties':
                        {'altText': {'expr': {'Literal': {'Value': "'כרטיס'"}}}}}]},
                    'query': {'queryState': {'Values': {'projections': [
                        {'field': {'Measure': {'Expression': {'SourceRef': {'Entity': 't%d' % t}},
                                               'Property': 'm%d_%d' % (t, m)}},
                         'queryRef': 'q'}]}}},
                },
            }
            _w(os.path.join(vdir, vid, 'visual.json'), json.dumps(doc, ensure_ascii=False))
    return rep, sm


def _w(path, text):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, 'w', encoding='utf-8') as fh:
        fh.write(text)


# ══════════════════════════ מדידה ══════════════════════════
def _run_main(mod_name, argv):
    """מריץ main() של שלב עם argv נתון, תוך בליעת stdout. מחזיר (ok, err)."""
    import importlib
    mod = importlib.import_module(mod_name)
    old_argv, buf = sys.argv, io.StringIO()
    try:
        sys.argv = [mod_name + '.py'] + argv
        if mod_name == 'pbi_check' and hasattr(mod, '_FINDINGS'):
            mod._FINDINGS.clear()  # אחרת ממצאים מצטברים בין סבבים ומכפילים את העבודה
        with contextlib.redirect_stdout(buf):
            mod.main()
        return True, ''
    except SystemExit:
        return True, ''
    except Exception as e:  # שלב שקורס נרשם, לא מפיל את הבנץ׳ — זו בדיקת יציבות
        return False, '%s: %s' % (type(e).__name__, e)
    finally:
        sys.argv = old_argv


def measure(mod_name, argv, rounds):
    """מחזיר {min_ms, median_ms, peak_mb, ok, err} על פני rounds הרצות (gc בין הרצות)."""
    times, peak, ok, err = [], 0, True, ''
    for _ in range(rounds):
        gc.collect()
        tracemalloc.start()
        t0 = time.perf_counter()
        ok, err = _run_main(mod_name, argv)
        ms = (time.perf_counter() - t0) * 1000
        _, pk = tracemalloc.get_traced_memory()
        tracemalloc.stop()
        times.append(ms)
        peak = max(peak, pk)
        if not ok:
            break
    times.sort()
    return {'min_ms': round(times[0], 2), 'median_ms': round(times[len(times) // 2], 2),
            'peak_mb': round(peak / (1024 * 1024), 3), 'ok': ok, 'err': err}


STAGES = [
    ('extract', 'pbi_extract', lambda rp, sm: [rp] + (['--model', sm] if sm else [])),
    ('analyze', 'pbi_analyze', lambda rp, sm: [x for x in (sm, rp) if x]),
    ('check',   'pbi_check',   lambda rp, sm: [rp] + (['--model', sm] if sm else [])),
    ('map',     'pbi_map',     lambda rp, sm: [rp] + (['--model', sm] if sm else [])),
]


def bench(report_dir, model_dir, rounds):
    out = {}
    for name, mod, mk in STAGES:
        out[name] = measure(mod, mk(report_dir, model_dir), rounds)
    return out


# ══════════════════════════ baseline + השוואה ══════════════════════════
def compare(current, baseline, tolerance):
    """מחזיר רשימת (שלב, יחס, מצב) — יחס > tolerance = רגרסיה. טקסט בלבד, בלי exit codes."""
    rows = []
    for stage, cur in current.items():
        base = baseline.get(stage)
        if not base or not base.get('min_ms'):
            rows.append((stage, None, 'חדש'))
            continue
        ratio = cur['min_ms'] / base['min_ms'] if base['min_ms'] > 0 else 1.0
        rows.append((stage, ratio, '⚠️ רגרסיה' if ratio > tolerance else 'תקין'))
    return rows


def render(results, rounds, cmp_rows=None):
    L = ['# ביצועי צינור הסוקר (pbi_bench) — %d הרצות לכל שלב' % rounds, '']
    L.append('| שלב | min ms | median ms | זיכרון שיא MB | מצב |')
    L.append('|-----|--------|-----------|---------------|------|')
    for name, r in results.items():
        state = '✅' if r['ok'] else '❌ ' + r['err']
        L.append('| %s | %.1f | %.1f | %.2f | %s |'
                 % (name, r['min_ms'], r['median_ms'], r['peak_mb'], state))
    if cmp_rows:
        L.append('')
        L.append('## השוואה מול baseline')
        for stage, ratio, verdict in cmp_rows:
            rel = ('×%.2f' % ratio) if ratio else '—'
            L.append('- **%s**: %s מול baseline — %s' % (stage, rel, verdict))
    return '\n'.join(L)


def main():
    ap = argparse.ArgumentParser(description='מדידת ביצועים/עומס לצינור הסוקר (stdlib, אופליין)')
    ap.add_argument('report', nargs='?', default=None)
    ap.add_argument('--model', default=None)
    ap.add_argument('--rounds', type=int, default=3)
    ap.add_argument('--synthesize', default=None,
                    help='PxV — מייצר פרויקט עומס סינתטי (למשל 20x5) בתיקיית temp')
    ap.add_argument('--save-baseline', default=None)
    ap.add_argument('--check', default=None, help='קובץ baseline להשוואה')
    ap.add_argument('--tolerance', type=float, default=1.5)
    ap.add_argument('--json', dest='as_json', action='store_true',
                    help='פלט JSON בלבד (לצריכה תכנותית — סוכן/CI) במקום טבלת טקסט')
    a = ap.parse_args()

    tmp = None
    rp, sm = a.report, a.model
    if a.synthesize:
        try:
            np_, nv = (int(x) for x in a.synthesize.lower().split('x'))
        except ValueError:
            print('פורמט --synthesize שגוי. דוגמה: 20x5 (דפים x ויזואלים)')
            return
        tmp = tempfile.mkdtemp(prefix='pbi-bench-')
        rp, sm = synthesize(tmp, np_, nv)
        if not a.as_json:
            print('פרויקט סינתטי: %d דפים × %d ויזואלים + 3 טבלאות × 8 מדדים (%s)'
                  % (np_, nv, tmp))
    if not rp or not os.path.isdir(rp):
        print('לא נמצאה תיקיית .Report — העבר נתיב או --synthesize PxV')
        return

    results = bench(rp, sm, max(1, a.rounds))
    cmp_rows = None
    if a.check and os.path.exists(a.check):
        with open(a.check, encoding='utf-8') as fh:
            cmp_rows = compare(results, json.load(fh), a.tolerance)
    if a.as_json:
        print(json.dumps({'rounds': max(1, a.rounds), 'report': rp, 'model': sm,
                          'results': results, 'compare': cmp_rows,
                          'baseline_saved': None}, ensure_ascii=False))
    else:
        print(render(results, max(1, a.rounds), cmp_rows))
    if a.save_baseline:
        with open(a.save_baseline, 'w', encoding='utf-8') as fh:
            json.dump(results, fh, ensure_ascii=False, indent=1)
        if not a.as_json:
            print('\nbaseline נשמר: %s' % a.save_baseline)


if __name__ == '__main__':
    main()
