#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
docx_rtl.py — כתיבת מסמכי Word בעברית (RTL) ללא תלויות חיצוניות.

קובץ .docx הוא ארכיון ZIP של קובצי XML, ולכן אפשר לייצר אותו עם ספריית zipfile של
Python בלבד. זה חשוב: הסקריפטים של הערכה חייבים לרוץ על כל מחשב בארגון, גם בלי
הרשאות התקנה ובלי אינטרנט. אין python-docx, אין pip.

תמיכת RTL מלאה: <w:bidi/> בכל פסקה, <w:rtl/> בכל ריצת טקסט, <w:bidiVisual/> בטבלאות,
וכן w:szCs/w:rFonts w:cs — בלי אלה גופן וגודל לא חלים על טקסט עברי (complex script).

שימוש כספרייה:
    d = Doc("כותרת המסמך")
    d.h1("פרק"); d.p("פסקה"); d.table([["א","ב"],["1","2"]], widths=[3000,6000])
    d.save("out.docx")

קריאה חוזרת (כדי לשמר תוכן שאדם ערך):
    tables = read_tables("existing.docx")   # רשימת טבלאות, כל אחת רשימת שורות
    texts  = read_paragraphs("existing.docx")
"""
import zipfile, re, os
from xml.sax.saxutils import escape

FONT = "Segoe UI"

# ── צבעים (משותפים עם תבנית ה-HTML של דוחות הביקורת)
C_ACCENT = "1F4E79"
C_HUMAN  = "2D7A4F"   # ירוק — אזור אנושי
C_MACHINE= "5A6472"   # אפור — אזור מכונתי
C_WARN   = "C0392B"

_CT = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
<Default Extension="xml" ContentType="application/xml"/>
<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>
<Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/>
<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>
<Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/>
</Types>"""

_RELS = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>
<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/>
<Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/>
</Relationships>"""

_DOC_RELS = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>
</Relationships>"""

_APP = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties"
 xmlns:vt="http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes">
<Application>powerbi-report-reviewer</Application></Properties>"""


def _style(sid, name, sz, color, bold, outline=None, space_before=240, space_after=120):
    ol = '<w:outlineLvl w:val="%d"/>' % outline if outline is not None else ''
    return (
        '<w:style w:type="paragraph" w:styleId="%s"><w:name w:val="%s"/>'
        '<w:basedOn w:val="Normal"/><w:qFormat/>'
        '<w:pPr><w:bidi/><w:jc w:val="right"/>'
        '<w:spacing w:before="%d" w:after="%d"/>%s</w:pPr>'
        '<w:rPr><w:rFonts w:ascii="%s" w:hAnsi="%s" w:cs="%s"/>'
        '<w:b w:val="%s"/><w:bCs w:val="%s"/>'
        '<w:color w:val="%s"/><w:sz w:val="%d"/><w:szCs w:val="%d"/><w:rtl/></w:rPr></w:style>'
        % (sid, name, space_before, space_after, ol, FONT, FONT, FONT,
           '1' if bold else '0', '1' if bold else '0', color, sz, sz))


def _styles_xml():
    s = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
         '<w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">',
         '<w:docDefaults><w:rPrDefault><w:rPr>'
         '<w:rFonts w:ascii="%s" w:hAnsi="%s" w:cs="%s"/>'
         '<w:sz w:val="22"/><w:szCs w:val="22"/><w:rtl/></w:rPr></w:rPrDefault>'
         '<w:pPrDefault><w:pPr><w:bidi/><w:jc w:val="right"/>'
         '<w:spacing w:after="120" w:line="276" w:lineRule="auto"/></w:pPr></w:pPrDefault>'
         '</w:docDefaults>' % (FONT, FONT, FONT),
         '<w:style w:type="paragraph" w:default="1" w:styleId="Normal"><w:name w:val="Normal"/>'
         '<w:qFormat/></w:style>',
         _style('Title', 'Title', 40, C_ACCENT, True, space_before=0, space_after=120),
         _style('Heading1', 'heading 1', 30, C_ACCENT, True, outline=0, space_before=360),
         _style('Heading2', 'heading 2', 24, C_ACCENT, True, outline=1, space_before=280),
         _style('Heading3', 'heading 3', 22, "1A1F2B", True, outline=2, space_before=200),
         _style('Caption', 'caption', 18, C_MACHINE, False),
         '</w:styles>']
    return ''.join(s)


def _core(title):
    return ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" '
            'xmlns:dc="http://purl.org/dc/elements/1.1/">'
            '<dc:title>%s</dc:title><dc:creator>powerbi-report-reviewer</dc:creator>'
            '</cp:coreProperties>' % escape(title))


class Doc(object):
    def __init__(self, title="מסמך"):
        self.title = title
        self.body = []

    # ── פסקאות ────────────────────────────────────────────────
    def _run(self, text, bold=False, italic=False, color=None, sz=22, mono=False):
        f = "Consolas" if mono else FONT
        rpr = ['<w:rFonts w:ascii="%s" w:hAnsi="%s" w:cs="%s"/>' % (f, f, f)]
        if bold:
            rpr.append('<w:b/><w:bCs/>')
        if italic:
            rpr.append('<w:i/><w:iCs/>')
        if color:
            rpr.append('<w:color w:val="%s"/>' % color)
        rpr.append('<w:sz w:val="%d"/><w:szCs w:val="%d"/>' % (sz, sz))
        if not mono:
            rpr.append('<w:rtl/>')
        parts = []
        for i, ln in enumerate(str(text).split('\n')):
            if i:
                parts.append('<w:br/>')
            parts.append('<w:t xml:space="preserve">%s</w:t>' % escape(ln))
        return '<w:r><w:rPr>%s</w:rPr>%s</w:r>' % (''.join(rpr), ''.join(parts))

    def _para(self, runs, style=None, shade=None, border=None, indent=0, space_after=120,
              ltr=False):
        # פסקת קוד חייבת להיות LTR: בפסקה דו-כיוונית מנוע הטקסט מסדר מחדש סוגריים
        # ופסיקים, ו-CALCULATE( מוצג כ-)CALCULATE. ראה known-issues-log.
        ppr = ['<w:bidi w:val="0"/><w:jc w:val="left"/>'] if ltr \
            else ['<w:bidi/><w:jc w:val="right"/>']
        if style:
            ppr.insert(0, '<w:pStyle w:val="%s"/>' % style)
        if shade:
            ppr.append('<w:shd w:val="clear" w:color="auto" w:fill="%s"/>' % shade)
        if border:
            ppr.append('<w:pBdr><w:right w:val="single" w:sz="24" w:space="6" w:color="%s"/></w:pBdr>' % border)
        if indent:
            ppr.append('<w:ind w:right="%d"/>' % indent)
        ppr.append('<w:spacing w:after="%d"/>' % space_after)
        self.body.append('<w:p><w:pPr>%s</w:pPr>%s</w:p>' % (''.join(ppr), ''.join(runs)))

    def title_page(self, subtitle=""):
        self._para([self._run(self.title, bold=True, color=C_ACCENT, sz=40)], style='Title')
        if subtitle:
            self._para([self._run(subtitle, color=C_MACHINE, sz=20)])

    def h1(self, t):
        self._para([self._run(t, bold=True, color=C_ACCENT, sz=30)], style='Heading1')

    def h2(self, t):
        self._para([self._run(t, bold=True, color=C_ACCENT, sz=24)], style='Heading2')

    def h3(self, t):
        self._para([self._run(t, bold=True, sz=22)], style='Heading3')

    def p(self, t, bold=False, italic=False, color=None, sz=22):
        self._para([self._run(t, bold=bold, italic=italic, color=color, sz=sz)])

    def rich(self, parts):
        """parts = [(text, {bold/italic/color/mono})...] בפסקה אחת."""
        self._para([self._run(t, **(o or {})) for t, o in parts])

    def bullet(self, t, level=0):
        self._para([self._run("•  " + t)], indent=300 + level * 300, space_after=60)

    def note(self, t, color=C_WARN):
        self._para([self._run(t, sz=20)], shade="FFF8E6", border=color, indent=120)

    def code(self, t):
        for ln in str(t).split('\n'):
            self._para([self._run(ln or ' ', mono=True, sz=18)],
                       shade="F2F4F8", space_after=0, ltr=True)
        self.spacer()

    def spacer(self, after=120):
        self._para([self._run('')], space_after=after)

    def rule(self, color=C_ACCENT):
        self.body.append(
            '<w:p><w:pPr><w:bidi/><w:pBdr><w:bottom w:val="single" w:sz="12" '
            'w:space="1" w:color="%s"/></w:pBdr><w:spacing w:after="160"/></w:pPr></w:p>' % color)

    def page_break(self):
        self.body.append('<w:p><w:pPr><w:bidi/></w:pPr><w:r><w:br w:type="page"/></w:r></w:p>')

    # ── טבלאות ────────────────────────────────────────────────
    def table(self, rows, widths=None, header=True, head_fill=None, sz=20):
        if not rows:
            return
        ncol = max(len(r) for r in rows)
        if not widths:
            widths = [int(9360 / ncol)] * ncol
        head_fill = head_fill or C_ACCENT
        grid = ''.join('<w:gridCol w:w="%d"/>' % w for w in widths)
        out = ['<w:tbl><w:tblPr><w:bidiVisual/>'
               '<w:tblW w:w="%d" w:type="dxa"/>' % sum(widths),
               '<w:tblBorders>' + ''.join(
                   '<w:%s w:val="single" w:sz="4" w:space="0" w:color="D5DBE4"/>' % b
                   for b in ('top', 'left', 'bottom', 'right', 'insideH', 'insideV')) +
               '</w:tblBorders>',
               '<w:tblCellMar><w:top w:w="60" w:type="dxa"/><w:bottom w:w="60" w:type="dxa"/>'
               '<w:left w:w="90" w:type="dxa"/><w:right w:w="90" w:type="dxa"/></w:tblCellMar>',
               '</w:tblPr><w:tblGrid>%s</w:tblGrid>' % grid]
        for ri, row in enumerate(rows):
            is_h = header and ri == 0
            trpr = '<w:trPr><w:tblHeader/></w:trPr>' if is_h else ''
            cells = []
            for ci in range(ncol):
                val = row[ci] if ci < len(row) else ''
                shd = ('<w:shd w:val="clear" w:color="auto" w:fill="%s"/>' % head_fill) if is_h \
                    else ('<w:shd w:val="clear" w:color="auto" w:fill="F7F9FC"/>' if ri % 2 == 0 else '')
                run = self._run(val, bold=is_h, color=("FFFFFF" if is_h else None), sz=sz)
                cells.append(
                    '<w:tc><w:tcPr><w:tcW w:w="%d" w:type="dxa"/>%s'
                    '<w:vAlign w:val="center"/></w:tcPr>'
                    '<w:p><w:pPr><w:bidi/><w:jc w:val="right"/><w:spacing w:after="0"/></w:pPr>%s</w:p></w:tc>'
                    % (widths[ci], shd, run))
            out.append('<w:tr>%s%s</w:tr>' % (trpr, ''.join(cells)))
        out.append('</w:tbl>')
        self.body.append(''.join(out))
        self.spacer(80)

    def fill_table(self, pairs, label_w=2600, value_w=6760):
        """טבלת מילוי אנושי: תווית | ערך (ריק = "להשלמה")."""
        rows = [["שדה", "ערך"]]
        for k, v in pairs:
            rows.append([k, v if v else "— להשלמה —"])
        self.table(rows, widths=[label_w, value_w], head_fill=C_HUMAN)

    # ── שמירה ─────────────────────────────────────────────────
    def save(self, path):
        doc = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
               '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">'
               '<w:body>' + ''.join(self.body) +
               '<w:sectPr><w:pgSz w:w="11906" w:h="16838"/>'
               '<w:pgMar w:top="1134" w:right="1134" w:bottom="1134" w:left="1134" '
               'w:header="708" w:footer="708" w:gutter="0"/>'
               '<w:bidi/></w:sectPr></w:body></w:document>')
        d = os.path.dirname(os.path.abspath(path))
        if d and not os.path.isdir(d):
            os.makedirs(d)
        with zipfile.ZipFile(path, 'w', zipfile.ZIP_DEFLATED) as z:
            z.writestr('[Content_Types].xml', _CT)
            z.writestr('_rels/.rels', _RELS)
            z.writestr('word/_rels/document.xml.rels', _DOC_RELS)
            z.writestr('word/document.xml', doc)
            z.writestr('word/styles.xml', _styles_xml())
            z.writestr('docProps/core.xml', _core(self.title))
            z.writestr('docProps/app.xml', _APP)
        return path


# ── קריאה חוזרת ממסמך קיים (כדי לא לדרוס תוכן שאדם כתב) ──────────────
_TAG = re.compile(r'<[^>]+>')


def _xml_of(path):
    with zipfile.ZipFile(path) as z:
        return z.read('word/document.xml').decode('utf-8')


def _text(frag):
    frag = frag.replace('</w:p>', '\n').replace('<w:br/>', '\n')
    frag = re.sub(r'<w:tab/>', ' ', frag)
    txt = _TAG.sub('', frag)
    for a, b in (('&amp;', '&'), ('&lt;', '<'), ('&gt;', '>'),
                 ('&quot;', '"'), ('&apos;', "'")):
        txt = txt.replace(a, b)
    return txt.strip()


def read_tables(path):
    """מחזיר את כל הטבלאות במסמך כרשימת רשימות-שורות (כל תא = מחרוזת)."""
    xml = _xml_of(path)
    out = []
    for tbl in re.findall(r'<w:tbl>.*?</w:tbl>', xml, re.S):
        rows = []
        for tr in re.findall(r'<w:tr[ >].*?</w:tr>', tbl, re.S):
            rows.append([_text(tc) for tc in re.findall(r'<w:tc>.*?</w:tc>', tr, re.S)])
        out.append(rows)
    return out


def read_paragraphs(path):
    xml = _xml_of(path)
    body = xml.split('<w:body>', 1)[-1]
    body = re.sub(r'<w:tbl>.*?</w:tbl>', '', body, flags=re.S)
    return [t for t in (_text(p) for p in re.findall(r'<w:p[ >].*?</w:p>', body, re.S)) if t]


if __name__ == '__main__':
    d = Doc("בדיקת docx_rtl")
    d.title_page("מסמך בדיקה · עברית RTL")
    d.h1("כותרת ראשית")
    d.p("פסקה רגילה בעברית, מיושרת לימין, עם מונח לועזי כמו Power BI באמצע.")
    d.bullet("פריט ברשימה")
    d.table([["עמודה א", "עמודה ב"], ["ערך 1", "ערך 2"]], widths=[4000, 5360])
    d.code("Measure = SUM(Orders[Quantity])")
    d.note("הערה מודגשת.")
    p = d.save("/tmp/docx_rtl_test.docx")
    print("נכתב:", p)
    print("טבלאות שנקראו חזרה:", read_tables(p))
