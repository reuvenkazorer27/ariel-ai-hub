#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
pbi_validate.py — אימות דטרמיניסטי של פרויקט PBIP/PBIR אחרי עריכה — בלי Power BI Desktop.

למה: לולאת ה-edit→validate→read-back של הבונה הסתמכה על "פתח ב-Desktop" כצעד האימות.
הסקריפט הזה סוגר את הפער: הוא בודק **מבנה וצולבות הפניות** בקבצים עצמם — הדברים
ש-PBIR "בולע בשקט" (בלוק שגוי מרונדר ברירת-מחדל בלי שגיאה, דף שלא נרשם ב-pageOrder
ונעלם, קישור לשדה שלא קיים במודל). כל הבדיקות stdlib, אופליין, דטרמיניסטיות.

מה הוא לא מחליף (בכנות): רינדור בפועל, ערכי מדדים אמיתיים, וכשל שקט חזותי — אלה
דורשים מנוע חי. אחרי שהאימות הדטרמיניסטי עובר, read-back ב-Desktop נשאר **אופציונלי**
בלבד, לבדיקת עין סופית — לא חובה בזרימה.

שימוש:
    python pbi_validate.py "<תיקיית פרויקט או .Report>" [--model "<.SemanticModel>"] [--json]
בלי ארגומנטים — מחפש תיקיות *.Report / *.SemanticModel מתחת ל-cwd.

קוד יציאה תמיד 0: זה כלי שירות לסוכן שקורא את הדוח — לא שער CI (עקרון הערכה).
Python stdlib בלבד. אין רשת. כתיבה: אף פעם.
"""
import json, os, re, sys, glob, argparse, collections

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
try:
    from pbi_swap import ROLE_PLAN as _ROLE_PLAN, ROLE_ALIASES as _ROLE_ALIASES, \
        EXTRA_KNOWN_ROLES as _EXTRA_KNOWN, SCOPEID_TYPES as _SCOPEID_TYPES
except Exception:
    _ROLE_PLAN, _ROLE_ALIASES, _EXTRA_KNOWN = {}, {}, {}
    _SCOPEID_TYPES = frozenset({'pieChart', 'donutChart', 'scatterChart', 'treemap', 'funnel'})

# רמות: err = יישבר/ייעלם ב-Desktop; warn = חשוד, לבדוק; info = הערה
_ISSUES = []


def add(level, code, location, title, detail):
    _ISSUES.append({'level': level, 'code': code, 'location': location,
                    'title': title, 'detail': detail})


def _load_json(path):
    """JSON עם BOM או בלעדיו. מחזיר (obj, error)."""
    try:
        with open(path, 'rb') as fh:
            return json.loads(fh.read().decode('utf-8-sig')), None
    except Exception as e:
        return None, str(e)


def _walk(o, cb):
    if isinstance(o, dict):
        cb(o)
        for v in o.values():
            _walk(v, cb)
    elif isinstance(o, list):
        for v in o:
            _walk(v, cb)


def _unq(s):
    """שם TMDL: עטוף בגרשים (גרש פנימי כפול) או חשוף."""
    s = s.strip()
    if s.startswith("'"):
        m = re.match(r"^'((?:[^']|'')+)'", s)
        if m:
            return m.group(1).replace("''", "'")
    return s.split()[0] if s.split() else s


# קטלוג אייקוני CF חוקיים (MS skills-for-fabric conditional-formatting.md, סבב 83) —
# שם מחוץ לקטלוג = קריסת Desktop ("Unable to find resource").
_CF_ICON_NAMES = frozenset({
    '0',
    '1',
    '4CircleLow',
    '4CircleMedium2',
    'Aggregation',
    'Circle25',
    'Circle75',
    'CircleBlackFill',
    'CircleEmpty',
    'CircleFilled',
    'CircleGrayPatternFill',
    'CircleGreenBlackBackgroundPatternFill',
    'CircleGreenBlackOutlinePatternFill',
    'CircleGreenPatternFill',
    'CircleHalf',
    'CircleHigh',
    'CircleLow',
    'CircleMedium',
    'CirclePurplePatternFill',
    'CircleRedBlackBackgroundPatternFill',
    'CircleRedBlackOutlinePatternFill',
    'CircleRedPatternFill',
    'CircleSymbolHigh',
    'CircleSymbolLow',
    'CircleSymbolMedium',
    'CircleYellowBlackBackgroundPatternFill',
    'CircleYellowBlackOutlinePatternFill',
    'CircleYellowPatternFill',
    'ColoredArrowDown',
    'ColoredArrowDownGreen',
    'ColoredArrowDownRight',
    'ColoredArrowRight',
    'ColoredArrowUp',
    'ColoredArrowUpRed',
    'ColoredArrowUpRight',
    'ExpressionName',
    'FlagBlack',
    'FlagGreenPatternFill',
    'FlagHigh',
    'FlagLow',
    'FlagMedium',
    'FlagRedPatternFill',
    'FlagYellowPatternFill',
    'GreyArrowDown',
    'GreyArrowDownRight',
    'GreyArrowRight',
    'GreyArrowUp',
    'GreyArrowUpRight',
    'Measure',
    'Quadrant25',
    'Quadrant25Colored',
    'Quadrant50',
    'Quadrant50Colored',
    'Quadrant75',
    'Quadrant75Colored',
    'QuadrantEmpty',
    'QuadrantFull',
    'QuadrantFullColored',
    'SelectRef',
    'SignLow',
    'SignMedium',
    'SignalBarEmpty',
    'SignalBarFull',
    'SignalBarFullColored',
    'SignalBarLow',
    'SignalBarLowColored',
    'SignalBarMedium',
    'SignalBarMedium2',
    'SignalBarMedium2Colored',
    'SignalBarMediumColored',
    'SourceRef',
    'StarHigh',
    'StarHighLight',
    'StarLow',
    'StarMedium',
    'StarMediumLight',
    'SymbolHigh',
    'SymbolLow',
    'SymbolMedium',
    'TrafficBlackRimmed',
    'TrafficBlackRimmedLight',
    'TrafficHigh',
    'TrafficHighLight',
    'TrafficLow',
    'TrafficLowLight',
    'TrafficMedium',
    'TrafficMediumLight',
    'TriangleHigh',
    'TriangleLow',
    'TriangleMedium',
    'backColor',
    'color',
    'data',
    'dataPoint',
    'dataViewWildcard',
    'fill',
    'fontColor',
    'layout',
    'linearGradient2',
    'linearGradient3',
    'matchingOption',
    'metadata',
    'value',
    'values',
    'verticalAlignment'
})
# מאפייני CF פיקטיביים (לא קיימים במנוע — נזרקים בשקט; מלכודת הזיה של LLM):
_CF_PHANTOM_PROPS = frozenset({'backColorRule', 'fontColorRule', 'iconRule', 'iconDefinition'})


# ---------------------------------------------------------------------------
# סבב 118 · צורות expr מול סכמת semanticQuery 1.4.0
# מקור: data-goblin/power-bi-agentic-development @ tag v26.31.0 (GPL-3.0 —
# אפס ייבוא קוד; הרעיונות מומשו מחדש עם קרדיט):
# plugins/pbip/skills/pbir-format/references/schema-patterns/expressions.md,
# selectors.md, measures-and-literals.md.
# ---------------------------------------------------------------------------

_LIT_NUM = re.compile(r'^-?\d+(?:\.\d+)?$')
_NAME_RX = re.compile(r'^[\w-]+$')


def _read_extension_entities(report_dir):
    """{שם entity: {שמות מדדים}} מתוך definition/reportExtensions.json (אם קיים)."""
    rex = os.path.join(report_dir, 'definition', 'reportExtensions.json')
    if not os.path.exists(rex):
        return {}
    obj, _err = _load_json(rex)
    if not isinstance(obj, dict):
        return {}
    out = {}
    for e in obj.get('entities') or []:
        if isinstance(e, dict) and e.get('name'):
            out[e['name']] = {m.get('name') for m in e.get('measures') or []
                              if isinstance(m, dict) and m.get('name')}
    return out


def _theme_data_colors(report_dir):
    """מספר הצבעים הגדול ביותר ב-dataColors מבין קבצי ה-theme (None אם אין theme)."""
    best = None
    for tf in _theme_files(report_dir):
        obj, err = _load_json(tf)
        if err or not isinstance(obj, dict):
            continue
        dc = obj.get('dataColors')
        if isinstance(dc, list):
            best = max(best or 0, len(dc))
    return best



_VISUAL_CATALOG = None
_VISUAL_CATALOG_GLOBAL = None
def _visual_catalog():
    """קטלוג מאפייני visual.json שנצפו בקורפוס יצואי Desktop
    (data/pbir-visual-catalog.json — דוח שדה סבב 3 #6). None אם חסר."""
    global _VISUAL_CATALOG, _VISUAL_CATALOG_GLOBAL
    if _VISUAL_CATALOG is None:
        cp = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                          '..', 'data', 'pbir-visual-catalog.json')
        try:
            _VISUAL_CATALOG = json.load(open(cp, encoding='utf-8'))
        except Exception:
            _VISUAL_CATALOG = {}
        glob_cards = {'objects': collections.defaultdict(lambda: [set(), 0]),
                      'vco': collections.defaultdict(lambda: [set(), 0])}
        for e in (_VISUAL_CATALOG.get('visualTypes') or {}).values():
            for sec in ('objects', 'vco'):
                for card, props in (e.get(sec) or {}).items():
                    g = glob_cards[sec][card]
                    g[0] |= set(props.keys())
                    g[1] += sum(props.values())
        _VISUAL_CATALOG_GLOBAL = glob_cards
    return (_VISUAL_CATALOG or None), _VISUAL_CATALOG_GLOBAL


def _check_visual_catalog(vobj, vj_path):
    """M-28 · כרטיסים/מאפיינים ב-objects וב-visualContainerObjects מול קטלוג
    נצפה-בקורפוס (2594 ויזואלים מייצואי Desktop). דוח שדה סבב 3 (#6): ניחוש שם
    מאפיין ב-visual.json נכשל בשקט — אין סכמת objects רשמית מפורטת."""
    cat, glob_cards = _visual_catalog()
    if not cat:
        return
    v = vobj.get('visual') or {}
    vt = v.get('visualType')
    if not vt:
        return
    types = cat.get('visualTypes') or {}
    if vt not in types:
        add('info', 'M-28', vj_path, "visualType '%s' לא מופיע בקטלוג הקורפוס" % vt,
            'ייתכן custom visual; מאפייני ה-objects שלו לא נבדקו מול הקטלוג.')
        return
    entry = types[vt]
    n_vis = cat.get('visuals', 0)
    for section, sec in (('objects', 'objects'), ('visualContainerObjects', 'vco')):
        mine = entry.get(sec) or {}
        gsec = glob_cards[sec]
        for card, items in (v.get(section) or {}).items():
            if not isinstance(items, list):
                continue
            if card not in mine:
                if section == 'objects' and card == 'title':
                    # known-issues-log §1: מיקום legacy של כותרת (0/2594 בקורפוס
                    # המודרני — כמעט ודאי legacy בלבד; נשמר info, לא err)
                    add('info', 'M-28', vj_path,
                        "objects.title — מיקום legacy של כותרת (§1)",
                        'ב-2594 יצואי Desktop בקורפוס הכותרת תמיד ב-'
                        'visualContainerObjects.title; objects.title לא נצפה כלל. '
                        'לשקול להעביר ל-vco.')
                    continue
                if card in gsec:
                    add('info', 'M-28', vj_path,
                        "כרטיס '%s' תחת %s לא נצפה אצל %s בקורפוס (אך קיים אצל סוגים אחרים)"
                        % (card, section, vt),
                        'ייתכן שילוב חוקי ונדיר; לוודא ב-Desktop.')
                else:
                    add('err', 'M-28', vj_path,
                        "כרטיס לא מאומת: %s.objects.'%s'" % (vt, card) if section == 'objects'
                        else "כרטיס לא מאומת: %s.visualContainerObjects.'%s'" % (vt, card),
                        'הכרטיס לא נצפה באף אחד מ-%d הוויזואלים בקורפוס הייצואים — כמעט '
                        'בוודאות ניחוש/שגיאת כתיב שנכשלת בשקט (דוח שדה סבב 3 #6).' % n_vis)
                continue
            card_props = set(mine[card].keys())
            gset, gcount = gsec.get(card, [set(), 0])
            for item in items:
                if not isinstance(item, dict):
                    continue
                for prop in (item.get('properties') or {}):
                    if prop in card_props or prop in gset:
                        continue
                    if gcount >= 10:
                        add('err', 'M-28', vj_path,
                            "מאפיין לא מאומת: %s.%s.%s — '%s'" % (vt, card, prop, prop),
                            "המאפיין לא נצפה בכרטיס '%s' באף יצוא בקורפוס (%d תצפיות על "
                            'הכרטיס) — כמעט בוודאות ניחוש/שגיאת כתיב (דוח שדה סבב 3 #6).'
                            % (card, gcount))
                    else:
                        add('info', 'M-28', vj_path,
                            "מאפיין לא מאומת בכרטיס דל-דגימה: %s.%s.%s — '%s'"
                            % (vt, card, prop, prop),
                            'הכרטיס דל-תצפיות בקורפוס; לוודא ב-Desktop.')

def _check_expr_shapes(obj, path, ext_entities, model_tables, theme_colors=None):
    """R-87 · הפניות Measure להרחבה; R-90 · Literal.Value מעוות; R-88 · scopeId+Measure.

    מחזיר מספר שגיאות ברמת err שנוספו (הקורא מוריד את ok).
    """
    errs = [0]

    def cb(node):
        mexpr = node.get('Measure')
        if isinstance(mexpr, dict):
            sr = ((mexpr.get('Expression') or {}).get('SourceRef') or {})
            schema = sr.get('Schema')
            ent = sr.get('Entity')
            prop = mexpr.get('Property')
            if schema == 'extension':
                if ent not in ext_entities:
                    add('err', 'R-87', path,
                        "expr.Measure עם Schema extension מפנה ל-entity '%s' שלא קיים "
                        'ב-reportExtensions.json' % ent,
                        'מדדי הרחבה חייבים להיות רשומים תחת entities[] ב-definition/'
                        'reportExtensions.json — הפניה ל-entity חסר = ויזואל שבור. '
                        'מקור: data-goblin/power-bi-agentic-development v26.31.0 '
                        '(GPL-3.0), schema-patterns/expressions.md.')
                    errs[0] += 1
                elif prop and ext_entities.get(ent) and prop not in ext_entities[ent]:
                    add('err', 'R-87', path,
                        "expr.Measure מפנה למדד ההרחבה '%s'.'%s' — המדד לא רשום בישות"
                        % (ent, prop),
                        'הישות קיימת ב-reportExtensions.json אבל המדד לא מופיע '
                        'תחת measures[] שלה — ההפניה תישבר. מקור: data-goblin '
                        'v26.31.0 (GPL-3.0), schema-patterns/expressions.md.')
                    errs[0] += 1
            elif ent and ent in ext_entities and                     (not model_tables or ent not in model_tables):
                add('err', 'R-87', path,
                    "expr.Measure לישות ההרחבה '%s' בלי Schema:\"extension\"" % ent,
                    "בלי Schema:\"extension\" המנוע מחפש את הישות במודל הסמנטי "
                    'ולא מוצא — הפניה שבורה בשקט. מקור: data-goblin v26.31.0 '
                    '(GPL-3.0), schema-patterns/expressions.md § Extension Measure.')
                errs[0] += 1
        lit = node.get('Literal')
        if isinstance(lit, dict) and 'Value' in lit:
            v = lit.get('Value')
            if not isinstance(v, str):
                add('err', 'R-90', path,
                    'Literal.Value אינו מחרוזת (%s)' % type(v).__name__,
                    'סכמת semanticQuery 1.4.0 דורשת ש-Value תמיד יהיה מחרוזת '
                    '(מספר עם סיומת סוג, למשל "50D"). ערך JSON גולמי נדחה. '
                    'מקור: data-goblin v26.31.0 (GPL-3.0), expressions.md § Literal.')
                errs[0] += 1
            else:
                low = v.lower()
                if low in ('true', 'false') and v != low:
                    add('err', 'R-90', path,
                        "Literal.Value בוליאני באותיות גדולות: '%s'" % v,
                        "בוליאניים חייבים להיות lowercase בלבד ('true'/'false') — "
                        "'%s' לא יתפרסר. מקור: data-goblin v26.31.0 (GPL-3.0), "
                        'expressions.md § Boolean Literals.' % v)
                    errs[0] += 1
                elif _LIT_NUM.match(v):
                    add('err', 'R-90', path,
                        "Literal.Value מספרי בלי סיומת סוג: '%s'" % v,
                        'מספרים חייבים סיומת סוג: D (decimal), L (long) או M (money) '
                        '— למשל "50D". בלי סיומת הערך נדחה. מקור: data-goblin '
                        'v26.31.0 (GPL-3.0), expressions.md § Numeric Literals.')
                    errs[0] += 1
        tdc = node.get('ThemeDataColor')
        if isinstance(tdc, dict):
            cid = tdc.get('ColorId')
            pct = tdc.get('Percent')
            if isinstance(pct, (int, float)) and not isinstance(pct, bool) and \
                    not (-1.0 <= pct <= 1.0):
                add('err', 'R-89', path,
                    'ThemeDataColor.Percent מחוץ לתחום: %s' % pct,
                    'Percent הוא התאמה/הכהייה של צבע ה-theme בטווח [-1,1] בלבד '
                    '(שלילי = כהה יותר). ערך מחוץ לתחום נדחה. מקור: data-goblin '
                    'v26.31.0 (GPL-3.0), expressions.md § ThemeDataColor.')
                errs[0] += 1
            if theme_colors is not None and isinstance(cid, int) and \
                    not isinstance(cid, bool) and (cid < 0 or cid >= theme_colors):
                add('err', 'R-89', path,
                    'ThemeDataColor.ColorId=%s מעבר ל-dataColors של ה-theme (%d צבעים)'
                    % (cid, theme_colors),
                    'ColorId הוא אינדקס 0-based לתוך מערך dataColors של ה-theme; '
                    'אינדקס מחוץ לתחום = צבע שבור. מקור: data-goblin v26.31.0 '
                    '(GPL-3.0), expressions.md § ThemeDataColor.')
                errs[0] += 1
        qr = node.get('queryRef')
        fld = node.get('field')
        if isinstance(qr, str) and isinstance(fld, dict) and qr != 'select':
            if set(fld) == {'Column'} or set(fld) == {'Measure'}:
                inner = fld.get('Column') or fld.get('Measure')
                if isinstance(inner, dict):
                    sr2 = ((inner.get('Expression') or {}).get('SourceRef') or {})
                    ent2, prop2 = sr2.get('Entity'), inner.get('Property')
                    if ent2 and prop2 and qr != '%s.%s' % (ent2, prop2):
                        add('warn', 'R-91', path,
                            "queryRef '%s' אינו '%s.%s' של ה-field שלו"
                            % (qr, ent2, prop2),
                            'queryRef מחזיק "טבלה.שדה" — אי-התאמה היא שארית קלאסית '
                            'של rename שעודכן ב-field אך לא ב-queryRef; selectors '
                            'ומיון שמכוונים ל-queryRef לא יתאימו. מקור: data-goblin '
                            'v26.31.0 (GPL-3.0), renames.md § Reference fields.')
        sel = node.get('selector')
        if isinstance(sel, dict):
            data = sel.get('data') or []
            for dsel in data:
                dv = (dsel.get('dataViewWildcard') or {}) if isinstance(dsel, dict) else {}
                if dv.get('matchingOption') == 0:
                    props0 = node.get('properties')
                    hit0 = []
                    if isinstance(props0, dict):
                        def pcb0(n2):
                            if isinstance(n2.get('Measure'), dict) or \
                                    isinstance(n2.get('Conditional'), dict):
                                hit0.append(1)
                        _walk(props0, pcb0)
                    if hit0:
                        add('warn', 'R-94', path,
                            'dataViewWildcard עם matchingOption:0 לצד expr מסוג '
                            'Measure/Conditional',
                            'matchingOption:0 תואם סידרות וטוטלים (עיצוב ברמת סידרה); '
                            'עיצוב מותנה פר-נקודה דורש matchingOption:1 — אחרת ה-CF '
                            'לא יחול פר-נקודה. מקור: data-goblin v26.31.0 (GPL-3.0), '
                            'selectors.md § dataViewWildcard.')
            if any(isinstance(d, dict) and 'scopeId' in d for d in data):
                props = node.get('properties')
                hit = []
                if isinstance(props, dict):
                    def pcb(n2):
                        if isinstance(n2.get('Measure'), dict):
                            hit.append(1)
                    _walk(props, pcb)
                if hit:
                    add('warn', 'R-88', path,
                        'selector מסוג scopeId עם expr מסוג Measure — לא יוחל',
                        'scopeId מקבל ערכים ליטרליים בלבד; ביטוי Measure תחת scopeId '
                        'נדחק בשקט (מתועד עבור strokeColor). לעבור ל-metadata selector '
                        'או ל-dataViewWildcard עם matchingOption:1. מקור: data-goblin '
                        'v26.31.0 (GPL-3.0), measures-and-literals.md § scopeId.')

            md = sel.get('metadata')
            if isinstance(md, str) and md.startswith('SparklineData(') and model_tables:
                mm = re.match(r'^SparklineData\((.+?)_\[(.+)\]\)$', md)
                if mm:
                    me_ent, _sep, me_name = mm.group(1).partition('.')
                    gr_ent = mm.group(2).split('.')[0]
                    if me_ent not in model_tables or \
                            me_name not in model_tables[me_ent].get('measures', set()):
                        add('err', 'R-92', path,
                            "SparklineData selector מפנה למדד '%s' שלא קיים במודל" % mm.group(1),
                            'מחרוזת ה-metadata הקומפקטית מטמיעה הפניה למדד; מדד חסר = '
                            'עיצוב ה-sparkline שבור. מקור: data-goblin v26.31.0 '
                            '(GPL-3.0), renames.md § SparklineData.')
                        errs[0] += 1
                    if gr_ent not in model_tables:
                        add('err', 'R-92', path,
                            "SparklineData selector מפנה לטבלת קיבוץ '%s' שלא קיימת במודל" % gr_ent,
                            'החלק _[Entity.Hierarchy.Level] מטמיע הפניה לטבלת הקיבוץ; '
                            'טבלה חסרה = ה-sparkline שבור. מקור: data-goblin v26.31.0 '
                            '(GPL-3.0), renames.md § SparklineData.')
                        errs[0] += 1

    _walk(obj, cb)
    return errs[0]


def _scan_cf(o, hits):

    """סריקה רקורסיבית של objects: FillRule linearGradient3 בלי mid (R-70) ושמות
    מאפיינים פיקטיביים (R-72). hits = dict עם מונים."""
    if isinstance(o, dict):
        fr = o.get('FillRule')
        if isinstance(fr, dict):
            lg3 = fr.get('linearGradient3')
            if isinstance(lg3, dict) and 'mid' not in lg3:
                hits['g3_no_mid'] += 1
        for k, v in o.items():
            if k in _CF_PHANTOM_PROPS:
                hits['phantom'].append(k)
            _scan_cf(v, hits)
    elif isinstance(o, list):
        for v in o:
            _scan_cf(v, hits)


# ══════════════════════════ קריאת מודל (מינימלית — לצולבות בלבד) ══════════════════════════
DECOR = {'image', 'shape', 'textbox', 'actionButton', 'pageNavigator', 'basicShape',
         'bookmarkNavigator', 'group'}
# סוגים קומפקטיים מעצם טבעם — סליסר שורה ~38px וכרטיס KPI ~44px לגיטימיים
# (כיול קורפוס 7 דוחות אמיתיים, סבב 53). מינימום קריא לא חל עליהם.
COMPACT_VT = {'slicer', 'advancedSlicerVisual', 'card', 'cardVisual', 'multiRowCard',
              'kpi', 'kpiVisual'}

_DECL = re.compile(r"^(column|measure)\s+(?:'((?:[^']|'')+)'|([^\s=]+))")


def read_model_map(sm_dir):
    """{שם טבלה: {'columns': set, 'measures': set, 'col_types': {עמודה: dataType}}} —
    קישורי שדות + בדיקות מבוססות-טיפוס (למשל R-45)."""
    tables = {}
    for f in sorted(glob.glob(os.path.join(sm_dir, 'definition', 'tables', '*.tmdl'))):
        name = os.path.splitext(os.path.basename(f))[0]
        cols, measures, col_types = set(), set(), {}
        try:
            with open(f, encoding='utf-8-sig', errors='ignore') as fh:
                lines = fh.read().splitlines()
        except OSError as e:
            add('err', 'M-READ', f, 'לא ניתן לקרוא את קובץ הטבלה', str(e))
            continue
        for i, ln in enumerate(lines):
            s = ln.strip()
            if s.startswith('table '):
                name = _unq(s[6:])
                continue
            m = _DECL.match(s)
            if m:
                raw = m.group(2) if m.group(2) is not None else (m.group(3) or '')
                obj = _unq("'" + raw + "'" if m.group(2) is not None else raw)
                (cols if m.group(1) == 'column' else measures).add(obj)
                if m.group(1) == 'column':
                    ind = len(ln) - len(ln.lstrip('\t '))
                    j = i + 1
                    while j < len(lines) and (not lines[j].strip() or
                                              len(lines[j]) - len(lines[j].lstrip('\t ')) > ind):
                        dm = re.match(r"\s*dataType:\s*(\w+)", lines[j])
                        if dm:
                            col_types[obj] = dm.group(1)
                            break
                        j += 1
        tables[name] = {'columns': cols, 'measures': measures, 'col_types': col_types, 'file': f}
    return tables


def read_relationship_endpoints(sm_dir):
    """רשימת (from, to, active) — מ-relationships.tmdl וגם קשרים inline בתוך
    model.tmdl (מבנה התיקיות של TMDL הוא ברירת-מחדל בלבד; MS Learn tmdl-overview).
    מניעת FP ב-M-03/M-12/M-15 על מודלים עם קשרים inline (סבב 111 עשה זאת בסוקר)."""
    rels = []
    for rf in (os.path.join(sm_dir, 'definition', 'relationships.tmdl'),
               os.path.join(sm_dir, 'definition', 'model.tmdl')):
        if not os.path.exists(rf):
            continue
        with open(rf, encoding='utf-8-sig', errors='ignore') as fh:
            txt = fh.read()
        for blk in re.split(r'\n(?=relationship )', txt):
            if not blk.strip().startswith('relationship'):
                continue

            def _p(prop):
                m = re.search(r"^\s*" + prop + r":\s*(.+)$", blk, re.M)
                return m.group(1).strip() if m else ''
            # שומרים גם קצוות ריקים — M-03 מדווח 'קצה קשר בלתי קריא'
            rels.append((_p('fromColumn'), _p('toColumn'),
                         _p('isActive').lower() != 'false'))
    return rels


def read_role_permissions(sm_dir):
    """רשימת (קובץ, תפקיד, טבלה, ביטוי) מ-definition/roles/*.tmdl — לבדיקת RLS מול המודל.
    צורה אומתה מול ייצוא Desktop אמיתי (SpaceParts ב-data-goblin/power-bi-agentic-development):
    role 'Name'  /  tablePermission Table = <DAX>"""
    perms = []
    for f in sorted(glob.glob(os.path.join(sm_dir, 'definition', 'roles', '*.tmdl'))):
        try:
            with open(f, encoding='utf-8-sig', errors='ignore') as fh:
                txt = fh.read()
        except OSError:
            continue
        role = ''
        m = re.match(r"\s*role\s+(.+)$", txt, re.M)
        if m:
            role = _unq(m.group(1).strip())
        for tp in re.finditer(r"tablePermission\s+(?:'((?:[^']|'')+)'|([^\s=]+))\s*=\s*(.+)", txt):
            tbl = _unq("'" + tp.group(1) + "'") if tp.group(1) is not None else tp.group(2)
            perms.append((f, role, tbl, tp.group(3).strip()))
    return perms


def _split_ref(ref):
    """'fact x'.מק"ט → ('fact x', 'מק"ט')."""
    if '.' not in ref:
        return None, None
    t, c = ref.rsplit('.', 1)
    return _unq(t), _unq(c)


def _check_filter_shape(f, loc, desc, level):
    """בדיקות צורה של רשומת מסנן (מקור: MS skills-for-fabric filters.md).
    level: 'visual' | 'page' | 'report'. מחזיר False אם נמצאה שגיאה."""
    ok = True
    if f.get('type') == 'TopN':
        # TopN חוקי ברמת ויזואל בלבד; OrderBy חייב Aggregation מסביב לעמודה
        if level != 'visual':
            add('err', 'R-30', loc, 'מסנן TopN ברמת %s' % desc,
                'TopN חוקי כמסנן ויזואל בלבד — Desktop דוחה/מתעלם ברמת דף/דוח.')
            ok = False

        def _orderby(o):
            if isinstance(o, dict):
                for k, v in o.items():
                    if k == 'OrderBy' and isinstance(v, list):
                        for ob in v:
                            expr = (ob or {}).get('Expression')
                            if not (isinstance(expr, dict) and 'Aggregation' in expr):
                                add('err', 'R-30', loc,
                                    'OrderBy של TopN ב%s בלי Aggregation מסביב לעמודה' % desc,
                                    'עמודה גולמית ב-OrderBy של TopN = שגיאת Desktop '
                                    '(filters.md: "causes a Desktop error").')
                                return False
                    elif _orderby(v) is False:
                        return False
            elif isinstance(o, list):
                for v in o:
                    if _orderby(v) is False:
                        return False
            return True
        if _orderby(f) is False:
            ok = False

    # howCreated חובה על כל מסנן (filters.md: "must have")
    if 'howCreated' not in f:
        add('warn', 'R-31', loc, 'מסנן בלי howCreated ב%s' % desc,
            'מסנן בלי howCreated נכתב ביד — Desktop מצפה לשדה הזה ועלול לדחות את הרשומה.')

    # בתוך Where: SourceRef משתמש ב-"Source" (alias מ-From), לא ב-"Entity"
    def _where_refs(o):
        if isinstance(o, dict):
            for k, v in o.items():
                if k == 'SourceRef' and isinstance(v, dict) and 'Entity' in v:
                    return True
                if _where_refs(v):
                    return True
        elif isinstance(o, list):
            return any(_where_refs(v) for v in o)
        return False
    where = ((f.get('filter') or {}).get('Where')) or []
    if _where_refs(where):
        add('warn', 'R-32', loc,
            'SourceRef עם "Entity" בתוך Where של מסנן ב%s' % desc,
            'בתוך Where חובה "Source" (ה-alias מ-From) — "Entity" שם לא נרשם ע"י Desktop.')
    return ok


# קטלוג אייקונים חוקי (MS skills-for-fabric conditional-formatting.md) — שם לא חוקי
# מקריס את Desktop ("Unable to find resource").
VALID_ICONS = frozenset('CircleHigh CircleMedium CircleLow 4CircleMedium2 4CircleLow CircleFilled Circle75 CircleHalf Circle25 CircleEmpty CircleGreenPatternFill CircleYellowPatternFill CircleRedPatternFill CircleBlackFill CircleGrayPatternFill CirclePurplePatternFill CircleGreenBlackBackgroundPatternFill CircleYellowBlackBackgroundPatternFill CircleRedBlackBackgroundPatternFill CircleGreenBlackOutlinePatternFill CircleYellowBlackOutlinePatternFill CircleRedBlackOutlinePatternFill SignMedium SignLow SymbolHigh SymbolMedium SymbolLow CircleSymbolHigh CircleSymbolMedium CircleSymbolLow TriangleHigh TriangleMedium TriangleLow ColoredArrowUp ColoredArrowUpRight ColoredArrowRight ColoredArrowDownRight ColoredArrowDown ColoredArrowUpRed ColoredArrowDownGreen GreyArrowUp GreyArrowUpRight GreyArrowRight GreyArrowDownRight GreyArrowDown TrafficHigh TrafficMedium TrafficLow TrafficBlackRimmed TrafficHighLight TrafficMediumLight TrafficLowLight TrafficBlackRimmedLight FlagHigh FlagMedium FlagLow FlagBlack FlagGreenPatternFill FlagYellowPatternFill FlagRedPatternFill StarHigh StarMedium StarLow StarHighLight StarMediumLight SignalBarFull SignalBarMedium2 SignalBarMedium SignalBarLow SignalBarEmpty SignalBarFullColored SignalBarMedium2Colored SignalBarMediumColored SignalBarLowColored QuadrantFull Quadrant75 Quadrant50 Quadrant25 QuadrantEmpty QuadrantFullColored Quadrant75Colored Quadrant50Colored Quadrant25Colored'.split())

# שמות מאויישים בהזיה — לא קיימים ב-schema ונזרקים בשקט (MS conditional-formatting.md)
HALLUCINATED_CF_PROPS = ('backColorRule', 'fontColorRule', 'iconRule', 'iconDefinition')

# ערכי scaling חוקיים לתמונות רקע (MS page-formatting.md)
VALID_SCALING = frozenset(('Fit', 'Stretch', 'Fill'))
# מצבי filterCard חוקיים — PascalCase חובה, אחרת נזרק בשקט (MS filter-pane.md)
FILTER_CARD_STATES = frozenset(('Applied', 'Available'))
# רשימות המאפיינים המלאות של פאנל הסינון (MS skills-for-fabric filter-pane.md —
# "All 12 properties" / "8 properties per state"); שם לא ברשימה נזרק בשקט
OUTSPACE_PANE_PROPS = frozenset(('backgroundColor', 'transparency', 'foregroundColor',
                                 'titleSize', 'headerSize', 'searchTextSize', 'fontFamily',
                                 'border', 'borderColor', 'checkboxAndApplyColor',
                                 'inputBoxColor', 'width'))
FILTER_CARD_PROPS = frozenset(('backgroundColor', 'transparency', 'foregroundColor',
                               'textSize', 'fontFamily', 'inputBoxColor',
                               'border', 'borderColor'))
# אובייקטים שלא תומכים בסלקטור בכלל — selector עליהם מיותר (MS formatting.md)
NO_SELECTOR_OBJECTS = frozenset(('legend', 'categoryAxis', 'valueAxis', 'title', 'background', 'border'))

# stylePresets מובנים לטבלאות (MS table.md); Default/AlternatingRowsNew — tableEx בלבד
TABLE_STYLE_PRESETS = frozenset(('None', 'Minimal', 'BoldHeader', 'AlternatingRows',
                                 'ContrastAlternatingRows', 'FlashyRows',
                                 'BoldHeaderFlashyRows', 'Sparse', 'Condensed'))
TABLEEX_ONLY_PRESETS = frozenset(('Default', 'AlternatingRowsNew'))

# cardVisual: אובייקטי פורמט הדורשים selector {id:'default'} — בלעדיו נכשלים בשקט
# (MS skills-for-fabric card.md). cardCalloutArea/referenceLabel/referenceLabelLayout פטורים.
CARDVISUAL_SELECTOR_REQUIRED = frozenset(
    'value label accentBar outline padding spacing divider fillCustom shadowCustom '
    'glowCustom image layout referenceLabelTitle referenceLabelValue referenceLabelDetail'.split())

# visualType מיושן — card ו-multiRowCard הם legacy והוחלפו ב-cardVisual (MS card.md)
DEPRECATED_VISUALS = {'card': 'cardVisual', 'multiRowCard': 'cardVisual'}

# משפחת הקווים/שטחים — lineStyles חוקי רק בהם (MS skills-for-fabric cartesian.md)
LINE_STYLE_VISUALS = frozenset(('areaChart', 'lineChart', 'stackedAreaChart',
                                'lineStackedColumnComboChart', 'lineClusteredColumnComboChart',
                                'hundredPercentStackedAreaChart'))
# markers זמין על כל משפחת הקו/שטח + scatterChart (MS cartesian.md)
MARKER_VISUALS = LINE_STYLE_VISUALS | frozenset(('scatterChart',))
# ערכי enum חוקיים בתוך lineStyles (MS cartesian.md)
LINE_STYLE_ENUMS = {
    'lineStyle': frozenset(('solid', 'dashed', 'dotted', 'custom')),
    'markerShape': frozenset(('circle', 'square', 'diamond', 'triangle', 'x',
                              'shortDash', 'longDash', 'plus')),
    'lineChartType': frozenset(('linear', 'smooth', 'step')),
}

# ribbonBands קיים רק ב-stacked bar/column; totals (תוויות סכום) — גם, ובטבלאות/
# matrices יש אובייקט totals לגיטימי משלהם, לכן שם לא מסמנים (MS skills-for-fabric
# cartesian.md + ידיעת הפורמט של tableEx)
STACKED_VISUALS = frozenset(('barChart', 'columnChart'))
TABLE_FAMILY = frozenset(('tableEx', 'table', 'pivotTable', 'matrix'))

# data.mode חוקי לסליסרים + טיפוס השדה הנדרש לכל מצב (MS skills-for-fabric slicers.md)
# 'RelativeDatePicker' אומת כערך ש-Desktop כותב בייצוא אמיתי (advw בקורפוס, סבב 75) —
# קטלוג slicers.md מתעד 'Relative'; שתי המשפחות חוקיות בפועל.
SLICER_MODES = frozenset(('Dropdown', 'Basic', 'Between', 'Single', 'Before', 'After',
                          'Relative', 'RelativeDatePicker', 'RelativeTime'))
_DATE_TYPES = frozenset(('dateTime', 'date'))
_NUMERIC_TYPES = frozenset(('int64', 'integer', 'decimal', 'double', 'currency'))
SLICER_MODE_TYPES = {
    'Between': _DATE_TYPES,
    'Before': _DATE_TYPES | _NUMERIC_TYPES,
    'After': _DATE_TYPES | _NUMERIC_TYPES,
    'Relative': _DATE_TYPES,
    'RelativeDatePicker': _DATE_TYPES,
    'RelativeTime': frozenset(('dateTime',)),
}


def _collect_rpi(o, loc, vname, out):
    """איסוף הפניות ResourcePackageItem (תמונות) מכל עץ — לצross-ref מול report.json (R-43)."""
    if isinstance(o, dict):
        for k, v in o.items():
            if k == 'ResourcePackageItem' and isinstance(v, dict):
                out.append((loc, vname, v.get('ItemName'), v.get('PackageName')))
            else:
                _collect_rpi(v, loc, vname, out)
    elif isinstance(o, list):
        for v in o:
            _collect_rpi(v, loc, vname, out)


def _image_prop_issues(props, loc, vname):
    """R-37/38 · מאפיין image בתוך properties: חובה מבנה מקונן image.image.{name,url,scaling}
    (שטוח נכשל בשקט), ו-scaling חייב Fit/Stretch/Fill. מקור: MS page-formatting.md / image.md."""
    img = props.get('image')
    if not isinstance(img, dict):
        return True
    inner = img.get('image')
    if not isinstance(inner, dict):
        if any(k2 in img for k2 in ('name', 'url', 'scaling')):
            add('warn', 'R-37', loc,
                "מבנה image שטוח ב'%s' — לא ירנדר" % vname,
                'חובה מבנה מקונן image.image.name/url/scaling; מבנה שטוח נכשל בשקט (MS).')
            return False
        return True
    sc = ((((inner.get('scaling') or {}).get('expr') or {}).get('Literal') or {}).get('Value'))
    if isinstance(sc, str):
        val = sc.strip("'")
        if val and val not in VALID_SCALING:
            add('err', 'R-38', loc,
                "scaling '%s' לא חוקי ב'%s'" % (val, vname),
                'ערכים חוקיים: Fit / Stretch / Fill (MS).')
            return False
    return True


def _check_page_objects(pobj, pj_path, d):
    """R-36/37/38/39/41 · page.json objects: background/outspace בלי show (ה-schema דוחה),
    image מקונן + scaling חוקי, filterCard selector.id ב-PascalCase, בלי selector על
    אובייקטים שלא תומכים. מקור: MS page-formatting.md / filter-pane.md / formatting.md."""
    ok = True
    objects = pobj.get('objects')
    if not isinstance(objects, dict):
        return ok
    for key in ('background', 'outspace'):
        entries = objects.get(key) or []
        if not isinstance(entries, list):
            continue
        for entry in entries:
            if not isinstance(entry, dict):
                continue
            props = entry.get('properties') or {}
            if isinstance(props, dict) and 'show' in props:
                add('err', 'R-36', pj_path,
                    "'show' בתוך objects.%s של דף '%s'" % (key, d),
                    'רקע דף/wallpaper תמיד גלוי — אין show ברמת דף וה-schema דוחה אותו; '
                    'show קיים רק ב-VCO של ויזואל (MS).')
                ok = False
            if isinstance(props, dict) and _image_prop_issues(props, pj_path, "%s בדף '%s'" % (key, d)) is False:
                ok = False
    entries = objects.get('filterCard') or []
    if isinstance(entries, list):
        for entry in entries:
            if not isinstance(entry, dict):
                continue
            sel = entry.get('selector')
            if isinstance(sel, dict) and 'id' in sel and sel['id'] not in FILTER_CARD_STATES:
                add('warn', 'R-39', pj_path,
                    "filterCard selector.id='%s' בדף '%s'" % (sel['id'], d),
                    "חובה PascalCase: 'Applied' או 'Available' — ערך אחר נזרק בשקט (MS).")
    # R-56 · שמות מאפיינים מול הרשימה הסגורה של MS — שם לא מוכר נזרק בשקט
    for key56, allowed in (('outspacePane', OUTSPACE_PANE_PROPS),
                           ('filterCard', FILTER_CARD_PROPS)):
        for entry in objects.get(key56) or []:
            if not isinstance(entry, dict):
                continue
            props = entry.get('properties') or {}
            if not isinstance(props, dict):
                continue
            for pname in props:
                if pname not in allowed:
                    add('warn', 'R-56', pj_path,
                        "מאפיין '%s' ב-objects.%s של דף '%s' — לא ברשימה הסגורה של MS"
                        % (pname, key56, d),
                        'outspacePane: 12 מאפיינים; filterCard: 8. שם לא מוכר (למשל '
                        'הזיה של LLM) נזרק בשקט (MS filter-pane.md).')
    # R-78 (צד דף) · אובייקטים שהם VCO בלבד (title/subTitle/border/...) בתוך
    # page.json objects — בדף הם לא קיימים (background חוקי בשני הצדדים)
    # (MS formatting.md § Page Objects vs VCO, סבב 86).
    for key78 in sorted((VCO_KEYS - {'background'}) & set(objects.keys())):
        add('warn', 'R-78', pj_path,
            "אובייקט VCO '%s' בתוך page.json של דף '%s' — לא קיים ברמת דף" % (key78, d),
            'title/subTitle/border וכד׳ הם מאפייני מכולת-ויזואל (visualContainerObjects '
            'בתוך visual.json) בלבד; ב-page.json הם נזרקים (MS formatting.md § Page '
            'Objects vs Visual Container Objects).')
    for key in NO_SELECTOR_OBJECTS:
        entries = objects.get(key) or []
        if not isinstance(entries, list):
            continue
        for entry in entries:
            if isinstance(entry, dict) and 'selector' in entry:
                add('warn', 'R-41', pj_path,
                    "selector על '%s' בדף '%s' — האובייקט לא תומך בסלקטורים" % (key, d),
                    'legend/categoryAxis/valueAxis/title/background/border — להשמיט את ה-selector (MS).')
    return ok


# 15 מפתחות VCO חוקיים (MS formatting.md § VCO Property Reference, סבב 86)
VCO_KEYS = frozenset({'title', 'subTitle', 'divider', 'spacing', 'background',
                      'padding', 'lockAspect', 'general', 'border', 'dropShadow',
                      'visualLink', 'visualTooltip', 'stylePreset', 'visualHeader',
                      'visualHeaderTooltip'})
# אובייקטים של דף בלבד — אין להם מקום ב-visualContainerObjects של ויזואל
PAGE_ONLY_OBJECTS = frozenset({'outspace', 'outspacePane', 'filterCard'})

def _has_conditional(v):
    """האם בעץ הערך יש Conditional/FillRule/Icon — סימן לפורמט מותנה."""
    if isinstance(v, dict):
        for k, val in v.items():
            if k in ('Conditional', 'FillRule') or (k == 'kind' and val == 'Icon'):
                return True
            if _has_conditional(val):
                return True
    elif isinstance(v, list):
        return any(_has_conditional(x) for x in v)
    return False


def _check_objects(o, loc, vname, vt):
    """הליכה אחת על עץ ה-objects: גרדיאנטים (R-29), סלקטורים של פורמט מותנה (R-33),
    שמות אייקונים (R-34), שמות מאפיינים מומצאים (R-35). מקור: MS conditional-formatting.md."""
    ok = True
    if isinstance(o, dict):
        for k, v in o.items():
            if k == 'linearGradient3' and isinstance(v, dict) and 'mid' not in v:
                add('err', 'R-29', loc,
                    "linearGradient3 בלי 'mid' בוויזואל '%s'" % vname,
                    'גרדיאנט 3-תחנות חייב min+mid+max; חסר mid = שגיאת רינדור או גוף '
                    'טבלה ריק. צריך שתי תחנות? linearGradient2.')
                ok = False
            if k in NO_SELECTOR_OBJECTS and isinstance(v, list):
                for entry in v:
                    if isinstance(entry, dict) and 'selector' in entry:
                        add('warn', 'R-41', loc,
                            "selector על '%s' בוויזואל '%s' — האובייקט לא תומך בסלקטורים" % (k, vname),
                            'legend/categoryAxis/valueAxis/title/background/border — להשמיט את ה-selector (MS).')
            if vt == 'cardVisual' and k in CARDVISUAL_SELECTOR_REQUIRED and isinstance(v, list):
                entries = [e for e in v if isinstance(e, dict)]
                # כיול על ייצוא Desktop אמיתי: Desktop פולט רשומת reset ראשונה בלי
                # selector ואחריה רשומת id:default — חוקי. חריגה = רשומה עם properties
                # בלי selector כש**אף** רשומה לא נושאת id:default.
                has_default = any((e.get('selector') or {}).get('id') == 'default'
                                  for e in entries)
                for entry in entries:
                    if 'selector' not in entry and not has_default:
                        add('warn', 'R-47', loc,
                            "אובייקט '%s' ב-cardVisual '%s' בלי selector {id:'default'} — "
                            "המאפיינים נכשלים בשקט" % (k, vname),
                            'רוב אובייקטי cardVisual דורשים selector: {id:"default"}; בלעדיו '
                            'המאפיינים לא מיושמים (MS card.md). פטורים: cardCalloutArea/'
                            'referenceLabel/referenceLabelLayout.')
            if k == 'scopeId' and isinstance(v, dict):
                ck = (v.get('Comparison') or {}).get('ComparisonKind')
                if isinstance(ck, (int, float)) and not isinstance(ck, bool):
                    if ck >= 5:
                        add('err', 'R-40', loc,
                            "ComparisonKind=%s בסלקטור scopeId של '%s'" % (int(ck), vname),
                            'ערכים ≥5 = שגיאת schema; רק 0 (Equal) נתמך בסלקטור (MS).')
                        ok = False
                    elif ck != 0:
                        add('warn', 'R-40', loc,
                            "ComparisonKind=%s בסלקטור scopeId של '%s'" % (int(ck), vname),
                            'רק 0 (Equal) מיושם — 1..4 עוברים schema אך מתעלמים ברינדור (MS).')
            if k in HALLUCINATED_CF_PROPS:
                add('warn', 'R-35', loc,
                    "מאפיין '%s' בוויזואל '%s' לא קיים ב-schema — נזרק בשקט" % (k, vname),
                    'פורמט מותנה נכתב כ-Conditional.Cases בתוך המאפיין הרגיל '
                    '(backColor/fontColor/icon), לא במאפיין *Rule נפרד (MS).')
            if _check_objects(v, loc, vname, vt) is False:
                ok = False
        # רשומת CF: dict עם properties שמכיל פורמט מותנה
        props = o.get('properties')
        if isinstance(props, dict):
            is_cf = any(k2 in ('backColor', 'fontColor', 'icon') and _has_conditional(v2)
                        for k2, v2 in props.items())
            if _image_prop_issues(props, loc, "וויזואל '%s'" % vname) is False:
                ok = False
            if is_cf:
                sel = o.get('selector')
                if vt in ('tableEx', 'pivotTable'):
                    if not isinstance(sel, dict) or 'data' not in sel or 'metadata' not in sel:
                        add('warn', 'R-33', loc,
                            "פורמט מותנה בטבלה '%s' בלי selector מלא (data+metadata)" % vname,
                            'בטבלאות/matrices חובה גם data וגם metadata — כל אחד לבדו '
                            'נכשל בשקט והפורמט לא מיושם (MS).')
                elif isinstance(sel, dict) and 'metadata' in sel:
                    add('warn', 'R-33', loc,
                        "פורמט מותנה בוויזואל '%s' (%s) עם metadata בסלקטור" % (vname, vt),
                        'בתרשימים metadata בסלקטור גורמת כשל שקט — להסיר אותה (MS).')
                # R-34 · אייקונים
                icon = props.get('icon')
                if isinstance(icon, dict):
                    cases = (((icon.get('expr') or {}).get('Conditional') or {}).get('Cases')) or []
                    for case in cases:
                        lit = ((((case or {}).get('Value') or {}).get('Literal') or {}).get('Value'))
                        if isinstance(lit, str):
                            name = lit.strip("'")
                            if name and name not in VALID_ICONS:
                                add('err', 'R-34', loc,
                                    "אייקון '%s' לא בקטלוג בוויזואל '%s'" % (name, vname),
                                    'שם אייקון לא חוקי מקריס את Desktop ("Unable to find '
                                    'resource") — רק שמות מהקטלוג של MS.')
                                ok = False
    elif isinstance(o, list):
        for v in o:
            if _check_objects(v, loc, vname, vt) is False:
                ok = False
    return ok


def _filter_field_ref(f):
    """ממסנן PBIR: (kind, entity, property) או None. צורת field זהה לזו של projection
    (אומת מול ייצוא Desktop אמיתי: K201 ב-data-goblin/power-bi-agentic-development)."""
    fd = f.get('field')
    if not isinstance(fd, dict):
        return None
    for kind in ('Measure', 'Column'):
        node = fd.get(kind)
        if isinstance(node, dict) and node.get('Property'):
            try:
                sr = node['Expression']['SourceRef']
                if sr.get('Schema'):
                    return None  # extension measures — לא טבלת מודל
                return kind, sr.get('Entity', ''), str(node['Property'])
            except Exception:
                return None
    return None


def _check_ref(model_tables, kind, ent, prop, code, where, what):
    """בדיקת קישור שדה מול המודל (משותף ל-R-15 ול-R-22)."""
    if not model_tables or not ent:
        return True
    if ent not in model_tables:
        add('err', code, where,
            "%s מקושר לטבלה '%s' שלא קיימת במודל" % (what, ent),
            'שדה שמפנה לטבלה חסרה = שבירה שקטה אחרי שינוי שם טבלה ב-TMDL.')
        return False
    t = model_tables[ent]
    if prop not in t['columns'] and prop not in t['measures']:
        add('warn', code, where,
            "%s מקושר ל-%s[%s] שלא נמצא בטבלה" % (what, ent, prop),
            'ייתכן שינוי שם עמודה/מדד — %s יפסיק לעבוד בשקט.' % what)
    return True


# ══════════════════════════ בדיקות דוח (PBIR) ══════════════════════════
def validate_report(report_dir, model_tables=None):
    ok = True
    theme_presets = _theme_presets(report_dir)
    ext_entities = _read_extension_entities(report_dir)
    theme_colors = _theme_data_colors(report_dir)

    # R-01 · definition.pbir תקין
    pbir = os.path.join(report_dir, 'definition.pbir')
    if not os.path.exists(pbir):
        add('err', 'R-01', pbir, 'חסר definition.pbir', 'בלעדיו Desktop לא יפתח את הדוח.')
        ok = False
    else:
        obj, err = _load_json(pbir)
        if err:
            add('err', 'R-01', pbir, 'definition.pbir — JSON שבור', err)
            ok = False
        elif not obj.get('version'):
            add('warn', 'R-01', pbir, 'definition.pbir בלי שדה version',
                'הפורמט מצפה ל-version (למשל "4.0").')

        # R-84 · datasetReference.byPath חייב להיות יחסי ולהצביע לתיקיית מודל
        # קיימת. נתיב שבור = "הדוח לא מוצא את המודל" בפתיחה; נתיב מוחלט =
        # נעול למכונה של הכותב. מקור: Adam-pd/pbip-doctor rules/pbip.py —
        # PBIP002/PBIP005 (MIT, ריפו חדש); מקביל: pbi-assure PBI-MODEL-002.
        byp = (((obj or {}).get('datasetReference') or {}).get('byPath') or {}).get('path')
        if byp:
            if re.match(r'^(?:[A-Za-z]:[\\/]|\\\\|/)', byp):
                add('warn', 'R-84', pbir,
                    'datasetReference.byPath מוחלט — נעול למכונה של הכותב',
                    'נתיב מודל מוחלט ב-definition.pbir לא נייד למכונה/CI אחרים. '
                    'ערך הנתיב אינו מוצג (פרטיות). להחליף לנתיב יחסי '
                    '(למשל "../MyModel.SemanticModel").')
            else:
                tgt = os.path.normpath(os.path.join(report_dir, byp))
                if not os.path.isdir(tgt):
                    add('err', 'R-84', pbir,
                        "datasetReference.byPath מפנה ל-'%s' — התיקייה לא קיימת" % byp,
                        'הדוח לא ימצא את המודל בפתיחה. לתקן את הנתיב היחסי או '
                        'לשחזר את תיקיית המודל (*.SemanticModel / *.Dataset).')
                    ok = False
                elif not (tgt.endswith('.SemanticModel') or tgt.endswith('.Dataset')):
                    add('warn', 'R-84', pbir,
                        "datasetReference.byPath מצביע ל-'%s' — לא תיקיית מודל" % byp,
                        'היעד קיים אבל אינו *.SemanticModel/*.Dataset — Desktop '
                        'צפוי להיכשל בקישור הדוח למודל.')

    for fp in _local_artifacts(report_dir):
        add('warn', 'R-85', fp,
            "פריט מקומי '%s' בתוך תיקיית הדוח" % os.path.basename(fp),
            'קבצי .pbi/localSettings.json ו-cache.abf הם artifacts מקומיים של '
            'Desktop (MS Learn projects-overview, CC-BY-4.0). למחוק ולהוסיף '
            'ל-.gitignore.')

    # R-80 · פריסת PBIP מדור קודם (PBIR 1.x): report.json בשורש .Report בלי
    # definition/ בכלל. פריסה חוקית אך ישנה — אימות מבנה PBIR לא רלוונטי, ובלעדי
    # הזיהוי הכללים R-02/R-03/R-04 מפליטים מפל של "קבצים חסרים" מטעה.
    # מקור: NatVanG/PBI-Inspector (MIT) — fixtures בפריסת legacy
    # (definition.pbir "version": "1.0", report.json בשורש, model.bim במודל).
    legacy_layout = (not os.path.isdir(os.path.join(report_dir, 'definition'))) and \
                    os.path.exists(os.path.join(report_dir, 'report.json'))
    if legacy_layout:
        add('warn', 'R-80', os.path.join(report_dir, 'report.json'),
            'פריסת PBIP מדור קודם (PBIR 1.x) — report.json בשורש .Report, ללא definition/',
            'פריסה חוקית אך ישנה; אימות מבנה PBIR לא רלוונטי כאן (הסוקר גם מדלג על '
            'דוחות כאלה). שמירה מחדש ב-Desktop ממירה לפריסת PBIR מפורקת. '
            'מקור: NatVanG/PBI-Inspector (MIT) — fixtures של legacy layout.')

    # R-02 · version.json חובה
    ver = os.path.join(report_dir, 'definition', 'version.json')
    if legacy_layout:
        pass  # R-80 כבר דיווח — פריסה ישנה, לא קובץ חסר
    elif not os.path.exists(ver):
        add('warn', 'R-02', ver, 'חסר definition/version.json',
            'קובץ חובה בפורמט PBIR (מטא-דאטה של גרסת הפורמט). Desktop בדרך כלל סולח, '
            'אבל כלי צד-שלישי עלולים להיכשל.')
    else:
        obj, err = _load_json(ver)
        if err:
            add('err', 'R-02', ver, 'version.json — JSON שבור', err)
            ok = False

    # R-03 · report.json תקין
    rj_path = os.path.join(report_dir, 'definition', 'report.json')
    report_filters = []
    rj_obj = None
    rpi_refs = []
    if legacy_layout:
        pass  # R-80
    elif not os.path.exists(rj_path):
        add('err', 'R-03', rj_path, 'חסר definition/report.json', 'קובץ חובה בפורמט PBIR.')
        ok = False
    else:
        obj, err = _load_json(rj_path)
        if err:
            add('err', 'R-03', rj_path, 'report.json — JSON שבור', err)
            ok = False
        else:
            report_filters = (obj.get('filterConfig') or {}).get('filters') or []
            rj_obj = obj
            if _check_expr_shapes(obj, rj_path, ext_entities, model_tables, theme_colors):
                ok = False
            # R-82 · מפתח 'filters' ברמת השורש (schema 2.1.0+ מצפה ל-filterConfig
            # כעוגן הסינון) — מבלבל את Desktop; לא לערבב פורמטים באותו פרויקט
            # (powerbi-report-mcp pbir-gotchas.md Q3, MIT).
            if isinstance(obj.get('filters'), list):
                add('warn', 'R-82', rj_path,
                    "report.json עם מפתח 'filters' ברמת השורש",
                    'ב-schema 2.1.0+ עוגן הסינון הוא filterConfig.filters; מפתח '
                    "'filters' עצמאי עלול לבלבל את Desktop. לעבור ל-filterConfig "
                    '(או להשמיט לחלוטין כשאין מסננים). מקור: powerbi-report-mcp '
                    'pbir-gotchas.md Q3 (MIT).')

    # R-04 · pages.json: pageOrder מול תיקיות הדפים בפועל
    pages_root = os.path.join(report_dir, 'definition', 'pages')
    pj_path = os.path.join(pages_root, 'pages.json')
    page_dirs = sorted(d for d in os.listdir(pages_root) if os.path.isdir(os.path.join(pages_root, d))) \
        if os.path.isdir(pages_root) else []
    if legacy_layout:
        pass  # R-80
    elif not os.path.exists(pj_path):
        add('err', 'R-04', pj_path, 'חסר pages/pages.json', 'קובץ חובה — סדר הדפים והדף הפעיל.')
        ok = False
        order, active = [], None
    else:
        obj, err = _load_json(pj_path)
        if err:
            add('err', 'R-04', pj_path, 'pages.json — JSON שבור', err)
            ok = False
            order, active = [], None
        else:
            order = obj.get('pageOrder') or []
            active = obj.get('activePageName')
            missing_from_order = [d for d in page_dirs if d not in order]
            dangling_in_order = [o for o in order if o not in page_dirs]
            for d in missing_from_order:
                add('err', 'R-04', pj_path, "הדף '%s' לא רשום ב-pageOrder" % d,
                    'דף שאינו ב-pageOrder **נעלם בשקט** מהדוח ב-Desktop. קלאסי אחרי byte-copy. '
                    'תיקון אוטומטי: pbi_fix.py --fix pageorder.')
                ok = False
            for o in dangling_in_order:
                add('err', 'R-04', pj_path, "pageOrder מפנה לדף '%s' שלא קיים" % o,
                    'הפניה תלויה לדף שנמחק/שונה שמו.')
                ok = False
            if active and order and active not in order and active not in page_dirs:
                add('warn', 'R-04', pj_path, "activePageName '%s' אינו דף קיים" % active,
                    'הדף הפעיל מפנה לשם שלא קיים — Desktop ייפול לדף הראשון. '
                    'תיקון אוטומטי: pbi_fix.py --fix pageorder.')

    # לולאת דפים
    seen_page_names = {}
    page_visual_names = {}  # pname -> set of visual names (לסימניות R-23)
    for d in page_dirs:
        pd = os.path.join(pages_root, d)

        # R-05 · page.json
        pj = os.path.join(pd, 'page.json')
        if not os.path.exists(pj):
            add('err', 'R-05', pj, "חסר page.json בדף '%s'" % d, 'כל תיקיית דף חייבת page.json.')
            ok = False
            continue
        pobj, err = _load_json(pj)
        if err:
            add('err', 'R-05', pj, "page.json שבור בדף '%s'" % d, err)
            ok = False
            continue
        if _check_expr_shapes(pobj, pj, ext_entities, model_tables, theme_colors):
            ok = False
        pname = pobj.get('name')
        if pname and pname != d:
            add('warn', 'R-05', pj, "שם הדף ב-page.json ('%s') ≠ שם התיקייה ('%s')" % (pname, d),
                'אי-התאמה קלאסית אחרי byte-copy שלא עודכנו בה המזהים.')
        if pname:
            if pname in seen_page_names:
                add('err', 'R-05', pj, "שם דף כפול '%s'" % pname,
                    "גם בתיקייה '%s'. שמות דפים חייבים להיות ייחודיים." % seen_page_names[pname])
                ok = False
            seen_page_names[pname] = d
        # R-93 · תווים לא חוקיים בשם תיקיית דף / שדה name — Desktop מתעלם בשקט
        # והדף נעלם מהדוח הטעון (data-goblin c_pbip_skill.md § Naming rules).
        if not _NAME_RX.match(d):
            add('err', 'R-93', pj,
                "שם תיקיית הדף '%s' מכיל תווים מחוץ ל-^[\\w-]+$" % d,
                'רווחים/נקודות/סימני פיסוק בשם תיקיית דף = Desktop מתעלם מהדף '
                'בשקט, בלי הודעת שגיאה. לשנות לאותיות/ספרות/מקף/קו תחתון בלבד. '
                'מקור: data-goblin v26.31.0 (GPL-3.0), pbip skill § Naming rules.')
            ok = False
        if pname and not _NAME_RX.match(pname):
            add('err', 'R-93', pj,
                "שדה name של הדף ('%s') מכיל תווים מחוץ ל-^[\\w-]+$" % pname,
                'אותו כלל כמו שם התיקייה — name לא חוקי = הדף נעלם בשקט ב-Desktop. '
                'מקור: data-goblin v26.31.0 (GPL-3.0), pbip skill § Naming rules.')
            ok = False
        for dim in ('width', 'height'):
            if not isinstance(pobj.get(dim), (int, float)):
                add('warn', 'R-05', pj, "דף '%s' בלי %s מספרי" % (d, dim),
                    'ממדי קנבס חסרים/לא מספריים — הדף עלול להרנדר בגודל לא צפוי.')
        if 'displayOption' in pobj and not isinstance(pobj['displayOption'], str):
            add('err', 'R-05', pj, "displayOption בדף '%s' אינו מחרוזת" % d,
                'חייב להיות "FitToPage"/"FitToWidth"/"ActualSize" — לא מספר.')
            ok = False
        if isinstance(pobj.get('displayOption'), str) and \
                pobj['displayOption'] not in ('FitToPage', 'FitToWidth', 'ActualSize'):
            add('err', 'R-18', pj,
                "displayOption לא חוקי בדף '%s': '%s'" % (d, pobj['displayOption']),
                'ערכים חוקיים: FitToPage / FitToWidth / ActualSize — ערך לא מוכר עלול ליפול לברירת מחדל.')
            ok = False
        if not _check_page_objects(pobj, pj, d):
            ok = False
        _collect_rpi(pobj, pj, "דף '%s'" % d, rpi_refs)

        # R-82 · אותה בדיקה ברמת דף
        if isinstance(pobj.get('filters'), list):
            add('warn', 'R-82', pj,
                "page.json של דף '%s' עם מפתח 'filters' ברמת השורש" % d,
                'ב-schema 2.1.0+ עוגן הסינון הוא filterConfig.filters; מפתח '
                "'filters' עצמאי עלול לבלבל את Desktop (powerbi-report-mcp "
                'pbir-gotchas.md Q3, MIT).')
        page_filters = (pobj.get('filterConfig') or {}).get('filters') or []

        # ויזואלים
        vis_root = os.path.join(pd, 'visuals')
        vis_dirs = sorted(os.listdir(vis_root)) if os.path.isdir(vis_root) else []
        seen_vis = {}
        vis_names = []
        page_rects = []  # (key, x, y, w, h, is_decor_or_hidden, is_group_container)
        page_groups = {}    # R-67: key -> (x,y,w,h) של מכולת visualGroup
        page_members = []   # R-67: (member_key, parentGroupName, (x,y,w,h))
        page_z = {}
        for vd in vis_dirs:
            vj_path = os.path.join(vis_root, vd, 'visual.json')
            if not os.path.isdir(os.path.join(vis_root, vd)):
                continue
            # R-06 · visual.json
            if not os.path.exists(vj_path):
                add('err', 'R-06', vj_path, "חסר visual.json בוויזואל '%s'" % vd, '')
                ok = False
                continue
            vobj, err = _load_json(vj_path)
            if err:
                add('err', 'R-06', vj_path, "visual.json שבור בוויזואל '%s'" % vd, err)
                ok = False
                continue
            if _check_expr_shapes(vobj, vj_path, ext_entities, model_tables, theme_colors):
                ok = False
            _check_visual_catalog(vobj, vj_path)
            vname = vobj.get('name')
            if vname and vname != vd:
                add('info', 'R-06', vj_path, "שם הוויזואל ('%s') ≠ שם התיקייה ('%s')" % (vname, vd),
                    'שינוי שם name בתוך ה-JSON נתמך לפי MS (Desktop שומר את שם התיקייה); '
                    'כיול על דוחות אמיתיים הראה שאי-התאמה שכיחה ולא שוברת.')
            # R-93 · תווים לא חוקיים בשם תיקיית ויזואל / שדה name — נעלם בשקט
            if not _NAME_RX.match(vd):
                add('err', 'R-93', vj_path,
                    "שם תיקיית הוויזואל '%s' מכיל תווים מחוץ ל-^[\\w-]+$" % vd,
                    'רווחים/נקודות/סימני פיסוק בשם תיקיית ויזואל = Desktop מתעלם '
                    'מהוויזואל בשקט. מקור: data-goblin v26.31.0 (GPL-3.0), '
                    'pbip skill § Naming rules.')
                ok = False
            if vname and not _NAME_RX.match(vname):
                add('err', 'R-93', vj_path,
                    "שדה name של הוויזואל ('%s') מכיל תווים מחוץ ל-^[\\w-]+$" % vname,
                    'name לא חוקי = הוויזואל נעלם בשקט ב-Desktop. מקור: data-goblin '
                    'v26.31.0 (GPL-3.0), pbip skill § Naming rules.')
                ok = False
            key = vname or vd
            if key in seen_vis:
                add('err', 'R-06', vj_path, "שם ויזואל כפול '%s' בדף '%s'" % (key, d),
                    'מזהים כפולים שוברים סימניות, סינכרון סליסרים ואינטראקציות.')
                ok = False
            seen_vis[key] = vd
            vis_names.append(key)

            vis = vobj.get('visual') or {}
            # מכולת קבוצה (visualGroup): visual.json ללא מפתח visual בכלל — מבנה
            # חוקי (אומת חיה ב-Desktop ע"י mudassir09/pbi-enterprise-cli, MIT).
            is_group_container = isinstance(vobj.get('visualGroup'), dict)
            _p0 = vobj.get('position') or {}
            _rect = tuple(float(_p0.get(k) or 0) for k in ('x', 'y', 'width', 'height'))
            if is_group_container:
                page_groups[key] = _rect
            if vobj.get('parentGroupName'):
                page_members.append((key, vobj['parentGroupName'], _rect))
            if not vis.get('visualType') and not is_group_container:
                add('err', 'R-06', vj_path, "וויזואל '%s' בלי visualType" % key,
                    'בלי סוג הוויזואל לא ירונדר (כשל שקט).')
                ok = False
            # R-77 · objects / visualContainerObjects ברמת השורש של visual.json
            # במקום בתוך visual — המנוע מתעלם מהם לחלוטין (מבנה שגוי של LLM;
            # MS formatting.md § VCO: VCO הוא sibling של objects *בתוך* visual).
            for misplaced in ('objects', 'visualContainerObjects'):
                if isinstance(vobj.get(misplaced), dict):
                    add('err', 'R-77', vj_path,
                        "'%s' ברמת השורש של visual.json בוויזואל '%s' — יתעלמו ממנו"
                        % (misplaced, key),
                        "'%s' חייב לשבת בתוך אובייקט ה-visual (לצד visualType/query), "
                        "לא בשורש המסמך — במיקום הזה העיצוב כולו לא חל (MS formatting.md "
                        "§ Visual Container Objects)." % misplaced)
                    ok = False
            # R-95 · מפתחות שורש חוקיים ב-visual.json (דוח שדה סבב 3 #1, שורה 4:
            # syncGroup בשורש visual.json עבר עם "0 שגיאות" ו-Desktop דיווח 12
            # issues). סט השורש הנצפה בקורפוס (2640 קבצי visual.json מייצואי
            # Desktop אמיתיים): $schema/name/position/visual/parentGroupName/
            # isHidden/filterConfig/visualGroup/howCreated. syncGroup חוקי *רק*
            # כ-visual.syncGroup (דונור: capital/daq — {"groupName": ...,
            # "fieldChanges": ..., "filterChanges": ...}).
            if isinstance(vobj.get('syncGroup'), dict):
                add('err', 'R-95', vj_path,
                    "syncGroup ברמת השורש של visual.json בוויזואל '%s' — מיקום לא חוקי" % key,
                    'syncGroup חוקי רק כ-visual.syncGroup (בתוך אובייקט ה-visual, לצד '
                    'visualType). בשורש המסמך Desktop מדווח issues (דוח שדה סבב 3 — 12 '
                    'issues על שורה זו). נצפה ב-0/2640 קבצי visual.json בקורפוס; '
                    'המיקום הנכון נצפה בדונור capital/daq. להעביר לתוך visual.')
                ok = False
            _KNOWN_ROOT = {'$schema', 'name', 'position', 'visual', 'parentGroupName',
                           'isHidden', 'filterConfig', 'visualGroup', 'howCreated',
                           'syncGroup'}
            for _rk in vobj:
                if _rk not in _KNOWN_ROOT:
                    add('info', 'R-95', vj_path,
                        "מפתח שורש '%s' ב-visual.json של ויזואל '%s' לא נצפה בקורפוס" % (_rk, key),
                        'סט השורש הנצפה ב-2640 קבצי visual.json של יצואי Desktop: '
                        '$schema, name, position, visual, parentGroupName, isHidden, '
                        'filterConfig, visualGroup, howCreated. מפתח אחר = כנראה מבנה '
                        'שגוי (או חידוש עתידי של Microsoft) — לוודא מול Desktop.')
            # R-21 · שמות visualType שאינם סוגים חוקיים (מלכודת הזיה קלאסית של LLM)
            KNOWN_BAD_VT = {'stackedBarChart': 'barChart', 'stackedColumnChart': 'columnChart',
                            'matrix': 'pivotTable'}
            vt = vis.get('visualType')
            if vt in KNOWN_BAD_VT:
                add('warn', 'R-21', vj_path,
                    "וויזואל '%s' — visualType '%s' אינו סוג חוקי (האם התכוונת '%s'?)"
                    % (key, vt, KNOWN_BAD_VT[vt]),
                    'stacked הוא ברירת המחדל של barChart/columnChart; שם לא חוקי מרנדר אריח שבור. '
                    'מקור: jonathan-pap/powerbi-report-mcp docs/visual-types.md (MIT), אומת מול '
                    'קטלוג data-goblin/power-bi-agentic-development.')
            # R-48 · visualType מיושן (MS skills-for-fabric card.md: card/multiRowCard
            # הם legacy — תמיד cardVisual)
            if vt in DEPRECATED_VISUALS:
                add('warn', 'R-48', vj_path,
                    "וויזואל '%s' — visualType '%s' מיושן; המחליף הרשמי הוא '%s'"
                    % (key, vt, DEPRECATED_VISUALS[vt]),
                    'card ו-multiRowCard הם legacy לפי MS — cardVisual תומך בריבוי '
                    'ערכים, referenceLabels ועיצוב מלא. ההמרה: אותם מדדים ← queryState.Data.')
            # R-26 · צורת queryState מול תפקידי הסוג (roles) — מלכודת קלאסית של בנייה עיוורת:
            # role בשם שגוי או role חובה חסר = אריח ריק/שבור ב-Desktop (מתועד ב-MS
            # skills-for-fabric: cardVisual עם "Fields" מרונדר ריק). Tooltips הוא role
            # אוניברסלי חוקי (אומת בייצוא scatterChart אמיתי ב-K201).
            if vt in _ROLE_PLAN:
                qs = ((vis.get('query') or {}).get('queryState')) or {}
                # כיול: ויזואל placeholder בלי אף projection = אין כוונת נתונים —
                # לא לדרוש roles חובה על אריח ריק (אומת על דוחות אמיתיים).
                has26 = any((qs.get(r) or {}).get('projections') for r in qs)
                plan = {spec[0]: (len(spec) > 2 and spec[2]) for spec in _ROLE_PLAN[vt]}
                src_of = {spec[0]: spec[1] for spec in _ROLE_PLAN[vt]}
                aliases = _ROLE_ALIASES.get(vt, {})
                known_extra = _EXTRA_KNOWN.get(vt, set())
                # נרמול: alias של גרסת Desktop אחרת מספק את ה-role הקנוני שלו
                # (אומת מול ייצואי Desktop אמיתיים: retail scatterChart=Category,
                # superstore map=Location) — בלי זה R-26 מסמן פלט Desktop כשר שגוי.
                def _has_role(rname):
                    if (qs.get(rname) or {}).get('projections'):
                        return True
                    return any(a == rname and (qs.get(alt) or {}).get('projections')
                               for alt, a in aliases.items())
                for role, optional in plan.items():
                    if has26 and not optional and not _has_role(role):
                        # role ערך (מדד) חסר = אריח ריק לגמרי → err; role ציר חסר =
                        # תרשים מנוון של קטגוריה יחידה (חוקי ב-Desktop) → warn בלבד.
                        if src_of.get(role, '').startswith('M') or src_of.get(role) == 'ALL':
                            add('err', 'R-26', vj_path,
                                "וויזואל '%s' (%s) בלי role חובה '%s'" % (key, vt, role),
                                'הוויזואל ירונדר ריק — Desktop לא מצליח לקשור בליינדינג.')
                            ok = False
                        else:
                            add('warn', 'R-26', vj_path,
                                "וויזואל '%s' (%s) בלי role ציר '%s' — ירונדר כקטגוריה יחידה"
                                % (key, vt, role),
                                'חוקי ב-Desktop אבל כמעט תמיד לא כוונת המשתמש.')
                for role in qs:
                    if role not in plan and role not in ('Tooltips',) and \
                       role not in aliases and role not in known_extra and \
                       (qs.get(role) or {}).get('projections'):
                        add('warn', 'R-26', vj_path,
                            "וויזואל '%s' (%s) עם role לא מוכר '%s' — ידועים: %s"
                            % (key, vt, role, ', '.join(plan)),
                            'שם role שגוי (למשל Values במקום Data ב-cardVisual) מתעלם '
                            'בשקט — השדה פשוט לא מוצג.')

            # R-27 · projections ישירות תחת query (לא queryState) — שגיאת schema ב-Desktop
            # (MS skills-for-fabric authoring.md). שגיאת שיכון קלאסית של JSON בנוי ביד.
            q0 = vis.get('query') or {}
            if isinstance(q0, dict) and 'queryState' not in q0:
                misplaced = [k for k, v0 in q0.items()
                             if k == 'projections' or
                             (isinstance(v0, dict) and 'projections' in v0)]
                if misplaced:
                    add('err', 'R-27', vj_path,
                        "וויזואל '%s' — projections ישירות תחת query (%s) במקום queryState"
                        % (key, ', '.join(misplaced)),
                        'Desktop זורק schema validation error — הדף/וויזואל לא נטען.')
                    ok = False

            # R-28 · slicer עם Tooltips מאוכלס אבל בלי visualTooltip.show=true —
            # הפאנל כבוי כברירת מחדל וה-tooltip לעולם לא יוצג (MS skills-for-fabric slicers.md).
            if vt in ('slicer', 'advancedSlicerVisual'):
                qs0 = ((vis.get('query') or {}).get('queryState')) or {}
                if (qs0.get('Tooltips') or {}).get('projections'):
                    show_on = False
                    vco0 = vis.get('visualContainerObjects') or {}
                    for blk in vco0.get('visualTooltip') or []:
                        sh = ((blk or {}).get('properties') or {}).get('show')
                        val = ''
                        if isinstance(sh, dict):
                            val = str(((sh.get('expr') or {}).get('Literal') or {}).get('Value', ''))
                        show_on = show_on or val.strip("'").lower() == 'true'
                    if not show_on:
                        add('warn', 'R-28', vj_path,
                            "סליסר '%s' עם שדה ב-Tooltips אבל visualTooltip.show לא true" % key,
                            'ה-tooltip panel כבוי כברירת מחדל — בלי show=true המשתמש '
                            'מרחף ולא רואה כלום.')

            # R-44/45/46 · data.mode של סליסר — ערך בקטלוג, זמין רק ל-slicer, טיפוס שדה
            # מתאים למצב, והיררכיה רק ב-Basic/Dropdown (MS skills-for-fabric slicers.md)
            if vt in ('slicer', 'listSlicer', 'advancedSlicerVisual'):
                mode, mode_declared = None, False
                for blk in (vis.get('objects') or {}).get('data') or []:
                    mv = (((blk or {}).get('properties') or {}).get('mode') or {})
                    val = ((mv.get('expr') or {}).get('Literal') or {}).get('Value')
                    if isinstance(val, str):
                        mode, mode_declared = val.strip("'"), True
                if vt != 'slicer' and mode_declared:
                    add('warn', 'R-44', vj_path,
                        "data.mode מוצהר על %s ('%s') — לא זמין בסוג זה" % (vt, mode),
                        'data.mode זמין רק ל-visualType=slicer; ב-listSlicer/'
                        'advancedSlicerVisual נזרק (MS slicers.md).')
                if vt == 'slicer' and mode is not None and mode not in SLICER_MODES:
                    add('warn', 'R-44', vj_path,
                        "סליסר '%s' עם data.mode='%s' לא בקטלוג" % (key, mode),
                        'ערכים מתועדים: ' + '/'.join(sorted(SLICER_MODES)) + ' (MS slicers.md).')
                qs1 = ((vis.get('query') or {}).get('queryState')) or {}
                hier_hits = []
                _walk(qs1, lambda o: hier_hits.append(1) if 'HierarchyLevel' in o else None)
                if hier_hits and vt == 'slicer' and mode not in (None, 'Basic', 'Dropdown'):
                    add('warn', 'R-46', vj_path,
                        "סליסר '%s' עם היררכיה במצב '%s'" % (key, mode),
                        'סליסר היררכיה נתמך רק ב-Basic/Dropdown (או listSlicer) — '
                        'מצב אחר לא יציג drill (MS slicers.md).')
                # R-45 · טיפוס השדה מול המצב (דורש --model): Between/Relative = תאריך,
                # Before/After = תאריך או מספר, RelativeTime = dateTime בלבד
                if vt == 'slicer' and mode in SLICER_MODE_TYPES and model_tables:
                    col_refs = []

                    def _fr(o):
                        for kind0 in ('Measure', 'Column'):
                            fd = o.get(kind0)
                            if isinstance(fd, dict) and fd.get('Property'):
                                try:
                                    ent0 = fd['Expression']['SourceRef'].get('Entity', '')
                                except Exception:
                                    ent0 = ''
                                col_refs.append((kind0, ent0, str(fd['Property'])))
                    _walk(qs1, _fr)
                    for kind0, ent, prop in col_refs:
                        if kind0 != 'Column' or not ent or ent not in model_tables:
                            continue
                        dt = model_tables[ent].get('col_types', {}).get(prop, '')
                        if not dt:
                            continue
                        if dt not in SLICER_MODE_TYPES[mode]:
                            add('warn', 'R-45', vj_path,
                                "סליסר '%s' במצב '%s' על שדה מסוג %s" % (key, mode, dt),
                                'המצב דורש טיפוס אחר (Between/Relative = תאריך, '
                                'Before/After = תאריך או מספר, RelativeTime = dateTime) — '
                                'סליסר על טיפוס לא מתאים לא ירנדר נכון (MS slicers.md).')
                        break
                # R-68 · סלייסר inline אנכי מתחת לרצפת הגובה — כל שורה נקצצת.
                # רצפה 48px = שורה אחת (24px ב-9pt) + מרווח ביטחון 8 + padding דיפולטי 16,
                # גם כשה-header מוסתר (slicers.md Inline-list formula). מעל 48 ייתכן
                # תצורה חוקית, אז לא מסמנים. מצבים: ללא mode (רשימה דיפולטית) / Basic /
                # Single = inline; Dropdown נפתח כפופ-אפ ופטור. orientation קיים = אופקי
                # (1D/2D בייצוא אמיתי) ופטור. עמודת boolean = צ'קבוקס יחיד ופטורה.
                # נמצא בקורפוס: 32 סלייסרי insurance ב-h=38 (סבב 76).
                if (vt == 'slicer' and mode in (None, 'Basic', 'Single')):
                    has_orient = False
                    for blk in (vis.get('objects') or {}).get('general') or []:
                        if 'orientation' in ((blk or {}).get('properties') or {}):
                            has_orient = True
                            break
                    hh = ((vobj.get('position') or {}).get('height'))
                    if not has_orient and isinstance(hh, (int, float)) and hh < 48:
                        is_bool = False
                        if model_tables:
                            refs0 = []

                            def _frb(o):
                                fd = o.get('Column')
                                if isinstance(fd, dict) and fd.get('Property'):
                                    try:
                                        e0 = fd['Expression']['SourceRef'].get('Entity', '')
                                    except Exception:
                                        e0 = ''
                                    refs0.append((e0, str(fd['Property'])))
                            _walk(qs1, _frb)
                            for e0, p0 in refs0:
                                if e0 in model_tables and model_tables[e0].get('col_types', {}).get(p0) == 'boolean':
                                    is_bool = True
                                    break
                        if not is_bool:
                            add('warn', 'R-68', vj_path,
                                "סליסר '%s' inline (מצב %s) בגובה %dpx — מתחת לרצפת 48px" % (
                                    key, mode or 'ברירת מחדל', int(hh)),
                                'רצפה = שורה 24px + מרווח 8 + padding 16 גם בלי header; '
                                'מתחת לה כל פריט נקצץ (slicers.md Inline-list formula; '
                                'אומת בקורפוס: insurance h=38). הגבה או העבר ל-Dropdown.')
            # R-24 · ויזואלי insert (image/actionButton/pageNavigator) חייבים howCreated —
            # בלעדיו Desktop מפיל אותם מהקנבס בשקט, בלי שגיאה.
            if vt in ('image', 'actionButton', 'pageNavigator') and not vobj.get('howCreated'):
                add('info', 'R-24', vj_path,
                    "וויזואל '%s' (%s) בלי howCreated" % (key, vt),
                    'סוגי insert חייבים howCreated ברמה העליונה (כל ערך — InsertVisualButton, '
                    'Copilot וכדומה); בלעדיו הוויזואל נעלם מהקנבס בשקט. '
                    'מקור: jonathan-pap/powerbi-report-mcp docs/visual-types.md (MIT).')
            pos = vobj.get('position') or {}
            for k in ('x', 'y', 'width', 'height'):
                if not isinstance(pos.get(k), (int, float)):
                    add('err', 'R-06', vj_path, "וויזואל '%s' — position חסר/לא מספרי (%s)" % (key, k),
                        'בלי מיקום וגודל הוויזואל לא ירונדר כצפוי.')
                    ok = False
                    break
            else:
                # R-07 · חריגה מגבולות הקנבס
                pw, ph = pobj.get('width'), pobj.get('height')
                if isinstance(pw, (int, float)) and isinstance(ph, (int, float)):
                    if pos.get('x', 0) < -0.5 or pos.get('y', 0) < -0.5:
                        add('warn', 'R-07', vj_path, "וויזואל '%s' מתחיל מחוץ לקנבס (x/y שליליים)" % key,
                            'ייתכן מכוון (רקע), אבל לרוב טעות גרירה.')
                    elif pos['x'] + pos['width'] > pw + 0.5 or pos['y'] + pos['height'] > ph + 0.5:
                        add('warn', 'R-07', vj_path, "וויזואל '%s' חורג מגבולות הדף (%dx%d)" % (key, pw, ph),
                            'חריגה מהקנבס = תוכן נחתם. ליישר מיקום/גודל.')

                # R-19 · גודל אפס/שלילי
                if pos['width'] <= 0 or pos['height'] <= 0:
                    add('err', 'R-19', vj_path, "וויזואל '%s' עם רוחב/גובה אפס או שלילי" % key,
                        'ויזואל בגודל אפס לא מרונדר — כשל שקט בדף.')
                    ok = False

                # R-66 · תרשים קטן ממינימום קריא (80x60) — גרידת ייצור בונה
                # (HorizunGroup/horizun-pbi-mcp layout_doctor, Apache-2.0: MIN_ANCHO/
                # MIN_ALTO = 80/60 עם החרגת דקור. החרגת הקומפקטיים התווספה מכיול הקורפוס)
                if vt not in DECOR and vt not in COMPACT_VT and not vobj.get('isHidden'):
                    if 0 < pos['width'] < 80 or 0 < pos['height'] < 60:
                        add('warn', 'R-66', vj_path,
                            "וויזואל '%s' (%s) קטן ממינימום קריא — %dx%dpx"
                            % (key, vt, round(pos['width']), round(pos['height'])),
                            'תרשים מתחת ל-80x60px לא מציג צירים/תוויות בצורה קריאה. '
                            'סליסרים, כרטיסים ואלמנטי דקור מוחרגים. '
                            'מקור: horizun-pbi-mcp layout_doctor (Apache-2.0).')
                # R-17 · הוצא משימוש (סבב 13): קואורדינטות עשרוניות הן הנורמה בפלט
                # Desktop אמיתי (אומת מול 3 ייצואים עצמאיים, עד 13 ספרות אחרי הנקודה).
                # התרעה על position לא-שלם היא false-positive, ועיגול משנה קבצים תקינים.
                page_rects.append((key, float(pos['x']), float(pos['y']),
                                   float(pos['width']), float(pos['height']),
                                   (vis.get('visualType') in DECOR) or bool(vobj.get('isHidden')),
                                   is_group_container))
                z = pos.get('z')
                if isinstance(z, (int, float)):
                    page_z.setdefault(z, []).append(key)

            # R-81 · שדות ב-queryState.Tooltips אבל לוח ה-tooltip כבוי (visualTooltip.show
            # לא true) — ה-tooltip "כבוי כברירת מחדל והמשתמש לא יראה כלום בריחוף"
            # (MS skills-for-fabric slicers.md § General rules 5). שדות שהוכנסו
            # ללא הפעלת הלוח = שקט לחלוטין; נמצא בקורפוס: advw azureMap.
            _qs = ((vis.get('query') or {}).get('queryState') or {})
            _tt = _qs.get('Tooltips') or {}
            if _tt.get('projections'):
                _vco = vis.get('visualContainerObjects') or {}
                _vt = _vco.get('visualTooltip')
                _show = None
                _ttype = None
                if isinstance(_vt, list) and _vt:
                    _props = (_vt[0].get('properties') or {})
                    _sh = _props.get('show')
                    if isinstance(_sh, dict):
                        try:
                            _show = _sh['expr']['Literal']['Value']
                        except Exception:
                            pass
                    _ty = _props.get('type')
                    if isinstance(_ty, dict):
                        try:
                            _ttype = _ty['expr']['Literal']['Value'].strip("'")
                        except Exception:
                            pass
                if _show != 'true' and _ttype != 'Canvas':
                    add('warn', 'R-81', vj_path,
                        "וויזואל '%s' עם שדות Tooltips אבל לוח tooltip כבוי" % key,
                        'שדות ב-queryState.Tooltips אינם מספיקים — חובה '
                        'visualContainerObjects.visualTooltip.show=true, אחרת הלוח '
                        'כבוי כברירת מחדל והמשתמש לא רואה כלום בריחוף. '
                        'מקור: MS skills-for-fabric slicers.md § General rules.')

            # R-83 · filterConfig בתוך אובייקט visual (במקום ברמת visual.json) —
            # Desktop דוחה בטעינה: "additional property 'filterConfig' ... /visual"
            # (iamahlramz/pbip-tools TOOLCHAIN-FINDINGS-2026-07-13 #3, MIT).
            # ולידטורים headless לא תפסו: המסננים נעלמים גם מבדיקות R-08/R-22 למעלה.
            if isinstance(vis, dict) and 'filterConfig' in vis:
                add('err', 'R-83', vj_path,
                    "filterConfig בתוך אובייקט visual בוויזואל '%s'" % key,
                    'העוגן החוקי הוא ברמת visual.json (אח של visual/position/name). '
                    'Desktop דוחה את הקובץ בטעינה (additional property filterConfig '
                    'in /visual). '
                    'והמסננים לא נטענים כלל. להעביר את filterConfig לרמה העליונה. '
                    'מקור: iamahlramz/pbip-tools TOOLCHAIN-FINDINGS #3 (MIT).')
                ok = False

            # R-08 · מסננים בוויזואל
            vf = (vobj.get('filterConfig') or {}).get('filters') or []
            for f in vf:
                if not isinstance(f, dict) or not f.get('name') or not f.get('field'):
                    add('warn', 'R-08', vj_path, "מסנן בלי name/field בוויזואל '%s'" % key,
                        'רשומת מסנן חסרת שדות חובה — תידחה או תשבר בשקט.')
                else:
                    ref = _filter_field_ref(f)
                    if ref and not _check_ref(model_tables, ref[0], ref[1], ref[2],
                                              'R-22', vj_path, "מסנן בוויזואל '%s'" % key):
                        ok = False
                if isinstance(f, dict) and not _check_filter_shape(
                        f, vj_path, "-וויזואל '%s'" % key, 'visual'):
                    ok = False
            # R-29/33/34/35 · עץ ה-objects — הליכה אחת משותפת
            if not _check_objects(vis.get('objects') or {}, vj_path, key, vis.get('visualType')):
                ok = False

            # R-49/50 · אובייקטי קו/שטח מול סוג הוויזואל + ערכי enum (MS skills-for-fabric
            # cartesian.md): lineStyles רק במשפחת קו/שטח, markers גם ב-scatter, seriesLabels
            # רק ב-lineChart, y2Axis רק כש-role Y2 מאויש.
            vobjs = vis.get('objects') or {}
            if isinstance(vobjs, dict):
                if 'lineStyles' in vobjs and vt not in LINE_STYLE_VISUALS:
                    add('warn', 'R-49', vj_path,
                        "אובייקט lineStyles בוויזואל '%s' (%s) — נתמך רק במשפחת קו/שטח"
                        % (key, vt),
                        'lineStyles חוקי ב-areaChart/lineChart/stackedAreaChart/'
                        'lineStackedColumnComboChart/lineClusteredColumnComboChart/'
                        'hundredPercentStackedAreaChart בלבד; במקומות אחרים נזרק בשקט (MS).')
                if 'markers' in vobjs and vt not in MARKER_VISUALS:
                    add('warn', 'R-49', vj_path,
                        "אובייקט markers בוויזואל '%s' (%s) — נתמך רק בקו/שטח/scatter"
                        % (key, vt),
                        'markers זמין במשפחת line/area וב-scatterChart בלבד (MS).')
                if 'seriesLabels' in vobjs and vt != 'lineChart':
                    add('warn', 'R-49', vj_path,
                        "אובייקט seriesLabels בוויזואל '%s' (%s) — lineChart בלבד"
                        % (key, vt),
                        'תוויות סוף-קו קיימות רק ב-lineChart; בכל סוג אחר נזרקות בשקט (MS).')
                if 'y2Axis' in vobjs:
                    qs49 = ((vis.get('query') or {}).get('queryState')) or {}
                    y2 = (qs49.get('Y2') or {}).get('projections') or []
                    if not y2:
                        add('warn', 'R-49', vj_path,
                            "אובייקט y2Axis בוויזואל '%s' בלי role Y2 מאויש" % key,
                            'y2Axis מעצב את הציר המשני — רלוונטי רק כשיש projection '
                            'ב-Y2 (lineChart). בלי Y2 האובייקט מת (MS).')
                if 'ribbonBands' in vobjs and vt not in STACKED_VISUALS:
                    add('warn', 'R-52', vj_path,
                        "אובייקט ribbonBands בוויזואל '%s' (%s) — קיים רק ב-barChart/columnChart"
                        % (key, vt),
                        'רצועות ribbon מחברות סגמנטים של אותה סידרה בתרשימים מוערמים '
                        'בלבד; במקומות אחרים נזרקות בשקט (MS cartesian.md).')
                if ('totals' in vobjs and vt not in STACKED_VISUALS
                        and vt not in TABLE_FAMILY):
                    add('warn', 'R-52', vj_path,
                        "אובייקט totals בוויזואל '%s' (%s) — תוויות סכום קיימות רק "
                        "ב-stacked bar/column" % (key, vt),
                        'בתרשימי קו/שטח/עוגה אין תוויות totals (האובייקט מת); בטבלאות '
                        'ומטריצות totals הוא אובייקט שורות-סכום לגיטימי (MS cartesian.md).')
                # R-53 · defaultColor ב-clustered מכריח צבע אחד לכל העמודות והמקרא
                # (MS skills-for-fabric cartesian.md — "do NOT use defaultColor on
                # clustered charts")
                if vt in ('clusteredColumnChart', 'clusteredBarChart'):
                    for dp in vobjs.get('dataPoint') or []:
                        pr53 = (dp or {}).get('properties') or {}
                        if isinstance(pr53, dict) and 'defaultColor' in pr53:
                            add('warn', 'R-53', vj_path,
                                "dataPoint.defaultColor בוויזואל '%s' (%s) — כל העמודות "
                                "והמקרא יקבלו אותו צבע" % (key, vt),
                                'בתרשים clustered זה מבטל את הבידול בין קטגוריות. '
                                'צבע פר-סידרה: dataPoint.fill עם selector, או פלטת '
                                'dataColors של ה-theme (MS cartesian.md).')
                            break
                # R-55 · ThemeDataColor ב-dataPoint.fill עם metadata selector נופל
                # בשקט ללבן/שחור (MS skills-for-fabric theming.md §8 / SKILL anti-patterns)
                n55 = 0
                for dp in vobjs.get('dataPoint') or []:
                    if not isinstance(dp, dict):
                        continue
                    sel55 = dp.get('selector') or {}
                    if 'metadata' not in sel55:
                        continue
                    pr55 = dp.get('properties') or {}
                    if not isinstance(pr55, dict):
                        continue
                    fill55 = pr55.get('fill') or {}
                    tdc = (((fill55.get('solid') or {}).get('color') or {})
                           .get('expr') or {}).get('ThemeDataColor')
                    if tdc is not None:
                        n55 += 1
                if n55:
                    # איגוד: בעיה אחת לוויזואל גם כשכמה סידרות מושפעות —
                    # 3 סידרות באותו ויזואל הן אותה בעיה, לא 3 בעיות
                    add('warn', 'R-55', vj_path,
                        "dataPoint.fill עם ThemeDataColor + metadata selector "
                        "בוויזואל '%s' — %s נופל בשקט ללבן/שחור"
                        % (key, 'סידרה אחת' if n55 == 1 else ('%d סידרות' % n55)),
                        'במיקום של fill פר-סידרה (metadata selector) ThemeDataColor '
                        'לא נפתר נכון — להשתמש ב-hex ליטרלי (MS theming.md §8).')
                # R-69 · tableEx/pivotTable עם צבעים סטטיים מותאמים ב-objects אבל בלי
                # visualContainerObjects.stylePreset — פריסת ברירת-המחדל דורסת אותם בשקט
                # לרקע לבן (MS skills-for-fabric table.md: "the single most common
                # dark-mode table formatting bug"). תיקון: pbi_fix --fix stylepreset.
                if vt in ('tableEx', 'pivotTable'):
                    # סבב 134 (כשל שדה #1): הסגנון חי בתוך visual.visualContainerObjects;
                    # בלוק ברמת השורש מתעלם Desktop (R-77) — הבודק והפיקסר היו חלוקים עליו.
                    vco69 = (vis.get('visualContainerObjects') if isinstance(vis, dict) else None) or {}
                    has69 = any(isinstance(b, dict)
                                for b in (vco69.get('stylePreset') or []))
                    if not has69:
                        zones69 = (('values', ('backColorPrimary', 'backColorSecondary',
                                               'fontColorPrimary', 'fontColorSecondary')),
                                   ('columnHeaders', ('backColor', 'fontColor')),
                                   ('rowHeaders', ('backColor', 'fontColor')),
                                   ('rowTotal', ('backColor', 'fontColor')),
                                   ('columnTotal', ('backColor', 'fontColor')),
                                   ('subTotals', ('backColor', 'fontColor')))
                        hit69 = []
                        for obj69, props69 in zones69:
                            for blk in vobjs.get(obj69) or []:
                                if not isinstance(blk, dict):
                                    continue
                                pr69 = blk.get('properties') or {}
                                if isinstance(pr69, dict) and any(k in pr69 for k in props69):
                                    hit69.append(obj69)
                                    break
                        if hit69:
                            add('warn', 'R-69', vj_path,
                                "טבלה/מטריצה '%s' עם צבעים מותאמים (%s) בלי stylePreset — "
                                "הפריסה הדיפולטית דורסת אותם בשקט ללבן" % (key, ', '.join(hit69)),
                                "להוסיף visualContainerObjects.stylePreset עם name='None' — "
                                "בלעדיו הפריסה הדיפולטית מחילה רקע לבן מעל הצבעים המותאמים, "
                                "בלי שגיאה וללא אזהרה (MS table.md). תיקון אוטומטי: "
                                "pbi_fix --fix stylepreset.")
                # R-70/R-72 · סריקת CF רקורסיבית על objects (MS conditional-formatting.md,
                # סבב 83): linearGradient3 חייב min+mid+max — חסר mid = שגיאת רינדור /
                # גוף טבלה ריק; שמות backColorRule/fontColorRule/iconRule/iconDefinition
                # לא קיימים ונזרקים בשקט (מלכודת הזיה).
                _hits70 = {'g3_no_mid': 0, 'phantom': []}
                _scan_cf(vobjs, _hits70)
                if _hits70['g3_no_mid']:
                    add('err', 'R-70', vj_path,
                        "linearGradient3 בלי עצירת 'mid' בוויזואל '%s' — שגיאת רינדור / גוף ריק" % key,
                        "linearGradient3 מחייב שלוש עצירות (min/mid/max); לשתי עצירות "
                        "להשתמש ב-linearGradient2 (MS conditional-formatting.md).")
                if _hits70['phantom']:
                    add('warn', 'R-72', vj_path,
                        "מאפייני CF פיקטיביים בוויזואל '%s': %s — נזרקים בשקט"
                        % (key, ', '.join(sorted(set(_hits70['phantom'])))),
                        'המאפיינים האלה לא קיימים במנוע. CF מבוסס-כללים: expr עם '
                        'Conditional.Cases על backColor/fontColor/icon; אייקונים: '
                        'values.icon (MS conditional-formatting.md).')
                # R-71 · שם אייקון מחוץ לקטלוג = קריסת Desktop (Unable to find resource)
                for blk in vobjs.get('values') or []:
                    if not isinstance(blk, dict):
                        continue
                    icon71 = ((blk.get('properties') or {}).get('icon')) or {}
                    cond71 = icon71.get('Conditional') or {}
                    names71 = []
                    for case in cond71.get('Cases') or []:
                        v71 = (((case or {}).get('Value') or {}).get('Literal') or {}).get('Value')
                        if isinstance(v71, str):
                            names71.append(v71.strip("'"))
                    dv71 = ((cond71.get('DefaultValue') or {}).get('Literal') or {}).get('Value')
                    if isinstance(dv71, str):
                        names71.append(dv71.strip("'"))
                    bad71 = [n for n in names71 if n and n not in _CF_ICON_NAMES]
                    if bad71:
                        add('err', 'R-71', vj_path,
                            "אייקון CF לא בקטלוג בוויזואל '%s': %s — קריסת Desktop"
                            % (key, ', '.join(sorted(set(bad71)))),
                            'שם לא חוקי מקריס את Desktop ("Unable to find resource"). '
                            'רק שמות מהקטלוג (MS conditional-formatting.md Type 3).')
                        break
                # R-73 · CF על dataPoint.fill בתרשים עם selector שמכיל metadata —
                # כשל שקט: בתרשימים CF ערכי אסור לכלול metadata (MS conditional-
                # formatting.md: "Do NOT include metadata — it causes silent failure").
                for blk in vobjs.get('dataPoint') or []:
                    if not isinstance(blk, dict):
                        continue
                    sel73 = blk.get('selector') or {}
                    if 'metadata' not in sel73:
                        continue
                    pr73 = blk.get('properties') or {}
                    if not isinstance(pr73, dict):
                        continue
                    for slot73 in ('fill', 'fillRule'):
                        col73 = ((pr73.get(slot73) or {}).get('solid') or {}).get('color') or {}
                        ex73 = col73.get('expr') or {}
                        if 'FillRule' in ex73 or 'Conditional' in ex73:
                            add('warn', 'R-73', vj_path,
                                "CF על dataPoint.%s עם metadata selector בוויזואל '%s' — "
                                "כשל שקט (לא יוחל)" % (slot73, key),
                                'בתרשימים CF ערכי על dataPoint מגיע בלי selector או עם '
                                'dataViewWildcard בלבד — metadata גורם לכשל שקט. (metadata '
                                'נכון לצביעה סטטית פר-סידרה, לא ל-CF ערכי; MS '
                                'conditional-formatting.md selector summary).')
                            break

                # R-74 · dataPoint.fill סטטי עם metadata selector בוויזואל לא-קרטזי
                # (pie/donut/scatter/treemap/funnel) — נזרק בשקט; צביעה פר-קטגוריה שם
                # דורשת scopeId selectors (MS color-strategy.md § Compatibility).
                if vt in _SCOPEID_TYPES:
                    for blk in vobjs.get('dataPoint') or []:
                        if not isinstance(blk, dict):
                            continue
                        sel74 = blk.get('selector') or {}
                        if 'metadata' not in sel74:
                            continue
                        pr74 = blk.get('properties') or {}
                        col74 = (((pr74.get('fill') or {}).get('solid') or {}).get('color') or {})
                        if not col74:
                            continue
                        ex74 = col74.get('expr') or {}
                        if 'FillRule' in ex74 or 'Conditional' in ex74:
                            continue  # כשל ה-CF עצמו כבר מסומן ב-R-73
                        add('warn', 'R-74', vj_path,
                            "dataPoint.fill סטטי עם metadata selector בוויזואל לא-קרטזי "
                            "('%s', %s) — נזרק בשקט, הצבעים לא יוחלו" % (key, vt),
                            'בוויזואלים לא-קרטזיים (pie/donut/scatter/treemap/funnel) '
                            'metadata selectors ב-dataPoint.fill מתעלמים בשקט — '
                            'metadata עובד רק בוויזואלים קרטזיים (bar/column/line/area/'
                            'combo). לצביעה פר-קטגוריה ביעד הזה צריך scopeId selectors '
                            '(MS color-strategy.md § Compatibility).')
                        break

                # R-75 · scopeId selector עם ComparisonKind שונה מ-0 (Equal): 1-4 עוברים
                # schema validation אבל נזרקים בשקט ברינדור; >=5 = שגיאת schema
                # (MS formatting.md § Scope Identity Selector, סבב 86).
                # R-76 · selector על אובייקט שלא תומך בסלקטורים בכלל (legend,
                # categoryAxis, valueAxis, VCO title/background/border) — נזרק בשקט
                # (MS formatting.md § Which Objects Support Selectors, סבב 86).
                _ck_bad, _ck_err, _nosel76 = [], [], []
                for oname75, arr75 in vobjs.items():
                    if not isinstance(arr75, list):
                        continue
                    for blk in arr75:
                        if not isinstance(blk, dict):
                            continue
                        sel75 = blk.get('selector') or {}
                        for dd in sel75.get('data') or []:
                            if not isinstance(dd, dict):
                                continue
                            cmp75 = ((dd.get('scopeId') or {}).get('Comparison')) or {}
                            if not cmp75:
                                continue
                            k75 = cmp75.get('ComparisonKind')
                            if k75 in (None, 0):
                                continue
                            try:
                                k75i = int(k75)
                            except Exception:
                                k75i = -1
                            if k75i >= 5:
                                _ck_err.append('%s (ComparisonKind=%s)' % (oname75, k75))
                            else:
                                _ck_bad.append('%s (ComparisonKind=%s)' % (oname75, k75))
                        if oname75 in ('legend', 'categoryAxis', 'valueAxis') and sel75:
                            _nosel76.append(oname75)
                vco76 = vis.get('visualContainerObjects') or {}
                for oname76 in ('title', 'background', 'border'):
                    for blk in vco76.get(oname76) or []:
                        if isinstance(blk, dict) and blk.get('selector'):
                            _nosel76.append('visualContainerObjects.' + oname76)
                if _ck_err:
                    add('err', 'R-75', vj_path,
                        "scopeId selector עם ComparisonKind>=5 בוויזואל '%s': %s — "
                        "שגיאת schema validation" % (key, ', '.join(sorted(set(_ck_err)))),
                        'scopeId (צביעה פר-קטגוריה) מכבד רק ComparisonKind=0 (Equal); '
                        'ערכים >=5 מפילים את אימות הסכמה כולה. לתנאים מורכבים — '
                        'Conditional.Cases (MS formatting.md § Scope Identity).')
                if _ck_bad:
                    add('warn', 'R-75', vj_path,
                        "scopeId selector עם ComparisonKind 1-4 בוויזואל '%s': %s — "
                        "נזרק בשקט ברינדור" % (key, ', '.join(sorted(set(_ck_bad)))),
                        'רק ComparisonKind=0 (Equal) נכבד ב-scopeId; 1-4 עוברים schema '
                        'אבל לא חלים ברינדור — בלי שגיאה (MS formatting.md § Scope Identity).')
                if _nosel76:
                    add('warn', 'R-76', vj_path,
                        "selector על אובייקט שלא תומך בסלקטורים בוויזואל '%s': %s — "
                        "נזרק בשקט" % (key, ', '.join(sorted(set(_nosel76)))),
                        'legend / categoryAxis / valueAxis / VCO title,background,border '
                        'הם אובייקטים רוחביים — אין להם מופעי נתונים, ולכן selector עליהם '
                        'חסר משמעות ונזרק. סלקטורים נתמכים רק באובייקטים data-bound '
                        '(dataPoint/labels/values/columnFormatting) או tile-based עם id '
                        '(MS formatting.md § Which Objects Support Selectors).')

                # R-78 · אובייקטי דף (outspace/outspacePane/filterCard) בתוך
                # visualContainerObjects של ויזואל — לא קיימים שם, נזרקים
                # (MS formatting.md § Page Objects vs VCO, סבב 86).
                # R-79 · מפתח VCO לא מוכר מחוץ ל-15 המתועדים — schema דוחה/מתעלם
                # (PBIR_FORMATTING_OBJECT_UNKNOWN; MS formatting.md § VCO Property
                # Reference, סבב 86).
                _vco_mix78 = sorted(PAGE_ONLY_OBJECTS & set(vco76.keys()))
                if _vco_mix78:
                    add('warn', 'R-78', vj_path,
                        "אובייקטי דף בתוך visualContainerObjects של ויזואל '%s': %s"
                        % (key, ', '.join(_vco_mix78)),
                        'outspace/outspacePane/filterCard הם אובייקטים של page.json '
                        'בלבד — בתוך VCO של ויזואל אין להם משמעות והם נזרקים '
                        '(MS formatting.md § Page Objects vs Visual Container Objects).')
                _vco_unknown79 = sorted(set(vco76.keys()) - VCO_KEYS - PAGE_ONLY_OBJECTS)
                if _vco_unknown79:
                    add('warn', 'R-79', vj_path,
                        "מפתחות VCO לא מוכרים בוויזואל '%s': %s — נזרקים / דחיית schema"
                        % (key, ', '.join(_vco_unknown79)),
                        'visualContainerObjects מכיר 15 מפתחות בלבד (title, subTitle, '
                        'divider, spacing, background, padding, lockAspect, general, '
                        'border, dropShadow, visualLink, visualTooltip, stylePreset, '
                        'visualHeader, visualHeaderTooltip). שם אחר = '
                        'PBIR_FORMATTING_OBJECT_UNKNOWN (MS formatting.md § VCO Property '
                        'Reference).')

                # R-54 · logAxisScale: Desktop נופל ללינארי בשקט אם יש 0/שליליים
                # (MS cartesian.md — לאמת מול המשתמש לפני הפעלה)
                for ax in vobjs.get('valueAxis') or []:
                    pr54 = (ax or {}).get('properties') or {}
                    if not isinstance(pr54, dict) or 'logAxisScale' not in pr54:
                        continue
                    lv = (((pr54.get('logAxisScale') or {}).get('expr') or {})
                          .get('Literal') or {}).get('Value')
                    if lv == 'true':
                        add('warn', 'R-54', vj_path,
                            "logAxisScale בוויזואל '%s' — ודא שהשדה לא מכיל 0/שליליים" % key,
                            'לוג של 0/שלילי לא מוגדר — Desktop נופל לציר לינארי בשקט. '
                            'לאמת שהמדד/עמודה חיוביים תמיד, או לסנן ערכים לא-חיוביים '
                            '(MS cartesian.md).')
                    break
                if 'smallMultiplesLayout' in vobjs:
                    qs52 = ((vis.get('query') or {}).get('queryState')) or {}
                    rows52 = (qs52.get('Rows') or {}).get('projections') or []
                    if not rows52:
                        add('warn', 'R-52', vj_path,
                            "אובייקט smallMultiplesLayout בוויזואל '%s' בלי role Rows מאויש" % key,
                            'הגרף מתפצל ל-small multiples רק כש-Rows מאויש; בלעדיו '
                            'האובייקט מת (MS cartesian.md).')
                # R-57 · expansionStates: חוקי רק כשיש היררכיה בשאילתה, וכל הפניה
                # חייבת להתאים ל-queryRef/role קיימים (MS skills-for-fabric expressions.md)
                exps = ((vis.get('query') or {}).get('expansionStates')) or []
                if isinstance(exps, list) and exps:
                    qs57 = ((vis.get('query') or {}).get('queryState')) or {}
                    all_qrefs = set()
                    has_hier = False
                    for role57, blk in qs57.items():
                        for pr in ((blk or {}).get('projections') or []):
                            if not isinstance(pr, dict):
                                continue
                            if pr.get('queryRef'):
                                all_qrefs.add(pr['queryRef'])
                            f57 = pr.get('field') or {}
                            if isinstance(f57, dict) and ('HierarchyLevel' in f57 or 'Hierarchy' in f57):
                                has_hier = True
                    if not has_hier:
                        add('warn', 'R-57', vj_path,
                            "expansionStates בוויזואל '%s' בלי היררכיה בשאילתה" % key,
                            'expansionStates משמש רק כשיש HierarchyLevel/Hierarchy '
                            'ב-projection; בלי היררכיה — להשמיט לגמרי (MS expressions.md).')
                    for es in exps:
                        if not isinstance(es, dict):
                            continue
                        for role57 in es.get('roles') or []:
                            if role57 not in qs57:
                                add('warn', 'R-57', vj_path,
                                    "expansionStates.roles מכיל '%s' שלא קיים ב-queryState "
                                    "של '%s'" % (role57, key),
                                    'roles חייבים להיות roles עם היררכיה ב-queryState '
                                    '(למשל Rows במטריצה, Values בסליסר) (MS).')
                        for lvl in es.get('levels') or []:
                            for qr in ((lvl or {}).get('queryRefs') or []):
                                if qr not in all_qrefs:
                                    add('warn', 'R-57', vj_path,
                                        "expansionStates.levels.queryRefs מכיל '%s' שלא "
                                        "תואם queryRef בוויזואל '%s'" % (qr, key),
                                        'כל queryRef ברמות חייב להתאים ל-queryRef של '
                                        'projection קיים — אחרת מצב ההרחבה מת (MS).')
                for ls_entry in vobjs.get('lineStyles') or []:
                    ls_props = (ls_entry or {}).get('properties') or {}
                    if not isinstance(ls_props, dict):
                        continue
                    for prop, allowed in LINE_STYLE_ENUMS.items():
                        pv = ls_props.get(prop)
                        if not isinstance(pv, dict):
                            continue
                        lit = (((pv.get('expr') or {}).get('Literal') or {}).get('Value'))
                        if isinstance(lit, str):
                            val = lit.strip("'")
                            if val not in allowed:
                                add('warn', 'R-50', vj_path,
                                    "lineStyles.%s = '%s' בוויזואל '%s' — ערך לא חוקי"
                                    % (prop, val, key),
                                    'ערכים חוקיים: %s (MS cartesian.md). ערך לא מוכר '
                                    'נזרק בשקט.' % '/'.join(sorted(allowed)))

            _collect_rpi(vobj, vj_path, "וויזואל '%s'" % key, rpi_refs)

            # R-42 · stylePreset דורס צבעים מותאמים בטבלאות — בלי 'None' הצבעים
            # נדרסים בשקט ע"י ה-preset הדיפולטי (MS table.md)
            if vt in ('tableEx', 'pivotTable'):
                objs = vis.get('objects') or {}
                custom_colors = False
                for blk in objs.get('values') or []:
                    pr = (blk or {}).get('properties') or {}
                    if isinstance(pr, dict) and ('backColorPrimary' in pr or 'backColorSecondary' in pr):
                        custom_colors = True
                for blk in objs.get('columnHeaders') or []:
                    pr = (blk or {}).get('properties') or {}
                    if isinstance(pr, dict) and 'backColor' in pr:
                        custom_colors = True
                sp = None
                vco1 = vis.get('visualContainerObjects') or {}
                for blk in vco1.get('stylePreset') or []:
                    nm = (((blk or {}).get('properties') or {}).get('name') or {})
                    val = ((nm.get('expr') or {}).get('Literal') or {}).get('Value')
                    if isinstance(val, str):
                        sp = val.strip("'")
                if (sp is not None and sp not in TABLE_STYLE_PRESETS
                        and sp not in TABLEEX_ONLY_PRESETS
                        and sp not in theme_presets.get(vt, set())):
                    add('warn', 'R-42', vj_path,
                        "stylePreset '%s' לא מוכר בוויזואל '%s'" % (sp, key),
                        'המובנים: ' + '/'.join(sorted(TABLE_STYLE_PRESETS)) +
                        ' (+Default/AlternatingRowsNew ב-tableEx בלבד), או preset '
                        'custom הרשום ב-visualStyles של ה-theme (MS theming.md). '
                        'שם לא רשום נופל לדיפולט בשקט.')
                if sp in TABLEEX_ONLY_PRESETS and vt != 'tableEx':
                    add('warn', 'R-42', vj_path,
                        "stylePreset '%s' קיים רק ב-tableEx — לא ב-pivotTable ('%s')" % (sp, key),
                        'ב-pivotTable ייפול לברירת מחדל (MS).')
                if custom_colors and sp != 'None':
                    add('warn', 'R-42', vj_path,
                        "צבעים מותאמים בטבלה '%s' בלי stylePreset='None'" % key,
                        'ה-preset הדיפולטי דורס backColorPrimary/backColorSecondary/'
                        'columnHeaders.backColor בשקט — חובה stylePreset None (MS table.md).')

            # R-13 · mobile.json תקין אם קיים + position הגיוני
            # (visualContainerMobileState: x/y לא-שליליים, width/height חיוביים —
            #  מיקום שבור בנייד = ויזואל נעלם/משובש במובייל בשקט; microsoft/powerbi-models)
            mj = os.path.join(vis_root, vd, 'mobile.json')
            if os.path.exists(mj):
                mobj, err = _load_json(mj)
                if err:
                    add('err', 'R-13', mj, "mobile.json שבור בוויזואל '%s'" % key, err)
                    ok = False
                else:
                    mpos = mobj.get('position') if isinstance(mobj, dict) else None
                    if not isinstance(mpos, dict):
                        add('err', 'R-13', mj,
                            "mobile.json בלי position תקין בוויזואל '%s'" % key,
                            'חובה אובייקט position עם x/y/width/height.')
                        ok = False
                    else:
                        nums = {kk: mpos.get(kk) for kk in ('x', 'y', 'width', 'height')}
                        if any(not isinstance(vv, (int, float)) or isinstance(vv, bool)
                               for vv in nums.values()):
                            add('err', 'R-13', mj,
                                "mobile.json position חסר x/y/width/height מספריים בוויזואל '%s'" % key,
                                'וויזואל בלי גאומטריית נייד מלאה עלול להיעלם במובייל.')
                            ok = False
                        elif nums['width'] <= 0 or nums['height'] <= 0 or nums['x'] < 0 or nums['y'] < 0:
                            add('err', 'R-13', mj,
                                "mobile.json position לא הגיוני (x=%s y=%s w=%s h=%s) בוויזואל '%s'" % (
                                    nums['x'], nums['y'], nums['width'], nums['height'], key),
                                'ממדים לא-חיוביים או קואורדינטות שליליות שוברים את מתכונת הנייד.')
                            ok = False

            # איסוף קישורי שדות של הוויזואל — תמיד (R-25), ובדיקה מול המודל אם ניתן --model (R-15)
            refs = []

            if True:
                def field_cb(o):
                    for kind in ('Measure', 'Column'):
                        fd = o.get(kind)
                        if isinstance(fd, dict) and fd.get('Property'):
                            try:
                                sr = fd['Expression']['SourceRef']
                                if sr.get('Schema'):
                                    return  # extension measures — לא טבלת מודל
                                ent = sr.get('Entity', '')
                            except Exception:
                                ent = ''
                            refs.append((kind, ent, str(fd['Property'])))
                    ag = o.get('Aggregation')
                    if isinstance(ag, dict):
                        try:
                            c = ag['Expression']['Column']
                            refs.append(('Column', c['Expression']['SourceRef'].get('Entity', ''),
                                         str(c.get('Property', ''))))
                        except Exception:
                            pass

                _walk((vis.get('query') or {}).get('queryState') or {}, field_cb)
                # R-25 · sortDefinition: שדה המיון חייב להיות מוקרן בוויזואל + direction חוקי
                ref_keys = {(k2, e2, p2) for k2, e2, p2 in refs}
                sd = ((vis.get('query') or {}).get('sortDefinition') or {})
                for si, srt in enumerate(sd.get('sort') or []):
                    if not isinstance(srt, dict):
                        continue
                    dirc = srt.get('direction')
                    if dirc is not None and dirc not in ('Ascending', 'Descending'):
                        add('warn', 'R-25', vj_path,
                            "וויזואל '%s' — direction לא חוקי במיון: '%s'" % (key, dirc),
                            'ערכים חוקיים: Ascending / Descending.')
                    sfd = srt.get('field')
                    sref = None
                    if isinstance(sfd, dict):
                        for kind in ('Measure', 'Column'):
                            node = sfd.get(kind)
                            if isinstance(node, dict) and node.get('Property'):
                                try:
                                    sref = (kind, node['Expression']['SourceRef'].get('Entity', ''),
                                            str(node['Property']))
                                except Exception:
                                    sref = None
                    if sref and ref_keys and sref not in ref_keys:
                        add('warn', 'R-25', vj_path,
                            "וויזואל '%s' ממוין לפי %s[%s] שאינו מוקרן בוויזואל" % (key, sref[1], sref[2]),
                            'מיון מת — קלאסי אחרי הסרת שדה מהוויזואל בלי לעדכן sortDefinition. '
                            'אומת מול ייצוא Desktop אמיתי (K201).')
                for kind, ent, prop in (refs if model_tables else []):
                    if not ent:
                        continue
                    if ent not in model_tables:
                        add('err', 'R-15', vj_path,
                            "וויזואל '%s' מקושר לטבלה '%s' שלא קיימת במודל" % (key, ent),
                            'שדה שמפנה לטבלה חסרה = ויזואל שמרנדר ריק/שבור **בשקט**. '
                            'קלאסי אחרי שינוי שם טבלה ב-TMDL.')
                        ok = False
                    else:
                        t = model_tables[ent]
                        if prop not in t['columns'] and prop not in t['measures']:
                            add('warn', 'R-15', vj_path,
                                "וויזואל '%s' מקושר ל-%s[%s] שלא נמצא בטבלה" % (key, ent, prop),
                                'ייתכן שינוי שם עמודה/מדד. אם זו עמודה מחושבת ברמת הדוח — התעלם.')

        page_visual_names[pname or d] = set(vis_names)

        # R-16 · חפיפה בין ויזואלי נתונים
        # מכולות visualGroup לא נספרות: המכולה שקופה ומכילה את חבריה מתוך כוונה
        # (ה-bbox מחושב מהם) — זיווג מכולה/חבר הוא FP מובנה.
        data_rects = [r for r in page_rects if not r[5] and not r[6]]
        for i in range(len(data_rects)):
            for j in range(i + 1, len(data_rects)):
                ra, rb = data_rects[i], data_rects[j]
                ox = min(ra[1] + ra[3], rb[1] + rb[3]) - max(ra[1], rb[1])
                oy = min(ra[2] + ra[4], rb[2] + rb[4]) - max(ra[2], rb[2])
                if ox > 0.5 and oy > 0.5:
                    add('warn', 'R-16', pj, "חפיפה בדף '%s': '%s' מעל '%s'" % (d, ra[0], rb[0]),
                        'שני ויזואלי נתונים חופפים — כמעט תמיד תאונת גרירה. '
                        'ויזואלי דקור (צורות/טקסט/כפתורים) אינם נספרים.')

        # R-67 · שלמות קיבוץ ויזואלים (visualGroup). המבנה: מכולה = visual.json עם
        # visualGroup {displayName, groupMode} במקום visual + position שהוא bbox של
        # החברים; כל חבר מתויג parentGroupName ברמה העליונה. אומת מול
        # mudassir09/pbi-enterprise-cli pbir_backend.visual_group_add (MIT) — המחבר
        # וידא מול Desktop שמכולה ללא >=2 חברים אינה חוקית ושלחיצה על חבר בוחרת
        # את כל הקבוצה. בקורפוס הפתוח אין ייצואים מקובצים — כיסוי דרך הזרקה סינתטית.
        for mkey, mparent, mrect in page_members:
            if mparent not in page_groups:
                add('err', 'R-67', pj,
                    "וויזואל '%s' מתויג parentGroupName='%s' אבל אין מכולת קבוצה כזו בדף '%s'"
                    % (mkey, mparent, d),
                    'תיוג קבוצה תלוי = הוויזואל נגרר עם קבוצה שלא קיימת; Desktop מתעלם '
                    'או שובר את הבחירה. כנראה מחיקה חלקית של מכולת קבוצה.')
                ok = False
        for gkey, grect in page_groups.items():
            members = [m for m in page_members if m[1] == gkey]
            if len(members) < 2:
                add('warn', 'R-67', pj,
                    "מכולת הקבוצה '%s' בדף '%s' עם %d חברים בלבד — קבוצה דורשת 2+"
                    % (gkey, d, len(members)),
                    'Desktop יוצר קבוצה רק מ-2 ויזואלים ומעלה; מכולה עם פחות היא שארית '
                    'של ביטול קיבוץ חלקי.')
            gx, gy, gw, gh = grect
            for mkey, _mp, mrect in members:
                mx, my, mw, mh = mrect
                if mx < gx - 0.5 or my < gy - 0.5 or                    mx + mw > gx + gw + 0.5 or my + mh > gy + gh + 0.5:
                    add('warn', 'R-67', pj,
                        "הוויזואל '%s' חורג מה-bbox של מכולת הקבוצה '%s' בדף '%s'"
                        % (mkey, gkey, d),
                        'ה-bbox של המכולה מחושב מהחברים; חריגה = הזזה/שינוי קנה מידה '
                        'של הקבוצה לא יכסה את החבר.')

        # R-20 · z כפול — סדר שכבות לא מוגדר
        for z, names in page_z.items():
            if len(names) > 1:
                add('info', 'R-20', pj, "z=%s משותף בדף '%s' (%s)" % (z, d, ', '.join(names)),
                    'Desktop מקצה z ייחודי לכל ויזואל; z כפול = קלאסי של clone בלי עדכון, '
                    'וסדר השכבות בלתי צפוי.')

        # R-09 · מסנני דף
        for f in page_filters:
            if not isinstance(f, dict) or not f.get('name') or not f.get('field'):
                add('warn', 'R-09', pj, "מסנן דף בלי name/field בדף '%s'" % d,
                    'רשומת מסנן חסרת שדות חובה.')
            else:
                ref = _filter_field_ref(f)
                if ref and not _check_ref(model_tables, ref[0], ref[1], ref[2],
                                          'R-22', pj, "מסנן דף בדף '%s'" % d):
                    ok = False
            if isinstance(f, dict) and not _check_filter_shape(
                    f, pj, "-דף '%s'" % d, 'page'):
                ok = False

        # R-10 · visualInteractions מפנים לוויזואלים קיימים בדף
        for vi in pobj.get('visualInteractions') or []:
            for end in ('source', 'target'):
                tgt = vi.get(end)
                if tgt and tgt not in vis_names:
                    add('warn', 'R-10', pj,
                        "visualInteractions בדף '%s' מפנה לוויזואל '%s' שלא קיים" % (d, tgt),
                        'אינטראקציה לוויזואל שנמחק/שונה שמו = הגדרה מתה.')

    # R-09b · מסנני דוח
    for f in report_filters:
        if not isinstance(f, dict) or not f.get('name') or not f.get('field'):
            add('warn', 'R-09', rj_path, 'מסנן דוח גלובלי בלי name/field',
                'רשומת מסנן חסרת שדות חובה.')
        else:
            ref = _filter_field_ref(f)
            if ref and not _check_ref(model_tables, ref[0], ref[1], ref[2],
                                      'R-22', rj_path, 'מסנן דוח גלובלי'):
                ok = False
        if isinstance(f, dict) and not _check_filter_shape(
                f, rj_path, '-דוח גלובלי', 'report'):
            ok = False

    # R-11 · סימניות
    bm_root = os.path.join(report_dir, 'definition', 'bookmarks')
    bmj = os.path.join(bm_root, 'bookmarks.json')
    if os.path.exists(bmj):
        obj, err = _load_json(bmj)
        if err:
            add('err', 'R-11', bmj, 'bookmarks.json — JSON שבור', err)
            ok = False
        else:
            for item in obj.get('items') or []:
                bid = item.get('name')
                bf = os.path.join(bm_root, '%s.bookmark.json' % bid)
                if not bid:
                    continue
                if not os.path.exists(bf):
                    add('err', 'R-11', bmj, "לסימנייה '%s' אין קובץ %s.bookmark.json" % (bid, bid),
                        'סימנייה רשומה בלי קובץ מצב — תישבר בלחיצה.')
                    ok = False
                    continue
                bobj, err = _load_json(bf)
                if err:
                    add('err', 'R-11', bf, "קובץ הסימנייה '%s' שבור" % bid, err)
                    ok = False
                    continue
                # הפניה לדף: sections בשמות ישנים / targetVisualNames
                tgt_page = ((bobj.get('explorationState') or {}).get('activeSection')
                            or bobj.get('activeSection') or '')
                if tgt_page and page_dirs and tgt_page not in page_dirs and tgt_page not in seen_page_names:
                    add('warn', 'R-11', bf, "הסימנייה '%s' מפנה לדף '%s' שלא קיים" % (bid, tgt_page),
                        'סימנייה לדף שנמחק/שונה שמו (קלאסי אחרי שכפול דף).')
                # R-23 · מצב סימנייה מיושן: sections/ויזואלים שלא קיימים עוד
                es = bobj.get('explorationState') or {}
                for sec_name, sec in (es.get('sections') or {}).items():
                    if not isinstance(sec, dict):
                        continue
                    if sec_name not in seen_page_names and sec_name not in page_dirs:
                        add('warn', 'R-23', bf,
                            "הסימנייה '%s' שומרת מצב לדף '%s' שלא קיים" % (bid, sec_name),
                            'מצב מיושן לדף שנמחק/שונה שמו — נשאר בשקט.')
                        continue
                    live = page_visual_names.get(sec_name, set())
                    for vc_name in (sec.get('visualContainers') or {}):
                        if live and vc_name not in live:
                            add('warn', 'R-23', bf,
                                "הסימנייה '%s' שומרת מצב לוויזואל '%s' שלא קיים בדף '%s'"
                                % (bid, vc_name, sec_name),
                                'קלאסי אחרי מחיקת ויזואל — הסימנייה מסמנת ויזואל מת.')
    elif os.path.isdir(bm_root):
        add('warn', 'R-11', bm_root, 'תיקיית bookmarks קיימת בלי bookmarks.json', 'מבנה חסר.')

    # R-12 · reportExtensions.json תקין אם קיים. הרחבה (סבב 97): קובץ קיים עם
    # "entities": [] ריק = Desktop מתרסק בפתיחה, לא רק אזהרה — למחוק את הקובץ
    # כשאין מדדי הרחבה (jonathan-pap/powerbi-report-mcp pbir-gotchas.md B15, MIT;
    # אומת ע"י כתיבה->פתיחה ב-Desktop->קריאה חוזרת).
    rex = os.path.join(report_dir, 'definition', 'reportExtensions.json')
    if os.path.exists(rex):
        robj, err = _load_json(rex)
        if err:
            add('err', 'R-12', rex, 'reportExtensions.json — JSON שבור', err)
            ok = False
        elif isinstance(robj, dict) and isinstance(robj.get('entities'), list) \
                and not robj['entities']:
            add('err', 'R-12', rex,
                'reportExtensions.json עם entities ריק — Desktop מתרסק בפתיחה',
                'למחוק את הקובץ לחלוטין כשאין מדדי הרחבה; יוצרים אותו רק כשיש '
                'מה לאחסן (powerbi-report-mcp pbir-gotchas.md B15, MIT).')
            ok = False

    # R-14 · קבצי theme תקינים
    for tf in _theme_files(report_dir):
        obj14, err = _load_json(tf)
        if err:
            add('err', 'R-14', tf, 'קובץ theme/משאב שבור', err)
            ok = False
        else:
            _check_theme_content(tf, obj14,
                                 is_ms_base=('/BaseThemes/' in tf.replace(os.sep, '/') or
                                             '/BuiltInThemes/' in tf.replace(os.sep, '/')))

    # R-43 · תמונות — הפניות ResourcePackageItem מול רישום ב-report.json
    if not _resolve_rpi(report_dir, rj_obj, rpi_refs):
        ok = False

    return ok


# שדות צבע מבניים ב-theme (MS skills-for-fabric theming.md)
_THEME_COLOR_FIELDS = ('good', 'neutral', 'bad', 'maximum', 'center', 'minimum', 'null',
                       'foreground', 'background', 'tableAccent')
_THEME_HEX = re.compile(r'^#[0-9A-Fa-f]{6}([0-9A-Fa-f]{2})?$')


def _theme_files(report_dir):
    """קבצי theme/משאב תחת StaticResources (מסוננים לפי סיומת json)."""
    return glob.glob(os.path.join(report_dir, 'StaticResources', '**', '*.json'),
                     recursive=True)


def _theme_presets(report_dir):
    """stylePresets רשומים ב-theme: visualStyles[type][presetName] (רמה 2, חוץ מ-'*').
    מקור: MS skills-for-fabric theming.md — שמות preset הם מחרוזות שרירותיות
    שנרשמות ב-theme; בלי הרישום הוויזואל נופל ל-preset הדיפולטי ('*')."""
    presets = {}
    for tf in _theme_files(report_dir):
        obj, err = _load_json(tf)
        if err or not isinstance(obj, dict):
            continue
        vs = obj.get('visualStyles')
        if not isinstance(vs, dict):
            continue
        for vt, lv2 in vs.items():
            if vt == '*' or not isinstance(lv2, dict):
                continue
            for pname in lv2:
                if pname != '*':
                    presets.setdefault(vt, set()).add(pname)
    return presets



_THEME_CATALOG = None
def _theme_catalog():
    """קטלוג מאפייני theme מסכמת Microsoft הרשמית (reportThemeSchema-2.157.json,
    MIT — data/theme-catalog-2.157.json). None אם הקובץ חסר."""
    global _THEME_CATALOG
    if _THEME_CATALOG is None:
        cp = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                          '..', 'data', 'theme-catalog-2.157.json')
        try:
            _THEME_CATALOG = json.load(open(cp, encoding='utf-8'))
        except Exception:
            _THEME_CATALOG = {}
    return _THEME_CATALOG or None

def _check_theme_content(tf, obj, is_ms_base=False):
    """R-51 · תקינות צבעים/textClasses ב-theme (MS skills-for-fabric theming.md):
    dataColors ושדות הצבע המבניים הם hex (#RRGGBB או #RRGGBBAA); ב-textClasses
    fontSize מספרי ו-color הוא hex. ערך לא חוקי נזרק בשקט ב-Desktop."""
    if not isinstance(obj, dict):
        return
    def _bad_hex(c):
        return not (isinstance(c, str) and _THEME_HEX.match(c))
    dc = obj.get('dataColors')
    if isinstance(dc, list):
        for c in dc:
            if _bad_hex(c):
                add('warn', 'R-51', tf, 'dataColors מכיל צבע לא חוקי: %r' % (c,),
                    'צבעי theme הם מחרוזות hex (#RRGGBB) — ערך לא חוקי נזרק (MS).')
    for f in _THEME_COLOR_FIELDS:
        c = obj.get(f)
        if c is not None and _bad_hex(c):
            add('warn', 'R-51', tf, "שדה הצבע '%s' ב-theme לא hex חוקי: %r" % (f, c),
                'good/neutral/bad/maximum/center/minimum/null/foreground/background/'
                'tableAccent — hex בלבד (MS).')
    tc = obj.get('textClasses')
    if isinstance(tc, dict):
        for k, cls in tc.items():
            if not isinstance(cls, dict):
                continue
            fs = cls.get('fontSize')
            if fs is not None and (not isinstance(fs, (int, float)) or isinstance(fs, bool)):
                add('warn', 'R-51', tf, "textClasses.%s.fontSize לא מספרי: %r" % (k, fs),
                    'fontSize ב-pt כמספר (MS).')
            col = cls.get('color')
            if col is not None and _bad_hex(col):
                add('warn', 'R-51', tf, "textClasses.%s.color לא hex חוקי: %r" % (k, col),
                    'color ב-textClasses הוא מחרוזת hex (MS).')

    # M-27 · ולידציית theme מול קטלוג הסכמה הרשמית (microsoft/powerbi-desktop-samples,
    # reportThemeSchema 2.157, MIT). דוח שדה סבב 3 (#6): ניחוש שם מאפיין ב-theme
    # נכשל בשקט; שורש לא מוכר אסור לחלוטין (additionalProperties:false בסכמה).
    cat = _theme_catalog()
    if cat:
        root_keys = set(cat['rootKeys'])
        for k in obj:
            if k not in root_keys:
                add('err', 'M-27', tf, "מפתח שורש לא מוכר ב-theme: '%s'" % k,
                    'סכמת theme הרשמית (2.157) סוגרת את השורש (additionalProperties: false) — '
                    'מפתח כזה עלול לפסול את כל הקובץ (דוח שדה סבב 3: _source/_comment_chrome).')
        vs = obj.get('visualStyles')
        if isinstance(vs, dict):
            known_vts = set(cat['visualTypes'])
            common_cards = cat['commonCards']
            common_wild = set(cat['commonWildcardProps'])
            visual_props = cat['visualProps']
            for vt, presets in vs.items():
                if not isinstance(presets, dict):
                    continue
                if vt != '*' and vt not in known_vts:
                    if vt in cat.get('legacyAliases', {}):
                        pass  # כינוי legacy שנצפה בערכות MS רשמיות (basicShape ← shape)
                    else:
                        add('info', 'M-27', tf, "visualStyles.%s — סוג ויזואל לא מוכר בסכמה" % vt,
                            'ייתכן ויזואל מותאם (custom visual); המאפיינים שלו לא נבדקו.')
                        continue
                # איחוד המאפיינים שהסכמה מכירה עבור ה-vt: משטח ה-vt + הכרטיסים המשותפים
                # vt='*' פירושו "כל הוויזואלים" — מאחדים את כל המאפיינים הידועים
                if vt == '*':
                    allowed = set()
                    for vp in visual_props.values():
                        allowed |= set(vp)
                else:
                    allowed = set(visual_props.get(vt, []))
                allowed |= common_wild | set(cat['textClassProps']) | set(cat['internalKeys'])
                for cp in common_cards.values():
                    allowed |= set(cp)
                # שכבת "נצפה אצל Microsoft": מאפיינים שערכות הבסיס/המובנות הרשמיות
                # משתמשות בהם אף שסכמת 2.157 לא מונה אותם (למשל page.filterCard.*)
                for ovt, oprops in cat.get('observedProps', {}).items():
                    if vt == '*' or ovt == '*' or ovt == vt:
                        allowed |= set(oprops)
                for preset, cards in presets.items():
                    if not isinstance(cards, dict):
                        continue
                    for card, items in cards.items():
                        if not isinstance(items, list):
                            continue
                        for item in items:
                            if not isinstance(item, dict):
                                continue
                            for prop in item:
                                if prop not in allowed:
                                    add('err', 'M-27', tf,
                                        "מאפיין לא מוכר ב-theme: visualStyles.%s.%s.%s — '%s'"
                                        % (vt, preset, card, prop),
                                        'המאפיין לא קיים בסכמת theme 2.157 הרשמית. שגיאת '
                                        'כתיב/ניחוש כאן נכשלת בשקט או פוסלת את הקובץ '
                                        '(דוח שדה סבב 3 #6).')
                            if is_ms_base:
                                continue  # ערכות MS רשמיות משתמשות בכך לגיטימית
                            if vt == '*' and card == 'padding':
                                add('warn', 'M-27', tf,
                                    'visualStyles.*.*.padding בשימוש',
                                    'דוח שדה סבב 3 רשם שזה פסל את קובץ ה-theme כולו, אך '
                                    'מאפיין זה קיים גם בערכת הבסיס הרשמית Fluent 2 של '
                                    'Microsoft — סתירה; חובה אימות ב-Desktop.')
                            if vt == '*' and card == 'dropShadow' and 'shadowSpread' in item:
                                add('warn', 'M-27', tf,
                                    'visualStyles.*.*.dropShadow.shadowSpread בשימוש',
                                    'דוח שדה סבב 3 רשם שזה פסל את קובץ ה-theme כולו, אך '
                                    'מאפיין זה קיים גם בערכת הבסיס הרשמית Fluent 2 של '
                                    'Microsoft — סתירה; חובה אימות ב-Desktop.')
                if vt == 'textbox' and not is_ms_base:
                    add('warn', 'M-27', tf, 'visualStyles.textbox בשימוש',
                        'בשדה (דוח סבב 3) הפך תיבות טקסט לבלתי-נראות — לאמת ב-Desktop.')


# ══════════════════════════ בדיקות מודל (TMDL) ══════════════════════════
def _resolve_rpi(report_dir, rj_obj, rpi_refs):
    """R-43 · כל ResourcePackageItem חייב רשומה ב-report.json resourcePackages עם
    type='Image' וקובץ קיים ב-StaticResources/RegisteredResources (MS image.md)."""
    if not rpi_refs or not isinstance(rj_obj, dict):
        return True
    ok = True
    registered = {}
    for pkg in rj_obj.get('resourcePackages') or []:
        if isinstance(pkg, dict) and pkg.get('name') == 'RegisteredResources':
            for item in pkg.get('items') or []:
                if isinstance(item, dict) and item.get('name'):
                    registered[item['name']] = item
    for loc, vname, item_name, pkg_name in rpi_refs:
        if pkg_name != 'RegisteredResources' or not isinstance(item_name, str):
            continue
        entry = registered.get(item_name)
        if entry is None:
            add('err', 'R-43', loc,
                "ResourcePackageItem '%s' ב%s לא רשום ב-report.json" % (item_name, vname),
                'התמונה לא תרנדר — חובה רשומה תחת resourcePackages[RegisteredResources] '
                'והקובץ ב-StaticResources/RegisteredResources (MS image.md).')
            ok = False
            continue
        if entry.get('type') != 'Image':
            add('err', 'R-43', loc,
                "רשומת '%s' עם type='%s' במקום 'Image'" % (item_name, entry.get('type')),
                'type חייב להיות "Image" — ערך אחר מכשיל schema validation (MS).')
            ok = False
        if '.' not in os.path.basename(item_name):
            add('warn', 'R-43', loc,
                "שם הרשומה '%s' בלי סיומת קובץ" % item_name,
                'הסיומת חובה — השמטה שוברת רינדור של התמונה (MS).')
        path = entry.get('path') or item_name
        if not os.path.exists(os.path.join(report_dir, 'StaticResources',
                                            'RegisteredResources', path)):
            add('err', 'R-43', loc,
                "קובץ התמונה '%s' חסר ב-StaticResources/RegisteredResources" % path,
                'הרשומה קיימת אבל הקובץ לא — התמונה לא תרנדר (MS).')
            ok = False
    return ok


def _local_artifacts(d):
    """R-85 · פריטי cache/מקומיים בתוך תיקיית פרויקט: .pbi/localSettings.json,
    .pbi/cache.abf ו-*.pbix/*.pbit. ה-.gitignore ש-Desktop עצמו יוצר ב-PBIP
    מתעלם בדיוק משני הראשונים (MS Learn projects-overview, CC-BY-4.0, דף חדש);
    pbix/pbit הם בינאריים גדולים שלא שייכים לעץ מקור (pbip-doctor PBIP004, MIT).
    editorSettings.json מכוון לא להיספן — Desktop לא מתעלם ממנו."""
    hits = []
    pbi = os.path.join(d, '.pbi')
    for fn in ('localSettings.json', 'cache.abf'):
        fp = os.path.join(pbi, fn)
        if os.path.isfile(fp):
            hits.append(fp)
    return hits


def validate_model(sm_dir):
    ok = True
    tables_dir = os.path.join(sm_dir, 'definition', 'tables')
    if not os.path.isdir(tables_dir):
        add('warn', 'M-01', sm_dir, 'אין definition/tables — ייתכן model.bim (לא TMDL)',
            'בדיקות המבנה מכסות TMDL בלבד.')
        return ok

    model_tables = read_model_map(sm_dir)

    # M-25 · dataType חוקי בלבד (ממצא שדה סבב 2 #0, 🔴🔴 — הוולידטור אשרר ערך
    # לא חוקי והחזיר "0 שגיאות" על פרויקט ש-Desktop מסרב לפתוח). הטיפוסים
    # החוקיים לעמודה: Microsoft.AnalysisServices.Tabular.DataType enum
    # (MS Learn, CC-BY-4.0) + תצפית קורפוס (772 string / 458 int64 / 158 double
    # / 128 dateTime / 33 decimal / 11 boolean / 2 binary — כולם חוקיים).
    # ערך מחוץ לרשימה (טיפוסי: integer/int/text שהוקלדו ידנית או הולכו ע"י
    # מחולל) = שגיאת טעינה ב-Desktop → err. ההשוואה case-sensitive —
    # 'datetime' באותיות קטנות אינו 'dateTime' וגם הוא יסומן.
    _LEGAL_DT = {'automatic', 'string', 'int64', 'double', 'dateTime', 'decimal',
                 'boolean', 'binary', 'unknown', 'variant'}
    for tname, t in model_tables.items():
        for col, dt in t['col_types'].items():
            if dt not in _LEGAL_DT:
                add('err', 'M-25', t['file'],
                    "dataType לא חוקי '%s' בעמודה '%s'.'%s'" % (dt, tname, col),
                    'הערכים החוקיים היחידים: automatic, string, int64, double, dateTime, '
                    'decimal, boolean, binary, unknown, variant (enum '
                    'Microsoft.AnalysisServices.Tabular.DataType — MS Learn; שדה: '
                    'TmdlValue.ParseEnum דחה date). Desktop מסרב לפתוח מודל עם טיפוס לא '
                    'חוקי — כשל חוסם. לתקן לטיפוס המתאים (date→dateTime, integer→int64, text→string).')
                ok = False

    # M-29 · ולידציית ערכים מול סכמת TMDL (דוח שדה סבב 3 #1, 🔴🔴 — שורות
    # 2/3 בטבלת השבירות שלו: 'description:' כמאפיין measure ו-compatibilityLevel
    # שגוי עברו עם "0 שגיאות" ו-Desktop הציג Frown).
    # (א) description: בכתיב נקודתיים — TMDL מגדיר תיאורים *אך ורק* בתחביר ///
    #     מעל הצהרת האובייקט (MS Learn tmdl-overview § Descriptions: "descriptions
    #     are specified on top of each object declaration using triple-slash").
    #     שורת 'description:' היא מאפיין לא מוכר → שגיאת parse ב-Desktop.
    #     מפתח JSON מרושת ("description":) בתוך בלוק JSON (cultures) = חוקי.
    # (ב) compatibilityLevel — מאפיין ברמת מסד בלבד: definition/database.tmdl
    #     (או model.bim ב-Legacy). בכל קובץ tmdl אחר = שגיאת מיקום.
    #     ערך חוקי: מספר שלם מהרמות המתועדות ב-MS Learn (1100/1103/1200/1400/
    #     1500/1600/1700) או רמות-ביניים שנצפו ביצואי Desktop אמיתיים בקורפוס
    #     (1550/1567/1606/1702). ערך לא מוכר = warn בלבד (Desktop מוסיף רמות
    #     בין-גרסאות; אין לחסום רמה עתידית). לא-מספרי = err.
    _KNOWN_CL = {1100, 1103, 1200, 1400, 1500, 1550, 1567, 1600, 1606, 1700, 1702}
    _db_tmdl = os.path.join(sm_dir, 'definition', 'database.tmdl')
    for _root, _dirs, _files in os.walk(os.path.join(sm_dir, 'definition')):
        for _f in _files:
            if not _f.endswith('.tmdl'):
                continue
            _fp = os.path.join(_root, _f)
            try:
                with open(_fp, encoding='utf-8-sig', errors='ignore') as _fh:
                    _lines = _fh.read().splitlines()
            except OSError:
                continue
            for _ln in _lines:
                _m = re.match(r'^\s*description\s*:', _ln)
                if _m:
                    add('err', 'M-29', _fp,
                        "description: בכתיב נקודתיים — תחביר לא חוקי ב-TMDL",
                        'TMDL מגדיר תיאורים אך ורק כשורות /// מעל הצהרת האובייקט '
                        '(MS Learn tmdl-overview § Descriptions). שורת description: '
                        'היא מאפיין לא מוכר → Desktop מסרב לטעון (דוח שדה סבב 3, שורה 2). '
                        'להמיר לשורות /// מעל האובייקט.')
                    ok = False
                _m = re.match(r'^\s*compatibilityLevel\s*:\s*(\S+)', _ln)
                if _m:
                    _raw = _m.group(1).strip().rstrip(',')
                    if os.path.normpath(_fp) != os.path.normpath(_db_tmdl):
                        add('err', 'M-29', _fp,
                            "compatibilityLevel בקובץ הלא-נכון ('%s')" % _f,
                            'compatibilityLevel הוא מאפיין ברמת מסד — המיקום החוקי '
                            'היחיד ב-TMDL הוא definition/database.tmdl (ב-Legacy: '
                            'model.bim). בכל קובץ אחר Desktop מציג שגיאה.')
                        ok = False
                    elif not _raw.isdigit():
                        add('err', 'M-29', _fp,
                            "compatibilityLevel לא מספרי: '%s'" % _raw,
                            'הערך חייב להיות מספר שלם (למשל 1600). ערך טקסטואלי/'
                            'עשרוני = שגיאת טעינה ב-Desktop.')
                        ok = False
                    elif int(_raw) not in _KNOWN_CL:
                        add('warn', 'M-29', _fp,
                            "compatibilityLevel %s לא מתועד" % _raw,
                            'הרמות המתועדות ב-MS Learn: 1100/1103/1200/1400/1500/'
                            '1600/1700; רמות-ביניים שנצפו ביצואי Desktop בקורפוס: '
                            '1550/1567/1606/1702. ייתכן רמה חדשה מגרסת Desktop עדכנית '
                            '— לאמת מול Desktop לפני מסירה.')

    # M-02 · מחיצות: mode + source
    for tname, t in model_tables.items():
        f = t['file']
        with open(f, encoding='utf-8-sig', errors='ignore') as fh:
            txt = fh.read()
        for blk in re.split(r'\n(?=\tpartition )', txt):
            if not blk.strip().startswith('partition'):
                continue
            # כיול על מודל אמיתי: מחיצות calculationGroup/calculated אינן נושאות
            # mode/source בצורה חוקית — לא לדרוש אותן (powerbi-templates Time Comparison).
            head_ln = blk.strip().splitlines()[0]
            if re.search(r'=\s*(calculationGroup|calculated)\b', head_ln):
                continue
            if not re.search(r"(?m)^\s*mode:\s*\w+", blk):
                add('warn', 'M-02', f, "מחיצה בטבלה '%s' בלי mode" % tname,
                    'מחיצה חייבת mode (import/directQuery/dual).')
            if 'source' not in blk and 'expression' not in blk:
                add('warn', 'M-02', f, "מחיצה בטבלה '%s' בלי source" % tname,
                    'מחיצה בלי מקור = טבלה ריקה.')

    # M-16 · נתיב מקומי מוחלט בביטוי M של מחיצה (כונן X:\ או נתיב רשת \\) —
    # לא נייד: הדוח מתרענן אצל הכותב בלבד ונשבר אצל כל מפתח אחר או בשירות.
    # מקור: pbi-assure rule catalog — PBI-SOURCE-001 (MIT; ריפו חדש). כמו
    # שם, ערך הנתיב עצמו אינו מדווח בכוונה — נתיבים חושפים שמות משתמש.
    # נמצא בקורפוס האמיתי: claude — Csv.Document(File.Contents("C:\...\
    # Downloads\deliveries.csv")) ב-deliveries/matches; pbisample —
    # Excel.Workbook/Csv.Document מנתיב C:\Users\...\Desktop.
    _abspath = re.compile(r'"(?:[A-Za-z]:\\|\\\\[^\\/\s])')
    for tname, t in model_tables.items():
        f = t['file']
        with open(f, encoding='utf-8-sig', errors='ignore') as fh:
            txt = fh.read()
        n_hit = 0
        for blk in re.split(r'\n(?=\tpartition )', txt):
            if not blk.strip().startswith('partition'):
                continue
            n_hit += len(_abspath.findall(blk))
        if n_hit:
            add('warn', 'M-16', f,
                "טבלה '%s': נתיב מקומי מוחלט בביטוי M של המחיצה" % tname,
                'מקור: pbi-assure rule catalog — PBI-SOURCE-001 (MIT). נתיב קובץ '
                'מוחלט (כונן או רשת) אינו נייד: רענון במחשב של מפתח אחר או '
                'בשירות Power BI נכשל, וגם נתיב OneDrive/SharePoint המסונכרן '
                'מקומית שביר. ערך הנתיב אינו מוצג בכוונה (פרטיות). להחליף '
                'לפרמטר מקור או למקור ענן משותף.')

    # M-17 · נתיב מקומי מוחלט בביטוי משותף/פרמטר (expressions.tmdl). M-16 מכסה
    # partitions של טבלאות; הפרמטרים עצמם יושבים ב-expressions.tmdl — שם הנתיב
    # האמיתי מתחבא (נמצא בקורפוס: metro — פרמטר SourceFile עם נתיב C:\Users
    # אמיתי; insurance — pProjectRoot עם ברירת-מחדל מקומית). expressions.tmdl
    # הוא קובץ M טהור (אין DAX) — סריקה גולמית בטוחה. ערך הנתיב אינו מוצג
    # (פרטיות). מקור: MS Learn Power Query parameters (CC-BY-4.0, דף חדש) —
    # פרמטר הוא מנגנון הניידות הנכון, אבל ברירת-מחדל מקומית עדיין שבירה;
    # השלמה ל-pbi-assure PBI-SOURCE-001 (MIT).
    expr_file = os.path.join(sm_dir, 'definition', 'expressions.tmdl')
    if os.path.isfile(expr_file):
        with open(expr_file, encoding='utf-8-sig', errors='ignore') as fh:
            etxt = fh.read()
        for em in re.finditer(r"(?m)^expression\s+(?:'([^']+)'|(\S+))\s*=", etxt):
            ename = (em.group(1) or em.group(2) or '').strip()
            # הבלוק של הביטוי — עד ה-expression הבא או סוף הקובץ
            nxt = etxt.find('\nexpression ', em.end())
            blk = etxt[em.end(): nxt if nxt > 0 else len(etxt)]
            if _abspath.search(blk):
                add('warn', 'M-17', expr_file,
                    "ביטוי משותף '%s' מכיל נתיב מקומי מוחלט" % ename,
                    'מקור: MS Learn Power Query parameters (CC-BY-4.0). פרמטר/פונקציה '
                    'משותפת עם נתיב כונן או רשת מוחלט אינה ניידת — הרענון נכשל אצל '
                    'מפתח אחר או בשירות. ערך הנתיב אינו מוצג (פרטיות). גם כשהנתיב '
                    'יושב בפרמטר (התבנית הנכונה), ברירת-המחדל המקומית שבירה — '
                    'לתעד שהערך חייב להשתנות בכל סביבה.')

    for fp in _local_artifacts(sm_dir):
        add('warn', 'R-85', fp,
            "פריט מקומי '%s' בתוך תיקיית המודל" % os.path.basename(fp),
            'קבצי .pbi/localSettings.json ו-cache.abf הם artifacts מקומיים של '
            'Desktop — ה-.gitignore שהוא עצמו יוצר מתעלם מהם (MS Learn '
            'projects-overview, CC-BY-4.0). בעץ מקור משותף הם רעש שדורס '
            'הגדרות בין מפתחים. למחוק ולהוסיף ל-.gitignore.')

    # M-03 · קצוות קשר קיימים
    _rels = read_relationship_endpoints(sm_dir)
    for frm, to, _active in _rels:
        # M-04 · קשר עצמי (מעמודה לעצמה)
        st, sc = _split_ref(frm)
        et, ec = _split_ref(to)
        if st and st == et and sc == ec:
            add('err', 'M-04', 'relationships.tmdl',
                "קשר עצמי: '%s' → '%s'" % (frm, to),
                'קשר מעמודה לעצמה אינו חוקי — המודל לא ייטען.')
            ok = False
        # M-12 · עמודות הקשר חייבות אותו dataType (Tabular Editor built-in BPA:
        # "Relationship Columns Must Have Same Data Type"). סוג לא ידוע = מדלגים.
        st2, sc2 = _split_ref(frm)
        et2, ec2 = _split_ref(to)
        t1 = model_tables.get(st2, {}).get('col_types', {}).get(sc2) if st2 else None
        t2 = model_tables.get(et2, {}).get('col_types', {}).get(ec2) if et2 else None
        if t1 and t2 and t1 != t2:
            add('err', 'M-12', 'relationships.tmdl',
                "קשר '%s' (%s) ← '%s' (%s) — dataType שונה" % (frm, t1, to, t2),
                'קשר בין עמודות מסוגים שונים עלול להיכשל בטעינה או לגרום להתאמה שגויה. '
                'ליישר טיפוסים (Tabular Editor built-in BPA: Relationship Columns Must '
                'Have Same Data Type).')
            ok = False
        for ref in (frm, to):
            tname, col = _split_ref(ref)
            if not tname:
                add('err', 'M-03', 'relationships.tmdl', "קצה קשר בלתי קריא: '%s'" % ref, '')
                ok = False
                continue
            if tname not in model_tables:
                add('err', 'M-03', 'relationships.tmdl',
                    "קשר מפנה לטבלה '%s' שלא קיימת" % tname,
                    'המודל לא ייטען עם הפניה לטבלה חסרה.')
                ok = False
            elif col and col not in model_tables[tname]['columns']:
                add('err', 'M-03', 'relationships.tmdl',
                    "קשר מפנה לעמודה '%s' שלא קיימת בטבלה '%s'" % (col, tname),
                    'קלאסי אחרי שינוי שם עמודה — הקשר יישבר בטעינה.')
                ok = False

    # M-15 · שני קשרים פעילים בין אותו זוג טבלאות — נתיב סינון לא דטרמיניסטי;
    # Desktop אוכף קשר פעיל יחיד לזוג (השני הופך לא-פעיל אוטומטית). ב-TMDL
    # כתוב ביד אין חסם, והמנוע נכשל בטעינה עם ambiguous path.
    # (MS Learn relationships-active-inactive, CC-BY-4.0: "model relationships
    # are paths for filter propagation, and these paths must be deterministic";
    # עוגן פעיל יחיד. סבב 102.)
    pair_active = {}
    for frm, to, active in _rels:
        if not active:
            continue
        st, sc = _split_ref(frm)
        et, ec = _split_ref(to)
        if not st or not et or st == et:
            continue  # קשר עצמי — M-04 כבר תופס
        pair = tuple(sorted([st, et]))
        pair_active.setdefault(pair, []).append((frm, to))
    for pair, lst in pair_active.items():
        if len(lst) > 1:
            desc = '; '.join('%s → %s' % (f, t) for f, t in lst)
            add('err', 'M-15', 'relationships.tmdl',
                "%d קשרים פעילים בין '%s' ל-'%s'" % (len(lst), pair[0], pair[1]),
                'נתיב הסינון חייב להיות דטרמיניסטי — רק קשר פעיל אחד לזוג טבלאות. '
                'Desktop היה הופך את היתר ל-isActive: false; ב-TMDL כתוב ביד זו '
                'שגיאת טעינה. הקשרים: %s. לסמן isActive: false על כולם מלבד אחד '
                '(ולהפעיל ב-USERELATIONSHIP), או לפצל טבלת תפקידים '
                '(MS Learn relationships-active-inactive).' % desc)
            ok = False

    # M-07 · sortByColumn מפנה לעמודה שאינה קיימת באותה טבלה — שגיאת אימות ב-deploy
    sbc = re.compile(r'(?m)^\s*sortByColumn:\s*(.+)$')
    for tname, t in model_tables.items():
        with open(t['file'], encoding='utf-8-sig', errors='ignore') as fh:
            txt = fh.read()
        for m in sbc.finditer(txt):
            target = _unq(m.group(1))
            if target and target not in t['columns']:
                add('err', 'M-07', t['file'],
                    "sortByColumn מפנה לעמודה '%s' שלא קיימת בטבלה '%s'" % (target, tname),
                    'קלאסי אחרי מחיקה/שינוי שם של עמודת המיון — ה-deploy נכשל באימות.')
                ok = False

    # M-18 · מדד SVG שבור — prefix חסר (err), viewBox חסר או dataCategory לא
    # Image URL (warn). מקור: Dashboard-Design/Power-BI-Design-Files,
    # SVG_BEST_PRACTICES.md v2.1 (MIT, קרדיט: Sajjad Ahmadi, סבב 115) —
    # חוקים 1/5/6: RETURN מתחיל ב-'data:image/svg+xml...' , תמיד viewBox,
    # Data Category = Image URL. מופעל רק על מדדים שמכילים '<svg' — אפס FP.
    for tname, t in model_tables.items():
        with open(t['file'], encoding='utf-8-sig', errors='ignore') as fh:
            txt = fh.read()
        for blk in re.split(r'\n(?=\t(?:measure|column|partition) )', txt):
            if not blk.strip().startswith('measure') or '<svg' not in blk:
                continue
            mname = _unq(blk.strip().split('=', 1)[0][7:].strip())
            loc = "%s[%s]" % (tname, mname)
            if 'data:image/svg+xml' not in blk:
                add('err', 'M-18', t['file'],
                    "מדד SVG בלי prefix 'data:image/svg+xml': %s" % loc,
                    'בלי ה-prefix המנוע מחזיר טקסט SVG גולמי והתמונה לא מרונדרת. '
                    'לפתוח את ה-RETURN ב-"data:image/svg+xml;charset=utf-8," '
                    '(SVG_BEST_PRACTICES v2.1, חוק 1).')
                ok = False
                continue
            if 'viewBox' not in blk:
                add('warn', 'M-18', t['file'],
                    'מדד SVG בלי viewBox: %s' % loc,
                    'בלי viewBox התמונה נחתכת/לא נסקלת בגדלים שונים. להוסיף '
                    'viewBox + overflow="visible" (SVG_BEST_PRACTICES v2.1, חוק 5).')
                ok = False
            dc = re.search(r'(?m)^\s*dataCategory:\s*(.+)$', blk)
            if not dc or 'Image' not in dc.group(1):
                add('warn', 'M-18', t['file'],
                    'מדד SVG בלי dataCategory: Image URL: %s' % loc,
                    'Desktop מרנדר את המדד כתמונה רק כשה-Data Category הוא Image URL. '
                    'להוסיף dataCategory: Image URL תחת המדד (SVG_BEST_PRACTICES v2.1, חוק 6).')
                ok = False
            # D1 · xmlns חסר — svg-reviewer checklist #2 (data-goblin v26.31.0,
            # GPL-3.0, רעיון בלבד): <svg> חייב xmlns='http://www.w3.org/2000/svg'.
            if 'xmlns' not in blk:
                add('warn', 'M-18', t['file'],
                    'מדד SVG בלי xmlns: %s' % loc,
                    "אלמנט ה-<svg> חייב xmlns='http://www.w3.org/2000/svg' — בלי "
                    'ה-namespace רנדררים עלולים להתעלם מהתוכן. (data-goblin '
                    'svg-reviewer checklist #2, GPL-3.0).')
                ok = False
            # D2 · טקסט מדד ארוך מדי — checklist: מעל ~32K תווים מרונדרים נכשל;
            # מודדים את מקור ה-DAX (lower bound סביר) ומזהירים מ-30K.
            if len(blk) > 30000:
                add('warn', 'M-18', t['file'],
                    'מדד SVG ארוך מ-30K תווים: %s (%d)' % (loc, len(blk)),
                    'SVG מרונדר מעל ~32K תווים נכשל. לפצל למדדים קטנים יותר או '
                    'לקצר את התבנית. (data-goblin svg-reviewer checklist, GPL-3.0).')
                ok = False
            # D3 · בלי שמירת הקשר — checklist #7: להחזיר BLANK() כשאין הקשר
            # קטגוריה יחיד, אחרת הטוטלים נשברים. info בלבד (המחולל תמיד מוסיף).
            if 'HASONEVALUE' not in blk and 'ISBLANK' not in blk:
                add('info', 'M-18', t['file'],
                    'מדד SVG בלי שמירת HASONEVALUE/ISBLANK: %s' % loc,
                    'בלי שמירה המדד מנסה לרנדר גם בטוטלים/הקשר מרובה-ערכים ונשבר. '
                    '(data-goblin svg-reviewer checklist #7, GPL-3.0).')

    # M-08 · התנגשות שמות: שם מדד חייב להיות ייחודי מול כל מדד **וכל עמודה** במודל כולו.
    # Desktop חוסם יצירת מדד בשם תפוס; ב-TMDL כתוב ביד אין חסם — והשבר שקט:
    # הפניה ל-[X] הופכת ממדד לעמודה בהקשר שורה, ומדדים קיימים נשברים (sqlbi).
    meas_owner = {}
    col_owner = {}
    for tname, t in model_tables.items():
        for mn in t['measures']:
            meas_owner.setdefault(mn, []).append(tname)
        for cn in t['columns']:
            col_owner.setdefault(cn, []).append(tname)
    for mn, owners in meas_owner.items():
        if len(owners) > 1:
            add('err', 'M-08', owners[1],
                "מדד '%s' מוגדר פעמיים (טבלאות: %s)" % (mn, ', '.join(owners)),
                'שם מדד חייב להיות ייחודי במודל — Desktop היה חוסם; בקובץ כתוב השבר שקט.')
            ok = False
        if mn in col_owner:
            add('err', 'M-08', meas_owner[mn][0],
                "מדד '%s' מתנגש עם עמודה באותו שם (טבלאות: %s)" % (mn, ', '.join(col_owner[mn])),
                'מדד ועמודה באותו שם = הפניות [שם] מעורפלות ומדדים נשברים בשקט (sqlbi: '
                'Duplicated names in DAX).')
            ok = False

    # M-06 · הפניות 'טבלה'[עמודה] בתוך קבצי TMDL מול המודל
    qref = re.compile(r"'((?:[^']|'')+)'\[([^\]]+)\]")
    seen_ref = set()
    for tname, t in model_tables.items():
        with open(t['file'], encoding='utf-8-sig', errors='ignore') as fh:
            txt = fh.read()
        for m in qref.finditer(txt):
            rt = m.group(1).replace("''", "'")
            col = m.group(2)
            if rt not in model_tables or (rt, col) in seen_ref:
                continue
            seen_ref.add((rt, col))
            if col in model_tables[rt]['columns'] or col in model_tables[rt]['measures']:
                continue
            add('warn', 'M-06', t['file'],
                "הפניה ל-'%s'[%s] שלא קיים בטבלה" % (rt, col),
                'ביטוי שמפנה לעמודה/מדד שהושמט או שונה שמו — ייכשל בעיבוד המודל.')
    # M-14 · תלות מעגלית בין עמודות מחושבות/מדדים באותה טבלה — Desktop מסרב
    # לטעון את המודל. קשתות: (א) הפניות [עמודה] בביטוי DAX, (ב) sortByColumn —
    # קשת תלות מלאה (עמודה תלויה בעמודת המיון שלה; מיון עמודה בעמודה הנגזרת
    # ממנה = מעגל, endjin.com quick-tip sort-order circular refs). הולידטור
    # headless של pbip-tools החמיץ מעגל כזה בדוח אמיתי (TOOLCHAIN-FINDINGS #1).
    # כיסוי חלקי מתועד: מעגל דרך מדד עם context transition מזוהה רק כשהמדד
    # מפנה במפורש לעמודה מחושבת באותה טבלה (לא הרחבת "כל עמודות הטבלה").
    # סריקה לינארית: מוצאים קודם את הסוגריים המרובעים (O(n)) ורק אז מסתכלים
    # אחורה על המזהה הסמוך — ה-regex הקודם (prefix אופציונלי + \[) היה
    # ריבועי על מחרוזות ארוכות בלי סוגריים (מדד SVG של 30K תווים = ~5.5s).
    _mbracket = re.compile(r"\[([^\]]+)\]")
    _mtabpre = re.compile(r"(?:'((?:[^']|'')+)'|([A-Za-z0-9_\u05d0-\u05ea.]+))$")
    _memb = re.compile(r'^\t(column|measure)\s+(.*)$')
    _qname = re.compile(r"'((?:[^']|'')*)'\s*(?:=\s*(.*))?$")
    _pname = re.compile(r'([^\s=]+)\s*(?:=\s*(.*))?$')
    _prop = re.compile(r'^\s*[A-Za-z][A-Za-z0-9]*:')
    all_meas = set()
    for _t in model_tables.values():
        all_meas.update(_t['measures'])
    for tname, t in model_tables.items():
        with open(t['file'], encoding='utf-8-sig', errors='ignore') as fh:
            txt = fh.read()
        members = []  # [name, kind, expr, sortby]
        cur = None
        in_sub = False
        for ln in txt.splitlines():
            mm = _memb.match(ln)
            if mm:
                kind, rest = mm.group(1), mm.group(2)
                name, expr = rest, ''
                qm = _qname.match(rest)
                if qm and ("'" in rest):
                    name = qm.group(1).replace("''", "'")
                    expr = qm.group(2) or ''
                else:
                    em = _pname.match(rest)
                    if em:
                        name, expr = em.group(1), em.group(2) or ''
                cur = [name, kind, expr, None]
                members.append(cur)
                in_sub = False
                continue
            if cur is None:
                continue
            if re.match(r'^\t[^\t ]', ln) or not ln.strip():
                if not ln.strip() and cur[2] and not in_sub:
                    cur[2] += '\n'
                    continue
                cur = None
                in_sub = False
                continue
            # תת-בלוק של חבר (kpi ודומיו): מילה בודדת בזיזה של 2 טאבים. התוכן
            # (3+ טאבים) אינו חלק מביטוי ה-DAX הראשי — statusExpression של KPI
            # מפנה חוקית למדד עצמו, ואינו מעגל (אומת: retail TotalSalesTY).
            if in_sub:
                if re.match(r'^\t\t\t', ln):
                    continue
                in_sub = False
            if re.match(r'^\t\t[A-Za-z][A-Za-z0-9]*\s*$', ln):
                in_sub = True
                continue
            sm = re.match(r'^\s*sortByColumn:\s*(.+)$', ln)
            if sm:
                cur[3] = _unq(sm.group(1))
                continue
            if _prop.match(ln):
                continue
            # מאפייני-חבר עם '=' (formatStringDefinition וכו') — ביטוי פורמט דינמי
            # מפנה חוקית למדד עצמו; גם שורות תיעוד /// אינן DAX. (אומת: cap-daq
            # Gross Revenue). שורת המשך DAX אמיתית לא נפתחת ב-identifier בודד + '='.
            if re.match(r'^\s*[A-Za-z][A-Za-z0-9]*\s*=', ln) or ln.lstrip().startswith('///'):
                continue
            if cur[2] is not None:
                cur[2] += '\n' + ln
        colset = set(t['columns'])
        measset = set(t['measures'])
        edges = {}
        for name, kind, expr, sortby in members:
            deps = set()
            if expr and '[' in expr:
                for bm in _mbracket.finditer(expr):
                    ref = bm.group(1)
                    qtab = None
                    if bm.start() > 0:
                        pc = expr[bm.start() - 1]
                        if pc == "'" or pc.isalnum() or pc in '._':
                            qm = _mtabpre.search(expr[max(0, bm.start() - 1000):bm.start()])
                            if qm:
                                qtab = qm.group(1) or qm.group(2)
                    if qtab:
                        if _unq(qtab) != tname:
                            continue
                        if ref in colset or ref in measset:
                            deps.add(ref)
                    else:
                        if ref in colset or (ref in measset):
                            deps.add(ref)
            if sortby and sortby in colset:
                deps.add(sortby)
            edges[name] = deps
        color = {n: 0 for n in edges}
        stack = []
        cyc = None
        def _dfs(n):
            color[n] = 1
            stack.append(n)
            for d in edges.get(n, ()):
                if d not in edges:
                    continue
                if color[d] == 1:
                    return stack[stack.index(d):] + [d]
                if color[d] == 0:
                    r = _dfs(d)
                    if r:
                        return r
            stack.pop()
            color[n] = 2
            return None
        for n in edges:
            if color[n] == 0:
                cyc = _dfs(n)
                if cyc:
                    break
        if cyc:
            add('err', 'M-14', t['file'],
                "תלות מעגלית בטבלה '%s': %s" % (tname, ' \u2192 '.join(cyc)),
                'Desktop מסרב לטעון מודל עם מעגל תלות (כולל דרך sortByColumn — '
                'עמודה תלויה בעמודת המיון שלה). הולידטורים headless לא תופסים את '
                'זה. הפתרון המומלץ: לבנות עמודות מיון/נגזרות ב-Power Query או בטבלת '
                'ביקוש נפרדת (endjin.com quick-tip sort-order circular refs; '
                'pbip-tools TOOLCHAIN-FINDINGS #1).')
            ok = False

    # M-09 · RLS: tablePermission מפנה לטבלה קיימת, וההפניות בביטוי קיימות במודל
    # (ייצוא אמיתי: SpaceParts roles — שגיאה כזו מתפוצצת רק כשמשתמש נכנס לתפקיד).
    qref_r = re.compile(r"'((?:[^']|'')+)'\[([^\]]+)\]")
    for rf, role, rtbl, rexpr in read_role_permissions(sm_dir):
        if rtbl not in model_tables:
            add('err', 'M-09', rf,
                "tablePermission בתפקיד '%s' מפנה לטבלה '%s' שלא קיימת במודל" % (role, rtbl),
                'שינוי שם/מחיקת טבלה בלי עדכון התפקיד — RLS שבור לכל משתמשי התפקיד.')
            continue
        seen_r = set()
        for m in qref_r.finditer(rexpr):
            rt2 = m.group(1).replace("''", "'")
            col = m.group(2)
            if (rt2, col) in seen_r:
                continue
            seen_r.add((rt2, col))
            if rt2 not in model_tables:
                add('err', 'M-09', rf,
                    "RLS בתפקיד '%s' מפנה לטבלה '%s' שלא קיימת" % (role, rt2), '')
                continue
            if col in model_tables[rt2]['columns'] or col in model_tables[rt2]['measures']:
                continue
            add('err', 'M-09', rf,
                "RLS בתפקיד '%s' מפנה ל-'%s'[%s] שלא קיים" % (role, rt2, col),
                'ביטוי תפקיד שמפנה לעמודה שהושמטה/שונה שמה — התפקיד נכשל בעיבוד.')

    # M-10 · תחביר formatString (MS Learn: custom format strings):
    # מרכאות לא מאוזנות; רצפי escape לא נתמכרים (\\uXXXX / 0xNN — לא מתורגמים);
    # תווי תאריך/שעה לא מצוטטים בתוך פורמט מספרי (0.0 m יציג חודש/דקה במקום m).
    fs_re = re.compile(r'(?m)^\s*formatString:\s*(.+?)\s*$')
    dt_chars = set('acdhmnpqstw/:')
    for tname, t in model_tables.items():
        with open(t['file'], encoding='utf-8-sig', errors='ignore') as fh:
            txt = fh.read()
        for m in fs_re.finditer(txt):
            val = m.group(1)
            if len(val) >= 2 and val[0] == '"' and val[-1] == '"':
                val = val[1:-1].replace('\\\\', '\\').replace('\\"', '"')
            if val.count('"') % 2:
                add('err', 'M-10', t['file'],
                    "formatString עם מרכאות לא מאוזנות: '%s'" % val,
                    'טקסט ליטרלי חייב להיות סגור במרכאות משני הצדדים — אחרת הרינדור משתבש.')
                ok = False
            if re.search(r'\\u[0-9a-fA-F]{4}|(?<![\w])0x[0-9a-fA-F]+', val):
                add('warn', 'M-10', t['file'],
                    "formatString עם רצף escape שאינו נתמך: '%s'" % val,
                    "Power BI לא מתרגם \\uXXXX או 0xNN בפורמט — להדביק את תו ה-Unicode "
                    "עצמו בתוך מרכאות (למשל 0.0\" °C\").")
            if '0' not in val and '#' not in val:
                continue
            inq = False
            bad = set()
            k = 0
            while k < len(val):
                ch = val[k]
                if ch == '\\' and not inq:
                    k += 2
                    continue
                if ch == '[' and not inq:
                    # מקטע תנאי/צבע כמו [Red] — תוכנו ליטרלי, לא קודי פורמט
                    close = val.find(']', k)
                    if close < 0:
                        break
                    k = close + 1
                    continue
                if ch == '"':
                    inq = not inq
                elif not inq and ch in dt_chars:
                    bad.add(ch)
                k += 1
            if bad:
                add('warn', 'M-10', t['file'],
                    "formatString מספרי עם תווי תאריך/שעה לא מצוטטים (%s): '%s'"
                    % (' '.join(sorted(bad)), val),
                    'תווים כמו m/d/s בתוך פורמט מספרי מתפרשים כקודי תאריך/שעה — למשל '
                    '0.0 m יציג חודש במקום האות m. לצטט את הליטרל: 0.0" m".')
    # M-13 · רווחים מיותרים בשמות אובייקטים (Tabular Editor built-in BPA:
    # "Trim Object Names") — רווח מוביל/נגרר בשם שובר התאמות ומסתיר כפילויות.
    for tname, t in model_tables.items():
        if tname != tname.strip():
            add('warn', 'M-13', t['file'],
                "שם טבלה עם רווח מוביל/נגרר: '%s'" % tname,
                'לקצץ — רווחים בשמות גורמים להפניות שבורות ולכפילויות סמויות (TE BPA).')
        for obj in sorted(t['columns'] | t['measures']):
            if obj != obj.strip():
                add('warn', 'M-13', t['file'],
                    "שם אובייקט עם רווח מוביל/נגרר בטבלה '%s': '%s'" % (tname, obj),
                    'לקצץ — TE built-in BPA: Trim Object Names.')

    # M-11 · מאפייני timestamps תנודתיים (modifiedTime/refreshedTime וכו') — רעש
    # source-control שכלים מקצצים כברירת מחדל; Desktop עצמו לא כותב אותם בייצוא
    # TMDL (אומת על 5 דוחות אמיתיים). מקור: pbi-tools DefaultIgnoreProperties.
    volatile_props = ('modifiedTime', 'refreshedTime', 'lastProcessed',
                      'structureModifiedTime', 'lastUpdate', 'lastSchemaUpdate',
                      'createdTimestamp')
    vol_re = re.compile(r'(?m)^\s*(%s):' % '|'.join(volatile_props))
    for tname, t in model_tables.items():
        with open(t['file'], encoding='utf-8-sig', errors='ignore') as fh:
            txt = fh.read()
        found = sorted(set(m.group(1) for m in vol_re.finditer(txt)))
        if found:
            add('warn', 'M-11', t['file'],
                "טבלה '%s' עם מאפייני timestamps תנודתיים: %s" % (tname, ', '.join(found)),
                'ערכים אלה משתנים בכל שמירה ומלכלכים diffs ב-git — כלי PBIP (pbi-tools '
                'בין היתר) מקצצים אותם כברירת מחדל. לקצוץ לפני commit. '
                'מקור: pbi-tools/pbi-tools ModelSettings.DefaultIgnoreProperties (AGPL, עובדות).')

    return ok


# ══════════════════════════ פלט ══════════════════════════
def render():
    L = []
    A = L.append
    cnt = collections.Counter(i['level'] for i in _ISSUES)
    errs = [i for i in _ISSUES if i['level'] == 'err']
    A('# אימות מבנה PBIP/PBIR (pbi_validate) — דטרמיניסטי, בלי Desktop')
    A('')
    if not _ISSUES:
        # שדה סבב 3: הניסוח חייב לומר את האמת — הבדיקה היא עקביות מבנה בלבד.
        # "תקין" הובן כ"נפתח ומרונדר" ושמונה גרסאות שבורות אושררו כך.
        A('✅ **מבנה עקבי** · ❌ 0 שגיאות מבנה · '
          '⚠️ **חוקיות מאפיינים (סכמת TMDL/PBIR) ורינדור לא נבדקו — לפתוח ב-Desktop '
          'לפני מסירת וריאנט.**')
        A('')
        A('מה נבדק: JSON תקין, הפניות בין קבצים, מזהים, קישורי שדות מול המודל, ערכי enum '
          'מול רשימות סגורות. מה שלא: חוקיות מאפייני objects/theme מול הסכמה, ורינדור בפועל '
          '— אלה מוכחים רק בפתיחת Desktop (שדה סבב 3: 8 גרסאות "0 שגיאות" שהיו שבורות בפועל).')
        return '\n'.join(L)
    A('מצב: **%s** · ❌ %d שגיאות מבנה · ⚠️ %d אזהרות · ℹ️ %d הערות'
      % ('שבור — לתקן לפני המשך' if errs else 'מבנה עקבי',
         cnt['err'], cnt['warn'], cnt['info']))
    if not errs:
        A('⚠️ **חוקיות מאפיינים ורינדור לא נבדקו** — לפתוח ב-Desktop לפני מסירת וריאנט.')
    A('')
    for level, icon in (('err', '❌'), ('warn', '⚠️'), ('info', 'ℹ️')):
        items = [i for i in _ISSUES if i['level'] == level]
        if not items:
            continue
        A('## %s %s (%d)' % (icon, {'err': 'שגיאות', 'warn': 'אזהרות', 'info': 'הערות'}[level], len(items)))
        for i in items:
            A('- **[%s] %s** — `%s`' % (i['code'], i['title'], i['location']))
            if i['detail']:
                A('  - %s' % i['detail'])
        A('')
    return '\n'.join(L)


def validate_project(base):
    """בדיקות היגיינת פרויקט (M-19..M-22) — סבב 122, data-goblin v26.31.0 GPL-3.0."""
    ok = True
    # ── סבב 122 · אצווה C — היגיינת פרויקט (data-goblin/power-bi-agentic-development
    # v26.31.0, GPL-3.0 — רעיונות בלבד, מימוש מחדש עם קרדיט; c_filetypes/c_pbip_skill) ──
    # סריקה משותפת אחת: .platform (M-19), unappliedChanges (M-21), BOM (M-22)
    _platforms = []   # (logicalId, path)
    _schemas = []     # (path, url, kind, version) — M-23
    _unapplied = []   # paths
    _bom = []         # paths
    # סבב 150 (שדה סבב 2 #13): וריאנט מקונן בתוך הפרויקט מזהם את הסריקה —
    # 8 מתוך 16 שגיאות ה-M-22 שלו הגיעו מהווריאנט הישן, לא מהפרויקט. כשהבסיס
    # עצמו שורש פרויקט (.pbip ברמה העליונה), כל תת-תיקייה עם .pbip משלה היא
    # פרויקט מקונן: מדלגים עליה (M-26 info) במקום לערבב ממצאים. כשהבסיס הוא
    # מכולה של פרויקטים אחים (אין .pbip בראש) — ההתנהגות לא משתנה.
    _base_is_project = bool(glob.glob(os.path.join(base, '*.pbip')))
    _nested_roots = []
    for root, dirs, files in os.walk(base):
        dirs[:] = [d for d in dirs if d != '.git']
        if _base_is_project:
            _keep = []
            for _d in dirs:
                if glob.glob(os.path.join(root, _d, '*.pbip')):
                    _nested_roots.append(os.path.join(root, _d))
                else:
                    _keep.append(_d)
            dirs[:] = _keep
        for f in files:
            fp = os.path.join(root, f)
            if f == '.platform':
                pobj, perr = _load_json(fp)
                if not perr and pobj:
                    lid = (pobj.get('metadata') or {}).get('logicalId') or pobj.get('logicalId')
                    if lid:
                        _platforms.append((str(lid), fp))
            elif f == 'unappliedChanges.json':
                try:
                    if os.path.getsize(fp) > 4:
                        _unapplied.append(fp)
                except OSError:
                    pass
            if f.endswith(('.json', '.tmdl', '.pbir', '.pbism', '.pbip', '.csv')) or f == '.platform':
                try:
                    with open(fp, 'rb') as fh:
                        if fh.read(3) == b'\xef\xbb\xbf':
                            _bom.append(fp)
                except OSError:
                    pass
            if f.endswith(('.json', '.pbir', '.pbism', '.pbip')) or f == '.platform':
                try:
                    with open(fp, 'rb') as fh:
                        _txt = fh.read().decode('utf-8-sig', errors='ignore')
                    for _m in _SCHEMA_RE.finditer(_txt):
                        _schemas.append((fp, _m.group(1), _m.group(2), _m.group(3)))
                    if '"$schema"' in _txt:
                        for _m in re.finditer(
                                r'"\$schema"\s*:\s*"(https://developer\.microsoft\.com/json-schemas/fabric/[^"]*)"', _txt):
                            if not _SCHEMA_RE.match(_m.group(1)):
                                _schemas.append((fp, _m.group(1), None, None))
                except OSError:
                    pass
    # M-19 · logicalId זהה בשני פריטים שונים = שיבוט בלי ריענון GUID — Fabric מזהה
    # פריט לפי logicalId; כפילות = קונפליקט פריסה (c_filetypes.md: "when forking,
    # logicalId must be changed to a new GUID to avoid conflicts").
    _seen_lid = {}
    for lid, fp in sorted(_platforms):
        if lid in _seen_lid:
            add('err', 'M-19', fp,
                "logicalId '%s' זהה לזה של '%s'" % (lid, os.path.basename(os.path.dirname(_seen_lid[lid]))),
                'שיבוט פרויקט בלי ריענון logicalId — שני פריטים עם אותו מזהה Fabric '
                'מתנגשים בפריסה (Git integration/Deploy). לייצר GUID חדש לעותק '
                '(data-goblin c_filetypes.md § .platform).')
            ok = False
        else:
            _seen_lid[lid] = fp
    # M-20 · סתירת גרסה ב-definition.pbir/pbism: version '1.x' = פורמט Legacy בלבד
    # (report.json / model.bim) — תיקיית definition/ (PBIR/TMDL) לצידה = סתירה
    # שמטעה את Fabric Git integration (c_filetypes.md § version Property).
    for item_dir in sorted(set(glob.glob(os.path.join(base, '**', '*.Report'), recursive=True) +
                               glob.glob(os.path.join(base, '**', '*.SemanticModel'), recursive=True) +
                               glob.glob(os.path.join(base, '**', '*.Dataset'), recursive=True))):
        for ep in ('definition.pbir', 'definition.pbism'):
            epf = os.path.join(item_dir, ep)
            if not os.path.isfile(epf):
                continue
            eobj, eerr = _load_json(epf)
            if eerr or not eobj:
                continue
            ver = str(eobj.get('version') or '')
            has_def = os.path.isdir(os.path.join(item_dir, 'definition'))
            if ver.startswith('1.') and has_def:
                add('err', 'M-20', epf,
                    "%s version '%s' (Legacy בלבד) אך קיימת תיקיית definition/ (PBIR/TMDL)" % (ep, ver),
                    "version '1.0' מצהיר על פורמט Legacy (report.json/model.bim) בלבד — "
                    "תיקיית definition/ לצידה סותרת ומטעה את Fabric Git integration. "
                    "לעדכן ל-'4.0' (או למחוק את definition/ אם הפרויקט Legacy) "
                    '(data-goblin c_filetypes.md § version Property).')
                ok = False
    # M-29 (המשך, רמת פרויקט) · סתירת compatibilityLevel בין model.bim (Legacy)
    # ל-definition/database.tmdl (TMDL) באותו SemanticModel — דוח שדה סבב 3
    # שורה 3: "compatibilityLevel: 1600 מול מסד 1606" עבר עם 0 שגיאות ו-Desktop
    # הציג Frown. שתי הצהרות חיות חייבות להסכים.
    for _sm in sorted(glob.glob(os.path.join(base, '**', '*.SemanticModel'), recursive=True) +
                      glob.glob(os.path.join(base, '**', '*.Dataset'), recursive=True)):
        _cl = {}
        _dbf = os.path.join(_sm, 'definition', 'database.tmdl')
        if os.path.isfile(_dbf):
            try:
                with open(_dbf, encoding='utf-8-sig', errors='ignore') as _fh:
                    _m = re.search(r'(?m)^\s*compatibilityLevel\s*:\s*(\d+)', _fh.read())
                if _m:
                    _cl['definition/database.tmdl'] = _m.group(1)
            except OSError:
                pass
        _bim = os.path.join(_sm, 'model.bim')
        if os.path.isfile(_bim):
            _bobj, _berr = _load_json(_bim)
            if not _berr and _bobj and _bobj.get('compatibilityLevel') is not None:
                _cl['model.bim'] = str(_bobj['compatibilityLevel'])
        if len(set(_cl.values())) > 1:
            add('err', 'M-29', _sm,
                'compatibilityLevel סותר: %s' % ' מול '.join('%s=%s' % (k, v) for k, v in sorted(_cl.items())),
                'שתי הצהרות compatibilityLevel חיות באותו מודל חייבות להיות זהות — '
                'סתירה מפילה את הפתיחה ב-Desktop (דוח שדה סבב 3, שורה 3: "1600 מול '
                'מסד 1606"). ליישר לערך אחד (מומלץ: הרמה שהמודל באמת דורש).')
            ok = False
    # M-21 · unappliedChanges.json — שינויי Power Query ממתינים; apply דורס את
    # שאילתות המודל מהמטא-דאטה (c_filetypes.md WARNING). comitted = מוקד שקט.
    for fp in _unapplied:
        add('warn', 'M-21', fp,
            'unappliedChanges.json קיים — שינויי Power Query ממתינים',
            'אם השינויים יוחלו (Apply) הם דורסים את שאילתות המודל מהמטא-דאטה. '
            'ליישם או למחוק לפני commit (data-goblin c_filetypes.md § unappliedChanges).')
    # M-22 · BOM בקבצי מקור — UTF-8 חייב להיות בלי BOM; BOM גורם שגיאות parse
    # בחלק מהכלים (c_pbip_skill.md: "UTF-8 without BOM").
    for fp in _bom:
        # סבב 134 (דיווח שדה #2): Desktop 2.157 מסרב לפתוח פרויקט עם BOM
        # ("Only text with UTF8 encoding without BOM is supported. Detected BOM:
        # 'UTF-8'") — חוסם-פתיחה = שגיאה, לא רעש. יומן §10 (Desktop כותב BOM)
        # תיאר Desktop ישן; הווקטור נשמר לבדיקות parse/preserve של קריאה בלבד.
        add('err', 'M-22', fp,
            'UTF-8 BOM בקובץ מקור — חוסם פתיחה ב-Desktop 2.157+',
            'Power BI Desktop 2.157 מסרב לפתוח פרויקט עם BOM בקבצי מקור '
            '(דיווח שדה 14.9 — הווריאנט לא נפתח כלל עד להסרה ידנית של 55 קבצים). '
            'תיקון: pbi_fix --fix debom (או --fix bom) מסיר את שלושת הבתים EF BB BF; '
            'כל כתיבות הבונה נטולות BOM החל מסבב 134.')
        ok = False
    # M-23 · גרסת $schema מול טבלת הגרסאות הנתמכות (בקשת משתמש 14.9).
    # הטבלה = איחוד microsoft/json-schemas (נשלף 14.09.2026) + גרסאות שנצפו
    # בקורפוס Desktop-native אמיתי (advw 2.13.0, capital 2.12.0 — Desktop משחרר
    # לפני שהריפו הציבורי מתעדכן). גרסה מחוץ לטבלה = כנראה הזיית-מחולל
    # (2.10.0/2.11.0 לא קיימות באף מקור מהימן) → warn עם מסלול תיקון;
    # URL fabric מעוות → err; kind לא מוכר (חדש מ-Microsoft) → info בלבד.
    for fp, url, kind, ver in _schemas:
        if kind is None:
            add('err', 'M-23', fp,
                'כתובת $schema מעוותת (לא תבנית fabric חוקית)',
                'הכתובת "%s" אינה מתאימה לתבנית .../json-schemas/fabric/<kind>/<x.y.z>/schema.json — '
                'Desktop עלול לדחות את הקובץ. לתקן לכתובת מהטבלה ב-validate-checks.md §M-23.' % url)
            ok = False
            continue
        if kind not in SCHEMA_SUPPORTED:
            add('info', 'M-23', fp,
                "סוג schema '%s' לא מוכר לטבלה — לא נבדק" % kind,
                'kind חדש ש-Microsoft הוסיפה אחרי עדכון הטבלה (14.09.2026). אין פעולה.')
            continue
        versions, latest = SCHEMA_SUPPORTED[kind]
        if ver not in versions:
            add('warn', 'M-23', fp,
                "גרסת $schema %s לא מאומתת ל-%s (אינה בריפו הרשמי ולא בקורפוס Desktop-native)"
                % (ver, kind.rsplit('/', 1)[-1]),
                'גרסה זו לא קיימת ב-microsoft/json-schemas ולא נצפתה בפרויקט Desktop-native '
                'אמיתי — סימן אופייני לגרסה שהמציא מחולל (AI). אם Desktop מסרב לפתוח את '
                'הקובץ: pbi_fix --fix schemaver מפנה לגרסה המתפרסמת העדכנית (%s). '
                'טבלה מלאה: validate-checks.md §M-23.' % latest)

    # M-26 · פרויקט מקונן (וריאנט) שדולג מהסריקה (שדה סבב 2 #13).
    for nr in _nested_roots:
        add('info', 'M-26', nr,
            'פרויקט מקונן (וריאנט?) — דולג מהסריקה הזו',
            'הבסיס הוא שורש פרויקט ותיקייה זו מכילה .pbip משלה — סריקה משולבת '
            'מערבבת ממצאים של שני פרויקטים (שדה סבב 2 #13: 8/16 שגיאות M-22 '
            'הגיעו מהווריאנט). לסרוק אותו ישירות בפני עצמו.')
    return ok


_SCHEMA_RE = re.compile(
    r'(https://developer\.microsoft\.com/json-schemas/fabric/'
    r'([A-Za-z0-9/]+?)/([0-9]+\.[0-9]+\.[0-9]+)/schema\.json)')

# M-23 (סבב 132) — kind ← (גרסאות מאומתות, גרסה מתפרסמת עדכנית לתיקון).
# מקור: microsoft/json-schemas (נשלף 14.09.2026) + תצפיות קורפוס Desktop-native.
SCHEMA_SUPPORTED = {
    'item/report/definition/visualContainer': (
        {'1.0.0', '1.1.0', '1.2.0', '1.3.0', '1.4.0', '1.5.0', '1.6.0', '1.7.0', '1.8.0',
         '2.0.0', '2.1.0', '2.2.0', '2.3.0', '2.4.0', '2.5.0', '2.6.0', '2.7.0', '2.8.0',
         '2.9.0', '2.12.0', '2.13.0'}, '2.9.0'),
    'item/report/definition/visualContainerMobileState': (
        {'1.0.0', '1.1.0', '1.2.0', '1.3.0', '1.4.0', '1.5.0', '2.0.0', '2.1.0', '2.2.0',
         '2.3.0', '2.4.0', '2.7.0'}, '2.4.0'),
    'item/report/definition/page': (
        {'1.0.0', '1.1.0', '1.2.0', '1.3.0', '1.4.0', '2.0.0', '2.1.0'}, '2.1.0'),
    'item/report/definition/report': (
        {'1.0.0', '1.1.0', '1.2.0', '1.3.0', '2.0.0', '2.1.0', '3.0.0', '3.1.0', '3.2.0',
         '3.3.0'}, '3.3.0'),
    'item/report/definition/pagesMetadata': ({'1.0.0', '1.1.0'}, '1.1.0'),
    'item/report/definition/versionMetadata': ({'1.0.0'}, '1.0.0'),
    'item/report/definitionProperties': ({'1.0.0', '2.0.0'}, '2.0.0'),
    'item/semanticModel/definitionProperties': ({'1.0.0'}, '1.0.0'),
    'gitIntegration/platformProperties': ({'2.0.0', '2.1.0'}, '2.1.0'),
    'pbip/pbipProperties': ({'1.0.0'}, '1.0.0'),
    # סבב 148 — נצפו בייצואי Desktop רשמיים (FabricTools/pbir-samples, MIT,
    # 8 דוחות הדוגמה של Microsoft): bookmark 1.4.0 (x2 ב-Store Sales),
    # bookmarksMetadata 1.0.0, editorSettings 1.0.0 (בכל 8 המודלים).
    'item/report/definition/bookmark': ({'1.4.0'}, '1.4.0'),
    'item/report/definition/bookmarksMetadata': ({'1.0.0'}, '1.0.0'),
    'item/semanticModel/editorSettings': ({'1.0.0'}, '1.0.0'),
}


def main():
    ap = argparse.ArgumentParser(description='אימות מבנה דטרמיניסטי ל-PBIP/PBIR (אופליין, stdlib)')
    ap.add_argument('path', nargs='?', default=None,
                    help='תיקיית פרויקט (עם *.Report/*.SemanticModel) או תיקיית .Report')
    ap.add_argument('--model', default=None, help='תיקיית .SemanticModel מפורשת')
    ap.add_argument('--json', dest='as_json', action='store_true')
    a = ap.parse_args()

    rp = sm = None
    base = a.path or '.'
    if base.endswith('.Report') or os.path.isdir(os.path.join(base, 'definition', 'pages')):
        rp = base
    else:
        c = sorted(glob.glob(os.path.join(base, '*.Report')))
        rp = c[0] if c else None
        c = sorted(glob.glob(os.path.join(base, '*.SemanticModel')) or
                   glob.glob(os.path.join(base, '*.Dataset')))  # סבב 88: סיומת ישנה
        sm = c[0] if c else None
    sm = a.model or sm
    if not rp and not sm:
        c = sorted(glob.glob(os.path.join(base, '**', '*.Report'), recursive=True))
        rp = c[0] if c else None
        c = sorted(glob.glob(os.path.join(base, '**', '*.SemanticModel'), recursive=True) or
                   glob.glob(os.path.join(base, '**', '*.Dataset'), recursive=True))  # סבב 88
        sm = sm or (c[0] if c else None)

    if not rp and not sm:
        print('לא נמצאה תיקיית *.Report או *.SemanticModel מתחת ל-%s' % base)
        return

    model_tables = read_model_map(sm) if sm and os.path.isdir(os.path.join(sm, 'definition', 'tables')) else None
    ok = True
    # R-86 · נתיב יחסי ארוך מ-200 תווים — מתקרב ל-MAX_PATH (260) של Windows;
    # עם prefix שיבוט טיפוסי (C:\Users\\<user>\\source\\repos\\repo ≈ 40-60 תווים)
    # קובץ כזה חוצה את התקרה ושובר clone/checkout ב-Windows בלי longpaths.
    # (MS Learn maximum-file-path-limitation, CC-BY-4.0. סבב 110.)
    for root, dirs, files in os.walk(base):
        dirs[:] = [d for d in dirs if d != '.git']
        for f in files:
            rel = os.path.relpath(os.path.join(root, f), base)
            if len(rel) > 200:
                add('warn', 'R-86', os.path.join(root, f),
                    'נתיב יחסי ארוך (%d תווים): %s' % (len(rel), rel[-60:]),
                    'MAX_PATH ב-Windows הוא 260 תווים; נתיב יחסי מעל 200 חוצה את '
                    'התקרה כבר עם prefix שיבוט שגרתי (40-60 תווים) — clone/pull '
                    'נכשל בלי git longpaths. לקצר שמות תיקיות/קבצים או להפעיל '
                    'core.longpaths. (MS Learn maximum-file-path-limitation.)')
    # R-85 · קבצי pbix/pbit בשורש הפרויקט — בינאריים שלא שייכים לעץ מקור
    for blob in sorted(glob.glob(os.path.join(base, '*.pbix')) +
                       glob.glob(os.path.join(base, '*.pbit'))):
        add('warn', 'R-85', blob,
            "קובץ בינארי '%s' בתוך תיקיית הפרויקט" % os.path.basename(blob),
            'PBIX/PBIT הם קבצים בינאריים גדולים — PBIP נועד להחליף אותם בעץ '
            'מקור טקסטואלי. שילוב של שניהם מכפיל את המקור לאמת ומנפח את הריפו '
            '(pbip-doctor PBIP004, MIT).')
    # R-84 · artifacts ב-*.pbip בשורש הפרויקט חייבים להצביע לתיקיות קיימות
    # (pbip-doctor PBIP002, MIT). נבדק רק כש-base הוא שורש פרויקט, לא תיקיית
    # .Report בודדת (שם אין *.pbip בדרך כלל).
    for pj in sorted(glob.glob(os.path.join(base, '*.pbip'))):
        pobj, perr = _load_json(pj)
        if perr:
            add('err', 'R-84', pj, 'קובץ pbip — JSON שבור', perr)
            ok = False
            continue
        for art in (pobj or {}).get('artifacts', []):
            for kind in ('report', 'semanticModel'):
                pth = (art.get(kind) or {}).get('path')
                if not pth:
                    continue
                if re.match(r'^(?:[A-Za-z]:[\\/]|\\\\|/)', pth):
                    add('warn', 'R-84', pj,
                        "נתיב מוחלט ל-artifact '%s' בקובץ pbip" % kind,
                        'נתיב מוחלט אינו נייד בין מכונות. לעבור לנתיב יחסי.')
                elif not os.path.isdir(os.path.normpath(os.path.join(base, pth))):
                    add('err', 'R-84', pj,
                        "artifact '%s' מפנה ל-'%s' — התיקייה לא קיימת" % (kind, pth),
                        'הפניה שבורה בקובץ הפרויקט — Desktop לא יפתח את ה-artifact.')
                    ok = False
    ok = validate_project(base) and ok
    if sm:
        ok = validate_model(sm) and ok
    if rp:
        ok = validate_report(rp, model_tables) and ok

    if a.as_json:
        print(json.dumps({'ok': ok, 'issues': _ISSUES}, ensure_ascii=False, indent=1))
    else:
        print(render())
    # קוד יציאה 0 תמיד — הסוכן קורא את הדוח; זה לא שער CI.


if __name__ == '__main__':
    main()
