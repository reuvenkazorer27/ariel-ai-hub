#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
pbi_check.py — בדיקות דטרמיניסטיות (BPA אופליין) לפרויקט PBIP/PBIR — לסוקר Power BI.

למה: pbi_extract.py עונה על "מה יש בדוח" (מלאי + בדיקות רוחב פריסתיות), ו-pbi_analyze.py
עונה על "מה לא בשימוש". הסקריפט הזה עונה על שאלה שלישית: **מה שגוי** — כללי Best Practice
דטרמיניסטיים מעל ה-TMDL וה-PBIR, שאין בהם שיפוט ולכן אפשר לסמוך עליהם בעיניים עצומות.
המקורות: סט כללי ה-BPA הרשמי של מיקרוסופט/Tabular Editor (BPARules.json), הכללים המובנים
של Tabular Editor 3, ומדריכי הביצועים/הפורמט של Microsoft Learn. המיפוי המלא לכל כלל:
references/bpa-checks.md.

מה הוא לא עושה: לא קורא נתונים (אין VertiPaq/קרדינליות), לא מרנדר, לא כותר — קריאה בלבד.
כל ממצא הוא *מועמד*: הסוכן מאמת אותו מול הקובץ לפני דיווח (כלל "אמת מהקוד").

שימוש:
    python pbi_check.py "<.Report>" [--model "<.SemanticModel>"] [--json]
    python pbi_check.py --model "<.SemanticModel>"      # בדיקות מודל בלבד
בלי ארגומנטים — מחפש תיקיות *.Report / *.SemanticModel מתחת ל-cwd.
Python stdlib בלבד. אין רשת. אין כתיבה.
"""
import json, os, re, sys, glob, argparse, collections, hashlib

SEV = {"crit": "🔴", "warn": "🟡", "tip": "🟢"}
SEV_HE = {"crit": "קריטי", "warn": "לשיפור", "tip": "טיפ"}

SKIP_TABLE_PREFIXES = ('LocalDateTable_', 'DateTableTemplate_')

# ויזואלים מובנים של Power BI (שאינם מותאמים). מקור ראשי: קטלוג visual-types.md של
# jonathan-pap/powerbi-report-mcp (רישיון MIT, docs/visual-types.md, מאומת מול סכמת Fabric 2.7.0),
# בתוספת שמות מעטפת/מדיה מ-references/pbip-structure.md ושמות legacy (matrix/table/funnel)
# לתאימות דוחות ישנים. שים לב: אין stackedColumnChart/stackedBarChart — הגרסאות המוערמות
# הן columnChart/barChart (שמות stacked* הם הזיית LLM קלאסית — ראו RPT-27, ו-R-21 בבילדר).
BUILTIN_VISUALS = {
    # מוטות/עמודות — barChart/columnChart הם המוערמים; clustered* נפרדים
    'barChart', 'clusteredBarChart', 'hundredPercentStackedBarChart',
    'columnChart', 'clusteredColumnChart', 'hundredPercentStackedColumnChart',
    # קווים ושטחים
    'lineChart', 'areaChart', 'stackedAreaChart', 'hundredPercentStackedAreaChart',
    'lineClusteredColumnComboChart', 'lineStackedColumnComboChart', 'ribbonChart',
    # חלקים/זרימה/פיזור
    'waterfallChart', 'funnel', 'funnelChart', 'scatterChart', 'pieChart', 'donutChart',
    'treemap',
    # כרטיסים ו-KPI
    'card', 'cardNew', 'cardVisual', 'multiRowCard', 'kpi', 'gauge',
    # טבלאות (matrix/table — שמות legacy)
    'tableEx', 'table', 'pivotTable', 'matrix',
    # מפות
    'filledMap', 'shapeMap', 'map', 'azureMap',
    # AI וסקריפטים
    'decompositionTreeVisual', 'keyDriversVisual', 'qnaVisual', 'smartNarrative',
    'scriptVisual', 'rVisual', 'pythonVisual',
    # סליסרים
    'slicer', 'listSlicer', 'textSlicer', 'advancedSlicerVisual',
    # מעטפת/מדיה/ניווט
    'textbox', 'actionButton', 'pageNavigator', 'bookmarkNavigator', 'image', 'shape',
    'basicShape', 'group',
}
DECOR = {'image', 'shape', 'textbox', 'actionButton', 'pageNavigator', 'basicShape',
         'bookmarkNavigator', 'group'}

GENERIC_TITLES = {'נתונים', 'פילוח', 'ניצול', 'התפלגות', 'סיכום', 'גרף', 'טבלה', 'מידע', 'תוצאות', 'סקירה',
                  'data', 'chart', 'table', 'summary', 'overview', 'info', 'details', 'breakdown', 'graph'}
KEYISH = ('id', 'key', 'code', 'guid', 'no', 'num', 'מק"ט', 'קוד', 'מזהה', 'מספר', 'תאריך', 'date')
NUMERIC_TYPES = ('int64', 'decimal', 'double', 'currency', 'integer')
TI_FUNCS = ('SAMEPERIODLASTYEAR', 'DATEADD', 'DATESYTD', 'DATESMTD', 'DATESQTD',
            'PREVIOUSMONTH', 'PREVIOUSYEAR', 'PARALLELPERIOD', 'TOTALYTD', 'DATESBETWEEN')
RLS_HEAVY_FUNCS = ('LEFT(', 'RIGHT(', 'MID(', 'UPPER(', 'LOWER(', 'FIND(', 'SEARCH(')
DYNAMIC_RLS_FUNCS = ('USERPRINCIPALNAME(', 'USERNAME(', 'CUSTOMDATA(')

_FINDINGS = []


_PARTIAL = False  # True כשחלק מהבדיקות דולגו (פריסה ישנה, מודל חסר) — משפיע על שורת הסיכום


# cross-cutting #5 (דוח שדה 14.9): סיווג ודאות לחוקים עם false-positive ידוע,
# כדי שלא יעוותו את ציון הבריאות. כל ממצא נושא confidence; 'low' = אמת ידנית
# לפני דיווח, ומשוקלל במחצית הקנס בציון.
LOW_CONFIDENCE = {
    'A11Y-02': 'לא מתחשב ב-z-order — טקסט בהיר על צורה כהה מתחתיו נספר כטקסט על '
               'רקע הדף (FP מתועד בדוח השדה). אמת ויזואלית לפני דיווח.',
}


def add(rule, severity, category, location, title, detail, fix):
    conf = 'low' if rule in LOW_CONFIDENCE else 'high'
    _FINDINGS.append({
        'rule': rule, 'severity': severity, 'category': category,
        'location': location, 'title': title, 'detail': detail, 'fix': fix,
        'confidence': conf,
    })


# ══════════════════════════ קריאת TMDL ══════════════════════════
def _unq(s):
    """שם TMDL: עטוף בגרשים (גרש פנימי כפול) או חשוף. known-issues-log §12."""
    s = s.strip()
    if s.startswith("'"):
        m = re.match(r"^'((?:[^']|'')+)'", s)
        if m:
            return m.group(1).replace("''", "'")
    return s.split()[0] if s.split() else s


def _indent(line):
    return len(line) - len(line.lstrip('\t '))


_DECL = re.compile(r"^(column|measure|partition|hierarchy)\s+(?:'((?:[^']|'')+)'|([^\s=]+))")
_PROP2 = re.compile(r"^(formatString|displayFolder|description|lineageTag|annotation|"
                    r"dataCategory|isHidden|detailRowsDefinition|defaultValue|"
                    r"extendedProperty|isNameInferred|summarizeBy|sortByColumn|"
                    r"dataType|isKey|sourceColumn|isAvailableInMdx|kind|formatStringExpression)\s*:")


def _leading_doc_lines(lines, i):
    """True אם מעל ההצהרה בשורה i יש לפחות שורת /// אחת עם תוכן (יומן #15)."""
    k = i - 1
    while k >= 0 and lines[k].lstrip().startswith('///'):
        if lines[k].strip().strip('/').strip():
            return True
        k -= 1
    return False


def _read_table_file(path):
    """מחזיר {name, data_category, hidden, columns:[...], measures:[...], partitions:[...]}."""
    txt = open(path, encoding='utf-8-sig', errors='ignore').read()
    lines = txt.splitlines()
    # TMDL מ-Desktop מוזחת בטאבים, אבל קבצים שנכתבו ביד/AI מוזחים לפעמים ברווחים
    # (נמצא בקורפוס אמיתי: insurance-claims, טבלת field-parameter). בלי נרמול, כל
    # ההצהרות בקובץ כזה מוחמצות בשקט (indent 4 במקום 1). מנרמלים לטאבים לפי יחידת
    # ההזחה הקטנה ביותר — רק כשאין בקובץ טאבים בכלל.
    if not any(l.startswith('\t') for l in lines):
        units = sorted({len(l) - len(l.lstrip(' ')) for l in lines if l[:1] == ' '})
        if units:
            unit = units[0]
            lines = ['\t' * max(1, (len(l) - len(l.lstrip(' '))) // unit) + l.lstrip(' ')
                     if l[:1] == ' ' else l for l in lines]
    name = os.path.splitext(os.path.basename(path))[0]
    data_category, hidden = '', False
    calc_group = bool(re.search(r"(?m)^\s*calculationGroup\s*$", txt))
    # סבב 136 (כשל שדה #7): ב-TMDL התיאור הוא שורות /// מעל ההצהרה (יומן #15),
    # לא רק מאפיין description: — MDL-20 דיווח "27/27 ללא תיאור" על מודל מתועד במלואו.
    tbl_desc = bool(re.search(r"(?m)^\tdescription\s*:", '\n'.join(lines)))
    if not tbl_desc:
        for _ti, _tl in enumerate(lines):
            if _tl.strip().startswith('table '):
                if _leading_doc_lines(lines, _ti):
                    tbl_desc = True
                break
    columns, measures, partitions, hierarchies = [], [], [], []
    i = 0
    # שם הטבלה מהשורה הראשונה הלא-ריקה
    for ln in lines:
        s = ln.strip()
        if s.startswith('table '):
            name = _unq(s[6:])
            break
        if s:
            break
    while i < len(lines):
        ln = lines[i]
        if _indent(ln) != 1:
            if ln.strip().startswith('dataCategory:'):
                data_category = ln.split(':', 1)[1].strip()
            if ln.strip() == 'isHidden':
                hidden = True
            i += 1
            continue
        m = _DECL.match(ln.strip())
        if not m:
            s = ln.strip()
            if s.startswith('dataCategory:'):
                data_category = s.split(':', 1)[1].strip()
            elif s == 'isHidden':
                hidden = True
            i += 1
            continue
        kind = m.group(1)
        raw = m.group(2) if m.group(2) is not None else (m.group(3) or '')
        obj_name = _unq("'" + raw + "'" if m.group(2) is not None else raw)
        # אסוף את הבלוק (שורות מוזחות עמוק יותר)
        j = i + 1
        block = []
        while j < len(lines) and (not lines[j].strip() or _indent(lines[j]) > 1):
            block.append(lines[j])
            j += 1
        blk_txt = '\n'.join(block)
        if kind == 'column':
            calc = '=' in ln.split(_DECL.match(ln.strip()).group(0))[-1]
            columns.append({
                'name': obj_name,
                'calculated': calc,
                'expr': ln.split('=', 1)[1].strip() if calc else '',
                'dataType': (re.search(r"dataType:\s*(\w+)", blk_txt) or [None, ''])[1],
                'dataCategory': (re.search(r"dataCategory:\s*(.+)", blk_txt) or [None, ''])[1],
                'hidden': bool(re.search(r"^\s*isHidden\s*$", blk_txt, re.M) or
                               re.search(r"isHidden:\s*true", blk_txt)),
                'summarizeBy': (re.search(r"summarizeBy:\s*(\w+)", blk_txt) or [None, ''])[1],
                'sortByColumn': (re.search(r"sortByColumn:\s*(.+)", blk_txt) or [None, ''])[1],
                'isKey': bool(re.search(r"isKey:\s*true", blk_txt)),
                'fmt': bool(re.search(r"(?m)^\s*formatString\s*:", blk_txt)),
                'table': name,
            })
        elif kind == 'measure':
            # גוף הנוסחה = הבלוק פחות שורות מאפיין בהזחה 2, בלי גדרות ```
            body_lines = []
            first = ln.strip()
            body_lines.append(first.split('=', 1)[1] if '=' in first else '')
            for b in block:
                bs = b.strip()
                if not bs:
                    body_lines.append('')
                    continue
                if _indent(b) == 2 and _PROP2.match(bs):
                    continue
                body_lines.append(b)
            expr = '\n'.join(body_lines).replace('```', '')
            expr = '\n'.join(x.strip() for x in expr.split('\n') if x.strip())
            measures.append({'name': obj_name, 'table': name, 'expr': expr,
                             'fmt': bool(re.search(r"(?m)^\s*formatString\s*:", blk_txt)),
                             'folder': (re.search(r"displayFolder:\s*(.+)", blk_txt) or [None, ''])[1].strip(),
                             'desc': bool(re.search(r"(?m)^\s*description\s*:", blk_txt)
                                          # שורות /// רצופות מעל ההצהרה = description (יומן #15)
                                          or _leading_doc_lines(lines, i))})
        elif kind == 'hierarchy':
            # רמות היררכיה -> עמודה (HierarchyLevel ב-PBIR מפנה לרמה, לא לעמודה)
            lv = {}
            for lm in re.finditer(r"(?m)^\s*level\s+(?:'((?:[^']|'')+)'|(.+?))\s*$", blk_txt):
                lname = (lm.group(1).replace("''", "'") if lm.group(1) is not None
                         else lm.group(2)).strip()
                tail = blk_txt[lm.end():]
                nxt = re.search(r"(?m)^\s*level\s", tail)
                seg = tail[:nxt.start()] if nxt else tail
                cm = re.search(r"(?m)^\s*column:\s*(.+?)\s*$", seg)
                if cm:
                    lv[lname] = _unq(cm.group(1))
            hierarchies.append({'name': obj_name, 'levels': lv})
        elif kind == 'partition':
            pm = re.search(r"=\s*(\w+)", ln.strip())
            partitions.append({
                'name': obj_name, 'table': name,
                'ptype': pm.group(1) if pm else '',
                'mode': (re.search(r"mode:\s*(\w+)", blk_txt) or [None, ''])[1],
                'source': blk_txt,
            })
        i = j
    return {'name': name, 'data_category': data_category, 'hidden': hidden,
            'calc_group': calc_group, 'desc': tbl_desc,
            'columns': columns, 'measures': measures, 'partitions': partitions,
            'hierarchies': hierarchies}


def _read_relationships(sm_dir):
    rels = []
    # קשרים יכולים להופיע ב-relationships.tmdl או inline בסוף model.tmdl (TMDL)
    for rf in (os.path.join(sm_dir, 'definition', 'relationships.tmdl'),
               os.path.join(sm_dir, 'definition', 'model.tmdl')):
        if not os.path.exists(rf):
            continue
        txt = open(rf, encoding='utf-8-sig', errors='ignore').read()
        for blk in re.split(r'\n(?=relationship )', txt):
            if not blk.strip().startswith('relationship'):
                continue
            def _p(prop):
                m = re.search(r"^\s*" + prop + r":\s*(.+)$", blk, re.M)
                return m.group(1).strip() if m else ''
            fc, tc = _p('fromColumn'), _p('toColumn')
            if not (fc and tc):
                continue
            rels.append({
                'name': _unq(blk.strip().split('\n')[0].split(None, 1)[1]) if len(blk.strip().split(None, 1)) > 1 else '',
                'from': fc, 'to': tc,
                'active': _p('isActive').lower() != 'false',
                'both': 'bothDirections' in _p('crossFilteringBehavior'),
                'from_card': (_p('fromCardinality') or 'many').lower(),
                'to_card': (_p('toCardinality') or 'one').lower(),
            })
    return rels


def _read_roles(sm_dir):
    """מחזיר [{name, permission, filters:[(table, dax)]}] מקובצי definition/roles/."""
    roles = []
    for f in sorted(glob.glob(os.path.join(sm_dir, 'definition', 'roles', '*.tmdl'))):
        lines = open(f, encoding='utf-8-sig', errors='ignore').read().splitlines()
        role = {'name': os.path.splitext(os.path.basename(f))[0], 'permission': '', 'filters': []}
        i = 0
        while i < len(lines):
            s = lines[i].strip()
            if s.startswith('role '):
                role['name'] = _unq(s[5:])
            elif s.startswith('modelPermission:'):
                role['permission'] = s.split(':', 1)[1].strip()
            elif s.startswith('tablePermission '):
                rest = s[len('tablePermission '):]
                tbl = _unq(rest)
                expr = rest.split('=', 1)[1] if '=' in rest else ''
                j = i + 1
                while j < len(lines) and (not lines[j].strip() or _indent(lines[j]) > 1):
                    expr += '\n' + lines[j]
                    j += 1
                role['filters'].append((tbl, expr.strip()))
                i = j
                continue
            i += 1
        roles.append(role)
    return roles


def read_model(sm_dir):
    tables, auto_tables = [], []
    for f in sorted(glob.glob(os.path.join(sm_dir, 'definition', 'tables', '*.tmdl'))):
        base = os.path.basename(f)
        t = _read_table_file(f)
        if base.startswith(SKIP_TABLE_PREFIXES):
            auto_tables.append(t['name'])
            continue
        tables.append(t)
    return {'tables': tables, 'auto_date_tables': auto_tables,
            'relationships': _read_relationships(sm_dir), 'roles': _read_roles(sm_dir)}


# ══════════════════════════ בדיקות מודל ══════════════════════════
def _norm_expr(e):
    e = re.sub(r"--[^\n]*", "", e or "")
    e = re.sub(r"/\*.*?\*/", " ", e, flags=re.S)
    return re.sub(r"\s+", "", e)


_STR_LIT = re.compile(r'"(?:[^"]|"")*"')

# שמות בתוך סוגריים מרובעים בביטויי DAX — לזיהוי הפניות מדד-למדד (MDL-21)
_REF_NAME = re.compile(r"\[([^\]]+)\]")

# הפניה מסוגרת Table[Column] (טבלה אפשרית מרובאת-רווחים/מצוטטת) — לסריקת שימוש בעמודות (MDL-22)
_QUAL_REF = re.compile(r"(?:'((?:[^']|'')+)'|([A-Za-z0-9_\u0590-\u05ea .]+?))\s*\[([^\]]+)\]")


def _dax_clean(e):
    """DAX ללא מחרוזות והערות — לסריקת אופרטורים בלבד (לא מוצג למשתמש).
    הסדר חשוב: קודם מחרוזות — לקסית הן קודמות ('http://...' או '--' בתוך מחרוזת
    הוא תוכן, לא הערה; סבב 116 — מדדי SVG עם namespace http://www.w3.org נחתכו
    כ'הערת //', המרכאות נשברו ו-'/>' דולף כחילוק חשוף = FP של DAX-08)."""
    e = _STR_LIT.sub('""', e or "")
    e = re.sub(r"--[^\n]*", " ", e)
    e = re.sub(r"//[^\n]*", " ", e)
    e = re.sub(r"/\*.*?\*/", " ", e, flags=re.S)
    return e


def check_model(model):
    tables = model['tables']
    measures = [m for t in tables for m in t['measures']]
    columns = [c for t in tables for c in t['columns']]
    rels = model['relationships']
    rel_cols = set()
    for r in rels:
        for ref in (r['from'], r['to']):
            if '.' in ref:
                t, c = ref.rsplit('.', 1)
                rel_cols.add((_unq(t), _unq(c)))

    # MDL-01 · Auto date/time מופעל (טבלאות תאריך אוטומטיות במודל)
    if model['auto_date_tables']:
        ti_used = any(any(fn in m['expr'].upper() for fn in TI_FUNCS) for m in measures)
        has_marked = any(t['data_category'].lower() == 'time' for t in tables)
        sev = 'crit' if (ti_used and not has_marked) else 'warn'
        add('MDL-01', sev, 'מודל', 'SemanticModel',
            'Auto date/time מופעל — נמצאו %d טבלאות תאריך אוטומטיות' % len(model['auto_date_tables']),
            'טבלאות כמו %s נוצרות אוטומטית לכל עמודת תאריך ומנפחות את המודל (זיכרון + עומס).%s'
            % (', '.join(model['auto_date_tables'][:3]),
               ' במודל יש מדדי time-intelligence ואין טבלת תאריכים מסומנת — החישובים עלולים להיות לא אמינים.'
               if sev == 'crit' else ''),
            'לכבות Auto date/time בהגדרות Desktop (Data load) ולבנות/לסמן טבלת תאריכים ייעודית '
            '(תבנית מוכנה: references/dax-patterns.md). כלל מקביל: BPA REMOVE_AUTO-DATE_TABLE.')

    # MDL-02 · טבלת תאריכים שלא מסומנת
    for t in tables:
        if re.search(r"(?i)date|calendar|תאריך", t['name']) and t['data_category'].lower() != 'time':
            add('MDL-02', 'warn', 'מודל', "טבלה '%s'" % t['name'],
                'טבלת תאריכים שאינה מסומנת כ-Date table',
                'טבלה עם "date/תאריך" בשמה אך בלי dataCategory: Time. בלי סימון, time-intelligence '
                'לא מובטח לעבוד נכון. (זיהוי היוריסטי לפי שם — לוודא בקובץ.)',
                'לסמן ב-Desktop: Table tools → Mark as date table → עמודת התאריך הרציפה. '
                'כלל מקביל: BPA DATE/CALENDAR_TABLES_SHOULD_BE_MARKED_AS_A_DATE_TABLE.')

    # MDL-03 · עמודות שם-חודש/יום ללא sortByColumn
    for c in columns:
        if re.search(r"(?i)(month\s?name|weekday\s?name|שם.{0,2}חודש|יום.{0,2}שבוע)", c['name']):
            if not c['sortByColumn']:
                add('MDL-03', 'warn', 'מודל', "%s[%s]" % (c['table'], c['name']),
                    'עמודת שם-חודש/יום ללא sortByColumn — תמיין אלפביתית',
                    'עמודת טקסט של שמות חודשים/ימים תסודר א-ב (אפריל לפני ינואר) בלי sortByColumn '
                    'לעמודת המספר המקבילה.',
                    'להוסיף בעמודה: sortByColumn לעמודת מספר החודש/היום. '
                    'מקור: Microsoft TMDL guidelines — sortByColumn לשמות חודשים.')

    # MDL-04 · עמודות מספריות גלויות ללא summarizeBy: none
    summ = []
    for c in columns:
        if (c['dataType'] in NUMERIC_TYPES and not c['hidden'] and not c['isKey']
                and not c['summarizeBy'] and (c['table'], c['name']) not in rel_cols
                and not any(k in c['name'].lower() for k in KEYISH)):
            summ.append('%s[%s]' % (c['table'], c['name']))
    if summ:
        add('MDL-04', 'tip', 'מודל', '%d עמודות' % len(summ),
            'עמודות מספריות גלויות עם צבירה אוטומטית (Summarize by)',
            'עמודות כמו %s יקבלו צבירת Sum אוטומטית בגרירה לויזואל — מקור נפוץ למספרים מטעים '
            'ולמדדים מרומזים במקום מדדים מפורשים.' % (', '.join(summ[:6]) + ('…' if len(summ) > 6 else '')),
            'להגדיר summarizeBy: none לעמודות מספריות שאינן מיועדות לצבירה ישירה. '
            'כלל מקביל: Tabular Editor built-in — Set SummarizeBy to None.')

    # MDL-05 · מפתחות זרים גלויים בצד ה-fact
    hidden_fk = []
    for r in rels:
        if '.' in r['from']:
            t, c = r['from'].rsplit('.', 1)
            hidden_fk.append((_unq(t), _unq(c)))
    vis_fk = []
    cmap = {(c['table'], c['name']): c for c in columns}
    for tc in hidden_fk:
        col = cmap.get(tc)
        if col and not col['hidden']:
            vis_fk.append('%s[%s]' % tc)
    if vis_fk:
        add('MDL-05', 'tip', 'מודל', '%d עמודות' % len(vis_fk),
            'מפתחות זרים גלויים למשתמש',
            'עמודות קשר בצד ה-fact (%s) גלויות ברשימת השדות — משתמשים עלולים לגרור אותן במקום את '
            'עמודות הממד ולקבל סינון שבור.' % ', '.join(vis_fk[:6]),
            'להסתיר (isHidden) את עמודות המפתח הזר. כלל מקביל: Tabular Editor built-in — Hide Foreign Key Columns.')

    # MDL-06 · RLS סטטי (בלי USERPRINCIPALNAME)
    for role in model['roles']:
        if not role['filters']:
            continue
        all_dax = ' '.join(d for _, d in role['filters']).upper().replace(' ', '').replace('\t', '')
        if not any(fn in all_dax for fn in DYNAMIC_RLS_FUNCS):
            add('MDL-06', 'warn', 'מודל', "תפקיד '%s'" % role['name'],
                'RLS סטטי — סינון קבוע חקוק בקוד',
                'התפקיד מסנן לפי ערכים קבועים ולא לפי זהות המשתמש (USERPRINCIPALNAME). כל שינוי '
                'הרכב/מבנה מחייב עריכת המודל, וניהול תפקידים רבים הופך מסורבל.',
                'לשקול טבלת מיפוי (משתמש→יחידה) וסינון דינמי עם USERPRINCIPALNAME. '
                'כלל מקביל: BPA CHECK_IF_DYNAMIC_ROW_LEVEL_SECURITY_(RLS)_IS_NECESSARY.')

    # MDL-07 · לוגיקת טקסט כבדה ב-RLS
    for role in model['roles']:
        for tbl, dax in role['filters']:
            squashed = dax.upper().replace(' ', '').replace('\t', '')
            heavy = [f[:-1] for f in RLS_HEAVY_FUNCS if f in squashed]
            if heavy:
                add('MDL-07', 'warn', 'מודל', "תפקיד '%s' על '%s'" % (role['name'], tbl),
                    'פונקציות טקסט כבדות בסינון RLS (%s)' % ', '.join(heavy),
                    'פונקציות כמו LEFT/UPPER/FIND בתוך סינון שורה רצות על כל שאילתה ועל כל שורה — '
                    'פגיעה ישירה בביצועי כל משתמש.',
                    'להכין את העמודה המחושבת במקור (דוח נתונים/Power Query) ולסנן על עמודה מוכנה. '
                    'כלל מקביל: BPA LIMIT_ROW_LEVEL_SECURITY_(RLS)_LOGIC.')

    # MDL-08 · DirectQuery / Dual
    dq = [p for t in tables for p in t['partitions'] if p['mode'].lower() in ('directquery', 'dual')]
    if dq:
        add('MDL-08', 'warn', 'מודל', '%d מחיצות' % len(dq),
            'טבלאות במצב DirectQuery/Dual',
            'הטבלאות %s אינן בזיכרון — כל ויזואל פונה למקור בזמן אמת (ביצועים + עומס על המקור). '
            'אם זו בחירה מודעת — לתעד; אם לא — לבדוק.' % ', '.join(sorted({p['table'] for p in dq})[:5]),
            'לוודא שהבחירה מודעת, לשקול Import/Dual עם aggregations, ולתעד ב"תיק הדוח". '
            'מקור: Microsoft optimization guide.')

    # MDL-09 · שאילתת SQL ילידית ב-M (שבירת query folding)
    nq = []
    for t in tables:
        for p in t['partitions']:
            if '[Query=' in p['source'] or 'Value.NativeQuery' in p['source']:
                nq.append(p['table'])
    if nq:
        add('MDL-09', 'warn', 'מודל', ', '.join(sorted(set(nq))[:5]),
            'שאילתת SQL ילידית ב-Power Query — query folding נשבר',
            'שימוש ב-[Query="..."]/Value.NativeQuery גורם לכל טרנספורמציה עוקבת לרוץ מקומית במקום '
            'במסד — רענון איטי.',
            'להעביר את ה-SQL ל-view במקור, או לוודא שהטרנספורמציות נעשות לפני ה-Native Query. '
            'מקור: Microsoft optimization guide — query folding.')

    # MDL-10 · פרטי חיבור חקוקים ב-M (סודות — לספור, לא לצטט)
    conn = 0
    for t in tables:
        for p in t['partitions']:
            conn += len(re.findall(r'(?i)(?:Sql|Oracle|OleDb|Odbc)\.\w+\s*\(\s*"[^"]+"', p['source']))
            conn += len(re.findall(r'(?i)Web\.Contents\s*\(\s*"http', p['source']))
    if conn:
        add('MDL-10', 'warn', 'מודל', 'Power Query (M)',
            'נמצאו %d מחרוזות חיבור/כתובות חקוקות ב-M' % conn,
            'שמות שרתים/מסדים/כתובות חקוקים בקוד המקור. ⛔ לא מצטטים אותם לדוח הביקורת '
            '(§12ב — אבטחת מידע).',
            'להחליף בביטויים בעלי שם (expression Server = ... meta [IsParameterQuery=true]) — '
            'שינוי שרת במקום אחד. מקור: Microsoft TMDL guidelines — parameters.')

    # PQ-01 · Value.NativeQuery בלי EnableFolding=true — שובר query folding
    for t in tables:
        for p in t['partitions']:
            if (re.search(r"(?i)Value\.NativeQuery\s*\(", p['source'])
                    and not re.search(r"(?i)EnableFolding\s*=\s*true", p['source'])):
                add('PQ-01', 'warn', 'מודל', '%s/%s' % (t['name'], p['name']),
                    'שאילתת SQL ידנית בלי EnableFolding=true',
                    'Value.NativeQuery בלי EnableFolding=true מונע query folding מנקודת הקריאה — '
                    'כל הטרנספורמציות הבאות רצות מקומית על הטבלה המלאה בזיכרון (זמן רענון ועומס).',
                    'להוסיף [EnableFolding=true] כארגומנט רשומה ל-Value.NativeQuery (נתמך ב-SQL Server, '
                    'Oracle, MySQL ועוד) או להעביר את הלוגיקה ל-view. מקור: Microsoft Learn — '
                    'Query folding on native queries.')

    # PQ-02 · Web.BrowserContents — שאילתה שבירה
    for t in tables:
        for p in t['partitions']:
            if re.search(r"(?i)Web\.BrowserContents\s*\(", p['source']):
                add('PQ-02', 'tip', 'מודל', '%s/%s' % (t['name'], p['name']),
                    'שימוש ב-Web.BrowserContents',
                    'BrowserContents מרנדר דף כדפדפן ומחזיר DOM כטקסט — שביר לשינויי עיצוב באתר '
                    'ואיטי משמעותית מ-API.',
                    'להעדיף Web.Contents + Web.Page (או JSON/ממשק API ייעודי). '
                    'מקור: Microsoft Learn — Power Query best practices.')

    # PQ-03 · Table.Buffer / List.Buffer — שובר folding וטוען לזיכרון
    for t in tables:
        for p in t['partitions']:
            hits = re.findall(r"(?i)(?:Table|List)\.Buffer\s*\(", p['source'])
            if hits:
                add('PQ-03', 'tip', 'מודל', '%s/%s' % (t['name'], p['name']),
                    'שימוש ב-Table.Buffer/List.Buffer (%d)' % len(hits),
                    'Buffer מעתיק את כל התוצאה לזיכרון ושובר query folding אחריו — לגיטימי רק '
                    'לנעילת snapshot או לבידוד ממקור לא-יציב.',
                    'להסיר אם אין צורך ב-snapshot; אם יש — לתעד בהערה למה. '
                    'מקור: Microsoft Learn — Query folding guidance.')

    # DAX-01 · מדדים כפולים (אותה נוסחה, שמות שונים)
    seen = {}
    for m in measures:
        ne = _norm_expr(m['expr'])
        if len(ne) < 8:
            continue
        seen.setdefault(ne, []).append('%s[%s]' % (m['table'], m['name']))
    for ne, names in seen.items():
        if len(names) > 1:
            add('DAX-01', 'warn', 'DAX', ' × '.join(names[:4]),
                'מדדים כפולים — אותה נוסחה בשמות שונים',
                'שני מדדים או יותר עם נוסחה זהה. כפילות = תחזוקה כפולה וסיכון שהם יתפצלו בעתיד.',
                'להשאיר מקור אמת אחד ולמחוק/להסתיר את הכפילויות (§20). כלל מקביל: BPA AVOID_DUPLICATE_MEASURES.')

    # DAX-02 · IFERROR
    for m in measures:
        if re.search(r"(?i)IFERROR\s*\(", m['expr']):
            add('DAX-02', 'warn', 'DAX', "%s[%s]" % (m['table'], m['name']),
                'שימוש ב-IFERROR',
                'IFERROR מסתיר שגיאות אמיתיות (לא רק חלוקה באפס) ופוגע בביצועים. לרוב DIVIDE/VAR '
                'נותנים פתרון מדויק יותר.',
                'להחליף ב-DIVIDE (לחלוקה) או בדיקת תנאי מפורשת. כלל מקביל: BPA AVOID_USING_THE_IFERROR_FUNCTION.')

    # DAX-03 · FILTER על טבלה שלמה כארגומנט ל-CALCULATE
    filt_tbl = re.compile(r"(?i)FILTER\s*\(\s*(?:'(?:[^']|'')+'|[A-Za-z_א-ת][\wא-ת ]*)\s*,")
    for m in measures:
        if re.search(r"(?i)CALCULATE\s*\(", m['expr']) or re.search(r"(?i)CALCULATETABLE\s*\(", m['expr']):
            hits = filt_tbl.findall(m['expr'])
            if hits:
                add('DAX-03', 'warn', 'DAX', "%s[%s]" % (m['table'], m['name']),
                    'FILTER על טבלה שלמה בתוך CALCULATE',
                    'התבנית FILTER(\'טבלה\', \'טבלה\'[עמודה]="ערך") סורקת את כל הטבלה במקום לסנן עמודה. '
                    'עדיף: \'טבלה\'[עמודה]="ערך" (עם KEEPFILTERS כשצריך).',
                    'להחליף לפרדיקט עמודה ישיר. מקור: Microsoft — dax-avoid-filter-as-filter-argument; '
                    'כלל מקביל: BPA FILTER_COLUMN_VALUES.')

    # DAX-04 · ריבוי IF מקונן
    for m in measures:
        n_if = len(re.findall(r"(?i)\bIF\s*\(", m['expr']))
        if n_if >= 3:
            add('DAX-04', 'tip', 'DAX', "%s[%s]" % (m['table'], m['name']),
                '%d תנאי IF במדד אחד — קריאות ותחזוקה' % n_if,
                'שרשרת IF מקוננת קשה לקריאה ולתחזוקה.',
                'להחליף ל-SWITCH(TRUE(), ...) עם VAR. מקור: קונבנציית DAX מקובלת (SQLBI).')

    # DAX-05 · EARLIER
    for m in measures:
        if re.search(r"(?i)\bEARLIER\s*\(", m['expr']):
            add('DAX-05', 'warn', 'DAX', "%s[%s]" % (m['table'], m['name']),
                'שימוש ב-EARLIER',
                'EARLIER שביר ומבלבל; הדרך המודרנית והבטוחה היא VAR + EVALUATE-and-capture.',
                'להחליף ב-VAR ששומר את הערך מהקונטקסט החיצוני. מקור: SQLBI — variables replace EARLIER.')

    # DAX-06 · עמודה מחושבת עם RELATED
    for c in columns:
        if c['calculated'] and re.search(r"(?i)\bRELATED\s*\(", c['expr']):
            add('DAX-06', 'tip', 'DAX', "%s[%s]" % (c['table'], c['name']),
                'עמודה מחושבת עם RELATED',
                'עמודות מחושבות מתדחסות גרוע מעמודות מקור ומנפחות את המודל.',
                'להעביר לעמודת מקור (Power Query) או למדד. כלל מקביל: BPA REDUCE_USAGE_OF_CALCULATED_COLUMNS_THAT_USE_THE_RELATED_FUNCTION.')

    # DAX-07 · מדד שהוא הפניה ישירה למדד אחר
    mnames = {m['name'] for m in measures}
    for m in measures:
        ne = m['expr'].strip()
        r = re.fullmatch(r"\[([^\]]+)\]", ne)
        if r and r.group(1).strip() in mnames and r.group(1).strip() != m['name']:
            add('DAX-07', 'tip', 'DAX', "%s[%s]" % (m['table'], m['name']),
                'מדד שהוא כינוי בלבד למדד אחר',
                'מדד שכולו [מדד אחר] מוסיף שכבת בלבול בלי ערך.',
                'להשתמש במדד המקורי ישירות ולמחוק את הכינוי. כלל מקביל: BPA MEASURES_SHOULD_NOT_BE_DIRECT_REFERENCES_OF_OTHER_MEASURES.')

    # MDL-11 · עמודות double (נקודה צפה)
    fl = ['%s[%s]' % (c['table'], c['name']) for c in columns if c['dataType'] == 'double']
    if fl:
        add('MDL-11', 'tip', 'מודל', '%d עמודות' % len(fl),
            'עמודות בטיפוס נקודה צפה (Double)',
            'Double עלול לייצר שגיאות עיגול בלתי צפויות בסכימה (%s).' % (', '.join(fl[:5]) + ('…' if len(fl) > 5 else '')),
            'להעדיף int64/decimal/currency כשמתאים. כלל מקביל: BPA AVOID_FLOATING_POINT_DATA_TYPES.')

    # MDL-12 · קשר על עמודת dateTime
    for r in rels:
        for ref in (r['from'], r['to']):
            if '.' not in ref:
                continue
            t, c = ref.rsplit('.', 1)
            col = cmap.get((_unq(t), _unq(c)))
            if col and col['dataType'] == 'dateTime':
                add('MDL-12', 'warn', 'מודל', ref,
                    'קשר שנבנה על עמודת dateTime',
                    'קשר על עמודת תאריך+שעה = קרדינליות גבוהה וזיכרון מנופח. מקובל לקשר על עמודת '
                    'תאריך (date) בלבד ולפצל את השעה לעמודה נפרדת.',
                    'אין dataType: date ב-TMDL — dateTime הוא הערך היחיד לעמודת תאריך; אל תשנה את '
                    'ה-dataType (Desktop יסרב לפתוח — שדה סבב 2 #0). הטיפול ב-Power Query בלבד: '
                    'לפצל תאריך/שעה לעמודות נפרדות ולקשר על עמודת התאריך. כלל מקביל: BPA SPLIT_DATE_AND_TIME (עותק סטטי).')
                break

    # MDL-13 · קשר לא-פעיל שאף מדד לא מפעיל
    any_userel = any(re.search(r"(?i)USERELATIONSHIP\s*\(", m['expr']) for m in measures)
    for r in rels:
        if not r['active'] and not any_userel:
            add('MDL-13', 'tip', 'מודל', "%s → %s" % (r['from'], r['to']),
                'קשר לא-פעיל שאף מדד לא משתמש בו',
                'קשר מכובה ללא USERELATIONSHIP באף מדד = משקל מת במודל.',
                'להפעיל עם USERELATIONSHIP במדד ייעודי, או למחוק. כלל מקביל: BPA INACTIVE_RELATIONSHIPS_THAT_ARE_NEVER_ACTIVATED.')



    # MDL-14 · אין טבלת תאריכים כלל
    has_marked = any(t['data_category'].lower() == 'time' for t in tables)
    has_date_named = any(re.search(r"(?i)date|calendar|תאריך", t['name']) for t in tables)
    if tables and not has_marked and not has_date_named:
        add('MDL-14', 'warn', 'מודל', 'SemanticModel',
            'אין טבלת תאריכים במודל',
            'לא נמצאה טבלה מסומנת (dataCategory: Time) ואף לא טבלה עם date/תאריך בשמה. '
            'time-intelligence (YTD/אשתקד) דורש טבלת תאריכים ייעודית ומסומנת.',
            'לבנות טבלת תאריכים ייעודית (תבנית: references/dax-patterns.md) ולסמן אותה כ-Date table. '
            'כלל מקביל: BPA MODEL_SHOULD_HAVE_A_DATE_TABLE.')

    # MDL-15 · קצוות קשר בטיפוסי נתונים שונים
    for r in rels:
        ends = []
        for ref in (r['from'], r['to']):
            col = None
            if '.' in ref:
                t, c = ref.rsplit('.', 1)
                col = cmap.get((_unq(t), _unq(c)))
            ends.append(col['dataType'] if col else '')
        if all(ends) and ends[0] != ends[1]:
            add('MDL-15', 'warn', 'מודל', "%s ↔ %s" % (r['from'], r['to']),
                'קצוות הקשר בטיפוסים שונים (%s מול %s)' % (ends[0], ends[1]),
                'קשר בין טיפוסים שונים (למשל int64 מול string) מכריח המרה בכל שאילתה ועלול '
                'להיכשל בשקט על ערכים שלא נתאמים.',
                'ליישר טיפוסים בשני הצדדים (עדיף int64). כלל מקביל: BPA RELATIONSHIP_COLUMNS_SAME_DATA_TYPE.')

    # MDL-16 · טבלאות יתומות (ללא אף קשר)
    if len(tables) >= 2 and rels:
        linked = {t for t, _ in rel_cols}
        orphans = [t['name'] for t in tables if not t['hidden'] and t['name'] not in linked]
        if orphans:
            add('MDL-16', 'tip', 'מודל', ', '.join(orphans[:5]),
                '%d טבלאות ללא אף קשר (יתומות)' % len(orphans),
                'טבלה בלי קשר לא מסתננת מאף ממד. יוצאי דופן לגיטימיים: טבלאות פרמטרים/בחירה '
                'מנותקות בכוונה — ואז ראוי לתעד זאת.',
                'לקשר למודל, או לתעד כמנותקת בכוונה בתיק הדוח. כלל מקביל: BPA ENSURE_TABLES_HAVE_RELATIONSHIPS.')

    # MDL-17 · קשר many-to-many
    for r in rels:
        if r.get('from_card') == 'many' and r.get('to_card') == 'many':
            add('MDL-17', 'warn', 'מודל', "%s ↔ %s" % (r['from'], r['to']),
                'קשר many-to-many',
                'קשר רבים-לרבים יוצר סינון דו-משמעי, תוצאות לא אינטואיטיביות ופגיעת ביצועים. '
                '(ב-TMDL: fromCardinality + toCardinality שניהם many.)',
                'להעדיף טבלת גישור (bridge) או סינון חד-כיווני. '
                'כלל מקביל: BPA MANY-TO-MANY_RELATIONSHIPS_SHOULD_BE_SINGLE-DIRECTION.')

    # MDL-18 · קשר דו-כיווני
    for r in rels:
        if r['both']:
            add('MDL-18', 'warn', 'מודל', "%s ↔ %s" % (r['from'], r['to']),
                'קשר דו-כיווני (bothDirections)',
                'סינון דו-כיווני מוסיף דו-משמעות לנתיב הסינון ומאט שאילתות — לגיטימי רק כשיש '
                'צורך מוכח בסינון הדדי.',
                'לבטל אלא אם יש צורך מתועד; לתעד את הסיבה. '
                'כלל מקביל: BPA CHECK_IF_BI-DIRECTIONAL_AND_MANY-TO-MANY_RELATIONSHIPS_ARE_VALID.')

    # MDL-19 · מדדים רבים שטוחים בלי אף displayFolder — ארגון רשימת שדות
    # (bernatagulloesbrina/TabularEditor-Scripts, MIT: Move All Columns to a DisplayFolder /
    # Clean Up Columns Measures — ארגון מדדים לתיקיות תצוגה הוא פרקטיקת עבודה סטנדרטית)
    if len(measures) >= 8 and not any(m.get('folder') for m in measures):
        add('MDL-19', 'tip', 'מודל', '%d מדדים' % len(measures),
            '%d מדדים בלי אף displayFolder' % len(measures),
            'כל המדדים מוצגים שטוחים ברשימת השדות — קשה לאתר מדד במודל גדול. '
            'ארגון לתיקיות תצוגה לפי נושא הוא פרקטיקה סטנדרטית (Tabular Editor scripts).',
            'להוסיף displayFolder למדדים (למשל לפי תחום: KPI, Time Intelligence). '
            'מקור: bernatagulloesbrina/TabularEditor-Scripts (MIT).')

    # MDL-23 · מדדים רבים בטבלאות נתונים, בלי טבלת מדדים ייעודית
    # (data-mozart.com "5 tips" Tip #1 — טבלת מדדים ייעודית מפרידה ארגון מדדים
    #  מטבלאות נתונים; נמצא על 5 הדשבורדים השבורים: ~15 מדדים בטבלת ה-fact)
    if len(measures) >= 10:
        def _is_measures_table(t):
            vis_cols = [c for c in t['columns'] if not c.get('hidden')]
            return t['measures'] and not vis_cols and not t['partitions']
        if not any(_is_measures_table(t) for t in tables):
            host = sorted({m['table'] for m in measures})
            add('MDL-23', 'tip', 'מודל', ', '.join(host[:4]),
                '%d מדדים בטבלאות נתונים — אין טבלת מדדים ייעודית' % len(measures),
                'כל המדדים שוכנים בטבלאות שמכילות נתונים. במודלים עם מדדים רבים זה '
                'מערבב אחריות: רשימת השדות מוצפת, קשה למצוא מדד, ואין מקום אחד '
                'לתחזוקה. מקור: data-mozart.com — 5 tips to boost your Power BI '
                'development, Tip #1 (קרדיט: Nikola Ilic).',
                'ליצור טבלה ריקה (Enter Data) בשם _מדדים, להעביר אליה את המדדים '
                '(Home table) ולמחוק את העמודה הדמה — הטבלה תוצג ראשונה עם אייקון '
                'מחשבון. לשלב עם displayFolder (MDL-19).')

    # MDL-20 · מדדים ללא description — תיעוד חסר (nara-technologies/pbip-lens,
    # Apache-2.0: missing-description rule — מדד/טבלה בלי תיאור = Low violation)
    if len(measures) >= 5:
        undoc = [m for m in measures if not m.get('desc')]
        if len(undoc) > len(measures) // 2:  # רוב בלתי-מתועד — מתחת לזה זה רעש
            cov = 100 * (len(measures) - len(undoc)) // len(measures)
            undoc_t = [t['name'] for t in tables if not t.get('desc') and not t.get('hidden')]
            add('MDL-20', 'tip', 'מודל', 'SemanticModel',
                '%d מתוך %d מדדים ללא description (%d%% מתועדים)' % (len(undoc), len(measures), cov),
                'מדדים כמו %s חסרי תיאור. description הוא שכבת התיעוד שמופיעה ב-tooltip '
                'ברשימת השדות ובכלי governance — בלעדיו משמעות המדד נעלמת למי שלא כתב אותו.'
                % (', '.join('%s[%s]' % (m['table'], m['name']) for m in undoc[:4]) + ('…' if len(undoc) > 4 else '')) +
                (' גם %d טבלאות גלויות חסרות תיאור.' % len(undoc_t) if undoc_t else ''),
                'להוסיף description קצר (מה המדד מודד + הנחות) לכל מדד. '
                'מקור: nara-technologies/pbip-lens — MissingDescriptionRule (Apache-2.0); '
                'ראו references/documentation-standard.md.')

    # DAX-08 · חילוק חשוף במקום DIVIDE
    for m in measures:
        if '/' in _dax_clean(m['expr']):
            add('DAX-08', 'warn', 'DAX', "%s[%s]" % (m['table'], m['name']),
                'חילוק חשוף (/) במקום DIVIDE',
                'האופרטור / מחזיר שגיאה או אינסוף בחלוקה באפס ואינו מוגן. DIVIDE מחזיר BLANK '
                '(או ערך חלופי) וקריא יותר.',
                'להחליף ל-DIVIDE(מונה, מכנה) — אפשר אוטומטית עם pbi_fix.py של הבונה (--fix divide). '
                'כלל מקביל: BPA USE_THE_DIVIDE_FUNCTION_FOR_DIVISION.')

    # DAX-15 · SUM(x)/COUNT(x) על אותה עמודה — AVERAGE מובנית עושה את זה
    # (dax.guide/AVERAGE: מחזירה ממוצע חשבוני של עמודה מספרית; נמצא על דוח
    #  משתמש אמיתי: ציון ממוצע = SUM(Score)/COUNT(Score))
    _sc = re.compile(
        r"SUM\s*\(\s*(?:'[^']+'|[\w\u0590-\u05ff]+)?\s*\[\s*([^\]]+?)\s*\]\s*\)"
        r"\s*/\s*"
        r"COUNT\s*\(\s*(?:'[^']+'|[\w\u0590-\u05ff]+)?\s*\[\s*([^\]]+?)\s*\]\s*\)",
        re.I)
    for m in measures:
        mm = _sc.search(_dax_clean(m['expr']))
        if mm and mm.group(1).strip().casefold() == mm.group(2).strip().casefold():
            add('DAX-15', 'tip', 'DAX', "%s[%s]" % (m['table'], m['name']),
                "SUM/COUNT על '%s' — המצאה-מחדש של AVERAGE" % mm.group(1).strip(),
                'רמת ביטחון: גבוהה (אותה עמודה במונה ובמכנה). SUM(x)/COUNT(x) שקול '
                'ל-AVERAGE(x) לעמודה מספרית, אבל ארוך יותר, חשוף לחלוקה באפס (ראו '
                'DAX-08) ומסתיר כוונה. מקור: dax.guide/AVERAGE.',
                "להחליף ל-AVERAGE('%s') — קצר, מוגן וברור." % mm.group(1).strip())

    # DAX-16 · COUNT על עמודה כשהכוונה ספירת שורות/ייחודיים — COUNTROWS/DISTINCTCOUNT
    # (MS Learn DAX best practices, CC-BY-4.0: "כשהכוונה ספירת שורות — תמיד
    #  COUNTROWS: יעיל יותר, לא מושפע מ-BLANKs, והכוונה מתועדת בעצמה". נמצא על
    #  דוחות שבורים של המשתמש: מספר רשומות = COUNT(MoveID); ספקים ייחודיים = COUNT.)
    _col_by_qual = {(c['table'], c['name']): c for c in columns}
    _count_col = re.compile(
        r"(?i)\bCOUNT\s*\(\s*(?:'([^']+)'|([\w\u0590-\u05ff]+))?\s*\[\s*([^\]]+?)\s*\]\s*\)")
    _rowcount_name = re.compile(
        r"(?i)(מספר|ספירה|ספירת|רשומות|שורות|כמות|count|rows|records|entries)")
    _uniq_name = re.compile(r"(?i)(ייחודי|ייחודיים|distinct|unique)")
    for m in measures:
        nm = m['name']
        for mm in _count_col.finditer(_dax_clean(m['expr'])):
            ent = mm.group(1) or mm.group(2) or m['table']
            prop = mm.group(3).strip()
            col0 = _col_by_qual.get((ent, prop))
            if _uniq_name.search(nm):
                add('DAX-16', 'warn', 'DAX', "%s[%s]" % (m['table'], nm),
                    "COUNT על '%s' במדד '%s' — הכוונה כנראה DISTINCTCOUNT" % (prop, nm),
                    'שם המדד מבטיח ספירה ייחודית, אבל COUNT סופר ערכים לא-ריקים כולל '
                    'כפילויות — המספר שיוצג יהיה שגוי בשקט אם יש חזרות. מקור: MS Learn '
                    'DAX best practices (CC-BY-4.0).',
                    "להחליף ל-DISTINCTCOUNT('%s'[%s])." % (ent, prop))
            elif (col0 and col0.get('isKey')) or _rowcount_name.search(nm):
                add('DAX-16', 'tip', 'DAX', "%s[%s]" % (m['table'], nm),
                    "COUNT על '%s' — COUNTROWS מדויק ויעיל יותר לספירת שורות" % prop,
                    'כשהכוונה ספירת שורות, COUNTROWS(טבלה) עדיף: לא מושפע מ-BLANKs '
                    'בעמודה, מתבצע מהיר יותר, והכוונה מתועדת בעצמה. מקור: MS Learn '
                    'DAX best practices — "Use COUNTROWS instead of COUNT" (CC-BY-4.0).',
                    "להחליף ל-COUNTROWS('%s') אם הכוונה ספירת שורות." % ent)

    # DAX-17 · אריתמטיקת no-op במדד (*1, /1, +0, -0) — רעש שנשאר מעתיקה
    # (נמצא על דוחות שבורים של המשתמש: עלות מתואמת = SUM(x) * 1)
    _noop = re.compile(r"([*/])\s*1(?![\d.])|([+-])\s*0(?![\d.])")
    for m in measures:
        hits = _noop.findall(_dax_clean(m['expr']))
        if hits:
            pats = sorted({op + val for op, val in hits})
            add('DAX-17', 'tip', 'DAX', "%s[%s]" % (m['table'], m['name']),
                'אריתמטיקה חסרת אפקט: %s' % ', '.join(pats),
                'כפל/חילוק ב-1 או חיבור/חיסור 0 לא משנים את התוצאה — שארית של עריכה '
                'שמאריכה את הנוסחה ומטעה את הקורא לחפש כוונה שאין.',
                'להסיר את האיבר העודף מהנוסחה.')

    # DAX-18 · מספר קסם גדול במדד — קבוע חקוק בלי שם או מדד-יעד
    # (נמצא על דוחות שבורים של המשתמש: פער מהיעד = SUM(x) - 100000)
    # רק בהקשר של סף/יעד (+/-/השוואה) — חילוק בחזקת 10 הוא סקיילינג תצוגה
    # לגיטימי (FP שנמצא בקורפוס: capital מחלק ב-1000000 בתוך FORMAT למיליונים)
    _magic = re.compile(r"(?:>=|<=|<>|>|<|\+|-)[\s(]*(\d{5,})(?![\d.])")
    for m in measures:
        hits = [h for h in _magic.findall(_dax_clean(m['expr']))
                if int(h) % 100 == 0]
        if hits:
            add('DAX-18', 'tip', 'DAX', "%s[%s]" % (m['table'], m['name']),
                'מספר קסם במדד: %s' % ', '.join(sorted(set(hits))[:3]),
                'קבוע גדול חקוק בנוסחה בלי שם או הפניה — לא ברור מה הוא מייצג (יעד? '
                'תקציב? סף?) וישתנה בשקט כשהעסק יזוז. (מועמד — לוודא מול המודל.)',
                'להוציא למדד יעד נפרד או לטבלת פרמטרים (What-if) עם שם מתועד.')

    # MDL-24 · קשר לעמודת טקסט שאינה מפתח בצד-היחיד — קשר על שם במקום מפתח
    # (radacad.com "Power BI Relationship Demystified", קרדיט: Reza Rad — צד-היחיד
    #  של קשר חייב עמודה ייחודית (מפתח); נמצא על 5 השבורים: פריט ← פריטים.שם_פריט)
    _colq = {(c['table'], c['name']): c for t in tables for c in t['columns']}
    for r in rels:
        if r.get('active') is False:
            continue
        for end in ('to', 'from'):
            ref = r.get(end, '')
            if '.' not in ref:
                continue
            rt, rc = ref.rsplit('.', 1)
            col0 = _colq.get((_unq(rt), _unq(rc)))
            if not col0:
                continue
            # רק צד ה-'to' (הממד): FK טקסטואלי בצד many הוא נורמלי.
            # warn לעמודת שם-תצוגה; tip לעמודת קוד/מזהה טקסטואלית (Claim_ID וכו')
            if end == 'to' and col0.get('dataType') == 'string' and not col0.get('isKey'):
                sev24 = 'warn' if re.search(r"(?i)(שם|תיאור|name|desc)", _unq(rc)) else 'tip'
                add('MDL-24', sev24, 'מודל', "%s ← %s" % (r['from'], r['to']),
                    "צד-היחיד של הקשר הוא עמודת טקסט לא-מפתח: '%s'" % _unq(rc),
                    'קשר על עמודת שם/טקסט בצד-היחיד שביר פעמיים: שמות אינם מובטחים '
                    'ייחודיים (שני ספקים באותו שם ישברו את הסכמה בשקט או יעלו שגיאת '
                    'כפילות בטעינה), והשוואת טקסט איטית ורגישה לרווחים/ניקוד. מקור: '
                    'radacad.com — Relationship Demystified (קרדיט: Reza Rad).',
                    'להוסיף עמודת מפתח (ID) לממד, לסמן isKey, ולבנות את הקשר עליה; '
                    'את עמודת השם להשאיר לתצוגה בלבד.')

    # MDL-25 · 2+ טבלאות נתונים בלי אף קשר ביניהן — סכמה מנותקת
    # (learn.microsoft.com desktop-create-and-manage-relationships, CC-BY-4.0 —
    #  "כשיש כמה טבלאות, קשרים ביניהן נחוצים כדי לחשב תוצאות נכונות ולהציג מידע
    #  נכון בדוחות"; נמצא על דוחות המשתמש 01/03/05: פריטים+עובדים ללא קשר)
    _conn = [t for t in tables
             if any(not c.get('hidden') and c.get('name') for c in t['columns'])]
    if len(_conn) >= 2 and not rels:
        add('MDL-25', 'warn', 'מודל', ', '.join(_unq(t['name']) for t in _conn[:4]),
            '%d טבלאות נתונים בלי אף קשר ביניהן' % len(_conn),
            'המודל מכיל %d טבלאות נתונים (עם עמודות גלויות) ואפס קשרים. בלי קשרים '
            "אין הפצת סינון בין הטבלאות: ויז'ואל שמערב שדות משתי טבלאות מציג "
            'מכפלה קרטזית או ערכים כפולים/ריקים. טבלאות תאריך אוטומטיות וטבלאות '
            'מדדים-בלבד אינן נספרות (מנותקות מכוונת). מקור: learn.microsoft.com — '
            'Create and manage relationships in Power BI Desktop (CC-BY-4.0).'
            % len(_conn),
            'ליצור קשר (Modeling → Manage relationships) על עמודות המפתח בין '
            'הטבלאות; אם הטבלאות באמת בלתי-קשורות, לשקול לפצל למודלים נפרדים.')

    # DAX-19 · השוואת סכום לממוצע בתנאי — רמות אגרגציה שונות
    # (נמצא על 5 השבורים: סטטוס כולל = IF([עלות כוללת] > [ממוצע עלות], ...))
    _mexpr19 = {m['name']: m['expr'] for m in measures}
    _cmp19 = re.compile(r"\[([^\]]+)\]\s*(>=|<=|<>|>|<)\s*\[([^\]]+)\]")
    def _root_agg(e):
        m = re.search(r"(?i)\b(SUM|AVERAGE|COUNTROWS|DISTINCTCOUNT|COUNT|MIN|MAX)\s*\(", e or '')
        return m.group(1).upper() if m else ''
    for m in measures:
        for mm in _cmp19.finditer(_dax_clean(m['expr'])):
            a, b = mm.group(1).strip(), mm.group(3).strip()
            ea, eb = _mexpr19.get(a), _mexpr19.get(b)
            if ea is None or eb is None:
                continue
            ga, gb = _root_agg(ea), _root_agg(eb)
            if {ga, gb} == {'SUM', 'AVERAGE'}:
                add('DAX-19', 'tip', 'DAX', "%s[%s]" % (m['table'], m['name']),
                    "השוואה בין '%s' (סכום) ל-'%s' (ממוצע) — רמות שונות" % (a, b),
                    'רמת ביטחון: בינונית (השוואת שורשי אגרגציה). סכום גדל עם מספר '
                    'השורות בהקשר, ממוצע לא — ההשוואה ביניהם תלויה בכמות הרשומות '
                    'ולא בביצועים; סינון יחליש את הסכום וישאיר את הממוצע. (מועמד — '
                    'לוודא שההשוואה מכוונת.)',
                    'להשוות באותה רמה: ממוצע מול ממוצע, או סכום מול יעד-סכום '
                    '(טבלת יעדים), ולתעד את הכוונה בשם המדד.')

        # DAX-20 · FILTER על טבלה שלמה עם תנאי פשוט — לסנן עמודה, לא טבלה
        # (sqlbi.com "Filter Arguments in CALCULATE", קרדיט: Marco Russo &
        #  Alberto Ferrari — ארגומנט סינון ב-CALCULATE הוא איטרטור; תנאי עמודה
        #  ישיר קצר ומהיר יותר מ-FILTER על טבלה. נמצא בקורפוס: insurance
        #  FactClaims[Settlement_Days], claude WinCount.)
    _tnames = {t['name'] for t in tables}
    _filt = re.compile(r"(?i)\bFILTER\s*\(\s*(?:'((?:[^']|'')+)'|([A-Za-z0-9_\u0590-\u05ea][A-Za-z0-9_\u0590-\u05ea .]*?))\s*,")
    for m in measures:
        expr = _dax_clean(m['expr'])
        for fm in _filt.finditer(expr):
            tname = _unq(fm.group(1) or fm.group(2) or '')
            if tname not in _tnames:
                continue  # משתנה טבלה מקומי — לא שולחן מודל, מדלגים
            # התנאי = עד הסוגר המאוזן של FILTER
            depth, k = 1, fm.end()
            while k < len(expr) and depth:
                if expr[k] == '(':
                    depth += 1
                elif expr[k] == ')':
                    depth -= 1
                k += 1
            cond = expr[fm.end():k - 1]
            if '&&' in cond or '||' in cond:
                continue  # תנאי מרוכב — חייב איטרציה, חוקי
            add('DAX-20', 'tip', 'DAX', "%s[%s]" % (m['table'], m['name']),
                "FILTER על כל הטבלה '%s' עם תנאי פשוט" % tname,
                'ארגומנט סינון ב-CALCULATE הוא איטרטור: FILTER על טבלה שלמה '
                'סורק כל שורה. תנאי עמודה ישיר (T[c]=v) קצר, קריא ומהיר יותר. '
                'מקור: sqlbi.com — Filter Arguments in CALCULATE (קרדיט: '
                'Marco Russo & Alberto Ferrari).',
                "לשכתב כתנאי עמודה ישיר בתוך CALCULATE, או FILTER על עמודה "
                "בלבד (VALUES/ALL) במקום על הטבלה כולה.")

        # DAX-09 · INTERSECT במקום TREATAS
    for m in measures:
        if re.search(r"(?i)\bINTERSECT\s*\(", m['expr']):
            add('DAX-09', 'tip', 'DAX', "%s[%s]" % (m['table'], m['name']),
                'שימוש ב-INTERSECT (קשר וירטואלי)',
                'TREATAS קריא יותר ומהיר יותר לקשרים וירטואליים.',
                'להחליף ל-TREATAS. כלל מקביל: BPA USE_THE_TREATAS_FUNCTION_INSTEAD_OF_INTERSECT.')

    # DAX-10 · EVALUATEANDLOG במודל ייצור
    for m in measures:
        if re.search(r"(?i)\bEVALUATEANDLOG\s*\(", m['expr']):
            add('DAX-10', 'warn', 'DAX', "%s[%s]" % (m['table'], m['name']),
                'EVALUATEANDLOG נשאר במודל',
                'פונקציית דיבוג שכותבת לוג בכל הפעלה — לא מיועדת למודל ייצור (ביצועים + רעש).',
                'להסיר אחרי סיום הדיבוג. כלל מקביל: BPA EVALUATEANDLOG_SHOULD_NOT_BE_USED_IN_PRODUCTION_MODELS.')

    # DAX-11 · מדד ללא formatString
    no_fmt = ['%s[%s]' % (m['table'], m['name']) for m in measures if not m.get('fmt')]
    if no_fmt:
        add('DAX-11', 'tip', 'DAX', '%d מדדים' % len(no_fmt),
            'מדדים ללא formatString',
            'מדדים כמו %s ירונדרו בפורמט ברירת-מחדל — בלי מפריד אלפים/אחוזים עקביים.'
            % (', '.join(no_fmt[:6]) + ('…' if len(no_fmt) > 6 else '')),
            'להגדיר formatString (#,0 / 0.0% וכו\') לכל מדד גלוי. כלל מקביל: BPA PROVIDE_FORMAT_STRING_FOR_MEASURES.')

    # DAX-14 · עמודה מספרית/תאריך גלויה בלי formatString
    # (Tabular Editor built-in BPA: "Provide Format String for Numeric and Date Columns")
    _NUMDT = ('int64', 'double', 'decimal', 'dateTime')
    col_no_fmt = ['%s[%s]' % (c['table'], c['name']) for c in columns
                  if c.get('dataType') in _NUMDT and not c.get('hidden')
                  and not c.get('fmt') and not c.get('isKey')]
    if col_no_fmt:
        add('DAX-14', 'tip', 'DAX', '%d עמודות' % len(col_no_fmt),
            'עמודות מספריות/תאריך גלויות ללא formatString',
            'רמת ביטחון: גבוהה. עמודה גלויה מסוג %s בלי formatString תוצג בפורמט '
            'כללי (למשל 1000000 במקום 1,000,000). מקור: Tabular Editor 3 built-in '
            'BPA — Provide Format String for Numeric and Date Columns. '
            'נמצאו: %s' % ('/'.join(_NUMDT),
                           ', '.join(col_no_fmt[:6]) + ('…' if len(col_no_fmt) > 6 else '')),
            'להגדיר formatString מתאים (#,0 לשלמים, #,0.00 לעשרוני, dd/mm/yyyy לתאריך) '
            'או להסתיר עמודות טכניות.')

    # DAX-12 · סיווג שגוי בהפניות: עמודה חייבת טבלה[עמודה], מדד חייב [מדד] בלבד
    measure_ci = {m['name'].casefold() for m in measures}
    col_ci = {c['name'].casefold() for t in tables for c in t['columns']}
    ambiguous = measure_ci & col_ci   # שם שקיים כמדד וגם כעמודה — לא ניתן להכריע, מדלגים
    qref = re.compile(r"'([^']+)'\[([^\]\n]+)\]|([A-Za-z_][\w]*)\[([^\]\n]+)\]")
    bref = re.compile(r"(?<![\w\]'])\[([^\]\n]+)\]")
    for m in measures:
        ce = _dax_clean(m['expr'])
        qualified_measure, bare_column = [], []
        for mm in qref.finditer(ce):
            ref = (mm.group(2) or mm.group(4) or '').strip().casefold()
            if ref in measure_ci and ref not in ambiguous:
                qualified_measure.append(mm.group(0))
        for mm in bref.finditer(ce):
            ref = mm.group(1).strip().casefold()
            if ref in col_ci and ref not in ambiguous:
                bare_column.append(mm.group(1).strip())
        if qualified_measure or bare_column:
            parts = []
            if bare_column:
                parts.append('עמודות ללא שם טבלה: %s' % ', '.join(sorted(set(bare_column))[:3]))
            if qualified_measure:
                parts.append('מדדים עם שם טבלה: %s' % ', '.join(sorted(set(qualified_measure))[:3]))
            add('DAX-12', 'tip', 'DAX', "%s[%s]" % (m['table'], m['name']),
                'סיווג שגוי בהפניות שדות',
                '. '.join(parts) + '. ההפך מהמוסכמה מקשה על קריאה: בעין רגילה טבלה[X] נראית '
                'כמו עמודה, ו-[X] בלי טבלה נראה כמו מדד.',
                "עמודות תמיד עם שם טבלה ('דימ'[עמודה]), מדדים תמיד בלי ([מדד]). "
                'כללים מקבילים: BPA DAX_COLUMNS_FULLY_QUALIFIED + DAX_MEASURES_UNQUALIFIED (MIT).')

    # DAX-13 · קשר לא-פעיל שאף מדד לא מפעיל (USERELATIONSHIP)
    squashed_dax = re.sub(r"[\s']+", '', ' '.join(_dax_clean(m['expr']) for m in measures)).casefold()
    for r in rels:
        if r['active'] or '.' not in r['from'] or '.' not in r['to']:
            continue
        ft, fc = r['from'].rsplit('.', 1)
        tt, tc = r['to'].rsplit('.', 1)
        f_ref = '%s[%s]' % (_unq(ft), _unq(fc))
        t_ref = '%s[%s]' % (_unq(tt), _unq(tc))
        activated = ('userelationship(' in squashed_dax and
                     f_ref.casefold() in squashed_dax and t_ref.casefold() in squashed_dax)
        if not activated:
            add('DAX-13', 'warn', 'מודל', '%s → %s' % (f_ref, t_ref),
                'קשר לא-פעיל שאף מדד לא מפעיל',
                'הקשר מוגדר isActive: false אבל אף מדד במודל לא מפעיל אותו ב-USERELATIONSHIP — '
                'משקל מת של הגדרה שלא משפיעה על שום חישוב (או שהופעלה נשכחה).',
                'אם הקשר לגיבוי עתידי — לתעד בתיאור; אם נשכח — להפעיל במדד הרלוונטי ב-'
                'USERELATIONSHIP או למחוק. כלל מקביל: BPA INACTIVE_RELATIONSHIPS_THAT_ARE_NEVER_ACTIVATED (MIT).')

# ══════════════════════════ קריאת דוח (PBIR) ══════════════════════════
def _load_json(path):
    with open(path, 'rb') as fh:
        return json.loads(fh.read().decode('utf-8-sig'))


def _dct(v):
    """כפייה ל-dict סלחנית לסעיפים מקוננים מ-JSON חיצוני (§16)."""
    return v if isinstance(v, dict) else {}


def _str(v):
    """כפייה ל-str סלחנית לשדות סקלריים מ-JSON חיצוני (§16)."""
    return v if isinstance(v, str) else ('' if v is None else str(v))


def _walk(o, cb):
    if isinstance(o, dict):
        cb(o)
        for v in o.values():
            _walk(v, cb)
    elif isinstance(o, list):
        for v in o:
            _walk(v, cb)


def _literal(node):
    """ערך Literal מביטוי PBIR: {'expr': {'Literal': {'Value': ...}}}"""
    try:
        return str(node['expr']['Literal']['Value']).strip("'")
    except Exception:
        return None



def _has_alt_text(visual):
    """alt text מפורש ולא-ריק על ויזואל (visualContainerObjects/general/properties/altText)."""
    vco = _dct(visual).get('visualContainerObjects') or {}
    for blk in vco.get('general') or []:
        props = (blk or {}).get('properties') or {}
        at = props.get('altText')
        if not at:
            continue
        if isinstance(at, dict):
            val = _literal(at)
            if val is None and 'expr' in at:
                return True  # ביטוי מותנה — altText הוגדר
            if val and val.strip():
                return True
        elif str(at).strip():
            return True
    return False

def _mob_dims(path):
    """מידות פריסת מובייל מ-mobile.json (אם קיים), אחרת None."""
    try:
        d = json.load(open(path, encoding='utf-8-sig'))
        pos = d.get('position', {})
        if not isinstance(pos, dict):
            return None
        w, h = pos.get('width'), pos.get('height')
        if isinstance(w, (int, float)) and isinstance(h, (int, float)):
            return (w, h)
    except Exception:
        pass
    return None


def _hex_norm(v):
    if not v:
        return None
    v = v.strip().strip("'").upper()
    m = re.match(r"^#([0-9A-F]{6}|[0-9A-F]{3})$", v)
    if not m:
        return None
    h = m.group(1)
    if len(h) == 3:
        h = ''.join(ch * 2 for ch in h)
    return '#' + h


def _visual_fields(v):
    """זהות שדות מ-query: *.Property + Entity (known-issues-log §2)."""
    out = []

    def rec(o):
        if isinstance(o, dict):
            for kind in ('Measure', 'Column', 'Aggregation'):
                d = o.get(kind)
                if isinstance(d, dict) and d.get('Property'):
                    ent = ''
                    try:
                        ent = d['Expression']['SourceRef'].get('Entity', '')
                    except Exception:
                        pass
                    out.append((ent, str(d['Property'])))
            for val in o.values():
                rec(val)
        elif isinstance(o, list):
            for val in o:
                rec(val)
    rec(_dct(_dct(v).get('visual')).get('query', {}))
    return out


def read_report(report_dir):
    """מחזיר dict עם pages (כולל page.json), visuals מלאים, theme, mobile, report filters."""
    pages, themes = [], []
    report_filters = []
    errors = []   # קבצים שלא נקראו — הופך לממצא RPT-22, כי קובץ שבור = עיוורון בביקורת
    rf = os.path.join(report_dir, 'definition', 'report.json')
    if os.path.exists(rf):
        try:
            rj = _load_json(rf)
            if not isinstance(rj, dict):
                raise ValueError('JSON תקין אבל לא אובייקט (%s)' % type(rj).__name__)
            report_filters = (rj.get('filterConfig') or {}).get('filters') or []
        except Exception as e:
            errors.append({'file': 'definition/report.json', 'err': str(e)})
    # theme — איחוד פלטות מכל קבצי ה-theme (RegisteredResources + BaseThemes)
    theme_wild, theme_typed = {}, {}
    palette, theme_fonts = set(), set()
    theme_bg = theme_fg = None
    theme_data_colors = []
    for tf in glob.glob(os.path.join(report_dir, 'StaticResources', '**', '*.json'), recursive=True):
        try:
            t = _load_json(tf)
        except Exception:
            continue
        if not isinstance(t, dict) or 'dataColors' not in t:
            continue
        themes.append(os.path.basename(tf))
        # ADV-26/27 — מפל העיצוב: ברירות wildcard ו-visualTypes מה-theme (theme-cascade)
        for scope, lvl1 in (t.get('visualStyles') or {}).items():
            if not isinstance(lvl1, dict):
                continue
            for _l2, groups in lvl1.items():
                if not isinstance(groups, dict):
                    continue
                for g, entries in groups.items():
                    if not isinstance(entries, list):
                        continue
                    for ent in entries:
                        if not isinstance(ent, dict):
                            continue
                        for prop, val in ent.items():
                            nv = _fmt_val(val)
                            if nv is None:
                                continue
                            if scope == '*':
                                theme_wild[(g, prop)] = nv
                            else:
                                theme_typed[(scope, g, prop)] = nv
        for c in t.get('dataColors', []):
            h = _hex_norm(str(c))
            if h:
                palette.add(h)
                if h not in theme_data_colors:
                    theme_data_colors.append(h)
        for k in ('background', 'foreground', 'tableAccent'):
            h = _hex_norm(str(t.get(k, '')))
            if h:
                palette.add(h)
        if theme_bg is None:
            theme_bg = _hex_norm(str(t.get('background', '')))
        if theme_fg is None:
            theme_fg = _hex_norm(str(t.get('foreground', '')))
        for cls in (t.get('textClasses') or {}).values():
            if isinstance(cls, dict) and cls.get('fontFace'):
                theme_fonts.add(str(cls['fontFace']))
    # pages.json — נקרא לכיסוי RPT-22 (§16): קובץ קטוע/בצורה לא צפויה הוא ממצא קריטי,
    # לא דילוג שקט (cross-cutting #4 בדוח השדה 14.9 — היה עיוורון מתועד).
    psj = os.path.join(report_dir, 'definition', 'pages', 'pages.json')
    if os.path.exists(psj):
        try:
            j = _load_json(psj)
            if not isinstance(j, dict):
                raise ValueError('JSON תקין אבל לא אובייקט (%s)' % type(j).__name__)
        except Exception as e:
            errors.append({'file': 'definition/pages/pages.json', 'err': str(e)})
    page_dirs = sorted(glob.glob(os.path.join(report_dir, 'definition', 'pages', '*')))
    for pd in page_dirs:
        if not os.path.isdir(pd):
            continue
        pj_path = os.path.join(pd, 'page.json')
        pjson = {}
        if os.path.exists(pj_path):
            try:
                pjson = _load_json(pj_path)
                if not isinstance(pjson, dict):
                    raise ValueError('JSON תקין אבל לא אובייקט (%s)' % type(pjson).__name__)
            except Exception as e:
                pjson = {}
                errors.append({'file': 'definition/pages/%s/page.json' % os.path.basename(pd),
                               'err': str(e)})
        # שדות סקלריים מגיעים מקובץ חיצוני — מכפילים ל-str כדי שכללים במורד
        # (למשל RPT-19 שעושה casefold) לא ייפלו על name: 5 ודומיו (§16).
        ptype = pjson.get('type', '')
        pvis = pjson.get('visibility', '')
        page = {
            'id': os.path.basename(pd),
            'name': _str(pjson.get('displayName', '') or pjson.get('name', '')),
            'type': ptype if isinstance(ptype, str) else '',
            'visibility': pvis if isinstance(pvis, str) else '',
            'w': pjson.get('width'), 'h': pjson.get('height'),
            'raw': pjson,
            'filters': (pjson.get('filterConfig') or {}).get('filters') or [],
            'visuals': [],
        }
        for vf in sorted(glob.glob(os.path.join(pd, 'visuals', '*', 'visual.json'))):
            vid = os.path.basename(os.path.dirname(vf))
            rel = 'definition/pages/%s/visuals/%s/visual.json' % (os.path.basename(pd), vid)
            raw_txt = ''
            # כל גוף הלולאה בתוך try (§16): קובץ פגום נרשם ב-errors ולא מפיל את הבדיקה.
            try:
                raw_txt = open(vf, 'rb').read().decode('utf-8-sig')
                d = json.loads(raw_txt)
                if not isinstance(d, dict):
                    raise ValueError('JSON תקין אבל לא אובייקט (%s)' % type(d).__name__)
                v = d.get('visual', {})
                if not isinstance(v, dict):
                    v = {}
                pos = d.get('position', {})
                if not isinstance(pos, dict):
                    pos = {}
                # altText: visualContainerObjects.general[].properties.altText
                alt = None
                vco = v.get('visualContainerObjects', {})
                if not isinstance(vco, dict):
                    vco = {}
                gen = vco.get('general', []) or []
                for blk in gen:
                    if not isinstance(blk, dict):
                        continue
                    for prop, val in (blk.get('properties', {}) or {}).items():
                        if prop == 'altText':
                            alt = _literal(val) or 'measure'
            except Exception as e:
                errors.append({'file': rel, 'err': str(e)})
                continue
            vname = d.get('name')
            page['visuals'].append({
                'id': vname if isinstance(vname, str) else vid,  # §16: name מספרי → שם התיקייה
                'vid': vid,
                'type': v.get('visualType', 'group' if 'visualGroup' in d else '?'),
                'fields': _visual_fields(d),
                'tabOrder': _num(pos.get('tabOrder')),
                'w': _num(pos.get('width')), 'h': _num(pos.get('height')),
                'x': _num(pos.get('x')), 'y': _num(pos.get('y')),
                'altText': alt,
                'syncGroup': v.get('syncGroup'),
                'raw': d, 'raw_txt': raw_txt,
                'hidden': bool(d.get('isHidden', False)),
                'mob': _mob_dims(os.path.join(os.path.dirname(vf), 'mobile.json')),
            })
        pages.append(page)
    n_mobile = len(glob.glob(os.path.join(report_dir, 'definition', 'pages', '*', 'visuals', '*', 'mobile.json')))
    has_bm = bool(glob.glob(os.path.join(report_dir, 'definition', 'bookmarks', '*.bookmark.json')))
    return {'has_bookmarks': has_bm, 'pages': pages, 'report_filters': report_filters, 'palette': palette,
            'theme_wild': theme_wild, 'theme_typed': theme_typed,
            'theme_fonts': theme_fonts, 'themes': themes, 'n_mobile': n_mobile,
            'theme_bg': theme_bg, 'theme_fg': theme_fg, 'theme_data_colors': theme_data_colors,
            'errors': errors, 'dir': report_dir}


# ══════════════════════════ בדיקות דוח ══════════════════════════
def check_report(rep):
    pages = rep['pages']
    data_visuals = [v for p in pages for v in p['visuals']
                    if v['type'] not in DECOR and not v['hidden']]

    # RPT-22 · קובץ JSON שלא ניתן לקריאה או בצורה לא צפויה (§16)
    for e in rep.get('errors', []):
        add('RPT-22', 'crit', 'דוח', e['file'],
            'קובץ JSON שבור או בצורה לא צפויה',
            'הקובץ לא נקרא (%s). החלק הזה נעלם מהביקורת, ובדרך כלל גם שובר את פתיחת '
            'הדוח ב-Desktop. הבדיקה ממשיכה ומדווחת במקום להיפול — קלט פגום אחד לא רשאי '
            'להפיל סריקה שלמה.' % e['err'],
            'לפתוח את הקובץ, לתקן את ה-JSON (או למחוק את הוויזואל/הדף ולשמור מחדש '
            'ב-Desktop), ולהריץ שוב. מקור: דפוס graceful-degradation — NVIDIA/SkillSpector '
            'issue #250 (קלט פגום אחד הפיל סריקה שלמה).')

    # RPT-01 · צבעים חקוקים שאינם בפלטת ה-theme
    hard = collections.Counter()
    for p in pages:
        for v in p['visuals']:
            def cb(o):
                c = o.get('solid')
                if isinstance(c, dict) and isinstance(c.get('color'), dict):
                    h = _hex_norm(_literal(c['color']) or '')
                    if h and h not in rep['palette']:
                        hard[h] += 1
            _walk(v['raw'], cb)
    if hard:
        note = ('אין קובץ theme מותאם — כל צבע בדוח חקוק ידנית.'
                if not rep['themes'] else
                'צבעים שלא מופיעים בפלטת ה-theme (%s).' % ', '.join(rep['themes']))
        add('RPT-01', 'warn', 'דוח', '%d צבעים שונים' % len(hard),
            'צבעים חקוקים שאינם בפלטת ה-theme',
            '%s דוגמאות: %s. צבע חקוק לא מתעדכן עם החלפת theme ושובר עקביות בין דפים.'
            % (note, ', '.join('%s×%d' % kv for kv in hard.most_common(6))),
            'להעביר צבעים ל-theme (dataColors) או להשתמש בצבעי סכמה (ThemeDataColor). '
            'מקור: PBIR theme inheritance — data-goblin; Microsoft theme docs.')

    # RPT-02 · גופנים מעורבים
    fonts = collections.Counter()
    def _font_cb(o):
        f = o.get('fontFace')
        if isinstance(f, dict):
            val = _literal(f)
            if val:
                fonts.update([val])
    for p in pages:
        for v in p['visuals']:
            _walk(v['raw'], _font_cb)
    if len(fonts) > 2:
        add('RPT-02', 'tip', 'דוח', '%d גופנים' % len(fonts),
            'גופנים מעורבים בין ויזואלים',
            'נמצאו %d גופנים שונים חקוקים בוויזואלים: %s.' % (len(fonts), ', '.join(fonts)),
            'לאחד גופן דרך textClasses ב-theme במקום עקיפות מקומיות. מקור: PBIR theme inheritance.')

    # RPT-03 · גדלי קנבס לא אחידים
    sizes = {(p['w'], p['h']) for p in pages if p['w'] and p['h']}
    if len(sizes) > 1:
        add('RPT-03', 'tip', 'דוח', '%d גדלים' % len(sizes),
            'גדלי קנבס שונים בין דפים',
            'הדפים לא חולקים גודל קנבס אחיד (%s) — מעבר בין דפים "קופץ" והפריסה לא עקבית.'
            % ', '.join('%dx%d' % s for s in sorted(sizes)),
            'לאחד ל-16:9 (למשל 1280×720) בכל הדפים, אלא אם דף tooltip מכוון.')

    # RPT-04 · אין תצוגת מובייל
    if pages and rep['n_mobile'] == 0:
        add('RPT-04', 'tip', 'דוח', 'כל הדוח',
            'לא הוגדרה תצוגת מובייל (phone layout)',
            'לא נמצאו קובצי mobile.json לאף ויזואל — בטלפון המשתמש יקבל את פריסת הדסקטופ כמו שהיא.',
            'להגדיר Mobile layout ב-Desktop (View → Mobile layout) לפחות לדף הראשי. '
            'מקור: Microsoft — mobile-optimized reports.')

    # RPT-05 · alt text חסר
    no_alt = [v for v in data_visuals if not v['altText']]
    if no_alt:
        add('RPT-05', 'tip', 'דוח', '%d/%d ויזואלים' % (len(no_alt), len(data_visuals)),
            'ויזואלי נתונים ללא alt text (נגישות)',
            'קוראי מסך לא יכולים לתאר את הוויזואלים האלה. ה-alt text יושב ב-'
            'visualContainerObjects.general.properties.altText — ניתן גם למדד DAX דינמי.',
            'להוסיף alt text תיאורי (סוג הגרף + המדד + השאלה שהוא עונה עליה, עד ~150 תווים). '
            'מקור: Microsoft accessibility; PBIR הופך את זה לניתן-ביקורת.')

    # RPT-06 · סדר טאב לא הוגדר
    for p in pages:
        vs = [v for v in p['visuals'] if v['type'] not in DECOR and not v['hidden']]
        orders = {v['tabOrder'] for v in vs if v['tabOrder'] is not None}
        if len(vs) >= 3 and len(orders) <= 1:
            add('RPT-06', 'tip', 'דוח', "דף '%s'" % (p['name'] or p['id'][:8]),
                'סדר טאב (tab order) לא הוגדר',
                'כל הוויזואלים עם tabOrder זהה — ניווט מקלדת ילך לפי סדר היצירה, לא לפי סדר הקריאה.',
                'להגדיר tabOrder לפי סדר קריאה (ב-RTL: ימין→שמאל, מעלה→מטה). שים לב: ערך גבוה יותר = '
                'מוקדם יותר ברצף, והוא צריך להיות פרופורציוני ל-z. מקור: Microsoft accessibility / PBIR.')

    # RPT-25 · ויזואל מוסתר בדף גלוי — תוכן שהמשתמש לא רואה
    # (נמצא על 5 הדשבורדים השבורים: ויזואל isHidden:true בדף סקירה כללית.
    #  דוח עם bookmarks — ויזואלים מוסתרים הם ככל הנראה מטרות bookmark
    #  (לוחות open/close); FP שנמצא בקורפוס: capital, 42 ויזואלים מוסתרים)
    for p in ([] if rep.get('has_bookmarks') else pages):
        if p.get('visibility', '') == 'Hidden':
            continue
        hid = [v for v in p['visuals'] if v['hidden'] and v['type'] not in DECOR]
        if hid:
            add('RPT-25', 'tip', 'דוח', "דף '%s'" % (p['name'] or p['id'][:8]),
                '%d ויזואלי נתונים מוסתרים בדף גלוי' % len(hid),
                'וויזואל מוסתר לא מוצג אבל עדיין נטען, מריץ שאילתה ומתעדכן — עלות '
                'ביצועים בלי ערך למשתמש. לגיטימי רק כיעד drill-through/הסבר זמני '
                'מתועד. (מועמד — לוודא שההסתרה לא מכוונת.)',
                'אם מיותר — למחוק; אם משמש drill-through/tooltip — לתעד בהערה. '
                'מקור: PBI-Inspector hidden-content checks (MIT).')

    # RPT-26 · אי-אחידות ויזואלית בין דפים: פלטות חקוקות זרות + רקעים מעורבים
    # (נמצא על 5 השבורים: דף 1 פלטה אחת, דף 2 פלטה זרה לגמרי + רקע בהיר מול כהה)
    page_cols = {}
    bg_lum = {}
    for p in pages:
        cols = set()
        for v in p['visuals']:
            for c in re.findall(r"#[0-9A-Fa-f]{6}", v['raw_txt']):
                n = _hex_norm(c)
                if n:
                    cols.add(n)
        if len(cols) >= 3:
            page_cols[p['name'] or p['id'][:8]] = cols
        bg, assumed = _page_bg(p, rep)
        if not assumed:
            bg_lum[p['name'] or p['id'][:8]] = (bg, _luminance(bg))
    names = sorted(page_cols)
    disjoint = []
    for i in range(len(names)):
        for j in range(i + 1, len(names)):
            if not (page_cols[names[i]] & page_cols[names[j]]):
                disjoint.append("'%s' מול '%s'" % (names[i], names[j]))
    dark = [n for n, (b, l) in bg_lum.items() if l < 0.35]
    light = [n for n, (b, l) in bg_lum.items() if l > 0.65]
    if disjoint or (dark and light):
        parts = []
        if disjoint:
            parts.append('פלטות חקוקות זרות: ' + '; '.join(disjoint[:3]))
        if dark and light:
            parts.append('רקעים מעורבים: בהיר ב-%s, כהה ב-%s'
                         % (', '.join("'%s'" % n for n in light[:3]),
                            ', '.join("'%s'" % n for n in dark[:3])))
        add('RPT-26', 'warn', 'דוח', 'כל הדוח',
            'אי-אחידות ויזואלית בין דפים — ' + '; '.join(parts),
            'כל דף נראה כמו דוח אחר: פלטת צבעים שונה לחלוטין או רקע בהיר מול כהה '
            'בלי מעבר מודע. הקורא מאבד את התחושה שהוא באותו דוח, ומעבר בין רקע '
            'בהיר לכהה מכריח התאמת עין בכל ניווט. (נמצא על הדשבורדים השבורים.)',
            'לאחד ל-theme אחד (RPT-01) ולרקע דף עקבי. אם דף כהה מכוון (דגש) — '
            'להתאים גם את צבעי הטקסט והוויזואלים באותו דף.')

    # RPT-07 · סליסרים לא מסונכרנים בין דפים
    slicer_pages = collections.defaultdict(list)
    for p in pages:
        for v in p['visuals']:
            if v['type'] == 'slicer' and v['fields']:
                slicer_pages[v['fields'][0]].append((p['name'] or p['id'][:8], v))
    for (ent, prop), lst in slicer_pages.items():
        pnames = {x[0] for x in lst}
        if len(pnames) > 1 and any(not x[1]['syncGroup'] for x in lst):
            add('RPT-07', 'warn', 'דוח', "סליסר '%s[%s]'" % (ent, prop),
                'אותו סליסר ב-%d דפים ללא סנכרון (syncGroup)' % len(pnames),
                'הסליסר על %s[%s] מופיע בדפים %s אבל חלק מהמופעים ללא syncGroup — המשתמש יסנן בדף '
                'אחד ויתפלא שהדף הבא לא מסונן.' % (ent, prop, ', '.join(sorted(pnames))),
                'View → Sync slicers, או syncGroup זהה ב-visual.json. מקור: PBIR visual.json — syncGroup.')

    # RPT-08 · מסננים ברמת דוח (גלובליים, סמויים מהקורא)
    if rep['report_filters']:
        add('RPT-08', 'warn', 'דוח', 'report.json',
            '%d מסננים ברמת כל הדוח (Report-level filters)' % len(rep['report_filters']),
            'מסנן ברמת דוח חל על כל דף ואינו גלוי על הקנבס — עלול להקטין בשקט את המכנה של כל '
            'מספר בדוח (§11 — משמעת מכנה).',
            'לוודא שהמסנן הגלובלי מכוון ומתועד (בתיק הדוח), או להוריד לרמת דף. מקור: PBIR filterConfig.')

    # RPT-09 · מסנני שלילה (Not) — החרגות שקטות
    def _find_not(filters, where):
        for f in filters:
            field = ''
            fld = f.get('field') or {}
            for kind in ('Measure', 'Column'):
                if isinstance(fld.get(kind), dict) and fld[kind].get('Property'):
                    ent = ''
                    try:
                        ent = fld[kind]['Expression']['SourceRef'].get('Entity', '')
                    except Exception:
                        pass
                    field = '%s[%s]' % (ent, fld[kind]['Property']) if ent else str(fld[kind]['Property'])
            found = []
            _walk(f.get('filter'), lambda o: found.append(1) if 'Not' in o else None)
            inv = 'isInvertedSelectionMode' in json.dumps(f, ensure_ascii=False)
            if found or inv:
                add('RPT-09', 'warn', 'דוח', where,
                    'מסנן שלילה (Not/היפוך) — החרגה שקטה של ערכים%s' % (': ' + field if field else ''),
                    'מסנן שמחריג ערכים (כולל אפשרות Blank) משנה מכנים בשקט. הקורא לא רואה מה הושמט. '
                    '(§11 — משמעת מכנה.)',
                    'לוודא שההחרגה מכוונת, מתועדת, ולא מסתירה "לא נמסר"/ריק. לשקול להחליף בלוגיקת '
                    'מדד מפורשת. מקור: PBIR filter-pane — inverted selection.')
    _find_not(rep['report_filters'], 'רמת דוח')
    for p in pages:
        _find_not(p['filters'], "דף '%s'" % (p['name'] or p['id'][:8]))
        for v in p['visuals']:
            vf = ((v['raw'].get('filterConfig') or {}).get('filters')) or []
            _find_not(vf, "ויזואל %s בדף '%s'" % (v['type'], p['name'] or p['id'][:8]))

    # RPT-10 · drill-through
    has_dt = any('Drillthrough' in json.dumps(p['raw'], ensure_ascii=False) for p in pages)
    if pages and not has_dt:
        add('RPT-10', 'tip', 'דוח', 'כל הדוח',
            'אין דף drill-through בדוח',
            'לא נמצא מסנן drill-through באף דף — אין דרך לצלול מפרט לפרטים (קליק ימני → drill-through).',
            'אם יש ממד עם פירוט (מוצר/מבנה/לקוח) — להוסיף דף drill-through עם כפתור חזרה (§14). '
            'מקור: PBIR page.md — drillthrough filter ב-page filterConfig.')

    # RPT-11 · דפי tooltip
    tt_pages = [p for p in pages if p['type'] == 'Tooltip']
    if tt_pages:
        opted = any('visualTooltip' in v['raw_txt'] for p in pages for v in p['visuals'])
        if not opted:
            add('RPT-11', 'warn', 'דוח', ', '.join(p['name'] or p['id'][:8] for p in tt_pages),
                'דפי tooltip קיימים אך אף ויזואל לא משתמש בהם',
                'דף מסוג Tooltip ללא visualTooltip באף ויזואל = קוד מת (או שהחיווי נשבר).',
                'לקשר ויזואלים לדף ה-tooltip (visualContainerObjects.visualTooltip, section = שם הדף). '
                'מקור: PBIR page.md — tooltip pages.')
    else:
        add('RPT-11', 'tip', 'דוח', 'כל הדוח',
            'אין tooltip pages מותאמים',
            'ה-tooltip של Power BI כברירת מחדל בסיסי; דף tooltip מותאם נותן הקשר בכל ריחוף.',
            'לשקול דף tooltip קטן (hidden, ActualSize) עם כרטיסי הקשר. מקור: PBIR page.md.')

    # RPT-12 · כפתורים מתים
    for p in pages:
        for v in p['visuals']:
            if v['type'] == 'actionButton':
                low = v['raw_txt'].lower()
                if not any(k in low for k in ('pagenavigation', 'bookmark', '"back"', 'drillthrough')):
                    add('RPT-12', 'warn', 'דוח', "כפתור בדף '%s'" % (p['name'] or p['id'][:8]),
                        'כפתור ללא פעולה משויכת (כפתור מת)',
                        'לא נמצאה פעולת ניווט/סימנייה ב-visual.json של הכפתור (זיהוי היוריסטי — לוודא בקובץ).',
                        'להגדיר Action: Page navigation / Bookmark / Back. מקור: navigation.md.')

    # RPT-27 · visualType לא מזוהה במראה של שם מובנה — חשד לשם שהומצא (hallucination).
    # ויזואל מותאם אמיתי מ-AppSource נושא סיומת גיבוב ארוכה (למשל ...7E15AEF80B9E4D4F8E12924291ECE89A);
    # שם camelCase שנגמר ב-Chart/Map/Slicer וכו' אך אינו בקטלוג המובנה — כמעט תמיד שם שהומצא,
    # והדסקטופ מציג אותו כאריח שבור. המקרה הקלאסי: stackedColumnChart במקום columnChart.
    # מקור: powerbi-report-mcp docs/visual-types.md (MIT) + כלל R-21 בבילדר.
    HALLUC_LIKE = re.compile(r'(?:Chart|Map|Slicer|Card|Gauge|Table|Matrix|Tree|Treemap|Kpi|Visual|Funnel|Navigator)$')
    CUSTOM_SIG = re.compile(r'[0-9A-Fa-f]{16,}$')
    susp = collections.Counter(v['type'] for p in pages for v in p['visuals']
                               if v['type'] not in BUILTIN_VISUALS and v['type'] != '?'
                               and HALLUC_LIKE.search(v['type'])
                               and not CUSTOM_SIG.search(v['type']))
    if susp:
        add('RPT-27', 'warn', 'דוח', ', '.join('%s×%d' % kv for kv in sorted(susp.items())),
            'שם visualType לא מזוהה — חשד לשם שהומצא (hallucination)',
            'שמות הוויזואלים אינם בקטלוג המובנה ואינם נושאים סיומת גיבוב של ויזואל מותאם מ-AppSource, '
            'ולכן כנראה הומצאו (למשל על ידי LLM). שם לא חוקי מוצג בדסקטופ כאריח שבור. '
            "המקרה הקלאסי: 'stackedColumnChart'/'stackedBarChart' — השמות החוקיים הם "
            "'columnChart'/'barChart'. מקור: powerbi-report-mcp docs/visual-types.md (MIT).",
            'להחליף לשם המובנה המדויק מהקטלוג, אם הכוונה הייתה לוויזואל מובנה; אם זה ויזואל '
            'מותאם — לייבא אותו כראוי מ-AppSource.')

    # RPT-13 · ויזואלים מותאמים (custom) — חשודי RPT-27 אינם נספרים כאן
    customs = collections.Counter(v['type'] for p in pages for v in p['visuals']
                                  if v['type'] not in BUILTIN_VISUALS and v['type'] != '?'
                                  and v['type'] not in susp)
    customs = {k: c for k, c in customs.items() if 'html' not in k.lower()}
    if customs:
        add('RPT-13', 'tip', 'דוח', ', '.join('%s×%d' % kv for kv in customs.items()),
            'ויזואלים מותאמים (custom visuals) בשימוש',
            'ויזואלים שאינם מובנים תלויים בתחזוקת צד-שלישי (עדכונים, אישור ארגוני, ביצועים). '
            '(HTML Content אינו נספר — הוא המלצה מכוונת ל-RTL.)',
            'לוודא שהם מאושרים ארגונית ושיש להם חלופה; לתעד ב"תיק הדוח".')

    # RPT-14 · ויזואלים קשורים לטבלאות תאריך אוטומטיות
    auto_pages = set()
    for p in pages:
        for v in p['visuals']:
            if 'LocalDateTable_' in v['raw_txt'] or 'DateTableTemplate_' in v['raw_txt']:
                auto_pages.add(p['name'] or p['id'][:8])
    if auto_pages:
        add('RPT-14', 'warn', 'דוח', ', '.join(sorted(auto_pages)[:5]),
            'ויזואלים מקושרים לטבלאות התאריך האוטומטיות',
            'חלק מהוויזואלים משתמשים ב-LocalDateTable_* (Auto date/time) במקום בטבלת תאריכים '
            'ייעודית — time-intelligence עליהן אינו אמין.',
            'להחליף את שדה התאריך לעמודה מטבלת תאריכים מסומנת (ראה MDL-01).')



    # RPT-15 · מדדים מרומזים — צבירה ישירה של עמודה בוויזואל
    AGG_FN = {0: 'Sum', 1: 'Average', 2: 'DistinctCount', 3: 'Min', 4: 'Max',
              5: 'Count', 6: 'Median', 7: 'StdDev', 8: 'Variance'}
    for p in pages:
        for v in p['visuals']:
            if v['type'] in DECOR or v['hidden']:
                continue
            aggs = []

            def agg_cb(o, _out=aggs):
                d = o.get('Aggregation')
                if isinstance(d, dict):
                    fn = AGG_FN.get(d.get('Function'), '?')
                    ref = ''
                    try:
                        c = d['Expression']['Column']
                        ent = c['Expression']['SourceRef'].get('Entity', '')
                        ref = '%s[%s]' % (ent, c.get('Property', ''))
                    except Exception:
                        pass
                    _out.append('%s(%s)' % (fn, ref or '?'))

            _walk(_dct(_dct(v['raw']).get('visual')).get('query') or {}, agg_cb)
            if aggs:
                add('RPT-15', 'warn', 'דוח',
                    "דף '%s' · ויזואל '%s'" % (p['name'] or p['id'][:8], v['id'][:12]),
                    'מדד מרומז — צבירה ישירה של עמודה בוויזואל (%s)' % ', '.join(aggs[:3]),
                    'הוויזואל צובר עמודה גולמית (Sum/Count…) במקום לפנות למדד מפורש. אין מקור '
                    'אמת אחד: אי אפשר לעשות שימוש חוזר בחישוב, לתעד אותו או לאמתו (§19).',
                    'לבנות מדד מפורש ב-TMDL ולהחליף את הקישור בוויזואל. מקור: PBIR visual.json — '
                    'Aggregation projections (QueryAggregateFunction).')

    # RPT-16 · ויזואל מחוץ לגבולות הקנבס
    for p in pages:
        if not p['w'] or not p['h']:
            continue
        for v in p['visuals']:
            if None in (v['x'], v['y'], v['w'], v['h']) or v['hidden']:
                continue
            if v['x'] < 0 or v['y'] < 0 or v['x'] + v['w'] > p['w'] or v['y'] + v['h'] > p['h']:
                add('RPT-16', 'warn', 'דוח',
                    "דף '%s' · ויזואל '%s'" % (p['name'] or p['id'][:8], v['id'][:12]),
                    'ויזואל חורג מגבולות הקנבס (%gx%g)' % (p['w'], p['h']),
                    'המיקום/הגודל (%g,%g %gx%g) יוצא מהדף — בדרך כלל גרירה שגויה או שריד '
                    'מדף אחר; הוויזואל עלול להיחתך או להיעלם.' % (v['x'], v['y'], v['w'], v['h']),
                    'להזיז/להקטין לתוך גבולות הקנבס. מקור: PBIP Doctor PBIR002; PBIR position.')

    # RPT-17 · חפיפה גסה בין ויזואלי נתונים
    for p in pages:
        vs = [v for v in p['visuals']
              if v['type'] not in DECOR and not v['hidden']
              and v['type'] != 'group'  # מכולת visualGroup שקופה ומכילה את חבריה — חפיפה מובנית, לא ממצא
              and None not in (v['x'], v['y'], v['w'], v['h'])]
        pairs = []
        for i in range(len(vs)):
            for j in range(i + 1, len(vs)):
                a, b = vs[i], vs[j]
                ox = max(0.0, min(a['x'] + a['w'], b['x'] + b['w']) - max(a['x'], b['x']))
                oy = max(0.0, min(a['y'] + a['h'], b['y'] + b['h']) - max(a['y'], b['y']))
                if not ox or not oy:
                    continue
                smaller = min(a['w'] * a['h'], b['w'] * b['h'])
                if smaller > 0 and (ox * oy) / smaller >= 0.5:
                    pairs.append((a, b, (ox * oy) / smaller))
        if pairs:
            add('RPT-17', 'tip', 'דוח', "דף '%s'" % (p['name'] or p['id'][:8]),
                '%d זוגות ויזואלי נתונים עם חפיפה >= 50%%' % len(pairs),
                'חפיפה גסה בין ויזואלי נתונים (%s) — אחד מסתיר את השני או שהשכבות לא '
                'מכוונות. (ויזואלי דקור — shape/image/textbox — לא נספרים: רקע הוא לגיטימי.)'
                % ', '.join("'%s'↔'%s' %.0f%%" % (a['id'][:8], b['id'][:8], r * 100)
                            for a, b, r in pairs[:3]),
                'אם השכבוב מכוון — לתעד; אחרת לסדר מיקום/גודל. מקור: PBIP Doctor PBIR003.')

    # RPT-18 · כפתור ניווט שמצביע לדף שלא קיים
    valid_pages = set()
    for p in pages:
        valid_pages.add(p['id'])
        if p['name']:
            valid_pages.add(p['name'])
    NAV_KEYS = ('targetpage', 'targetpagename', 'navigationtarget', 'activepagename')
    for p in pages:
        for v in p['visuals']:
            hits = []

            def nav_cb(o, _h=hits):
                for k, val in o.items():
                    nk = k.replace('_', '').replace('-', '').lower()
                    if nk in NAV_KEYS and isinstance(val, str) and val:
                        _h.append(val)
            _walk(v['raw'], nav_cb)
            for t in hits:
                if t not in valid_pages:
                    add('RPT-18', 'warn', 'דוח',
                        "דף '%s' · ויזואל '%s'" % (p['name'] or p['id'][:8], v['id'][:12]),
                        "ניווט מצביע לדף '%s' שלא קיים" % t,
                        'פעולת Page navigation (או Page navigator) עם יעד שאינו תואם אף דף '
                        'בדוח — כפתור מת שלא יתגלה עד שמישהו לוחץ. (זיהוי לפי מפתחות יעד '
                        'מוכרים — לוודא מול הקובץ.)',
                        'לעדכן את היעד לדף קיים או למחוק את הפעולה. מקור: PBIP Doctor PBIR005.')

    # RPT-19 · שם דף כפול (name או displayName)
    for field, label in (('id', 'שם פנימי'), ('name', 'displayName')):
        seen = collections.defaultdict(list)
        for p in pages:
            val = p[field]
            if val:
                seen[val.casefold()].append(val)
        for val, lst in seen.items():
            if len(lst) > 1:
                add('RPT-19', 'warn', 'דוח', "%s '%s'" % (label, lst[0]),
                    '%d דפים עם אותו %s' % (len(lst), label),
                    'שמות דפים כפולים הופכים ניווט, סימניות ו-deep links לדו-משמעיים.',
                    'לתת לכל דף שם ייחודי. מקור: PBIP Doctor PBIR004.')

    # RPT-20 · סימנייה שמצביעה לדף שלא קיים
    for bf in sorted(glob.glob(os.path.join(rep['dir'], 'definition', 'bookmarks', '*.json'))):
        try:
            bj = _load_json(bf)
        except Exception:
            continue
        refs = []

        def bm_cb(o, _r=refs):
            for k, val in o.items():
                nk = k.replace('_', '').replace('-', '').lower()
                if nk in ('targetpage', 'pagename') and isinstance(val, str) and val:
                    _r.append(val)
        _walk(bj, bm_cb)
        for t in refs:
            if t not in valid_pages:
                add('RPT-20', 'tip', 'דוח', os.path.basename(bf),
                    "סימנייה מצביעה לדף '%s' שלא קיים" % t,
                    'סימנייה (bookmark) מתייחסת לדף שנמחק/שונה — שבורה בשקט.',
                    'למחוק או ליצור מחדש את הסימנייה. מקור: PBIP Doctor PBIR006.')


    # RPT-23 · דף tooltip/drillthrough שאינו מוסתר
    for p in pages:
        is_tt = p.get('type') == 'Tooltip'
        has_dt = any(isinstance(f, dict) and f.get('type') == 'Drillthrough'
                     for f in p.get('filters') or [])
        if (is_tt or has_dt) and p.get('visibility', '') != 'Hidden':
            kind = 'tooltip' if is_tt else 'drillthrough'
            add('RPT-23', 'warn', 'דוח', "דף '%s'" % (p['name'] or p['id'][:8]),
                'דף %s גלוי בסרגל הדפים' % kind,
                'דפי tooltip/drillthrough נועדו לקפוץ מהקשר, לא לניווט ישיר — כשהם גלויים הם '
                'מבלבלים קוראים ומנפחים את סרגל הדפים.',
                'להסתיר את הדף (visibility: Hidden) — ההפעלה מ-tooltip/drill-through ממשיכה '
                'לעבוד גם כשהדף מוסתר. מקור: PBI-Inspector HIDE_TOOLTIP_DRILLTROUGH_PAGES (MIT).')

    # RPT-24 · מסנני TopN/Advanced ברמת ויזואל
    for p in pages:
        counts = collections.Counter()
        for v in p['visuals']:
            fc = _dct(v.get('raw')).get('filterConfig') or {}
            for f in _dct(fc).get('filters') or []:
                t = _dct(f).get('type', '')
                if t in ('TopN', 'Advanced'):
                    counts[t] += 1
        if counts:
            add('RPT-24', 'tip', 'דוח', "דף '%s'" % (p['name'] or p['id'][:8]),
                'מסנני %s ברמת ויזואל' % '/'.join(sorted(counts)),
                'נמצאו %s. מסנן ויזואלי מורכב מוסתר מהקורא ונשכח בתחזוקה; TopN אינטראקטיבי '
                'גם מונע שימוש חוזר במדדים.' % ', '.join('%s×%d' % kv for kv in counts.most_common()),
                'להעדיף מדד מפורש (TOPN ב-DAX) או מסנן דף מתועד. מקור: PBI-Inspector '
                'REDUCE_TOPN_FILTERS / REDUCE_ADVANCED_FILTERS (MIT).')


# ══════════════════════════ נגישות (A11Y) ══════════════════════════
# משפחת כללים דטרמיניסטית לנגישות דוח, בהשראת מנוע הכללים של PBIX A11y (pbiaudits.com)
# ושל Juls-BI/pbir-a11y (רישיון PolyForm Shield — רעיונות הבדיקה בלבד, מימוש מחדש מלא כאן),
# NatVanG/PBI-Inspector, ותקני W3C WCAG 2.1/2.2. המיפוי המלא: references/bpa-checks.md.

def _query_roles(v):
    """{role: [(kind, entity, property)]} מ-queryState של ויזואל גולמי (sortDefinition בחוץ).
    שמות ה-roles אומתו מול corpus של תבניות PBIR מייצואי Desktop אמיתיים."""
    roles = {}
    q = _dct(_dct(_dct(v).get('visual')).get('query')).get('queryState')
    if not isinstance(q, dict):
        return roles
    for role, blk in q.items():
        projs = _dct(blk).get('projections')
        if not isinstance(projs, list):
            continue
        for pr in projs:
            f = _dct(pr).get('field')
            if not isinstance(f, dict):
                continue
            for kind in ('Measure', 'Column'):
                node = f.get(kind)
                if isinstance(node, dict) and node.get('Property'):
                    ent = ''
                    try:
                        ent = node['Expression']['SourceRef'].get('Entity', '')
                    except Exception:
                        pass
                    roles.setdefault(role, []).append((kind, ent, str(node['Property'])))
            # HierarchyLevel — הרמה היא עמודה בטבלה (MS expressions.md); נרשם כ-Column
            # כדי שכללים מבוססי-מודל (dataType/sortByColumn) יחולו גם על היררכיות
            hl = f.get('HierarchyLevel')
            if isinstance(hl, dict) and hl.get('Level'):
                ent = ''
                try:
                    ent = hl['Expression']['Hierarchy']['Expression']['SourceRef'].get('Entity', '')
                except Exception:
                    pass
                roles.setdefault(role, []).append(('Column', ent, str(hl['Level'])))
            # Aggregation — עטיפת צבירה סביב Column; פורשים לעמודה (MS expressions.md)
            ag = f.get('Aggregation')
            if isinstance(ag, dict):
                inner = ag.get('Expression') or {}
                node = inner.get('Column')
                if isinstance(node, dict) and node.get('Property'):
                    ent = ''
                    try:
                        ent = node['Expression']['SourceRef'].get('Entity', '')
                    except Exception:
                        pass
                    roles.setdefault(role, []).append(('Column', ent, str(node['Property'])))
    return roles



def _extra_field_refs(v):
    """(kind, entity, property) ממקורות הפניה מחוץ ל-queryState: sortDefinition,
    ביטויי objects (expr עם Measure/Column, כולל FillRule.Input), ו-filterConfig
    (שדה המסנן + תנאי Where). הרחבת ADV-17 (סבב 85) — מקור: bernatagulloesbrina/
    TabularEditor-Scripts Advanced/Report Layer Macros/Fix Broken Fields.cs,
    GetAllFields(): projections + SortDefinition + objects + filterConfig (MIT).
    מכסה גם את מלכודת צביעת הסידרות מסבב 84: metadata/CF על שדה מת נזרק בשקט."""
    refs = []
    vis = _dct(_dct(v).get('visual'))

    def _fld(node):
        if not isinstance(node, dict):
            return
        for kind in ('Measure', 'Column'):
            f = node.get(kind)
            if isinstance(f, dict) and f.get('Property'):
                ent = ''
                try:
                    ent = _dct(_dct(f.get('Expression')).get('SourceRef')).get('Entity', '')
                except Exception:
                    pass
                refs.append((kind, ent, str(f['Property'])))

    # sortDefinition.sort[].field
    for srt in _dct(_dct(vis.get('query')).get('sortDefinition')).get('sort') or []:
        _fld(_dct(srt).get('field'))

    # objects + filterConfig — הליכה גנרית: כל צומת dict עם Measure/Column בעל Property
    # (מכסה expr.Measure/Column, FillRule.Input, filter.field, תנאי In/Not/Comparison)
    def _walk(o):
        if isinstance(o, dict):
            _fld(o)
            for vv in o.values():
                _walk(vv)
        elif isinstance(o, list):
            for vv in o:
                _walk(vv)
    _walk(vis.get('objects'))
    _walk(vis.get('filterConfig'))
    return refs


_CYCLIC_AXIS_RE = re.compile(
    r"(?i)(month\s?name|month\s*number|\bmonth\b|חודש|quarter|רבעון|week\s?(day|num|number)?|"
    r"day\s?of\s?week|weekday|יום.{0,3}שבוע)")
_YEAR_AXIS_RE = re.compile(r"(?i)^(year|שנה|calendar\s?year|fiscal\s?year)$")


def _date_span_years(sm_dir):
    """טווח השנים של טבלת תאריכים מחושבת — קריא מ-CALENDAR(DATE(y,..),DATE(y2,..))
    בלבד. CALENDARAUTO/טבלה מיובאת = לא קריא מהקבצים (None) — ראה RPT-28."""
    years = []
    base = os.path.join(sm_dir, 'definition')
    files = glob.glob(os.path.join(base, 'tables', '*.tmdl')) + [os.path.join(base, 'model.tmdl')]
    for f in files:
        if not os.path.isfile(f):
            continue
        try:
            txt = open(f, encoding='utf-8-sig').read()
        except Exception:
            continue
        for m in re.finditer(
                r"CALENDAR\s*\(\s*DATE\s*\(\s*(\d{4})[^)]*\)\s*,\s*DATE\s*\(\s*(\d{4})",
                txt):
            years.append((int(m.group(1)), int(m.group(2))))
    return years


def check_time_axis(rep, model, sm_dir):
    """RPT-28 (דוח שדה סבב 2 #8): ציר קטגוריה מחזורי (שם חודש/רבעון עם
    sortByColumn לעמודה מחזורית) על נתונים רב-שנתיים בלי מסנן/סליסר שנה —
    החודשים של כל השנים נערמים על אותו ציר, והשנה האחרונה (חלקית) נראית
    כצניחה מדומה (יולי←אוגוסט). שלושת הרכיבים קריאים מהקבצים:
    sortByColumn ב-TMDL, טווח השנים מ-CALENDAR ליטרלי, וסריקת פילטרים/סליסרים.
    טווח לא קריא (CALENDARAUTO/ייבוא) = לא יורים (אין ראיית רב-שנתיות)."""
    tables = (model or {}).get('tables') or []
    cyclic = []  # (table, column) — עמודת קטגוריה מחזורית ממוינת
    for t in tables:
        for c in t.get('columns', []):
            if c.get('sortByColumn') and _CYCLIC_AXIS_RE.search(c.get('name', '')):
                cyclic.append((c.get('table', ''), c['name']))
    if not cyclic:
        return
    spans = _date_span_years(sm_dir) if sm_dir else []
    multi_year = any(y2 > y1 for y1, y2 in spans)
    if not multi_year:
        return
    # מסנן/סליסר שנה מספק הקשר — מכסה את הפיתוי. סריקה טקסטואלית של הפילטרים.
    def _is_year_filter(flt):
        try:
            blob = json.dumps(flt, ensure_ascii=False)
        except Exception:
            blob = str(flt)
        return bool(re.search(r'"(Year|שנה)"|Year', blob))
    for flt in rep.get('report_filters') or []:
        if _is_year_filter(flt):
            return
    for p in rep['pages']:
        if p.get('type') == 'tooltip':
            continue
        for flt in p.get('filters') or []:
            if _is_year_filter(flt):
                return
        for v in p['visuals']:
            if v['type'] == 'slicer' and any(_YEAR_AXIS_RE.match(prop)
                                             for _e, prop in v.get('fields') or []):
                return
    for tbl, col in cyclic:
        pages_using = []
        for p in rep['pages']:
            if any(e == tbl and prop == col for v in p['visuals']
                   if not v['hidden'] for e, prop in (v.get('fields') or [])):
                pages_using.append(p['name'] or p['id'][:8])
        if not pages_using:
            continue
        yrs = '%d–%d' % (min(y1 for y1, _y2 in spans), max(y2 for _y1, y2 in spans)) \
            if spans else ''
        add('RPT-28', 'warn', 'דיווח', "%s[%s]" % (tbl, col),
            'ציר מחזורי על נתונים רב-שנתיים ללא מסנן שנה (%d דפים)' % len(pages_using),
            'העמודה ממוינת מחזורית (sortByColumn) וטבלת התאריכים משתרעת על יותר '
            'משנה (%s). בלי מסנן/סליסר שנה, כל השנים נערמות על אותו ציר והשנה '
            'השוטפת (חלקית) נראית כצניחה מדומה בסוף הגרף. דפים: %s. הטווח נקרא '
            'מ-CALENDAR ליטרלי; טבלה עם CALENDARAUTO/ייבוא אינה קריאה מהקבצים '
            '(ודאות בינונית — היוריסטיקה טקסטואלית).' % (yrs, ', '.join(pages_using[:4])),
            'להוסיף סליסר/מסנן שנה לדפים האלה, או להחליף את הציר לעמודת חודש-שנה '
            'רציפה (Month Year). מקור: דוח שדה סבב 2 #8.')


_NAV_TYPES = ('actionButton', 'pageNavigator', 'bookmarkNavigator')


def check_fake_nav(rep):
    """RPT-29 (דוח שדה סבב 2 #9): "ניווט מדומה" — תפריט textbox גאומטרי
    (>=3 תיבות באותו x, רוחב זהה, מרווחי y קבועים) בדוח בלי אף ויזואל ניווט
    אמיתי (actionButton/pageNavigator/bookmarkNavigator) — התפריט אינו לחיץ.
    הדפוס גאומטרי מובהק; 🔴 לפי הדיווח."""
    has_nav = any(v['type'] in _NAV_TYPES and not v['hidden']
                  for p in rep['pages'] for v in p['visuals'])
    if has_nav:
        return
    for p in rep['pages']:
        if p.get('type') == 'tooltip':
            continue
        boxes = [v for v in p['visuals']
                 if v['type'] == 'textbox' and not v['hidden']
                 and v['x'] is not None and v['y'] is not None and v['w']]
        # קבוצות לפי (x, w) בקירוב 2px
        groups = {}
        for v in boxes:
            key = (round((v['x'] or 0) / 2), round((v['w'] or 0) / 2))
            groups.setdefault(key, []).append(v['y'])
        for ys in groups.values():
            if len(ys) < 3:
                continue
            ys = sorted(ys)
            diffs = [b - a for a, b in zip(ys, ys[1:])]
            if min(diffs) <= 0:
                continue
            if max(diffs) - min(diffs) <= 3:
                add('RPT-29', 'crit', 'דיווח', "דף '%s'" % (p['name'] or p['id'][:8]),
                    'תפריט textbox שאינו לחיץ (%d פריטים)' % len(ys),
                    'תיבות טקסט מסודרות כתפריט (אותו x, רוחב זהה, מרווחי y קבועים) '
                    'אבל בדוח כולו אין אף ויזואל ניווט אמיתי — המשתמש מצפה ללחוץ '
                    'ולא קורה כלום. מקור: דוח שדה סבב 2 #9.',
                    'להחליף ב-pageNavigator אמיתי או actionButton עם פעולת '
                    'ניווט לכל פריט (תבניות: references/pbir-templates.csv).')


_BUCKET_LIT_RE = re.compile(r"(?<![\d.])(\d{1,3})\s*[-–]\s*(\d{1,3})(?![\d.])|(?<![\d.])(\d{1,3})\s*\+")


def _bucket_literals(expr):
    """מחרוזות דליים ('Overdue 1-30', '90+', '< 10') בביטוי DAX של עמודה מחושבת.
    מסנן שנים פיסקליות ('2024-2025' ממוינת נכון גם אלפביתית)."""
    out = set()
    for lit in re.findall(r'"([^"]{1,40})"', expr or ''):
        m = _BUCKET_LIT_RE.search(lit)
        if m:
            out.add(lit)
    return out


def check_bucket_sort(rep, model):
    """MDL-26 (דוח שדה סבב 2 #11): עמודת דליים (ערכים כמו 'Overdue 1-30',
    '90+') בלי sortByColumn — הציר/האגדה ממוינים א-ב ('31-60' לפני '90+' או
    'Current' באמצע) והסדר הגיולי מתבלבל. הערכים קריאים מהליטרלים ב-DAX של
    העמודה המחושבת; יורים רק כשהעמודה בשימוש בוויזואל בדוח."""
    used = set()
    for p in rep['pages']:
        for v in p['visuals']:
            if v['hidden']:
                continue
            for e, prop in (v.get('fields') or []):
                used.add((e, prop))
    for t in (model or {}).get('tables') or []:
        for c in t.get('columns', []):
            if c.get('sortByColumn') or not c.get('calculated'):
                continue
            if (c.get('table', ''), c['name']) not in used:
                continue
            lits = _bucket_literals(c.get('expr', ''))
            if len(lits) < 2:
                continue
            add('MDL-26', 'warn', 'מודל', "%s[%s]" % (c.get('table', ''), c['name']),
                'עמודת דליים ללא sortByColumn (%d ערכים)' % len(lits),
                'ערכי העמודה (%s) הם דליים מספריים; בלי sortByColumn הם ממוינים '
                'א-ב והסדר הגיולי (1-30 ← 31-60 ← 61-90 ← 90+) מתבלבל. מקור: '
                'דוח שדה סבב 2 #11.' % ', '.join(sorted(lits)[:4]),
                'להוסיף עמודת סדר מספרית (bucket index באותו DAX) ולקשר אליה '
                'ב-sortByColumn.')


def check_filter_controls(rep):
    """RPT-30 (דוח שדה סבב 2 #10): דוח רב-דפי (>=2 דפי תוכן) בלי אף פקד סינון —
    0 סליסרים ו-0 filterConfig בכל שלוש הרמות (דוח/דף/וויזואל). הצופה לא יכול
    לחתוך את הנתונים בכלל. חומרה גבוהה לפי הדיווח (בדיקה דטרמיניסטית)."""
    pages = [p for p in rep['pages'] if p.get('type') != 'tooltip']
    if len(pages) < 2:
        return
    if rep.get('report_filters'):
        return
    for p in pages:
        if p.get('filters'):
            return
        for v in p['visuals']:
            if v['hidden']:
                continue
            if v['type'] == 'slicer':
                return
            if ((_dct(v.get('raw')).get('filterConfig') or {}).get('filters')):
                return
    add('RPT-30', 'crit', 'דיווח', 'כל הדוח (%d דפים)' % len(pages),
        'אפס פקדי סינון בדוח רב-דפי',
        'אין אף סליסר ואין אף filterConfig (דוח/דף/וויזואל) — הצופה לא יכול '
        'לחתוך את הנתונים לתקופה/יחידה/מגזר, והדוח קבוע לחלוטין. מקור: דוח '
        'שדה סבב 2 #10.',
        'להוסיף לפחות סליסר תקופה (שנה/חודש) וסליסר מימד מרכזי בדף הראשי; '
        'סליסרים מסונכרנים (syncGroup) לשאר הדפים.')


def check_design(rep, model):
    """המלצות שינוי ויזואל מסיגנלים בקוד בלבד — לא ליקויים. כל המלצה נושאת רמת ביטחון
    והצדקה. הבונה מבצע החלפות רק בתבנית corpus מוכחת (clone-never-construct)."""
    dtypes, measures = {}, set()
    col_meta, tbl_cols = {}, {}
    for t in (model or {}).get('tables', []):
        tbl_cols[t['name']] = t.get('columns', [])
        for c in t.get('columns', []):
            dtypes[(t['name'], c['name'])] = c.get('dataType', '')
            col_meta[(t['name'], c['name'])] = c
        for m in t.get('measures', []):
            measures.add((t['name'], m.get('name', '') if isinstance(m, dict) else str(m)))
    # צדדי קשרים: to = צד-היחיד (מפתח ממד), from = צד-הרבים (FK) — רמז לעמודת מזהה
    rel_keys = set()
    for r in (model or {}).get('relationships', []):
        for ref in (r.get('from', ''), r.get('to', '')):
            if '.' in ref:
                rt, rc = ref.rsplit('.', 1)
                rel_keys.add((_unq(rt), _unq(rc)))
    # גרף קשרים לא-מכוון בין טבלאות — לזיהוי שילוב שדות מטבלאות מנותקות (ADV-11)
    tbl_adj = {}
    for r in (model or {}).get('relationships', []):
        pair = []
        for ref in (r.get('from', ''), r.get('to', '')):
            if '.' in ref:
                pair.append(_unq(ref.rsplit('.', 1)[0]))
        if len(pair) == 2:
            tbl_adj.setdefault(pair[0], set()).add(pair[1])
            tbl_adj.setdefault(pair[1], set()).add(pair[0])

    # גרף קשרים פעילים בלבד — לזיהוי מסלול שקיים רק דרך קשר לא-פעיל (ADV-24).
    # קשר לא-פעיל לא מפיץ סינון לוויזואלים — רק חישוב עם USERELATIONSHIP מפעיל אותו
    # (MS Learn desktop-relationships-understand, CC-BY-4.0).
    tbl_adj_active = {}
    for r in (model or {}).get('relationships', []):
        if r.get('active') is False:
            continue
        pair = []
        for ref in (r.get('from', ''), r.get('to', '')):
            if '.' in ref:
                pair.append(_unq(ref.rsplit('.', 1)[0]))
        if len(pair) == 2:
            tbl_adj_active.setdefault(pair[0], set()).add(pair[1])
            tbl_adj_active.setdefault(pair[1], set()).add(pair[0])

    # טבלאות בצד many של קשר חד-כיווני פעיל (one→many בלבד). סליסר על עמודה כזו
    # מסנן רק את טבלת ה-fact — לא מסנן מימדים (MS Learn: הפצת סינון מצד one לצד many)
    many_side = set()
    for r in (model or {}).get('relationships', []):
        if r.get('both') or r.get('active') is False:
            continue
        if r.get('from_card') == 'many' and '.' in r.get('from', ''):
            many_side.add(_unq(r['from'].rsplit('.', 1)[0]))

    # שם מדד -> ביטוי (לניתוח משפחות אגרגציה) וטבלאות fact-like (מארחות >=3 מדדים)
    mexpr = {}
    for t in (model or {}).get('tables', []):
        for m in t.get('measures', []):
            mexpr[(t['name'], m.get('name', ''))] = m.get('expr', '') if isinstance(m, dict) else ''
    fact_like = set(many_side)
    for t in (model or {}).get('tables', []):
        if len(t.get('measures', [])) >= 3:
            fact_like.add(t['name'])

    def tables_connected(ta, tb, adj=None):
        """BFS קצר — האם יש מסלול קשרים בין שתי טבלאות (adj=גרף חלופי, למשל פעילים בלבד)."""
        adj = tbl_adj if adj is None else adj
        if ta == tb:
            return True
        seen, stack = {ta}, [ta]
        while stack:
            cur = stack.pop()
            for nxt in adj.get(cur, ()):
                if nxt == tb:
                    return True
                if nxt not in seen:
                    seen.add(nxt)
                    stack.append(nxt)
        return False

    GEO_CATS = frozenset(('address', 'city', 'continent', 'countryorregion', 'country',
                          'county', 'latitude', 'longitude', 'place', 'postalcode',
                          'stateorprovince', 'state'))

    def geo_cat(ent, prop):
        """dataCategory גיאוגרפי מוצהר במודל, או ''."""
        c = col_meta.get((ent, prop))
        if not c:
            return ''
        dc = (c.get('dataCategory') or '').strip().lower()
        return dc if dc in GEO_CATS else ''

    def label_candidate(ent, prop):
        """עמודת תווית קריאה באותה טבלה (string גלויה שאינה מפתח) — להחלפת ציר מזהה."""
        cands = [c for c in tbl_cols.get(ent, [])
                 if c['name'] != prop and c.get('dataType') == 'string'
                 and not c.get('hidden') and not c.get('isKey') and not c.get('calculated')
                 and (ent, c['name']) not in rel_keys]
        if not cands:
            return None
        named = [c for c in cands if re.search(r"(?i)name|title|desc|שם", c['name'])]
        return (named or cands)[0]['name']

    def is_date(ent, prop):
        dt = dtypes.get((ent, prop), '')
        if dt:
            return ('date' in dt.lower(), True)
        return (prop.lower() in ('date', 'תאריך') or 'date' in prop.lower(), False)

    BARISH = ('barChart', 'clusteredBarChart', 'columnChart', 'clusteredColumnChart',
              'donutChart', 'pieChart', 'funnelChart', 'treemap')
    # MDL-21+MDL-22 prep — מעבר איסוף אחד משותף על הדוח (ביצועים: שני הכללים
    # רוכבים על אותה רקורסיה): שמות מדדים שנצרכים + הפניות עמודות מכל הסוגים
    hm22 = {}
    for t in (model or {}).get('tables', []):
        for h in t.get('hierarchies', []):
            for lname, col in h.get('levels', {}).items():
                hm22[(t['name'].lower(), lname.lower())] = col.lower()
    used21, used22 = set(), set()

    def rec2122(o):
        if isinstance(o, dict):
            dm = o.get('Measure')
            if isinstance(dm, dict) and dm.get('Property'):
                used21.add(str(dm['Property']).lower())
            for kind in ('Column', 'Aggregation'):
                d = o.get(kind)
                if isinstance(d, dict) and d.get('Property'):
                    ent = ''
                    try:
                        ent = d['Expression']['SourceRef'].get('Entity', '')
                    except Exception:
                        pass
                    used22.add((str(ent).lower(), str(d['Property']).lower()))
            hl = o.get('HierarchyLevel')
            if isinstance(hl, dict) and hl.get('Level'):
                ent = ''
                try:
                    ent = hl['Expression']['Hierarchy']['Expression']['SourceRef'].get('Entity', '')
                except Exception:
                    pass
                ent, lev = str(ent).lower(), str(hl['Level']).lower()
                used22.add((ent, hm22.get((ent, lev), lev)))
            for val in o.values():
                rec2122(val)
        elif isinstance(o, list):
            for val in o:
                rec2122(val)

    for p in rep['pages']:
        rec2122(p.get('filters') or [])
        for v in p['visuals']:
            rec2122(v.get('raw') or {})
    rec2122(rep.get('report_filters') or [])

    def qual22(e):
        # הפניות Table[Column] מסוגרות בלבד (ביטויי DAX) — משותף ל-MDL-22
        out = set()
        for mm in _QUAL_REF.finditer(_dax_clean(e)):
            tbl = (mm.group(1) or mm.group(2) or '').strip()
            if tbl:
                out.add((tbl.lower(), mm.group(3).strip().lower()))
        return out

    # MDL-21 · מדדים יתומים — אף ויזואל/מסנן לא מגיע אליהם, גם לא דרך מדדים אחרים
    # (JonathanJihwanKim/pbip-impact-analyzer + pbip_model_lenz, MIT: reachability ולא
    # שימוש ישיר — מדד בסיס שמדד מוצג בונה עליו חי. אצלם 101 "לא בשימוש" הצטמצמו ל-11
    # אחרי הליכה ברשת ההפניות; אותה תבנית בקורפוס שלנו: capital 48→11)
    mdl21_all = [(t['name'], m['name'], m.get('expr', ''))
                 for t in (model or {}).get('tables', []) for m in t.get('measures', [])]
    if len(mdl21_all) >= 5:
        # זרע נוסף: הפניות מתוך המודל עצמו שאינן מדדים — עמודות מחושבות ומקורות
        # מחיצות (שם חיים פרמטרי-שדה עם NAMEOF), כדי לא לסמן מדד שצרוץ דרכם
        for t in (model or {}).get('tables', []):
            for c in t.get('columns', []):
                if c.get('expr'):
                    used21.update(x.lower() for x in _REF_NAME.findall(_dax_clean(c['expr'])))
            for prt in t.get('partitions', []):
                src = prt.get('source', '')
                if src:
                    used21.update(x.lower() for x in _REF_NAME.findall(_dax_clean(src)))
        byname21 = {}
        for t, n, e in mdl21_all:
            if n.lower() not in byname21:
                byname21[n.lower()] = (t, n, e)
        reached21 = {n.lower() for _, n, _ in mdl21_all if n.lower() in used21}
        queue21 = [x for x in mdl21_all if x[1].lower() in used21]
        while queue21:
            _, _, e = queue21.pop()
            for rn in _REF_NAME.findall(_dax_clean(e)):
                tgt = byname21.get(rn.lower())
                if tgt and tgt[1].lower() not in reached21:
                    reached21.add(tgt[1].lower())
                    queue21.append(tgt)
        unused21 = [(t, n) for t, n, _ in mdl21_all if n.lower() not in reached21]
        if len(unused21) >= 3:
            add('MDL-21', 'tip', 'מודל', 'SemanticModel',
                '%d מתוך %d מדדים לא מגיעים לאף ויזואל — גם לא דרך מדדים אחרים'
                % (len(unused21), len(mdl21_all)),
                'הליכה לאחור מכל מדד שמוצג בוויזואל או במסנן דרך הפניות מדד-למדד, '
                'כולל הפניות מעמודות מחושבות ופרמטרי-שדה. דוגמאות: %s.'
                % ', '.join('%s[%s]' % (t, n) for t, n in unused21[:5]),
                'מדד יתום = משקל מת שמנפח את המודל ומבלבל. לוודא שהוא לא משמש דוח '
                'מחובר חיצוני או התאמה אישית של משתמשים, ולמחוק. '
                'מקור: pbip-impact-analyzer (MIT).')

    # MDL-22 · עמודות גלויות ללא שימוש — dead weight במודל
    # (sql-bi/Bravo, MIT — IsReferenced מ-vertipaq; כאן חישוב סטטי מקביל: ויזואלים,
    # מסננים, קשרים, DAX, sortBy, היררכיות, RLS, מחיצות. HierarchyLevel נפתר דרך
    # מפת רמה->עמודה מה-TMDL — אחרת Customer[City] וחבריו FP ב-AdventureWorks)
    for r in (model or {}).get('relationships', []):
        for ref in (r.get('from', ''), r.get('to', '')):
            if '.' in ref:
                rt, rc = ref.rsplit('.', 1)
                used22.add((_unq(rt).lower(), _unq(rc).lower()))
    for role in (model or {}).get('roles', []):
        for rf22 in role.get('filters', []):
            used22 |= qual22(rf22[1] if isinstance(rf22, (list, tuple)) else str(rf22))
    all_cols22 = []
    for t in (model or {}).get('tables', []):
        if t.get('calc_group'):
            continue
        for m in t.get('measures', []):
            used22 |= qual22(m.get('expr', ''))
        for c in t.get('columns', []):
            if c.get('expr'):
                used22 |= qual22(c['expr'])
            if c.get('sortByColumn'):
                used22.add((t['name'].lower(), c['sortByColumn'].strip().lower()))
            all_cols22.append((t, c))
        for prt in t.get('partitions', []):
            if prt.get('source'):
                used22 |= qual22(prt['source'])
    unused22 = [(t['name'], c['name']) for t, c in all_cols22
                if not c.get('hidden') and not c.get('isKey')
                and (t['name'].lower(), c['name'].lower()) not in used22]
    if len(unused22) >= 3:
        add('MDL-22', 'tip', 'מודל', 'SemanticModel',
            '%d עמודות גלויות ללא שום שימוש — לא בוויזואל, מסנן, קשר, DAX או היררכיה'
            % len(unused22),
            'עמודה שלא נצרכת בכלל תופסת זיכרון vertipaq (Bravo קורא את זה מ-IsReferenced; '
            'כאן חישוב סטטי). דוגמאות: %s.'
            % ', '.join('%s[%s]' % (t, c) for t, c in unused22[:5]),
            'לוודא שהעמודה לא נצרכת בדוח מחובר חיצוני / drillthrough משותף, ולהסיר '
            'או להסתיר. מקור: sql-bi/Bravo (MIT).')

    # ADV-17 prep — איחוד שמות כל העמודות והמדדים במודל (דיוק מירבי נגד FP)
    known_tbls17 = set(tbl_cols)
    auto_tbls17 = set((model or {}).get('auto_date_tables', []))
    calc_tbls17 = {t['name'] for t in (model or {}).get('tables', []) if t.get('calc_group')}
    all_props17 = set()
    for (tn, cn) in dtypes:
        all_props17.add(cn)
    for (tn, mn) in measures:
        all_props17.add(mn)
    for p in rep['pages']:
        data_vs = [v for v in p['visuals'] if v['type'] not in DECOR and not v['hidden']]

        # ADV-23 · דף בלי אף אלמנט כותרת — לא textbox ולא ויזואל עם title מוצג
        # (סבב 78; מקור חדש powerbiconsulting.com — כותרת ברורה משמאל-למעלה היא אבן
        # היסוד של הקשר; אומת בקורפוס: יורה על דוח 02, 13 בסיסים ללא שינוי)
        _has_tb = any(v['type'] == 'textbox' for v in p['visuals'])
        _has_ttl = False
        if not _has_tb:
            for v in p['visuals']:
                _vco = _dct(_dct(v['raw']).get('visual')).get('visualContainerObjects') or {}
                for blk in _vco.get('title') or []:
                    _show = (blk or {}).get('properties', {}).get('show')
                    _show = _literal(_show) if isinstance(_show, dict) else _show
                    if str(_show) == 'true':
                        _has_ttl = True
                        break
                if _has_ttl:
                    break
        if not _has_tb and not _has_ttl and data_vs:
            add('ADV-23', 'tip', 'עיצוב', "דף '%s'" % (p['name'] or p['id']),
                'דף ללא כותרת — אין textbox ואין ויזואל עם title מוצג',
                'רמת ביטחון: בינונית-גבוהה (סיגנל אובייקטיבי מהקוד). דף בלי כותרת משאיר '
                'את הקורא בלי הקשר: מה הנושא, באיזה חתך, לאיזו תקופה. (אומת בקורפוס: '
                'דוח 02 — תחזוקה מונעת; שאר 13 הבסיסים בקורפוס לא הושפעו.)',
                'להוסיף textbox כותרת בראש העמוד (שם הנושא + חתך/תקופה), או להציג '
                'title בוויזואל הראשי. סטנדרט: כותרת ברורה משמאל-למעלה '
                '(powerbiconsulting.com).')

        # ADV-25 · שם דף ברירת-מחדל ("Page 1" / "עמוד 1") — הכותב לא שינה את
        # השם; בסרגל הניווט ובשיתוף הדוח הלשונית חסרת משמעות
        # (akhilannan/pbir-utils rules.yaml explicit_page_names, MIT).
        _dn = (p['name'] or '').strip()
        if re.match(r'^(Page|עמוד) \d+$', _dn):
            add('ADV-25', 'tip', 'עיצוב', "דף '%s'" % _dn,
                "דף עם שם ברירת-מחדל '%s'" % _dn,
                'רמת ביטחון: גבוהה (סיגנל אובייקטיבי מהקוד). שם ברירת-מחדל אומר '
                'שהכותב לא נתן לדף שם משמעותי — בסרגל הלשוניות, בתפריט הניווט '
                'ובשיתוף יופיע "Page 1" במקום נושא הדף. מקור: akhilannan/'
                'pbir-utils explicit_page_names (MIT). אומת בקורפוס: claude '
                '"Page 1" מכוון אמיתי, 65 דפים אחרים נקיים.',
                'לשנות את שם הדף לנושא התוכן (לחיצה כפולה על הלשונית ב-Desktop).')

        # ADV-04 · דף עמוס — מעל 8 ויזואלי נתונים
        if len(data_vs) > 8:
            add('ADV-04', 'tip', 'עיצוב', "דף '%s'" % (p['name'] or p['id']),
                'דף עם %d ויזואלי נתונים — עומס קוגניטיבי' % len(data_vs),
                'רמת ביטחון: בינונית. הסיגנל (ספירת ויזואלים בקוד) אובייקטיבי, אבל צפיפות '
                'נכונה תלויה בקהל ובסיפור. מעל ~8 ויזואלים קשה לעקוב אחרי מסר אחד.',
                'לשקול לפצל לשני דפים (תמונה כוללת + פירוט), להעביר פירוט ל-tooltip page '
                'או ל-drillthrough, או להסתיר ויזואלים משניים מאחורי סימנייה.')

        # ADV-14 · כמה cardVisual חד-ערכיים באותה שורה — לאחד לכרטיס רב-ערכי
        # (MS skills-for-fabric card.md: ברירת המחדל ל-2+ KPIs = cardVisual רב-ערכי אחד;
        # מפרידים רק כשצריך עיצוב או אינטראקציה שונה פר-כרטיס)
        singles = []
        for v in data_vs:
            if v['type'] != 'cardVisual':
                continue
            vroles = _query_roles(v['raw'])
            if len(vroles.get('Data') or []) == 1 and len(vroles) <= 2:
                singles.append(v)
        singles.sort(key=lambda v: (v['y'] if isinstance(v.get('y'), (int, float)) else 0))
        row_groups = []
        for v in singles:
            vy = v['y'] if isinstance(v.get('y'), (int, float)) else 0
            if row_groups and abs(vy - row_groups[-1][0]) <= 40:
                row_groups[-1][1].append(v)
            else:
                row_groups.append((vy, [v]))
        for _, grp in row_groups:
            if len(grp) < 2:
                continue
            sigs = set()
            for v in grp:
                objs = (((v['raw'].get('visual') or {}).get('objects')) or {})
                sigs.add(json.dumps(objs, sort_keys=True, default=str))
            if len(sigs) > 1:
                continue  # עיצוב שונה פר-כרטיס = הסיבה הלגיטימית להפרדה (MS)
            ids = ', '.join(v['id'] for v in grp[:5])
            add('ADV-14', 'tip', 'עיצוב', "דף '%s'" % (p['name'] or p['id']),
                '%d כרטיסי cardVisual חד-ערכיים באותה שורה (%s)' % (len(grp), ids),
                'רמת ביטחון: בינונית. MS ממליצה במפורש: ברירת המחדל לכמה KPIs היא '
                'cardVisual רב-ערכי אחד (כל המדדים ב-queryState.Data) — פחות ויזואלים, '
                'פחות שאילתות, רינדור כשורת callouts אחת. הפרדה מוצדקת רק לעיצוב '
                '(accentBar/רקע שונה) או אינטראקציה (drillthrough) נפרדת פר-כרטיס.',
                'לאחד ל-cardVisual אחד: כל המדדים ← queryState.Data של אותו ויזואל '
                '(הבונה מבצע דרך pbi_swap). אם יש סיבת עיצוב/אינטראקציה פר-כרטיס — להשאיר.')

        # ADV-16 · שורת ויזואלים כמעט-מיושרת — פער y של פיקסלים בודדים בלבד
        # (powerbi.tips, Mike Carlo, "Using Grids to Improve Visualization Placement":
        # יישור ויזואלים לרשת מסיר הסחות דעת מהדף — סטנדרט עיצוב בסיסי לדוח)
        rows16 = []
        for v in sorted([v for v in data_vs if isinstance(v.get('y'), (int, float))],
                        key=lambda v: v['y']):
            if rows16 and abs(v['y'] - rows16[-1][0]) <= 40:
                rows16[-1][1].append(v)
            else:
                rows16.append((v['y'], [v]))
        for _, grp in rows16:
            if len(grp) < 2:
                continue
            ys = [v['y'] for v in grp]
            dy = max(ys) - min(ys)
            if dy == 0 or dy > 20:
                continue  # 0 = שורה מיושרת; >20px = כבר לא "כמעט" — סידור מכוון סביר
            add('ADV-16', 'tip', 'עיצוב', "דף '%s'" % (p['name'] or p['id']),
                '%d ויזואלים כמעט בשורה אחת — סטיית y של %dpx (%s)'
                % (len(grp), int(dy), ', '.join(v['id'] for v in grp[:5])),
                'רמת ביטחון: בינונית. פער של פיקסלים בודדים בין ויזואלים באותה שורה הוא '
                'סימן קלאסי לגרירה ידנית בלי snapping — ויזואלית מסיח (powerbi.tips: '
                'יישור לרשת מסיר הסחות דעת).',
                'ליישר את כל ויזואלי השורה לאותו y (ב-Desktop: Format → Align, או Grid). '
                'אם הסטייה מכוונת (stagger) — להתעלם.')

        for v in data_vs:
            loc = "דף '%s' ויזואל '%s'" % (p['name'] or p['id'], v['id'])
            roles = _query_roles(v['raw'])
            vt = v['type']

            # ADV-17 · הפניה לשדה שלא קיים במודל (שם שונה/נמחק — הפניה מתה ב-queryState)
            # (bernatagulloesbrina/TabularEditor-Scripts — Fix Broken Fields, MIT:
            # סריקת שדות הוויזואלים מול שדות המודל לאיתור הפניות שבורות)
            if known_tbls17:
                bad17, seen17 = [], set()
                # סבב 85: ההפניות נאספות גם מ-sortDefinition, ביטויי objects
                # (כולל FillRule.Input — CF על שדה מת נזרק בשקט) ו-filterConfig,
                # בנוסף ל-queryState (Fix Broken Fields.cs GetAllFields, MIT).
                _all17 = [f for _r, _flds in roles.items() for f in _flds]
                _all17 += _extra_field_refs(v['raw'])
                for kind, ent, prop in _all17:
                    if not ent or ent in auto_tbls17 or ent in calc_tbls17:
                        continue  # טבלאות תאריך אוטומטיות ופריטי calc group אינן עמודות רגילות
                    if (ent, prop) in seen17:
                        continue
                    if ent not in known_tbls17 or prop not in all_props17:
                        seen17.add((ent, prop))
                        bad17.append("%s[%s]" % (ent, prop))
                if bad17:
                    add('ADV-17', 'warn', 'עיצוב', loc,
                        '%d הפניות לשדות שלא קיימים במודל' % len(bad17),
                        'רמת ביטחון: גבוהה. הוויזואל מפנה ל-%s — שם שלא נמצא באף עמודה או מדד '
                        'במודל. שינוי שם או מחיקה במודל משאירים הפניה מתה — ב-queryState, '
                        'ב-sortDefinition, בביטויי עיצוב (objects/CF) או במסננים '
                        '(filterConfig); בחלק מהמקומות הכשל שקט (צבע/מיון שלא חלים).' %
                        (', '.join(bad17[:4]) + ('…' if len(bad17) > 4 else '')),
                        'לתקן את ההפניה לשדה הקיים (או להחזיר את השדה למודל). '
                        'מקור: bernatagulloesbrina/TabularEditor-Scripts — Fix Broken Fields.')

            # ADV-18 · gridlines מופעלות במפורש בגרף cartesian
            # (Plainsight Playbook — Report Design Standards: gridlines off by default,
            # רעש ויזואלי; ב-bar/line/scatter לכבות ולהעדיף data labels/tooltips)
            vobjs = _dct(_dct(_dct(v['raw']).get('visual')).get('objects'))
            CART18 = ('lineChart', 'areaChart', 'stackedAreaChart', 'scatterChart',
                      'lineClusteredColumnComboChart', 'lineStackedColumnComboChart',
                      'ribbonChart', 'waterfallChart')
            if vt in BARISH or vt in CART18:
                on_axes = []
                for axis in ('valueAxis', 'categoryAxis'):
                    for blk in vobjs.get(axis, []) or []:
                        pv = _literal(_dct(_dct(blk).get('properties')).get('gridlineShow'))
                        if pv and pv.lower() == 'true':
                            on_axes.append(axis)
                if on_axes:
                    add('ADV-18', 'tip', 'עיצוב', loc,
                        'gridlines מופעלות במפורש (%s)' % ', '.join(on_axes),
                        'רמת ביטחון: גבוהה (הגדרה מפורשת ב-visual.json). gridlines על גרף '
                        'cartesian מוסיפות רעש ויזואלי; הסטנדרט: כבויות כברירת מחדל, וכשצריך '
                        'קריאת ערך מדויקת — data labels או tooltip.',
                        'לכבות gridlineShow ב-%s, אלא אם זו טבלה אנליטית צפופה שצריכה '
                        'מעקב עין בין שורות. מקור: Plainsight Playbook — Report Design '
                        'Standards.' % '/'.join(on_axes))

            # ADV-19 · מקרא מתחת לגרף — מיקום קריאה לא טבעי
            # (Plainsight Playbook: מקרא עליון ל-5 סדרות ומטה; מתחת לגרף העין נאלצת
            # לרדת אחרי קריאת הנתונים — המיקום הכי פחות טבעי)
            lp19 = None
            for blk in vobjs.get('legend', []) or []:
                lp19 = _literal(_dct(_dct(blk).get('properties')).get('position'))
                if lp19:
                    break
            if lp19 and 'Bottom' in lp19:
                add('ADV-19', 'tip', 'עיצוב', loc,
                    "מקרא במיקום '%s'" % lp19,
                    'רמת ביטחון: בינונית. מקרא מתחת לגרף מרחיק את העין מהנתונים אחרי הקריאה. '
                    'הסטנדרט: מקרא עליון ל-5 סדרות ומטה, או data labels ישירים על הסדרות.',
                    'להעביר את legend position ל-Top. מקור: Plainsight Playbook — '
                    'Report Design Standards.')

            # ADV-01 · ציר זמן על ויזואל שאינו קו — מגמה לא נראית
            if vt in BARISH and roles.get('Category'):
                ent, prop = roles['Category'][0][1], roles['Category'][0][2]
                d, typed = is_date(ent, prop)
                if d:
                    conf = ('גבוהה' if typed else 'בינונית')
                    why = ('dataType=date במודל' if typed else
                           'שם השדה מרמז על תאריך (לא אומת מול המודל)')
                    add('ADV-01', 'tip', 'עיצוב', loc,
                        "שדה זמן '%s' על ציר Category של %s — מגמה לא נקריאה" % (prop, vt),
                        'רמת ביטחון: %s (%s). סדרת זמן על עמודות/טבעת מכריחה השוואת '
                        'גבהים במקום לראות קו; lineChart/areaChart מספרים מגמה טבעית.' % (conf, why),
                        'להחליף ל-lineChart (או areaChart למילוי). הבונה מחליף visualType '
                        'לפי תבנית lineChart מה-corpus: Category נשאר, Y מקבל את הערך.')

            # ADV-02 · lineChart על קטגוריה שאינה זמן — קו מרמז על רצף שאינו קיים
            if vt in ('lineChart', 'areaChart') and roles.get('Category'):
                ent, prop = roles['Category'][0][1], roles['Category'][0][2]
                dt = dtypes.get((ent, prop), '')
                col0 = col_meta.get((ent, prop))
                if dt and 'date' not in dt.lower() and not (col0 and col0.get('sortByColumn')):
                    add('ADV-02', 'tip', 'עיצוב', loc,
                        "lineChart על '%s' (dataType=%s) — הקו מרמז על רצף שאין" % (prop, dt),
                        'רמת ביטחון: בינונית. הקו מחבר נקודות כאילו יש סדר רציף; על קטגוריות '
                        'בדידות (מוצר, אזור) זה מטעה — ההשוואה הנכונה היא עמודות.',
                        'להחליף ל-clusteredColumnChart/barChart (Category נשאר, Y נשאר). '
                        'אם יש סדר טבעי לקטגוריות (sortByColumn) — להשאיר ולהצדיק.')

            # ADV-03 · טבלה דלה — הייתה יכולה להיות תרשים
            if vt == 'tableEx':
                vals = roles.get('Values', [])
                cols = [f for f in vals if f[0] == 'Column']
                meas = [f for f in vals if f[0] == 'Measure']
                if len(vals) == 2 and len(cols) == 1 and len(meas) == 1:
                    ax_ent, ax_prop = cols[0][1], cols[0][2]
                    ax_dt = dtypes.get((ax_ent, ax_prop), '')
                    is_time = 'date' in ax_dt.lower() if ax_dt else False
                    target = 'lineChart' if is_time else 'barChart/clusteredBarChart'
                    why_dt = (' העמודה מסוג %s במודל — ציר זמן, ולכן קו (מגמה) ולא עמודות.'
                              % ax_dt) if is_time else ''
                    add('ADV-03', 'tip', 'עיצוב', loc,
                        'טבלה עם עמודה אחת + מדד אחד — %s מספר את הסיפור מהר יותר' % target.split('/')[0],
                        'רמת ביטחון: %s. שני שדות בלבד = דירוג פשוט; העין קוראת הפרשי '
                        'אורכים מהר יותר מהפרשי מספרים. טבלה עדינה אם הערך המדויק חשוב.%s'
                        % ('גבוהה' if is_time else 'בינונית', why_dt),
                        'להחליף ל-%s: העמודה ← Category, המדד ← Y.%s'
                        % (target, ' למיין יורד.' if not is_time else ''))
                elif len(vals) == 1 and len(meas) == 1:
                    add('ADV-03', 'tip', 'עיצוב', loc,
                        'טבלה עם מדד בודד — cardVisual מתאים יותר',
                        'רמת ביטחון: גבוהה. טבלה של תא אחד היא כרטיס מסכם במסווה; '
                        'cardVisual נועד בדיוק לזה ומוצג בולד.',
                        'להחליף ל-cardVisual: המדד ← queryState.Data.')

            # ADV-05 · KPI/gauge בלי יעד — מאבד את כל המשמעות
            if vt == 'kpi' and not roles.get('Goal'):
                add('ADV-05', 'tip', 'עיצוב', loc,
                    'KPI בלי Goal — אין יעד להשוות אליו',
                    'רמת ביטחון: גבוהה (מבני). כל ערכת ה-KPI היא ערך מול יעד ומגמה; בלי '
                    'Goal נשאר מספר על רקע — cardVisual עושה את זה זול יותר.',
                    'להוסיף מדד יעד ל-Goal, או להחליף ל-cardVisual אם אין יעד עסקי.')
            if vt == 'gauge' and not roles.get('TargetValue'):
                add('ADV-05', 'tip', 'עיצוב', loc,
                    'gauge בלי TargetValue — המחוג לא מראה התקדמות',
                    'רמת ביטחון: גבוהה (מבני). gauge בלי יעד מציג מספר על סקאלה שרירותית; '
                    'הערך שלו כולו במרחק מהיעד.',
                    'להוסיף מדד יעד ל-TargetValue (ולהגדיר MaxValue), או לעבור ל-cardVisual.')

            # ADV-06 · שדה גיאוגרפי (dataCategory מוצהר במודל) על ויזואל שאינו מפה
            if vt in BARISH + ('tableEx',) and roles.get('Category'):
                ent, prop = roles['Category'][0][1], roles['Category'][0][2]
                gc = geo_cat(ent, prop)
                if gc:
                    add('ADV-06', 'tip', 'עיצוב', loc,
                        "שדה גיאוגרפי '%s' (dataCategory=%s) על %s — המפה לא מנוצלת" % (prop, gc, vt),
                        'רמת ביטחון: גבוהה. ה-dataCategory מוצהר במודל עצמו — זה ראיה מהדאטה, '
                        'לא ניחוש משם. פיזור גיאוגרפי על מפה חושף דפוסים אזוריים שרשימת '
                        'עמודות מסתירה.',
                        'להחליף ל-map (או filledMap לאזורים): השדה ← Category. הבונה מחליף '
                        'לפי תבנית map מה-corpus: Category נשאר, Size ← הערך.')
            # ADV-06b · map שהשדה שלו בלי dataCategory גיאוגרפי — Desktop מנחש לפי שם
            if vt in ('map', 'filledMap', 'azureMap') and roles.get('Category'):
                ent, prop = roles['Category'][0][1], roles['Category'][0][2]
                if (ent, prop) in col_meta and not geo_cat(ent, prop):
                    add('ADV-06', 'tip', 'עיצוב', loc,
                        "מפה על '%s' בלי dataCategory גיאוגרפי — המיקום ניחוש לפי שם" % prop,
                        'רמת ביטחון: גבוהה (המטה-דאטה במודל ריקה). בלי סימון, Bing מנחש '
                        'מיקום משם הערך — ערים בעלות שם זהה במדינות שונות יתמפו לא נכון.',
                        'לסמן בעמודה dataCategory מתאים (City/StateOrProvince/CountryOrRegion) '
                        'במודל, או להשתמש בקואורדינטות Latitude/Longitude ב-roles X/Y.')

            # ADV-07 · ציר על עמודת מזהה/מפתח במקום תווית קריאה
            if vt in BARISH + ('tableEx',) and roles.get('Category'):
                kind0, ent, prop = roles['Category'][0]
                col0 = col_meta.get((ent, prop))
                if kind0 == 'Column' and col0 and col0.get('dataType') != 'dateTime' and \
                   (col0.get('isKey') or (ent, prop) in rel_keys):
                    lbl = label_candidate(ent, prop)
                    if lbl:
                        add('ADV-07', 'tip', 'עיצוב', loc,
                            "הציר על עמודת המזהה '%s' — המשתמש רואה מפתחות, לא שמות" % prop,
                            'רמת ביטחון: בינונית-גבוהה. העמודה מסומנת isKey או משמשת בקשר '
                            'במודל (ראיה מבנית מהדאטה), ובאותה טבלה קיימת עמודת תווית '
                            "מועמדת '%s'. מזהים גולמיים על ציר לא קריאים." % lbl,
                            "להחליף את שדה ה-Category ל-'%s' (או לאמת שהתווית הנכונה). "
                            'אם דווקא המזהה רלוונטי — להשאיר ולהצדיק.' % lbl)

            # ADV-08 · עמודה מספרית עם summarizeBy=none בהקשר שכופה אגרגציה — תוצג כספירה
            # (היקף מדויק אחרי כיול על corpus + דוחות המשתמש: רק גרפים/כרטיסים כופים
            #  אגרגציה; בסליסר role Values הוא שדה הסינון (FP סבב 55), ובטבלה
            #  tableEx/pivotTable לא נכפית אגרגציה — עמודת טקסט מציגה ערכים ועמודה
            #  מספרית מוצגת don't-summarize (FP: 16/86 מממצאי דוחות המשתמש, סבב 56).
            #  עמודת טקסט מוחרגת גם בגרף — שם היא First, לא Count; הבלבול סכום/ספירה
            #  רלוונטי רק למספרית.)
            if vt not in ('slicer', 'listSlicer', 'advancedSlicerVisual', 'tableEx', 'pivotTable'):
                for role in ('Values', 'Y', 'Data'):
                    for kind0, ent, prop in roles.get(role, []):
                        if kind0 != 'Column':
                            continue
                        col0 = col_meta.get((ent, prop))
                        if col0 and (col0.get('summarizeBy') or '').lower() == 'none' \
                           and col0.get('dataType') in NUMERIC_TYPES:
                            add('ADV-08', 'tip', 'עיצוב', loc,
                                "עמודה '%s' (summarizeBy=none) ב-role %s — תוצג כספירה, לא כסכום" % (prop, role),
                                'רמת ביטחון: גבוהה. summarizeBy=none מוצהר במודל — Desktop יציע '
                                'רק Count/Count distinct. אם הכוונה הייתה סכום/ממוצע, המספר '
                                'שיוצג יהיה שגוי בשקט.',
                                'אם הכוונה צבירה — לבנות מדד מפורש (SUM/AVERAGE) ולהציב אותו; '
                                'אם ספירה — עדיף מדד ספירה מפורש לקריאות.')

            # ADV-20 · עוגה/דונאט עם קטגוריה מטבלת fact — יותר מדי פרוסות
            # (Stephen Few, "Save the Pies for Dessert", perceptualedge.com: עוגה עם
            #  פרוסות רבות בלתי קריאה; נמצא על 5 השבורים: דונאט על עמודת fact)
            if vt in ('pieChart', 'donutChart') and roles.get('Category'):
                kind0, ent, prop = roles['Category'][0]
                if kind0 == 'Column' and ent in fact_like:
                    add('ADV-20', 'tip', 'עיצוב', loc,
                        "%s — הקטגוריה '%s' מטבלת ה-fact" % (vt, prop),
                        'רמת ביטחון: בינונית (קטגוריה מטבלה בצד-many / טבלה שמארחת '
                        'מדדים). עמודת טקסט בטבלת עובדות נוטה לקרדינליות גבוהה — עוגה '
                        'עם עשרות פרוסות בלתי קריאה, והפרוסות הקטנות מתאחדות לרעש. '
                        'מקור: Stephen Few — "Save the Pies for Dessert" '
                        '(perceptualedge.com; קרדיט: Stephen Few).',
                        'להעביר את הקטגוריה לטבלת ממד (ביצועים + סכמה), או להחליף '
                        'לגרף עמודות עם TopN + Others.')

            # ADV-21 · כותרת גנרית חסרת תוכן ("נתונים", "פילוח"...)
            # (נמצא על 5 השבורים: כותרות "נתונים", "פילוח", "ניצול", "התפלגות")
            _vco21 = _dct(_dct(v['raw']).get('visual')).get('visualContainerObjects') or {}
            for blk in _vco21.get('title') or []:
                _t21 = (blk or {}).get('properties', {}).get('text')
                _t21 = _literal(_t21) if isinstance(_t21, dict) else _t21
                if _t21 and str(_t21).strip().casefold() in GENERIC_TITLES:
                    add('ADV-21', 'tip', 'עיצוב', loc,
                        "כותרת גנרית '%s'" % str(_t21).strip(),
                        'כותרת של מילה גנרית אחת לא אומרת לקורא מה הוא רואה — באיזה '
                        'מדד, באיזה חתך, לאיזו תקופה. (נמצא על הדשבורדים השבורים: '
                        '"נתונים", "פילוח", "ניצול".)',
                        'לנסח כותרת שעונה על שאלה: מה מוצג + באיזה חתך. למשל '
                        '"עלות לפי מחסן — חודש נוכחי".')

            # ADV-22 · multiRowCard שמערבב סקאלות (כסף + אחוז + ספירה)
            # (נמצא על 5 השבורים: כרטיס אחד עם עלות + אחוז ניצול + מספר רשומות + יחס)
            if vt == 'multiRowCard':
                fams = set()
                for kind0, ent, prop in roles.get('Values', []):
                    if kind0 != 'Measure':
                        continue
                    el = _dax_clean(mexpr.get((ent, prop), '')).upper()
                    if re.search(r"\bDIVIDE\s*\(|/", el):
                        fams.add('יחס/אחוז')
                    elif re.search(r"\bCOUNTROWS\s*\(|\bCOUNT\s*\(|\bDISTINCTCOUNT\s*\(", el):
                        fams.add('ספירה')
                    elif re.search(r"\b(SUM|AVERAGE|MIN|MAX)\s*\(", el):
                        fams.add('גודל מספרי')
                if len(fams) >= 3:
                    add('ADV-22', 'tip', 'עיצוב', loc,
                        'multiRowCard מערבב %d סוגי סקאלה: %s' % (len(fams), ' + '.join(sorted(fams))),
                        'כרטיס אחד שמציג כסף לצד אחוזים לצד ספירות מאלץ את הקורא '
                        'להחליף קנה מידה בין שורה לשורה — קל לקרוא 87% כ-87 שקל. '
                        '(נמצא על הדשבורדים השבורים.)',
                        'לפצל לכרטיסים נפרדים לפי משפחה, או לעבור לכרטיס החדש '
                        '(cardVisual) עם reference labels מקובצים.')

            # ADV-09 · שדה מוסתר במודל (isHidden) מוצג בוויזואל — סתירת כוונת המודל
            for role, flds in roles.items():
                for kind0, ent, prop in flds:
                    col0 = col_meta.get((ent, prop))
                    if kind0 == 'Column' and col0 and col0.get('hidden'):
                        add('ADV-09', 'tip', 'עיצוב', loc,
                            "שדה מוסתר '%s.%s' משמש ב-role %s" % (ent, prop, role),
                            'רמת ביטחון: גבוהה (isHidden מוצהר ב-TMDL). עמודה מוסתרת סומנה '
                            'במודל כלא-מיועדת לתצוגה — שימוש בה בוויזואל סוטר את כוונת המודל '
                            'ותשבור אם תשתנה/תימחק.',
                            'להחליף לעמודה גלויה מקבילה או לבנות מדד גלוי; אם מכוון — '
                            'לשקול להסיר את ההסתרה במודל.')

            # ADV-10 · ציר על עמודה מספרית רציפה (לא מפתח/קשר) — קטגוריה לכל ערך
            if vt in BARISH and roles.get('Category'):
                kind0, ent, prop = roles['Category'][0]
                col0 = col_meta.get((ent, prop))
                if kind0 == 'Column' and col0 and col0.get('dataType') in NUMERIC_TYPES and \
                   not col0.get('isKey') and (ent, prop) not in rel_keys:
                    add('ADV-10', 'tip', 'עיצוב', loc,
                        "ציר Category על עמודה מספרית '%s' (dataType=%s)" % (prop, col0.get('dataType')),
                        'רמת ביטחון: בינונית. עמודה מספרית לא-מפתח על ציר = עמודה לכל ערך '
                        'בדיד; אם הערכים רציפים (מחיר, גיל) התרשים יתפזר לעשרות עמודות דקות.',
                        'אם רציף — לבצע binning במודל (קבוצות) או scatterChart עם סכמה; '
                        'אם בדיד מעט ערכים (דירוג 1-5) — להשאיר.')

            # ADV-11 · עמודות מטבלאות מנותקות (בלי מסלול קשרים) על אותו ויזואל
            if vt not in ('slicer', 'advancedSlicerVisual'):
                col_tables = []
                for role, flds in roles.items():
                    for kind0, ent, prop in flds:
                        if kind0 == 'Column' and ent and ent not in col_tables:
                            col_tables.append(ent)
                disconnected = []
                for i in range(len(col_tables)):
                    for j in range(i + 1, len(col_tables)):
                        if not tables_connected(col_tables[i], col_tables[j]):
                            disconnected.append('%s + %s' % (col_tables[i], col_tables[j]))
                if not disconnected:
                    # ADV-24 · מחוברות, אבל רק דרך קשר לא-פעיל — הסינון ההדדי לא יעבוד
                    inactive_only = []
                    for i in range(len(col_tables)):
                        for j in range(i + 1, len(col_tables)):
                            if not tables_connected(col_tables[i], col_tables[j],
                                                    adj=tbl_adj_active):
                                inactive_only.append('%s + %s' % (col_tables[i], col_tables[j]))
                    if inactive_only:
                        add('ADV-24', 'tip', 'עיצוב', loc,
                            'עמודות מטבלאות שמחוברות רק בקשר לא-פעיל: %s' % '; '.join(inactive_only[:2]),
                            'רמת ביטחון: בינונית-גבוהה. קשר לא-פעיל (isActive: false) לא מפיץ '
                            'סינון לוויזואלים — העמודות יוצגו אבל לא יסננו זו את זו, והערכים '
                            'יהיו כאילו אין קשר. מקור: MS Learn desktop-relationships-understand '
                            '(CC-BY-4.0).',
                            'להפעיל את הקשר, לשכפל מימד role-playing, או להשתמש '
                            'ב-USERELATIONSHIP במדדים הרלוונטיים.')
                if disconnected:
                    add('ADV-11', 'tip', 'עיצוב', loc,
                        'עמודות מטבלאות מנותקות על ויזואל אחד: %s' % '; '.join(disconnected[:2]),
                        'רמת ביטחון: בינונית-גבוהה. גרף הקשרים במודל לא מחבר את הטבלאות — '
                        'עמודות מטבלאות מנותקות לא יכולות לסנן זו את זו, והתוצאה תהיה '
                        'שכפול קרטזי/ריק. (מדד עם SELECTEDVALUE על טבלת פרמטרים = דפוס '
                        'לגיטימי — הכלל בודק עמודות בלבד.)',
                        'לבדוק שהקשר חסר בטעות במודל (וליצור אותו), או להחליף את אחד השדות '
                        'לעמודה מטבלה מחוברת. אם טבלת פרמטרים מכוונת — להשאיר.')

            # ADV-12 · pie/donut בלי קטגוריה — פרוסה אחת חסרת משמעות
            if vt in ('pieChart', 'donutChart'):
                has_cat = bool(roles.get('Category') or roles.get('Series') or
                               roles.get('Legend') or roles.get('Details'))
                if not has_cat and roles.get('Values'):
                    add('ADV-12', 'tip', 'עיצוב', loc,
                        'עוגה/טבעת בלי שדה קטגוריה — תוצג פרוסה אחת של 100%',
                        'רמת ביטחון: גבוהה (מבני). בלי Legend/Category הערכים מתאחדים '
                        'לפרוסה יחידה — הוויזואל לא משווה דבר.',
                        'להוסיף שדה קטגוריה ל-Legend, או להחליף ל-cardVisual אם המטרה '
                        'מספר מסכם יחיד.')

            # ADV-13 · card/multiRowCard מיושנים — cardVisual הוא המחליף הרשמי (MS card.md)
            if vt in ('card', 'multiRowCard'):
                add('ADV-13', 'tip', 'עיצוב', loc,
                    "וויזואל '%s' מסוג %s — סוג מיושן (legacy)" % (v['id'], vt),
                    'רמת ביטחון: גבוהה (מבני). Microsoft מגדירה card ו-multiRowCard '
                    'כ-deprecated; cardVisual הוא המחליף הרשמי — תומך בריבוי ערכים '
                    'בוויזואל אחד, referenceLabels ואפשרויות עיצוב מלאות.',
                    'להמיר ל-cardVisual: המדד/ים עוברים ל-queryState.Data. ההמרה '
                    'מתבצעת בבונה (clone דרך pbi_swap, לא בנייה מאפס).')

            # ADV-15 · סליסר על עמודת צד-many — מסנן רק מטה, לא מסנן מימדים
            if vt in ('slicer', 'listSlicer', 'advancedSlicerVisual'):
                for kind, ent, prop in (roles.get('Values') or []):
                    if kind == 'Column' and ent in many_side:
                        add('ADV-15', 'tip', 'עיצוב', loc,
                            "סליסר על העמודה '%s' מטבלת צד-many (%s)" % (prop, ent),
                            'רמת ביטחון: בינונית (מבוסס cardinality של הקשרים במודל). '
                            'הקשר חד-כיווני (one→many): סליסר על עמודת fact מסנן רק את '
                            'טבלת ה-fact עצמה — הוא לא מסנן טבלאות מימד, ורשימת הערכים '
                            'עלולה להיות עצומה (cardinality גבוה של עמודות fact).',
                            'להעביר את הסליסר לעמודת מימד מתאימה (צד one של הקשר), '
                            'או ליצור עמודת מימד מקובצת. אם הסליסר מכוון לסינון פנימי '
                            'של ה-fact בלבד — להשאיר.')
                        break


def _srgb_lin(c):
    c = c / 255.0
    return c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4


def _luminance(h):
    """בהירות יחסית לפי WCAG 2.x (sRGB)."""
    r, g, b = (int(h[i:i + 2], 16) for i in (1, 3, 5))
    return 0.2126 * _srgb_lin(r) + 0.7152 * _srgb_lin(g) + 0.0722 * _srgb_lin(b)


def _contrast(a, b):
    la, lb = _luminance(a), _luminance(b)
    hi, lo = max(la, lb), min(la, lb)
    return (hi + 0.05) / (lo + 0.05)


def _any_color(v):
    """צבע hex מכל צורת PBIR: מחרוזת, expr Literal, solid.color, properties.color."""
    if isinstance(v, str):
        return _hex_norm(v)
    if isinstance(v, dict):
        s = v.get('solid')
        if isinstance(s, dict):
            c = _any_color(s.get('color'))
            if c:
                return c
        lit = _literal(v)
        if lit:
            h = _hex_norm(lit)
            if h:
                return h
        for k in ('color', 'properties'):
            if isinstance(v.get(k), (dict, str)):
                c = _any_color(v[k])
                if c:
                    return c
    return None


def _num(v):
    """מספר מכל צורה: מספר, מחרוזת ('8', '8pt'), או expr Literal."""
    if isinstance(v, (int, float)) and not isinstance(v, bool):
        return float(v)
    if isinstance(v, str):
        s = v.strip().lower().rstrip('pt').strip()
        try:
            return float(s)
        except ValueError:
            return None
    if isinstance(v, dict):
        lit = _literal(v)
        if lit is not None:
            return _num(lit)
    return None


def _page_bg(p, rep):
    """צבע רקע הדף: מפורש ב-page.json → background של ה-theme → ברירת מחדל לבן (מסומן)."""
    found = []

    def cb(o):
        for k in ('background', 'pageBackground'):
            v = o.get(k)
            if isinstance(v, dict):
                c = _any_color(v)
                if c:
                    found.append(c)
            elif isinstance(v, list):
                for it in v:
                    c = _any_color(it)
                    if c:
                        found.append(c)
    _walk(p['raw'], cb)
    if found:
        return found[0], False
    if rep.get('theme_bg'):
        return rep['theme_bg'], False
    return '#FFFFFF', True


def _text_runs(raw):
    """textRuns של textbox (מבנה PBIR משתנה בין גרסאות — חיפוש סובלני).
    סבב 132 (כשל שדה 14.9): Desktop כותב paragraphs גם כ-expr-Literal שבתוכו
    מחרוזת JSON — לפרסר גם אותה, אחרת הרצים בלתי-נראים לבדיקות."""
    runs = []

    def cb(o):
        tr = o.get('textRuns')
        if isinstance(tr, list):
            for r in tr:
                if isinstance(r, dict):
                    runs.append(r)
        pars = o.get('paragraphs')
        if isinstance(pars, dict):
            val = _literal(pars)
            if isinstance(val, str):
                try:
                    parsed = json.loads(val)
                except (ValueError, TypeError):
                    parsed = None
                if isinstance(parsed, list):
                    _walk(parsed, cb)
    _walk(raw, cb)
    return runs


def _min_font_size(raw):
    """fontSize המפורש הקטן ביותר בוויזואל (נקודות), או None."""
    vals = []

    def cb(o):
        if 'fontSize' in o:
            n = _num(o['fontSize'])
            if n is not None:
                vals.append(n)
        ts = o.get('textStyle')
        if isinstance(ts, dict) and 'fontSize' in ts:
            n = _num(ts['fontSize'])
            if n is not None:
                vals.append(n)
    _walk(raw, cb)
    return min(vals) if vals else None


_CARD_LABEL_TYPES = ('cardVisual', 'multiRowCard')


def _card_label_shown(vis):
    """objects.label.text לא-ריק בכרטיס = השם הנראה למשתמש (known-issues-log §18;
    אובייקט title בכרטיס לרוב מיותר). רווח-בלבד (' ') = הסתרה מכוונת, לא כותרת.
    תווית מותנית/מחושבת (Conditional) נחשבת קיימת."""
    for blk in ((vis.get('objects') or {}).get('label') or []):
        if not isinstance(blk, dict):
            continue
        t = ((blk.get('properties') or {}).get('text')) or {}
        if not isinstance(t, dict):
            continue
        try:
            if str(t['expr']['Literal']['Value']).strip("'").strip():
                return True
        except Exception:
            if t.get('expr'):
                return True
    return False


def _title_shown_off(raw):
    """title כבוי מפורשות ב-visualContainerObjects.title."""
    vco = _dct(_dct(raw).get('visual')).get('visualContainerObjects') or {}
    for blk in vco.get('title') or []:
        props = (blk or {}).get('properties') or {}
        show = props.get('show')
        lit = _literal(show) if isinstance(show, dict) else show
        if lit is not None and str(lit).strip().lower() in ('false', '0'):
            return True
    return False


def _paragraph_list(props):
    """שליפת paragraphs של textbox כרשימה. שתי צורות חוקיות ב-PBIR
    (כשל שדה 14.9 — crash בסשן המשתמש): מערך native, או expr-Literal שבתוכו
    מחרוזת JSON (Desktop כותב את שתיהן). מחזיר רשימה (ריקה אם לא ניתן לפרסר)."""
    pars = (props or {}).get('paragraphs')
    if isinstance(pars, list):
        return pars
    if isinstance(pars, dict):
        val = _literal(pars)
        if isinstance(val, str):
            try:
                out = json.loads(val)
                return out if isinstance(out, list) else []
            except (ValueError, TypeError):
                return []
    return []


def _solid_fill_color(obj_list):
    """צבע מילוי solid מבלוק objects (fill/background). מכבד show=false.
    תומך במפתחות color/fillColor (צורות כותבות fillColor — נצפה בפרויקט המשתמש 14.9)."""
    for blk in obj_list or []:
        props = (blk or {}).get('properties') or {}
        show = _literal(props.get('show'))
        if show is not None and str(show).lower() == 'false':
            continue
        for key in ('fillColor', 'color'):
            c = _any_color(props.get(key))
            if c:
                return c
    return None


def _rect(pos):
    try:
        return (float(pos.get('x') or 0), float(pos.get('y') or 0),
                float(pos.get('width') or 0), float(pos.get('height') or 0))
    except (TypeError, AttributeError):
        return (0.0, 0.0, 0.0, 0.0)


def _overlap(a, b):
    ix = max(0.0, min(a[0] + a[2], b[0] + b[2]) - max(a[0], b[0]))
    iy = max(0.0, min(a[1] + a[3], b[1] + b[3]) - max(a[1], b[1]))
    return ix * iy


def _textbox_bg(p, v, page_bg):
    """הרקע שהטקסט באמת נשען עליו (סבב 133): מילוי משלו → הצורה העליונה ביותר
    מתחתיו (z נמוך יותר, חפיפה גאומטרית; PBIR מערם לפי z) → רקע הדף.
    בלעדיו 47 הקריטים על הפרויקט האמיתי היו רעש: הטקסט הלבן יושב על צורות
    צבעוניות, לא על רקע הדף (מקור הסמנטיקה: microsoft/skills-for-fabric
    textbox.md, MIT — textbox = כותרות/הערות מעל אלמנטי עיצוב)."""
    raw = _dct(v['raw'])
    vis = _dct(raw.get('visual'))
    own = _solid_fill_color(_dct(vis.get('objects')).get('background'))
    if own:
        return own, 'מילוי ה-textbox'
    tpos = _dct(raw.get('position'))
    tz = float(tpos.get('z') or 0)
    best = None
    for o in p['visuals']:
        if o is v or o['hidden'] or o['type'] not in ('shape', 'basicShape'):
            continue
        oraw = _dct(o['raw'])
        opos = _dct(oraw.get('position'))
        oz = float(opos.get('z') or 0)
        if oz >= tz:
            continue
        if _overlap(_rect(tpos), _rect(opos)) <= 0:
            continue
        c = _solid_fill_color(_dct(_dct(oraw.get('visual')).get('objects')).get('fill'))
        if c and (best is None or oz > best[1]):
            best = (c, oz)
    if best:
        return best[0], 'צורה מתחת לטקסט'
    return page_bg, 'רקע הדף'


def check_a11y(rep):
    pages = rep['pages']

    # A11Y-01 · ניגודיות foreground/background של ה-theme (WCAG SC 1.4.3)
    if rep.get('theme_bg') and rep.get('theme_fg'):
        ratio = _contrast(rep['theme_fg'], rep['theme_bg'])
        if ratio < 4.5:
            sev = 'crit' if ratio < 3.0 else 'warn'
            add('A11Y-01', sev, 'נגישות', ', '.join(rep['themes']) or 'theme',
                'ניגודיות טקסט/רקע של ה-theme %.2f:1 (נדרש 4.5:1)' % ratio,
                'ה-foreground (%s) על ה-background (%s) של ה-theme נותן %.2f:1. זה ברירת '
                'המחדל של כל הטקסטים בדוח — כשהיא נמוכה, כל כותרת ותווית נפגעות. '
                '(WCAG 2.1 SC 1.4.3 — AA דורש 4.5:1 לטקסט רגיל, 3:1 לטקסט גדול.)'
                % (rep['theme_fg'], rep['theme_bg'], ratio),
                'לכהות/להבהיר את foreground או background בקובץ ה-theme. לבדוק מחדש אחרי '
                'השינוי — הבדיקה דטרמיניסטית. מקור: W3C WCAG 2.1; pbiaudits.com theme audit.')

    # A11Y-02 · ניגודיות טקסט של textbox מול הרקע שהוא נשען עליו בפועל
    for p in pages:
        page_bg, assumed = _page_bg(p, rep)
        for v in p['visuals']:
            if v['type'] != 'textbox' or v['hidden']:
                continue
            bg, bg_src = _textbox_bg(p, v, page_bg)
            worst = None
            for r in _text_runs(v['raw']):
                style = r.get('textStyle') or {}
                c = _any_color(style.get('color'))
                if not c:
                    continue
                ratio = _contrast(c, bg)
                if ratio < 4.5 and (worst is None or ratio < worst[0]):
                    worst = (ratio, c)
            if worst:
                ratio, c = worst
                sev = 'crit' if ratio < 3.0 else 'warn'
                add('A11Y-02', sev, 'נגישות',
                    "textbox בדף '%s'" % (p['name'] or p['id'][:8]),
                    'טקסט %s על רקע %s — ניגודיות %.2f:1' % (c, bg, ratio),
                    'run של טקסט ב-textbox עם צבע מפורש שנוגע בקשה בקריאה מול %s%s. '
                    '(WCAG SC 1.4.3 — 4.5:1 ל-AA.)' % (bg_src, ' (הנחה: לבן — לא הוגדר רקע מפורש)' if assumed and bg_src == 'רקע הדף' else ''),
                    'לבחור צבע טקסט עם ניגודיות >= 4.5:1 מול הרקע, או להסיר את העקיפה ולתת '
                    'ל-theme לשלוט. מקור: W3C WCAG 2.1; pbir-a11y contrast check.')

    # A11Y-10 · טקסט עברי מיושר שמאל מפורשות (RTL שבור)
    # (נמצא על 5 הדשבורדים השבורים: horizontalTextAlignment: left ב-textbox עברי,
    #  alignment: left בכותרות ויזואלים עבריות)
    _heb = re.compile(r"[\u0590-\u05FF]")
    def _lit_val(x):
        return _literal(x) if isinstance(x, dict) else x
    for p in pages:
        left_tb, left_ti = 0, 0
        for v in p['visuals']:
            if v['hidden']:
                continue
            if v['type'] == 'textbox':
                for o in (_dct(_dct(v['raw']).get('visual')).get('objects') or {}).get('general') or []:
                    for par in _paragraph_list((o or {}).get('properties')):
                        runs = (par or {}).get('textRuns') or []
                        txt = ''.join(str(r.get('value', '')) for r in runs if isinstance(r, dict))
                        if _heb.search(txt) and str((par or {}).get('horizontalTextAlignment', '')).lower() == 'left':
                            left_tb += 1
                            break
            vco = _dct(_dct(v['raw']).get('visual')).get('visualContainerObjects') or {}
            for blk in vco.get('title') or []:
                props = (blk or {}).get('properties') or {}
                tval = _lit_val(props.get('text')) or ''
                aval = str(_lit_val(props.get('alignment')) or '').lower()
                if aval == 'left' and _heb.search(str(tval)):
                    left_ti += 1
        if left_tb or left_ti:
            parts = []
            if left_tb:
                parts.append('%d textbox' % left_tb)
            if left_ti:
                parts.append('%d כותרות ויזואלים' % left_ti)
            add('A11Y-10', 'warn', 'נגישות', "דף '%s'" % (p['name'] or p['id'][:8]),
                'טקסט עברי מיושר שמאל מפורשות: %s' % ' + '.join(parts),
                'עברית נקראת מימין לשמאל; יישור שמאל מפורש על טקסט עברי שובר את '
                'סדר הקריאה, חותך ניקוד/סימני פיסוק לקצה הלא נכון ונראה זר. מקור: '
                'W3C Internationalization — RTL text basics; מוסכמת BI בעברית.',
                "לשנות ל-right (או להסיר את העקיפה ולתת לזיהוי השפה לעבוד). לבדוק "
                "שאר הדפים — בדרך כלל זה עקבי בכל הדוח.")
        # A11Y-11 · ויזואל נתונים בלי אובייקט title בכלל — כותרת אוטומטית משם שדה
    # (נמצא על 5 השבורים: כרטיס/gauge/גרף/multiRowCard בלי title מפורש)
    for p in pages:
        nt = [v for v in p['visuals']
              if v['type'] not in DECOR and v['type'] != 'textbox' and not v['hidden']
              and not (_dct(_dct(v['raw']).get('visual')).get('visualContainerObjects') or {}).get('title')
              and not (v['type'] in _CARD_LABEL_TYPES
                       and _card_label_shown(_dct(_dct(v['raw']).get('visual'))))]
        if len(nt) >= 2:
            add('A11Y-11', 'tip', 'נגישות', "דף '%s'" % (p['name'] or p['id'][:8]),
                '%d ויזואלים בלי כותרת מפורשת' % len(nt),
                'בלי אובייקט title הכותרת נגזרת אוטומטית משמות שדות ומדדים — לעית '
                'קרובות שמות טכניים באנגלית, ובכרטיסים היא עלולה להיעלם לגמרי. '
                'קורא מסך מסתמך על הכותרת כנקודת עיגון. (משלים A11Y-06 שתופס '
                'title כבוי מפורש.)',
                'להגדיר title מפורש בעברית לכל ויזואל נתונים. מקור: pbir-a11y '
                'missing-title; PBI-Inspector.')

    # A11Y-12 · רקע דף כהה מפורש עם טקסט ברירת-מחדל כהה — הטקסט נבלע
    # (נמצא על 5 השבורים: דף 2 רקע #1F1F1F על theme ברירת-מחדל עם טקסט כהה)
    fg_lum = _luminance(rep['theme_fg']) if rep.get('theme_fg') else None
    for p in pages:
        bg, assumed = _page_bg(p, rep)
        if assumed or _luminance(bg) >= 0.35:
            continue
        # ברירת המחדל של Power BI לטקסט היא כהה (#252423) — theme_fg חסר = כהה
        if fg_lum is not None and fg_lum >= 0.5:
            continue
        add('A11Y-12', 'warn', 'נגישות', "דף '%s'" % (p['name'] or p['id'][:8]),
            'רקע דף כהה (%s) עם טקסט ברירת-מחדל כהה' % bg,
            'הדף מגדיר רקע כהה מפורש, אבל צבע הטקסט המשתקף (theme foreground או '
            'ברירת המחדל של Power BI) כהה גם הוא — כותרות ותוויות ברירת-מחדל '
            'ייבלעו ברקע. (WCAG SC 1.4.3.)',
            'להגדיר foreground בהיר ב-theme או לעקוף צבעי טקסט בדף הזה; לוודא '
            'ניגודיות >= 4.5:1. מקור: W3C WCAG 2.1.')


    # A11Y-13 · ויזואל תמונה בלי alt text — לקורא מסך אין מה לומר על התמונה
    # (W3C WCAG 2.1 SC 1.1.1: תוכן לא-טקסטואלי דורש חלופה טקסטואלית. משלים את
    #  RPT-05 שמכסה ויזואלי נתונים — תמונות יושבות ב-DECOR ומחוץ לטווח שלו.)
    for p in pages:
        imgs = [v for v in p['visuals']
                if v['type'] == 'image' and not v['hidden']
                and not _has_alt_text(_dct(v['raw']).get('visual'))]
        if imgs:
            add('A11Y-13', 'tip', 'נגישות', "דף '%s'" % (p['name'] or p['id'][:8]),
                '%d ויזואלי תמונה בלי alt text' % len(imgs),
                'תמונה בלי חלופה טקסטואלית מוכרזת בקורא מסך כ"תמונה" בלבד — בלי '
                'תוכן, תפקיד או מקור. ויזואלי נתונים מכוסים ב-RPT-05 (וסובלים '
                'הכרזה אוטומטית מסוג/כותרת); לתמונה אין כיסוי כזה. לתמונה '
                'דקורטיבית בלבד — אין ב-Power BI סימון "דקורטיבי", ו-alt text '
                'קצר הוא המנוף היחיד. (WCAG 2.1 SC 1.1.1 — רמה A.)',
                'להגדיר alt text תמציתי ב-Format > General > Alt text. מקור: '
                'W3C WCAG 2.1 Understanding SC 1.1.1 (W3C Document License — '
                'עקרון בלבד); MS Learn accessibility.')

    # A11Y-03 · tabOrder כפול בדף
    for p in pages:
        vs = [v for v in p['visuals'] if not v['hidden']]
        orders = [v['tabOrder'] for v in vs if v['tabOrder'] is not None]
        # ערכים שליליים מוחרגים (סבב 92): Desktop כותב סכינת שלילית (~-9.99e6)
        # לוויזואל שהמחבר הוציא מסדר ה-tab בכוונה — פרקטיקה מומלצת לאלמנטים
        # דקורטיביים (MS Learn desktop-accessibility-creating-reports:
        # "remove those elements from the tab order"), לא סדר טאב שבור.
        nums = [o for o in orders if isinstance(o, (int, float)) and o >= 0]
        # דדופ מול RPT-06: אם כל הערכים זהים (למשל כולם 0) — RPT-06 כבר מדווח
        # "סדר טאב לא הוגדר"; A11Y-03 מיועד לכפילות *חלקית*
        dup = sorted(o for o, c in collections.Counter(nums).items()
                     if c > 1 and len(set(nums)) > 1)
        if dup:
            add('A11Y-03', 'warn', 'נגישות', "דף '%s'" % (p['name'] or p['id'][:8]),
                'סדר טאב שבור — ערכים כפולים: %s' % ', '.join('%g' % d for d in dup[:5]),
                'tabOrder כפול הופך את ניווט המקלדת לבלתי צפוי — קורא מסך לא יודע '
                'לאן הקפיצה הבאה. (משלים את RPT-06 שתופס "לא הוגדר בכלל". ערכים '
                'שליליים אינם ממצא: הוצאה מכוונת מסדר ה-tab.)',
                'להקצות tabOrder ייחודי לכל ויזואל לפי סדר קריאה. מקור: Microsoft '
                'accessibility; pbir-a11y tab-order check.')

    # A11Y-04 · אלמנט אינטראקטיבי קטן מ-24×24px (WCAG 2.2 SC 2.5.8)
    for p in pages:
        small = []
        for v in p['visuals']:
            if v['hidden']:
                continue
            interactive = v['type'] in ('slicer', 'actionButton') or 'button' in v['type'].lower()
            if interactive and v['w'] is not None and v['h'] is not None:
                if v['w'] < 24 or v['h'] < 24:
                    small.append('%s (%gx%g)' % (v['type'], v['w'], v['h']))
        if small:
            add('A11Y-04', 'warn', 'נגישות', "דף '%s'" % (p['name'] or p['id'][:8]),
                '%d אלמנטים אינטראקטיביים קטנים מ-24×24px' % len(small),
                'מטרות לחיצה מתחת ל-24×24 פיקסלים (יחידות הקנבס של PBIR ≈ px) קשות לפגיעה '
                'במגע ובעכבר לא מדויק: %s. (WCAG 2.2 SC 2.5.8 — Target Size Minimum.)'
                % ', '.join(small[:4]),
                'להגדיל ל-24×24 לפחות, או לרווח מספיק סביב מטרה קטנה. מקור: W3C WCAG 2.2; '
                'pbir-a11y target-size check.')

    # A11Y-09 · מטרת מגע קטנה מ-44px בפריסת מובייל (mobile.json)
    # (lukasreese.com — Power BI Dashboard Design Best Practices: במובייל יעדי מגע של
    # 44px לפחות; A11Y-04 בודק 24px בדסקטופ — כאן הפריסה הניידת, שבה האצבע פחות מדויקת)
    for p in pages:
        small_m = []
        for v in p['visuals']:
            if v['hidden'] or not v.get('mob'):
                continue
            interactive = v['type'] in ('slicer', 'actionButton') or 'button' in v['type'].lower()
            mw, mh = v['mob']
            if interactive and (mw < 44 or mh < 44):
                small_m.append('%s (%gx%g)' % (v['type'], mw, mh))
        if small_m:
            add('A11Y-09', 'tip', 'נגישות', "דף '%s'" % (p['name'] or p['id'][:8]),
                '%d מטרות מגע קטנות מ-44px בפריסת המובייל' % len(small_m),
                'בפריסת הנייד, אלמנטים אינטראקטיביים מתחת ל-44px קשים ללחיצה באצבע: %s. '
                'הסף של הדסקטופ (24px, WCAG 2.5.8) נמוך מדי למסך מגע.' % ', '.join(small_m[:4]),
                'להגדיל ל-44px לפחות בפריסת המובייל. מקור: lukasreese.com — Power BI '
                'Dashboard Design Best Practices (mobile touch targets); Apple HIG.')

    # A11Y-05 · fontSize מפורש מתחת ל-9pt
    for p in pages:
        tiny = []
        for v in p['visuals']:
            if v['hidden']:
                continue
            m = _min_font_size(v['raw'])
            if m is not None and m < 9:
                tiny.append('%s (%gpt)' % (v['type'], m))
        if tiny:
            add('A11Y-05', 'tip', 'נגישות', "דף '%s'" % (p['name'] or p['id'][:8]),
                '%d ויזואלים עם גופן מפורש מתחת ל-9pt' % len(tiny),
                'גופן מתחת ל-9pt בערך (מינימום קריאות מקובל לתוויות דוח): %s.'
                % ', '.join(tiny[:5]),
                'להעלות ל-9pt ומעלה דרך textClasses ב-theme. מקור: pbir-a11y font-scaling; '
                'Microsoft accessibility.')

    # A11Y-06 · כותרת כבויה בוויזואל נתונים
    for p in pages:
        off = [v for v in p['visuals']
               if v['type'] not in DECOR and not v['hidden'] and _title_shown_off(v['raw'])]
        if off:
            add('A11Y-06', 'tip', 'נגישות', "דף '%s'" % (p['name'] or p['id'][:8]),
                '%d ויזואלי נתונים עם כותרת כבויה' % len(off),
                'כותרת היא נקודת הייחוס הראשונה של הקורא. כיבוי לגיטימי רק כש-textbox סמוך '
                'משמש כותרת — אחרת הוויזואל "צף" בלי הקשר. (מועמד — לוודא מול הקובץ.)',
                'אם יש textbox-כותרת סמוך — לתעד; אחרת להפעיל title. מקור: pbir-a11y '
                'missing-title; PBI-Inspector.')

    # A11Y-07 · עומס ויזואלים בדף (clutter)
    for p in pages:
        n = len([v for v in p['visuals'] if not v['hidden']])
        if n > 10:
            add('A11Y-07', 'tip', 'נגישות', "דף '%s'" % (p['name'] or p['id'][:8]),
                '%d ויזואלים בדף אחד (עומס קוגניטיבי)' % n,
                'מעל ~10 ויזואלים על קנבס אחד, קורא מסך ומקלדת עוברים רצף ארוך, והעין מתקשה '
                'למצוא עוגן. (clutter index — pbir-a11y.)',
                'לפצל לדפים לפי שאלה עסקית, או להעביר פירוט ל-drill-through (§14). מקור: '
                'pbir-a11y clutter; PBI-Inspector VisOps.')

    # A11Y-08 · פלטת theme ללא פיזור בהירות (CVD/גווני אפור)
    cols = [c for c in rep.get('theme_data_colors', []) if _hex_norm(c)]
    if len(cols) >= 4:
        lums = [_luminance(c) for c in cols]
        spread = max(lums) - min(lums)
        if spread < 0.15:
            add('A11Y-08', 'tip', 'נגישות', ', '.join(rep['themes']) or 'theme',
                'פלטת dataColors ללא פיזור בהירות (טווח %.2f)' % spread,
                'כל %d צבעי הסדרות ב-theme יושבים בטווח בהירות של %.2f בלבד. לצופה עם '
                'עיוורון צבעים (ובהדפסה שחור-לבן) הסדרות מתמזגות — הצבע הוא הערוץ היחיד '
                'שמבדיל ביניהן.' % (len(cols), spread),
                'לבחור פלטה עם פיזור בהירות מובנה (viridis/cividis) או CVD-בטוחה '
                '(Okabe-Ito), ולהוסיף ערוץ שני (תווית/צורה). מקור: ColorBrewer; '
                'pbir-a11y CVD guidance.')


def check_local_artifacts(report_dir, model_dir):
    """RPT-21 · קבצי cache/local שנשארו בתיקיית הפרויקט (דליפת נתונים/נתיבים ל-Git)."""
    hits = []
    for base, label in ((report_dir, 'דוח'), (model_dir, 'מודל')):
        if not base or not os.path.isdir(base):
            continue
        for root, dirs, files in os.walk(base):
            rel = os.path.relpath(root, base)
            for f in files:
                low = f.lower()
                if low == 'localsettings.json' or low.endswith('.abf') or low == 'editorsettings.json':
                    hits.append('%s: %s' % (label, os.path.join(rel, f)))
    if hits:
        has_cache = any('.abf' in h for h in hits)
        add('RPT-21', 'warn' if has_cache else 'tip', 'דוח',
            '%d פריטים' % len(hits),
            'קבצי cache/הגדרות מקומיות בתיקיית הפרויקט',
            'נמצאו: %s. cache.abf מכיל **מטמון נתונים אמיתי** ו-localSettings.json נתיבים '
            'מקומיים — אם התיקייה הזו נכנסת ל-Git, זו דליפת נתונים/מידע. (§12 — אבטחת מידע.)'
            % '; '.join(hits[:5]),
            'להוסיף ל-.gitignore: .pbi/, *.abf, localSettings.json — ולמחוק מהמעקב אם כבר '
            'הוכנסו. מקור: PBIP Doctor git rules; Microsoft PBIP git integration docs.')


# ══════════════════════════ ציון + פלט ══════════════════════════
def health_score():
    """ציון היוריסטי שקוף: 100 פחות קנס לכלל (מכסה של 3 מופעים לכלל), רצפה 0.
    נועד למעקב בין ביקורות, לא לשיפוט מוחלט. ממצאים בודאות נמוכה (FP ידוע,
    cross-cutting #5) משוקללים במחצית הקנס — עדיין מופיעים ברשימה."""
    pen = {"crit": 8, "warn": 3, "tip": 1}
    per_rule = collections.defaultdict(int)
    total = 0.0
    for f in _FINDINGS:
        per_rule[f['rule']] += 1
        if per_rule[f['rule']] <= 3:
            w = 0.5 if f.get('confidence') == 'low' else 1.0
            total += pen[f['severity']] * w
    return max(0, int(round(100 - total)))


def render_text():
    L = []
    A = L.append
    cnt = collections.Counter(f['severity'] for f in _FINDINGS)
    A('# בדיקות דטרמיניסטיות (pbi_check) — BPA אופליין')
    A('')
    n_low = len([f for f in _FINDINGS if f.get('confidence') == 'low'])
    low_note = ' · מתוכם %d בודאות נמוכה (FP ידוע, מחצית-קנס בציון)' % n_low if n_low else ''
    A('ממצאים: %d · 🔴 %d · 🟡 %d · 🟢 %d · ציון בריאות (היוריסטי): **%d/100**%s'
      % (len(_FINDINGS), cnt['crit'], cnt['warn'], cnt['tip'], health_score(), low_note))
    A('החומרות הן הצעה — הסיווג הסופי לפי הצ\'קליסט. כל ממצא הוא מועמד: מאמתים מול הקובץ לפני דיווח.')
    A('')
    for cat in ('מודל', 'DAX', 'דוח', 'נגישות', 'עיצוב'):
        fs = [f for f in _FINDINGS if f['category'] == cat]
        if not fs:
            continue
        A('## %s (%d)' % (cat, len(fs)))
        for f in sorted(fs, key=lambda x: ({'crit': 0, 'warn': 1, 'tip': 2}[x['severity']], x['rule'])):
            conf_note = ''
            if f.get('confidence') == 'low':
                conf_note = ' · ⚠️ ודאות נמוכה (FP ידוע: %s)' % LOW_CONFIDENCE.get(f['rule'], '')
            A('- **[%s] %s %s** — %s%s' % (f['rule'], SEV[f['severity']], f['title'], f['location'], conf_note))
            A('  - למה: %s' % f['detail'])
            A('  - תיקון: %s' % f['fix'])
        A('')
    if not _FINDINGS:
        # סבב 92+: כשחלק מהבדיקות דולגו (למשל פריסת PBIP מדור קודם) — ציון 100
        # עם "לא נמצאו ליקויים" מטעה; לומר במפורש שהכיסוי חלקי.
        A('הסריקה כיסתה חלק מהבדיקות בלבד — ראה הערות הדילוג למעלה.'
          if _PARTIAL else 'לא נמצאו ליקויים דטרמיניסטיים. ✅')
    return '\n'.join(L)


# ══════════════════════════ מפל עיצוב theme (ADV-26/27) ══════════════════════════
# סבב 125 · מקור: data-goblin/power-bi-agentic-development modifying-theme-json
# (GPL-3.0, v26.31.0 — אימוץ רעיון בלבד): מפל העיצוב הוא
# ברירות-מחדל ← theme wildcard ← theme visualTypes ← overrides ב-visual.json.
# override שחוזר זהה על ויזואלים רבים או ששווה לערך שה-theme כבר נותן = רכיב
# שמקומו ב-theme; הוא חוסם שינוי theme עתידי ומפזר את נקודת האמת.

_FMT_SKIP_PROPS = {'paragraphs', 'imageUrl', 'filter'}   # תוכן, לא עיצוב


def _fmt_val(v):
    """ערך עיצוב נורמלי להשוואה: פירוק expr Literal של PBIR ('#FFF', 8.5D, true),
    צבע solid, lowercase ל-hex. None = ביטוי/מבנה מורכב — לא משווים."""
    if isinstance(v, dict):
        if 'solid' in v and isinstance(v['solid'], dict):
            v = v['solid'].get('color')
        elif 'expr' in v and isinstance(v['expr'], dict):
            lit = v['expr'].get('Literal')
            if isinstance(lit, dict):
                v = lit.get('Value')
        if isinstance(v, dict):
            return None
    if isinstance(v, str):
        v = v.strip()
        if len(v) >= 2 and v.startswith("'") and v.endswith("'"):
            v = v[1:-1].replace("''", "'")
        if v.endswith('D') and v[:-1].replace('.', '').replace('-', '').isdigit():
            v = float(v[:-1])
        if isinstance(v, str):
            lv = v.lower()
            if lv == 'true':
                return True
            if lv == 'false':
                return False
            if v.startswith('#'):
                return lv
        return v
    if isinstance(v, bool):
        return v
    if isinstance(v, (int, float)):
        return float(v)
    return None


def check_theme_cascade(rep):
    """ADV-26 override זהה לערך ה-theme (רעש נטו) · ADV-27 אותו override חוזר על
    >=4 ויזואלים לא-דקורטיביים (מקומו ב-theme). דילוג: רשומות עם selector
    (פורמט לפי סדרה = ספציפי לתוכן), מאפייני תוכן, ויזואלים דקורטיביים."""
    wild, typed = rep.get('theme_wild') or {}, rep.get('theme_typed') or {}
    redundant = {}   # (vtype, group, prop) -> [count, first_loc]
    repeats = collections.defaultdict(set)     # (group, prop, value) -> {visual keys}
    vis_pages = {}   # visual key -> page name (לציטוט)
    for p in rep.get('pages', []):
        for v in p['visuals']:
            if v['type'] in DECOR:
                continue
            key = "%s/%s" % (p['id'], v['id'])
            vis_pages[key] = p['name']
            raw_visual = v['raw'].get('visual')
            if not isinstance(raw_visual, dict):
                raw_visual = {}   # §16: visual כסקלר — לא מפיל את הבדיקה
            for g, entries in (raw_visual.get('objects') or {}).items():
                if not isinstance(entries, list):
                    continue
                for e in entries:
                    if not isinstance(e, dict) or e.get('selector'):
                        continue
                    for prop, val in (e.get('properties') or {}).items():
                        if prop in _FMT_SKIP_PROPS:
                            continue
                        nv = _fmt_val(val)
                        if nv is None:
                            continue
                        eff = typed.get((v['type'], g, prop), wild.get((g, prop)))
                        if eff is not None and eff == nv:
                            slot = redundant.setdefault((v['type'], g, prop), [0,
                                "דף '%s' ויזואל '%s'" % (p['name'] or p['id'][:8], v['id'])])
                            slot[0] += 1
                        else:
                            repeats[(g, prop, json.dumps(nv, ensure_ascii=False))].add(key)
    # ADV-26 · override זהה לערך שה-theme כבר מספק (מאוגד לפי סוג+קבוצה)
    by_vg = collections.defaultdict(lambda: [0, [], None])
    for (vt, g, prop), (count, loc) in sorted(redundant.items()):
        slot = by_vg[(vt, g)]
        slot[0] += count
        slot[1].append(prop)
        slot[2] = slot[2] or loc
    for (vt, g), (count, props, loc) in sorted(by_vg.items()):
        add('ADV-26', 'tip', 'עיצוב', loc,
            'overrides מיותרים ב-%s: %s זהים לערך ה-theme (×%d)' % (vt, ', '.join(props[:4]), count),
            'הוויזואלים קובעים במפורש ערכים זהים לזה שה-theme כבר מספק (wildcard או visualTypes). '
            'ה-overrides לא משנים דבר היום אבל ישברו שינוי theme עתידי — רעש נטו.',
            'להסיר את ה-overrides מה-visual.json ולתת ל-theme לשלוט. מקור הרעיון: '
            'data-goblin/power-bi-agentic-development modifying-theme-json (GPL-3.0) — מפל עיצוב.')
    # ADV-27 · אותו ערך חוזר על >=4 ויזואלים — מקומו ב-theme (ממצא יחיד לדוח)
    by_group = collections.defaultdict(list)
    for (g, prop, val), keys in sorted(repeats.items()):
        if len(keys) >= 4:
            by_group[g].append((prop, val, len(keys)))
    if by_group:
        ranked = sorted(by_group.items(), key=lambda kv: -max(c for _p, _v, c in kv[1]))
        examples = []
        for g, props in ranked[:4]:
            top = max(c for _p, _v, c in props)
            names = ', '.join('%s=%s' % (p, v) for p, v, _c in props[:3])
            examples.append('%s (×%d: %s)' % (g, top, names))
        add('ADV-27', 'tip', 'עיצוב', 'מפל עיצוב בכל הדוח',
            'עיצוב שחוזר זהה על ויזואלים רבים — מקומו ב-theme: %s' % '; '.join(examples),
            'אותם overrides מוחלים שוב ושוב על ויזואלים שונים (לרוב העתקות של ויזואל אחד). '
            'ברגע שהערך משתנה צריך לרדוף אחרי כל ויזואל בנפרד — סיבוך תחזוקה קלאסי. '
            'סה"כ %d קבוצות עיצוב עם חזרות.' % len(by_group),
            'לקדם את הערכים ל-theme (wildcard או visualStyles לפי סוג הוויזואל) ולהסיר את '
            'ה-overrides. מקור הרעיון: data-goblin/power-bi-agentic-development '
            'modifying-theme-json (GPL-3.0) — theme-first.')


# ══════════════════════════ בדיקת סטייה (drift) — מניפסט hashes ══════════════════════════
# סבב 126 · רעיון 3 מ-knoxgraeme/tieline (AGPL-3.0 — אימוץ רעיון בלבד, אפס ייבוא קוד):
# hash על הקבצים שחולצו, כדי לתפוס ממצאים שהישנו אחרי עריכות (למשל pbi_fix --apply).
# --manifest-out כותב מניפסט sha256 + תמונת ממצאים בסוף הרצה; --manifest-check משווה
# מניפסט ישן למצב הנוכחי — בדיקה זולה שאומרת אם הביקורת הקודמת עדיין בת-תוקף.

_MANIFEST_SCHEMA = 1


def _hash_tree(root, base):
    """{נתיב יחסי: sha256} לכל הקבצים תחת root (מיון דטרמיניסטי)."""
    files = {}
    for dp, dns, fns in os.walk(root):
        dns.sort()
        for fn in sorted(fns):
            fp = os.path.join(dp, fn)
            with open(fp, 'rb') as fh:
                files[os.path.relpath(fp, base)] = hashlib.sha256(fh.read()).hexdigest()
    return files


def _project_base(rp, sm):
    """שורש הפרויקט = ההורה המשותף של תיקיית הדוח והמודל."""
    cands = [os.path.dirname(os.path.abspath(d)) for d in (rp, sm) if d and os.path.isdir(d)]
    return os.path.commonpath(cands) if cands else None


def _scan_hashes(rp, sm, base):
    files = {}
    for d in (rp, sm):
        if d and os.path.isdir(d):
            files.update(_hash_tree(d, base))
    return files


def write_manifest(path, rp, sm):
    """מניפסט: hashes של כל הקבצים שהביקורת קראה + תמונת הממצאים הנוכחית."""
    base = _project_base(rp, sm)
    files = _scan_hashes(rp, sm, base)
    by_rule = collections.Counter(f['rule'] for f in _FINDINGS)
    import datetime
    doc = {
        'schema': _MANIFEST_SCHEMA,
        'created': datetime.datetime.now().isoformat(timespec='seconds'),
        'project_base': base,
        'report_dir': os.path.basename(rp.rstrip('/')) if rp else None,
        'model_dir': os.path.basename(sm.rstrip('/')) if sm else None,
        'files': files,
        'findings': dict(sorted(by_rule.items())),
        'total_findings': len(_FINDINGS),
    }
    with open(path, 'w', encoding='utf-8') as fh:
        json.dump(doc, fh, ensure_ascii=False, indent=1, sort_keys=True)
    return len(files)


def _drift_area(rel):
    if '.SemanticModel' in rel or '.Dataset' in rel:
        return 'מודל (MDL/DAX/PQ)'
    if 'StaticResources' in rel:
        return 'theme/עיצוב (ADV-26/27, RPT-01)'
    return 'דוח (RPT/ADV/A11Y)'


def drift_check(manifest_path, rp, sm):
    """משווה מניפסט ישן למצב הנוכחי. מדפיס דוח סטייה; מחזיר 0=נקי, 1=סטייה, 2=שגיאה."""
    try:
        with open(manifest_path, encoding='utf-8') as fh:
            old = json.load(fh)
    except Exception as e:
        print('שגיאה בקריאת מניפסט %s: %s' % (manifest_path, e))
        return 2
    if old.get('schema') != _MANIFEST_SCHEMA:
        print('סכמת מניפסט לא נתמכת: %s' % old.get('schema'))
        return 2
    base = _project_base(rp, sm)
    cur = _scan_hashes(rp, sm, base)
    prev = old.get('files') or {}
    changed = sorted(p for p in prev.keys() & cur.keys() if prev[p] != cur[p])
    added = sorted(cur.keys() - prev.keys())
    removed = sorted(prev.keys() - cur.keys())
    print('# בדיקת סטייה (drift) מול מניפסט מ-%s' % old.get('created', '?'))
    print('קבצים במניפסט: %d · כיום: %d · ממצאים בביקורת הקודמת: %d'
          % (len(prev), len(cur), old.get('total_findings', 0)))
    if not (changed or added or removed):
        print('\nללא שינויים — הביקורת הקודמת בת-תוקף.')
        return 0
    areas = collections.Counter()
    for p in changed + added + removed:
        areas[_drift_area(p)] += 1
    print('\nסטייה: %d שונו · %d נוספו · %d נמחקו' % (len(changed), len(added), len(removed)))
    print('אזורים מושפעים: ' + ', '.join('%s (%d)' % kv for kv in areas.most_common()))
    for label, lst in (('שונו', changed), ('נוספו', added), ('נמחקו', removed)):
        for p in lst[:10]:
            print('- %s: %s' % (label, p))
        if len(lst) > 10:
            print('- %s: עוד %d...' % (label, len(lst) - 10))
    print('\nממצאי הביקורת הקודמת עלולים להיות מיושנים — להריץ pbi_check מחדש.')
    return 1


# ══════════════════════════ אימות ציטוטים (VER) ══════════════════════════
# סבב 124 · "graded evidence verdicts" מתוך knoxgraeme/tieline (AGPL-3.0 —
# אימוץ רעיון בלבד, אפס ייבוא קוד; הסטאק שלהם TypeScript/tree-sitter/Postgres).
# כל ציטוט שכלל מפיק ב-location של ממצא חייב להתקיים בארטיפקטים שחולצו
# (דפים, ויזואלים, טבלאות, עמודות, מדדים). ציטוט בדקדק מוכר שלא נפתר =
# unsupported — זה באג בכלל עצמו, ומדווח כ-VER-01. location חופשי שלא תואם
# אף דקדק מהרשימה הסגורה אינו נכשל (לא מאומת ≠ שבור).

_VER_PAGE = re.compile(r"דף '([^']+)'")
_VER_VISID = re.compile(r"ויזואל '([^']+)'")
_VER_SLICER = re.compile(r"סליסר '([^']+)'")
_VER_TABLE = re.compile(r"טבלה '([^']+)'")
_VER_TEXTBOX = re.compile(r"textbox בדף '([^']+)'")
_VER_DISPN = re.compile(r"displayName '([^']+)'")
_VER_ARROW = re.compile(r'\s*(?:→|↔|←)\s*')
_VER_BRACKET = re.compile(r"^(.+?)\[([^\]]+)\]$")
_VER_HEB = re.compile(r'[\u0590-\u05ea]')


def _ver_unq(s):
    s = s.strip()
    if len(s) >= 2 and s.startswith("'") and s.endswith("'"):
        return s[1:-1].replace("''", "'")
    return s


def _ver_split_dotted(tok):
    """פיצול T.C על נקודה מחוץ למרכאות ('Dim Date'.Month מפולח לשני חלקים)."""
    parts, cur, inq = [], [], False
    i = 0
    while i < len(tok):
        ch = tok[i]
        if inq:
            cur.append(ch)
            if ch == "'":
                if tok[i + 1:i + 2] == "'":
                    cur.append("'")
                    i += 1
                else:
                    inq = False
        elif ch == "'":
            inq = True
            cur.append(ch)
        elif ch == '.':
            parts.append(''.join(cur))
            cur = []
        else:
            cur.append(ch)
        i += 1
    parts.append(''.join(cur))
    return parts


def _ver_resolve_vid(tok, ids):
    """מזהה ויזואל: התאמה מלאה, או קידומת חד-חד-ערכית (באנלוגיה ל-short hash של git —
    RPT-15/16 מצטטים v['id'][:12] לקריאות). קידומת דו-משמעית = ציטוט שבור."""
    if tok in ids:
        return True
    if len(tok) >= 8:
        hits = [i for i in ids if i.startswith(tok)]
        return len(hits) == 1
    return False


def _ver_resolve_ref(tok, tables, fields):
    """True = ההפניה נפתרה למודל; False = לא נפתרה; None = צורה לא מוכרת (מדולג)."""
    tok = tok.strip()
    if not tok:
        return None
    m = _VER_BRACKET.match(tok)
    if m:
        t, c = _ver_unq(m.group(1)), m.group(2).strip()
        return t in tables and c in fields.get(t, set())
    parts = _ver_split_dotted(tok)
    if len(parts) == 2 and all(p.strip() for p in parts):
        t, c = _ver_unq(parts[0]), _ver_unq(parts[1])
        return t in tables and c in fields.get(t, set())
    if len(parts) == 1:
        name = _ver_unq(tok)
        if name in tables:
            return True
        # שם שדה בלי טבלה (למשל סליסר שמצטט עמודה חד-חד-ערכית)
        return any(name in fset for fset in fields.values())
    return None


def verify_citations(rep, model):
    """מעבר אימות דטרמיניסטי על הציטוטים בכל הממצאים שנאספו (VER-01).
    rep/model יכולים להיות None כשהסריקה דילגה עליהם — הדקדקים התלויים מדולגים.
    מאגד לכל היותר ממצא VER-01 אחד לכל כלל שבור, כדי לא להציף את הדוח."""
    tables, fields = set(), {}
    if model:
        for t in model.get('tables', []):
            tables.add(t['name'])
            fields[t['name']] = ({c['name'] for c in t.get('columns', [])} |
                                 {m['name'] for m in t.get('measures', [])})
    pages, page_visuals, page_types, all_types = set(), {}, {}, set()
    if rep:
        for p in rep.get('pages', []):
            # A11Y-02 מצטט id[:8] כשאין displayName — כל צורות הזיהוי חוקיות
            ids = {p['id'], p['id'][:8]}
            for nm in {p['name']} | ids:
                if nm:
                    pages.add(nm)
                    # displayName כפול (RPT-19) — איחוד על פני כל הדפים בעלי השם,
                    # כי ציטוט לפי שם אינו מבדיל ביניהם (capital: שני דפי 'Brand Pulse')
                    page_visuals.setdefault(nm, set()).update(
                        {v['id'] for v in p['visuals']} | {v['vid'] for v in p['visuals']})
                    page_types.setdefault(nm, set()).update(v['type'] for v in p['visuals'])
            for v in p['visuals']:
                all_types.add(v['type'])
    broken = {}   # rule -> [finding, [ציטוטים שלא נפתרו], ספירה]
    for f in list(_FINDINGS):
        loc = f.get('location') or ''
        fails = []
        if rep:
            m = _VER_PAGE.search(loc)
            if m and m.group(1) not in pages:
                fails.append("דף '%s'" % m.group(1))
            m = _VER_VISID.search(loc)
            if m:
                pm = _VER_PAGE.search(loc)
                vid = m.group(1)
                if pm and pm.group(1) in pages and \
                        not _ver_resolve_vid(vid, page_visuals.get(pm.group(1), set())):
                    fails.append("ויזואל '%s'" % vid)
            m = _VER_TEXTBOX.search(loc)
            if m and m.group(1) in pages and 'textbox' not in page_types.get(m.group(1), set()):
                fails.append("textbox בדף '%s'" % m.group(1))
            m = _VER_DISPN.search(loc)
            if m:
                if m.group(1) not in pages:
                    fails.append("displayName '%s'" % m.group(1))
                else:
                    continue   # דקדק displayName מכסה את כל ה-location (לטיני טהור —
                             # בלי continue הוא היה נופל לדקדק ההפניות הגנרי)
        if model:
            m = _VER_SLICER.search(loc)
            if m and _ver_resolve_ref(m.group(1), tables, fields) is False:
                fails.append("סליסר '%s'" % m.group(1))
            m = _VER_TABLE.search(loc)
            if m and m.group(1) not in tables:
                fails.append("טבלה '%s'" % m.group(1))
        if fails:
            broken.setdefault(f['rule'], [f, fails, 0])[2] += 1
            continue
        # location ללא עברית — דקדקי הפניה מודל ורשימות סוגי ויזואלים
        if _VER_HEB.search(loc):
            continue
        if _VER_ARROW.search(loc):
            if model:
                sides = [s.strip() for s in _VER_ARROW.split(loc) if s.strip()]
                if sides and any(_ver_resolve_ref(s, tables, fields) is False for s in sides):
                    broken.setdefault(f['rule'], [f, ['הפניה בקשר: %s' % loc], 0])[2] += 1
        elif '×' in loc:
            if rep:
                miss = []
                for part in loc.split(','):
                    tname = re.sub(r'×\d+\s*$', '', part).strip()
                    if tname and tname not in all_types:
                        miss.append(tname)
                if miss:
                    broken.setdefault(f['rule'], [f, ['סוגי ויזואלים: %s' % ', '.join(miss)], 0])[2] += 1
        elif loc == 'SemanticModel' or not loc:
            continue   # תווית פסאודו מוסכמת / ממצא כללי בלי ציטוט
        elif model and ',' in loc:
            miss = [p.strip() for p in loc.split(',') if p.strip() and p.strip() not in tables]
            if miss:
                broken.setdefault(f['rule'], [f, ['טבלאות: %s' % ', '.join(miss)], 0])[2] += 1
        elif model:
            if _ver_resolve_ref(loc, tables, fields) is False:
                broken.setdefault(f['rule'], [f, ['הפניה: %s' % loc], 0])[2] += 1
    for rule, (f, fails, count) in sorted(broken.items()):
        add('VER-01', 'warn', 'ביקורת עצמית', f.get('location') or '',
            'ציטוט לא מאומת בממצא %s%s' % (rule, ' (+%d נוספים)' % (count - 1) if count > 1 else ''),
            'הממצא "%s" מצטט %s — שם שלא קיים בארטיפקטים שחולצו (דף/ויזואל/טבלה/שדה). '
            'ציטוט שבור מערער את אמינות הממצא; זהו באג בכלל %s עצמו, לא בדוח הנבדק. '
            'האימות דטרמיניסטי על רשימת דקדקי ציטוט סגורה.' % (f['title'], ', '.join(fails), rule),
            'לתקן את הכלל %s כך שיצטט שמות ומזהים כפי שהם בארטיפקטים בפועל. '
            'מקור הרעיון: knoxgraeme/tieline (AGPL-3.0) — דחייה דטרמיניסטית של ציטוטים שאינם קיימים.' % rule)


def main():
    ap = argparse.ArgumentParser(description='בדיקות BPA דטרמיניסטיות ל-PBIP/PBIR (אופליין, stdlib)')
    ap.add_argument('report', nargs='?', default=None)
    ap.add_argument('--model', default=None)
    ap.add_argument('--json', dest='as_json', action='store_true')
    ap.add_argument('--manifest-out', default=None, help='כותב מניפסט sha256 של הקבצים + תמונת ממצאים')
    ap.add_argument('--manifest-check', default=None, help='משווה מניפסט ישן למצב הנוכחי (בדיקת סטייה) ויוצא')
    a = ap.parse_args()
    rp = a.report
    sm = a.model
    if not rp and not sm:
        # סבב 150 (שדה סבב 2 #13): פרויקט ברמה העליונה קודם — גלוב רקורסיבי
        # עלול לקלוט וריאנט מקונן (demo2-variant/demo2.Report ממוין לפני
        # demo2.Report כי '-' < '.') ולסרוק את העותק במקום הפרויקט.
        c = sorted(glob.glob('*.Report')) or sorted(glob.glob('**/*.Report', recursive=True))
        rp = c[0] if c else None
        # סבב 88: גם *.Dataset (הסיומת הישנה של Semantic Model — עדיין בפרויקטים
        # אמיתיים, למשל NatVanG/fab-inspector Inventory sample). SemanticModel קודם.
        c = glob.glob('**/*.SemanticModel', recursive=True) or \
            glob.glob('**/*.Dataset', recursive=True)
        sm = sm or (c[0] if c else None)
    if a.manifest_check:
        sys.exit(drift_check(a.manifest_check, rp, sm))
    notes = []
    rep = None
    mdl = None
    if rp and not sm:
        notes.append('לא נמצאה תיקיית מודל (*.SemanticModel / *.Dataset) לצד הדוח — '
                     'בדיקות המודל (MDL/DAX/הפניות) דולגו.')
    if sm and os.path.isdir(sm):
        if os.path.isdir(os.path.join(sm, 'definition', 'tables')):
            mdl = read_model(sm)
            check_model(mdl)
        else:
            notes.append('המודל אינו בפורמט TMDL (אין definition/tables — ייתכן model.bim) — בדיקות המודל דולגו.')
    elif sm:
        notes.append('לא נמצאה תיקיית מודל: %s' % sm)
    if rp and os.path.isdir(rp):
        if os.path.isdir(os.path.join(rp, 'definition', 'pages')):
            rep = read_report(rp)
            check_report(rep)
            check_a11y(rep)
            check_design(rep, mdl if mdl else {'tables': []})
            check_time_axis(rep, mdl if mdl else {'tables': []}, sm)
            check_fake_nav(rep)
            check_filter_controls(rep)
            check_bucket_sort(rep, mdl if mdl else {'tables': []})
            check_theme_cascade(rep)
            check_local_artifacts(rp, sm if sm and os.path.isdir(sm) else None)
        else:
            notes.append('הדוח אינו בפורמט PBIR מפורק (אין definition/pages — ייתכן PBIR-Legacy) — בדיקות הדוח דולגו.')
    elif rp:
        notes.append('לא נמצאה תיקיית דוח: %s' % rp)
    verify_citations(rep, mdl)
    manifest_note = None
    if a.manifest_out:
        n = write_manifest(a.manifest_out, rp, sm)
        manifest_note = 'נכתב מניפסט סטייה: %s (%d קבצים).' % (a.manifest_out, n)
    if a.as_json:
        print(json.dumps({'notes': notes, 'score': health_score(), 'findings': _FINDINGS},
                         ensure_ascii=False, indent=1))
    else:
        global _PARTIAL
        _PARTIAL = bool(notes)
        for n in notes:
            print('⚠️ ' + n)
        print(render_text())
    if manifest_note:
        print(manifest_note)


if __name__ == '__main__':
    main()
