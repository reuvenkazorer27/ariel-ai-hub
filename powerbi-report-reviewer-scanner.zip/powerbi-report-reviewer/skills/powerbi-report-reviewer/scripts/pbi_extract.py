#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
pbi_extract.py — חילוץ תמצית מפרויקט PBIP/PBIR לצורך ביקורת.

למה: קריאת כל קובצי ה-visual.json והמודל ממלאת את חלון ההקשר (נמדד: 442KB ל-37 ויזואלים)
ומאטה את הריצה, בעוד שהבדיקות עצמן נוגעות רק בחלק קטן מהתוכן. הסקריפט מחלץ את מה שנבדק,
ומריץ את הבדיקות הצולבות (יישור, צפיפות, חפיפה) שאי אפשר לעשות קובץ-אחר-קובץ.

שימוש:
    python pbi_extract.py "<נתיב .Report>" [--model "<נתיב .SemanticModel>"] [--deep] [--json]

מצבים:
    ברירת מחדל  — תמצית + בדיקות רוחב (~5KB). מספיק לדוח מתחיל.
    --deep      — מוסיף חילוץ עמוק לכל ויזואל (query, כותרת, בלוקי עיצוב נבדקים,
                  ורשימת שמות שאר הבלוקים). ~55KB במקום 442KB. לדוח מתקדם.
    --json      — פלט JSON במקום טקסט.

ללא תלויות חיצוניות (stdlib בלבד).
"""
import json, os, sys, glob, argparse, collections

# ── בלוקי עיצוב שנבדקים בפועל בצ'קליסט §1–§22. שאר הבלוקים — רק השמות שלהם נשמרים.
KEEP_OBJECTS = {
    'title', 'general', 'labels', 'dataPoint', 'categoryAxis', 'valueAxis', 'legend',
    'background', 'border', 'visualHeader', 'wordWrap', 'values', 'columnHeaders',
    'total', 'subTotals', 'referenceLine', 'y1AxisReferenceLine', 'plotArea', 'text',
}
# ויזואלים שנושאים נתונים (נבדקים לעומק) מול ויזואלי עיצוב/ניווט
DECOR = {'image', 'shape', 'textbox', 'actionButton', 'pageNavigator', 'basicShape'}

# ── כללי דילוג במודל (רעש שנוצר אוטומטית)
SKIP_TABLE_PREFIXES = ('LocalDateTable_', 'DateTableTemplate_')


def load_json(path):
    """קריאה עמידה ל-BOM. קובצי PBIR עלולים להתחיל ב-\\ufeff (נמדד: 59 מתוך 105 קבצים
    בפרויקט אמיתי) — קורא utf-8 רגיל נחנק מזה. ראה known-issues-log §10."""
    with open(path, 'rb') as fh:
        return json.loads(fh.read().decode('utf-8-sig'))


def safe_int(v, default=0):
    """המרת מספר סלחנית — שדות position עלולים להגיע כמחרוזת/None בקובץ פגום
    (known-issues-log §16)."""
    try:
        return round(v)
    except Exception:
        return default


def literal(node):
    """שליפת ערך טקסט מביטוי PBIR (title.text וכדומה)."""
    try:
        return str(node[0]['properties']['text']['expr']['Literal']['Value']).strip("'")
    except Exception:
        return ''


_CARD_LABEL_TYPES = ('cardVisual', 'multiRowCard')


def label_text(v):
    """בכרטיסים השם הנראה למשתמש יושב ב-objects.label.text ולא ב-title —
    known-issues-log §18. תווית רווח-בלבד (' ') היא הסתרה מכוונת, לא כותרת."""
    for blk in v.get('objects', {}).get('label', []):
        t = literal([blk])
        if t.strip():
            return t
    return ''


def visual_title(v):
    """הכותרת יושבת ב-visualContainerObjects אצל רוב הוויזואלים, ולעיתים ב-objects.
    חובה לבדוק את שניהם — ראה known-issues-log §1. בכרטיסים (cardVisual/
    multiRowCard) הנפילבק הוא objects.label.text — §18."""
    t = literal(v.get('visualContainerObjects', {}).get('title', []))
    if not t:
        t = literal(v.get('objects', {}).get('title', []))
    if not t and v.get('visualType') in _CARD_LABEL_TYPES:
        t = label_text(v)
    return t


def fields_of(v):
    """זהות שדות מ-*.Property + Entity, לא מ-nativeQueryRef (known-issues-log §2)."""
    out = []
    def walk(o):
        if isinstance(o, dict):
            for kind in ('Measure', 'Column', 'Aggregation'):
                if kind in o and isinstance(o[kind], dict):
                    d = o[kind]
                    prop = d.get('Property')
                    ent = ''
                    try:
                        ent = d['Expression']['SourceRef'].get('Entity', '')
                    except Exception:
                        pass
                    if prop:
                        out.append(('%s[%s]' % (ent, prop)) if ent else str(prop))
            for val in o.values():
                walk(val)
        elif isinstance(o, list):
            for val in o:
                walk(val)
    walk(v.get('query', {}))
    seen, uniq = set(), []
    for f in out:
        if f not in seen:
            seen.add(f); uniq.append(f)
    return uniq


def detect_format(report_dir):
    """PBIR חדש (definition/pages/) מול ישן (report.json יחיד) — ראה pbip-structure.md.
    פלט שקט של '0 דפים' עלול להוליך את הסוכן למסקנה שגויה; לכן מזהים ומדווחים."""
    new_style = os.path.isdir(os.path.join(report_dir, 'definition', 'pages'))
    old_json = os.path.join(report_dir, 'report.json')
    if new_style:
        return 'pbir'
    if os.path.exists(old_json):
        return 'legacy'
    return 'unknown'


def deep_blocks(v, d, objs):
    """החילוץ העמוק לוויזואל אחד. גם מעטפת הוויזואל (visualContainerObjects) מסוננת
    לאותם בלוקים שנבדקים בצ'קליסט — 'title' תמיד נשמר כי בדיקת הכותרות היא חובה.
    שמות הבלוקים שסוננו נשמרים ב-containerObjectKeysAll, כדי שממצא שמצריך בלוק
    שאינו כאן יוביל לפתיחת הקובץ הבודד בלבד (אותו עקרון כמו objectKeysAll)."""
    vco = v.get('visualContainerObjects')
    return {
        'query': (v.get('query') or {}).get('queryState'),
        'containerObjects': ({k: val for k, val in vco.items() if k in KEEP_OBJECTS}
                             if isinstance(vco, dict) else vco),
        'containerObjectKeysAll': sorted(vco.keys()) if isinstance(vco, dict) else [],
        'objects': {k: val for k, val in objs.items() if k in KEEP_OBJECTS},
        'filters': d.get('filterConfig'),
    }


def read_report(report_dir, deep=False):
    """deep=True בונה גם את בלוקי החילוץ העמוק לכל ויזואל. במצב הרגיל הם לא נפלטים
    בכלל, ולכן אין טעם לבנות ולהחזיק אותם בזיכרון (queryState, מעטפת, פילטרים)."""
    pages = []
    page_dirs = sorted(glob.glob(os.path.join(report_dir, 'definition', 'pages', '*')))
    for pd in page_dirs:
        if not os.path.isdir(pd):
            continue
        pj = os.path.join(pd, 'page.json')
        name, disp, w, h = os.path.basename(pd), '', 1280, 720
        if os.path.exists(pj):
            try:
                p = load_json(pj)
                disp = p.get('displayName', '') or p.get('name', '')
                w = p.get('width', w) or w
                h = p.get('height', h) or h
            except Exception:
                pass
        vis = []
        for vf in sorted(glob.glob(os.path.join(pd, 'visuals', '*', 'visual.json'))):
            vid = os.path.basename(os.path.dirname(vf))
            # כל גוף הלולאה בתוך try: קובץ אחד פגום (אפילו JSON תקין בצורה לא
            # צפויה — §16) נרשם כשגיאה מובנית ולא מפיל את כל החילוץ.
            try:
                d = load_json(vf)
                if not isinstance(d, dict):
                    raise ValueError('JSON תקין אבל לא אובייקט (%s)' % type(d).__name__)
                v = d.get('visual', {})
                if not isinstance(v, dict):
                    v = {}
                pos = d.get('position', {})
                if not isinstance(pos, dict):
                    pos = {}
                objs = v.get('objects', {})
                if not isinstance(objs, dict):
                    objs = {}
                vname = d.get('name')
                item = {
                    'id': vname if isinstance(vname, str) else vid,  # §16: name מספרי → שם התיקייה
                    'type': v.get('visualType', 'group' if 'visualGroup' in d else '?'),
                    'x': safe_int(pos.get('x')), 'y': safe_int(pos.get('y')),
                    'w': safe_int(pos.get('width')), 'h': safe_int(pos.get('height')),
                    'z': safe_int(pos.get('z')),
                    'title': visual_title(v),
                    'fields': fields_of(v),
                    'hidden': bool(d.get('isHidden', False)),
                    'bytes': os.path.getsize(vf),
                    'objectKeys': sorted(objs.keys()),
                }
                if deep:
                    item['_deep'] = deep_blocks(v, d, objs)
            except Exception as e:
                vis.append({'error': '%s: %s' % (vid, e)})
                continue
            vis.append(item)
        pages.append({'id': name, 'name': disp, 'w': w, 'h': h, 'visuals': vis})
    return pages


def cross_checks(page):
    """הבדיקות שאי אפשר לעשות קובץ-אחר-קובץ: יישור, צפיפות, חפיפה, גדלים."""
    vs = [v for v in page['visuals'] if 'error' not in v and not v.get('hidden')]
    res = {}
    # חפיפות — עם הבחנה בין שכבות עיצוב מכוונות לבין חפיפת נתונים אמיתית
    real, decor = [], 0
    for i in range(len(vs)):
        for j in range(i + 1, len(vs)):
            a, b = vs[i], vs[j]
            dx = min(a['x'] + a['w'], b['x'] + b['w']) - max(a['x'], b['x'])
            dy = min(a['y'] + a['h'], b['y'] + b['h']) - max(a['y'], b['y'])
            if dx > 2 and dy > 2:
                if a['type'] in DECOR or b['type'] in DECOR:
                    decor += 1          # צורה/תמונה מאחורי פס — לרוב מכוון
                else:
                    real.append({'a': '%s "%s"' % (a['type'], a['title'][:20]),
                                 'b': '%s "%s"' % (b['type'], b['title'][:20]),
                                 'dx': int(dx), 'dy': int(dy),
                                 'z': '%d/%d' % (a['z'], b['z'])})
    res['overlaps_data'] = real
    res['overlaps_decor'] = decor
    # יישור — כמה עמודות/שורות שונות. הרבה ערכים = אין רשת
    res['x_values'] = len(set(v['x'] for v in vs))
    res['y_values'] = len(set(v['y'] for v in vs))
    res['n'] = len(vs)
    # צפיפות
    canvas = max(1, page['w'] * page['h'])
    res['coverage_pct'] = round(100.0 * sum(v['w'] * v['h'] for v in vs) / canvas)
    # גדלים ב-RTL (§22)
    res['small_cards'] = [{'title': v['title'][:24] or '(ללא כותרת)', 'w': v['w'], 'h': v['h']}
                          for v in vs if v['type'] == 'cardVisual' and (v['h'] < 110 or v['w'] < 200)]
    res['no_title'] = [v['type'] for v in vs if not v['title'] and v['type'] not in DECOR]
    res['tables'] = [v['title'][:24] or v['id'][:8]
                     for v in vs if v['type'] in ('tableEx', 'table', 'pivotTable')]
    # כותרות כפולות על תוכן שונה = "כותרת בהקשר שגוי" (נמצא בפועל: 3 כרטיסים "כמות שנתית"
    # שמציגים שלושה מדדים שונים). נראה רק כשמסתכלים על כל הדף יחד.
    by_title = collections.defaultdict(list)
    for v in vs:
        if v['title'] and v['type'] not in DECOR:
            by_title[v['title']].append(v)
    res['dup_titles'] = [
        {'title': t, 'count': len(g), 'fields': [', '.join(x['fields'][:2]) or '—' for x in g]}
        for t, g in by_title.items()
        if len(g) > 1 and len({tuple(x['fields']) for x in g}) > 1]
    return res


def read_model(model_dir):
    """קריאת מלאי המודל תוך דילוג על רעש אוטומטי — עם חריג התרגומים."""
    info = {'tables': [], 'skipped': [], 'cultures': None, 'relationships': 0}
    tdir = os.path.join(model_dir, 'definition', 'tables')
    for f in sorted(glob.glob(os.path.join(tdir, '*.tmdl'))):
        base = os.path.basename(f)
        if base.startswith(SKIP_TABLE_PREFIXES):
            info['skipped'].append(base + ' (טבלת תאריך אוטומטית)')
            continue
        try:
            txt = open(f, encoding='utf-8-sig').read()
        except Exception:
            continue
        lines = txt.splitlines()
        info['tables'].append({
            'file': base,
            'bytes': len(txt.encode('utf-8')),
            'measures': sum(1 for ln in lines if ln.strip().startswith('measure ')),
            'columns': sum(1 for ln in lines if ln.strip().startswith('column ')),
        })
    # cultures — לדלג, אלא אם יש בפנים תרגומים (שמות תצוגה) שרלוונטיים לביקורת עברית
    for f in glob.glob(os.path.join(model_dir, 'definition', 'cultures', '*.tmdl')):
        size = os.path.getsize(f)
        head = ''
        try:
            head = open(f, encoding='utf-8-sig', errors='ignore').read(200000)
        except Exception:
            pass
        has_tr = 'translation' in head
        info['cultures'] = {'file': os.path.basename(f), 'bytes': size, 'translations': has_tr}
    rf = os.path.join(model_dir, 'definition', 'relationships.tmdl')
    if os.path.exists(rf):
        info['relationships'] = sum(1 for ln in open(rf, encoding='utf-8-sig')
                                    if ln.strip().startswith('relationship '))
    return info


def render(pages, model, deep):
    L = []
    A = L.append
    total_bytes = sum(v.get('bytes', 0) for p in pages for v in p['visuals'])
    nvis = sum(len(p['visuals']) for p in pages)
    A('# תמצית פרויקט — לביקורת')
    A('')
    A('דפים: %d · ויזואלים: %d · נפח גולמי של קובצי הוויזואלים: %dKB'
      % (len(pages), nvis, total_bytes // 1024))
    types = collections.Counter(v['type'] for p in pages for v in p['visuals'] if 'error' not in v)
    A('סוגי ויזואלים: ' + ' · '.join('%s×%d' % (k, c) for k, c in types.most_common()))
    A('')
    for p in pages:
        c = cross_checks(p)
        A('## דף: %s (%s) — %d ויזואלים · קנבס %dx%d' %
          (p['name'] or p['id'], p['id'][:8], c['n'], p['w'], p['h']))
        A('')
        A('| סוג | x | y | רוחב | גובה | z | כותרת | שדות |')
        A('|---|---|---|---|---|---|---|---|')
        for v in p['visuals']:
            if 'error' in v:
                A('| ⚠️ שגיאת קריאה | | | | | | %s | |' % v['error']); continue
            A('| %s | %d | %d | %d | %d | %d | %s | %s |' % (
                v['type'], v['x'], v['y'], v['w'], v['h'], v['z'],
                v['title'] or '— (ללא) —',
                ', '.join(v['fields'][:4]) + ('…' if len(v['fields']) > 4 else '')))
        A('')
        A('**בדיקות רוחב (לא ניתנות לביצוע קובץ-אחר-קובץ):**')
        A('- כיסוי הקנבס: **%d%%** %s' % (c['coverage_pct'],
          '← עומס, שקול הסרה/דף נוסף' if c['coverage_pct'] > 75 else ''))
        A('- יישור: %d ערכי x שונים ו-%d ערכי y שונים ל-%d ויזואלים %s' %
          (c['x_values'], c['y_values'], c['n'],
           '← כמעט אין רשת יישור' if c['x_values'] > c['n'] * 0.6 else ''))
        if c['overlaps_data']:
            A('- ⚠️ **חפיפות בין ויזואלי נתונים: %d**' % len(c['overlaps_data']))
            for o in c['overlaps_data'][:6]:
                A('  - %s ↔ %s — חפיפה %dx%d פיקסלים (z=%s)' % (o['a'], o['b'], o['dx'], o['dy'], o['z']))
        else:
            A('- חפיפות בין ויזואלי נתונים: אין')
        A('- חפיפות שכוללות צורה/תמונה/ניווט: %d (לרוב שכבות מכוונות — לא לדווח בלי בדיקה)'
          % c['overlaps_decor'])
        if c['small_cards']:
            A('- ⚠️ כרטיסים מתחת לכלל §22 (גובה≥110 · רוחב≥200): %d' % len(c['small_cards']))
            for s in c['small_cards']:
                A('  - "%s" — %dx%d' % (s['title'], s['w'], s['h']))
        if c['no_title']:
            A('- ⚠️ ויזואלי נתונים ללא כותרת: %d (%s)' %
              (len(c['no_title']), ', '.join('%s×%d' % kv for kv in collections.Counter(c['no_title']).most_common())))
        if c['dup_titles']:
            A('- ⚠️ **כותרת זהה על תוכן שונה** (כותרת בהקשר שגוי): %d' % len(c['dup_titles']))
            for d in c['dup_titles']:
                A('  - "%s" ×%d — מציגים: %s' % (d['title'], d['count'], ' | '.join(d['fields'])))
        if c['tables']:
            A('- טבלאות/מטריצות (מועמדות ל-HTML Content ב-RTL): %s' % ', '.join(c['tables']))
        A('')
    if model:
        A('## מודל')
        A('טבלאות: %d · קשרים: %d · מדדים: %d · עמודות: %d' % (
            len(model['tables']), model['relationships'],
            sum(t['measures'] for t in model['tables']),
            sum(t['columns'] for t in model['tables'])))
        for t in model['tables']:
            A('- `%s` — %d מדדים, %d עמודות (%dKB)' %
              (t['file'], t['measures'], t['columns'], t['bytes'] // 1024))
        if model['skipped']:
            A('דולג: ' + ' · '.join(model['skipped']))
        cu = model['cultures']
        if cu:
            if cu['translations']:
                A('⚠️ `cultures/%s` מכיל בלוקי **translation** (שמות תצוגה מתורגמים) — **כן לקרוא אותו**.' % cu['file'])
            else:
                A('דולג: `cultures/%s` (%dKB) — מילון Q&A אוטומטי, ללא תרגומים.' % (cu['file'], cu['bytes'] // 1024))
        A('')
    if deep:
        A('## חילוץ עמוק לכל ויזואל')
        A('לכל ויזואל: השדות (query), מעטפת הוויזואל ובלוקי העיצוב הנבדקים, ורשימת שמות')
        A('שאר הבלוקים (objectKeysAll + containerObjectKeysAll). אם ממצא מחייב בלוק שאינו')
        A('כאן — פתח את הקובץ הבודד שלו בלבד.')
        A('')
        for p in pages:
            for v in p['visuals']:
                if 'error' in v:
                    continue
                d = dict(v.get('_deep') or {})
                d['objectKeysAll'] = v['objectKeys']
                A('### %s · %s · "%s"' % (p['name'] or p['id'][:8], v['type'], v['title'] or '(ללא כותרת)'))
                A('```json')
                A(json.dumps(d, ensure_ascii=False, separators=(',', ':')))
                A('```')
        A('')
    A('---')
    A('הופק ע"י pbi_extract.py · כללי דילוג: cultures (אלא אם translation), LocalDateTable_*,')
    A('DateTableTemplate_* · קריאה ב-utf-8-sig (עמידות ל-BOM).')
    return '\n'.join(L)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('report')
    ap.add_argument('--model', default=None)
    ap.add_argument('--deep', action='store_true')
    ap.add_argument('--json', dest='as_json', action='store_true')
    a = ap.parse_args()
    if not os.path.isdir(a.report):
        print('לא נמצאה תיקיית .Report: %s' % a.report); sys.exit(1)
    fmt = detect_format(a.report)
    if fmt != 'pbir':
        if fmt == 'legacy':
            print('⚠️ הדוח בפורמט PBIR ישן (report.json יחיד) — הסקריפט מנתח רק את הפורמט')
            print('   החדש (definition/pages/). קרא את report.json לפי references/pbip-structure.md')
            print('   ("פורמט ישן": sections[] / visualContainers[], config הוא JSON-מוקודד-כמחרוזת).')
        else:
            print('⚠️ לא נמצאו definition/pages/ ולא report.json — מבנה הדוח לא זוהה.')
            print('   ודא שהנתיב מצביע על תיקיית *.Report תקינה לפני שמסיקים "אין דפים".')
        print('')
    pages = read_report(a.report, deep=a.deep)
    model = read_model(a.model) if a.model and os.path.isdir(a.model) else None
    if a.as_json:
        for p in pages:
            p['checks'] = cross_checks(p)
        print(json.dumps({'pages': pages, 'model': model}, ensure_ascii=False, indent=1))
    else:
        print(render(pages, model, a.deep))


if __name__ == '__main__':
    main()
