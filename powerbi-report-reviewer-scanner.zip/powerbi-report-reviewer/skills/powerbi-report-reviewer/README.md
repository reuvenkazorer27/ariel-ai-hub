# סוקר דוחות Power BI — סוכן להתקנה

סוכן (Skill) ל-Claude שסוקר דוח Power BI בפורמט **PBIP/PBIR** ומחזיר **דוח ביקורת מסודר בעברית**:
הערכה כללית, מה עובד טוב, ממצאים לפי חומרה, ויזואלים מומלצים מהקטלוג, המלצות ניווט/תפריט צד,
בדיקת לוגו מחלקה/אוניברסיטה, אייקונים ל-KPI וערכת צבעים. עצמאי לחלוטין — ללא תלות ב-GitHub.

## התקנה (תיקיית skill)
העתיקו את התיקייה `powerbi-report-reviewer/` לאחד מהמיקומים:

- **לכל הפרויקטים (משתמש)**: `~/.claude/skills/powerbi-report-reviewer/`
- **לפרויקט בודד**: `<תיקיית-הפרויקט>/.claude/skills/powerbi-report-reviewer/`

(ב-Windows: `C:\Users\<שם>\.claude\skills\powerbi-report-reviewer\`.)

הפעילו מחדש את Claude / הסשן, והסוכן ייטען אוטומטית כשמבקשים ממנו לבקר דוח.

> מותקן גם כחבילת **`.plugin`** (ראה הקובץ `powerbi-report-reviewer.plugin`) — התקנה בקליק ב-Cowork.

## איך משתמשים
פתחו סשן, ציינו את תיקיית הפרויקט (או גררו קבצי PBIP), ובקשו למשל:

> "עבור על הדוח הזה ותן לי סיכום ביקורת" · "בקר לי את ה-PBIP" · "מה לשפר בדשבורד"

הסוכן יקרא את קבצי הדוח, ינתח, ויחזיר את דוח הביקורת בעברית.

## מבנה
```
powerbi-report-reviewer/
├── SKILL.md                         ← לוגיקת הסוכן (נטען אוטומטית)
├── README.md                        ← הקובץ הזה
└── references/
    ├── scope-and-safety.md          ← גבול תיקיית הפרויקט ואבטחת מידע (כלל קשיח)
    ├── pbip-structure.md            ← מבנה PBIP/PBIR: איפה מה, מה לחלץ
    ├── review-checklist-core.md     ← צ'קליסט §1–§12 (נטען תמיד)
    ├── review-checklist-advanced.md ← צ'קליסט §13–§22 (דוח מתקדם בלבד)
    ├── extraction-guide.md          ← מה לחלץ מכל קובץ (שלב 1)
    ├── (scripts/pbi_extract.py)     ← תמצית + בדיקות רוחב (יישור/צפיפות/חפיפה)
    ├── known-issues-log.md          ← יומן תקלות הסוכן (מסמך חי)
    ├── html-catalog-index.csv       ← אינדקס 44 הוויזואלים (במקום קריאת ה-HTML)
    ├── report-template.html         ← שלד עיצוב הדוח (CSS)
    ├── report-footer.html           ← סוגר + JS של כפתורי ההעתקה
    ├── report-assembly.md           ← הרכבת הדוח סעיף-אחר-סעיף
    ├── visual-catalog.md            ← 44 ויזואלים מהקטלוג + מתי להמליץ
    ├── navigation.md                ← תפריט צד/כפתורי ניווט: איך ואיפה
    ├── dax-patterns.md              ← DAX/מודל: בדיקות + תבניות מוכנות
    ├── theme-color-branding.md      ← 6 ערכות צבע, theme JSON, בדיקת לוגו
    ├── kpi-icons.md                 ← אייקונים ל-KPI + מימוש
    ├── html-content-visual.md       ← ויזואל HTML Content: מתי/איפה + מדדי DAX מוכנים
    ├── documentation-standard.md    ← תקן "תיק הדוח" ורמות תיעוד 1–3
    └── output-format.md             ← מבנה דוח הביקורת הסופי
```

## מקורות רעיוניים
נבנה בהשראת ההיקף של `odetma/Power-BI-Code` (DAX time-intelligence, טבלת תאריכים, מדדי HTML,
ביקורת דוחות, ערכות theme) ו-`microsoft/skills-for-fabric` (powerbi-authoring), וקטלוג הוויזואלים
המקומי `powerbi-html-catalog.html`. כל הידע מוטמע בסוכן — אין צורך בגישה למקורות בזמן ריצה.
