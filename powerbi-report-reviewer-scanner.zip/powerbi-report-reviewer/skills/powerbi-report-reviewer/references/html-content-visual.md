# ויזואל HTML Content — מתי להמליץ, איפה למקם, ומדד DAX מוכן

**שם מובנה / מרקטפלייס**: `HTML Content` (מאת Daniel Marsh-Patrick, מזהה: `htmlContent…` /
"HTML Content" ב-AppSource). ויזואל מותאם שמקבל **מדד יחיד שמחזיר מחרוזת HTML** ומרנדר אותה.
קיים גם `HTML Content (lite)` — קל יותר, ללא JS, מתאים לרוב מקרי ה-RTL.

## למה הוא קריטי בסביבה עברית (RTL)

הרכיבים המובנים של Power BI (בעיקר **Matrix/Table**) לא באמת תומכים ב-RTL מלא: יישור כותרות,
כיוון עמודות, סדר היררכיה ומיקום סמלים "נשברים" או מיושרים לשמאל. עם HTML Content אתה שולט
מלא ב-`dir="rtl"`, יישור, צבע מותנה, אייקונים ו-badges — ומקבל תצוגה עברית מדויקת.

## ★ כלל קבוע — מטריצה/טבלה שאינה HTML

**בכל דוח שבו מופיע `Matrix` (`pivotTable`) או `Table`/`tableEx` "רגיל" — המלץ תמיד להחליף
או לשכפל ל-HTML Content, בנימוק RTL.** זו לא המלצה מותנית: ציין את הדף והוויזואל המדויק, הסבר
שה-RTL נשבר במטריצה המובנית, וספק מדד HTML חלופי (ראה למטה). אם המשתמש רוצה לשמור את המטריצה
המקורית — המלץ HTML Content כתצוגה ראשית ומטריצה כ-drill-through.

## מתי עוד להמליץ (מעבר למטריצה)

- **כרטיסי KPI עשירים** — מספר + השוואה + חץ כיוון + אייקון בעברית, מיושר לימין, בכרטיס אחד.
- **טקסט מותנה / badge סטטוס** — "חריגה", "מתחת למינימום", "תקין" עם רקע צבעוני.
- **כותרת/כותרת-משנה מעוצבת RTL** — כשכותרת הוויזואל המובנית לא מיושרת נכון.
- **רשימות/טבלאות קצרות עם עיצוב** — פסי מלאי, מיני-בר, צבע לפי ערך.

## איפה למקם (בדוח שנבדק)

ציין תמיד מיקום קונקרטי: החלף את המטריצה/טבלה במקומה (אותו x/y/width/height), או מקם רצועת
KPI-HTML בראש הדף (מתחת לכותרת, ימין-עליון ב-RTL). לכרטיס HTML בודד — במקום `cardVisual` "יבש".

## מה הוא פותר (נסח את זה בדוח לכל המלצה)

לכל המלצת HTML Content כתוב שלושה דברים: (1) **הבעיה** (למשל "המטריצה בדף 'דוח מלאי' לא
מיושרת ל-RTL וכותרות העמודות נחתכות"); (2) **הפתרון** (מדד HTML שמרנדר טבלה `dir=rtl`); (3)
**המיקום** (איזה ויזואל מוחלף/היכן נוסף).

---

## מדד DAX מוכן #1 — כרטיס KPI ב-HTML (RTL, חץ כיוון, צבע מותנה)

```DAX
KPI_HTML_כמות_חודש =
VAR _cur   = [כמות חודש נוכחי]
VAR _prev  = [כמות חודש שעבר]
VAR _delta = DIVIDE(_cur - _prev, _prev)
VAR _color = IF(_delta < 0, "#D64550", "#1AAB40")
VAR _arrow = IF(_delta < 0, "▼", "▲")
RETURN
"<div dir='rtl' style=""font-family:Segoe UI;text-align:right;padding:8px"">" &
  "<div style=""font-size:13px;color:#6B7280"">כמות חודש נוכחי</div>" &
  "<div style=""font-size:28px;font-weight:600;color:#003C71"">" & FORMAT(_cur, "#,0") & "</div>" &
  "<div style=""font-size:12px;color:" & _color & """>" & _arrow & " " &
     FORMAT(_delta, "0.0%") & " מהחודש הקודם</div>" &
"</div>"
```

## מדד DAX מוכן #2 — החלפת מטריצה בטבלת HTML מיושרת RTL

מייצר טבלה עם `dir=rtl` על גבי כל שורה בממד (למשל מבנה/מוצר). התאם את שם הטבלה/העמודה והמדד:

```DAX
Table_HTML_מלאי =
VAR _rows =
    CONCATENATEX(
        VALUES('מוצרים'[שם מוצר]),
        VAR _qty = [כמות מלאי]
        VAR _min = [כמות מינ]
        VAR _bg  = IF(_qty < _min, "#FDE8E8", "#FFFFFF")
        RETURN
        "<tr style=""background:" & _bg & """>" &
          "<td style=""padding:4px 8px"">" & 'מוצרים'[שם מוצר] & "</td>" &
          "<td style=""padding:4px 8px;text-align:center"">" & FORMAT(_qty, "#,0") & "</td>" &
          "<td style=""padding:4px 8px;text-align:center"">" & FORMAT(_min, "#,0") & "</td>" &
        "</tr>",
        "",
        [כמות מלאי], DESC
    )
RETURN
"<table dir='rtl' style=""width:100%;font-family:Segoe UI;font-size:12px;border-collapse:collapse;text-align:right"">" &
  "<thead><tr style=""background:#003C71;color:#fff"">" &
    "<th style=""padding:6px 8px"">מוצר</th>" &
    "<th style=""padding:6px 8px"">כמות מלאי</th>" &
    "<th style=""padding:6px 8px"">מינימום</th>" &
  "</tr></thead><tbody>" & _rows & "</tbody></table>"
```

## הערות ומגבלות (ציין בדוח)

- הוויזואל מקבל **מדד יחיד** בשדה הערכים — כל הלוגיקה בתוך המדד.
- דורש התקנת הוויזואל המותאם (Import from AppSource) — ציין זאת כתנאי מוקדם.
- הימנע מ-JS/מקורות חיצוניים במחרוזת (אבטחה); העדף HTML+CSS מוטבע. השתמש ב-`HTML Content (lite)`
  אם ה-JS חסום בארגון.
- `""` כפול ב-DAX = מרכאה בודדת בפלט. בדוק שאין תווים שוברים (`&`, `<`) בערכי טקסט — עטוף/נקה
  אם צריך.
