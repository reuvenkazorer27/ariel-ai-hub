# בדיקות דטרמיניסטיות (pbi_check.py) — מה כל כלל בודק, למה, ומה המקור

`scripts/pbi_check.py` הוא מנוע הכללים (BPA אופליין) של הסוקר. הוא קורא את ה-TMDL וה-PBIR
ומוציא ממצאים עם מזהה כלל יציב (`MDL-xx` / `DAX-xx` / `PQ-xx` / `RPT-xx` / `A11Y-xx` / `ADV-xx`), חומרה מוצעת, מיקום ותיקון.
**הפלט הוא קלט לסוכן, לא דוח סופי**: כל ממצא הוא *מועמד* — מאמתים אותו מול הקובץ לפני שמדווחים
(כלל "אמת מהקוד"), והסיווג הסופי לפי הצ'קליסט §1–§22.

**מקורות הכללים**: סט כללי ה-BPA הרשמי (microsoft/Analysis-Services — BPARules.json, 71 כללים),
הכללים המובנים של Tabular Editor 3, מדריך האופטימיזציה של Microsoft Learn, מדריכי פורמט
TMDL/PBIR של Microsoft, ובדיקות המבנה של Adam-pd/pbip-doctor (MIT — רעיונות הבדיקה אומצו,
המימוש נכתב מחדש). בכל ממצא מופיע המקור שלו.

## כללי מודל (MDL)

| כלל | מה בודק | למה זה חשוב | מקור |
|-----|---------|-------------|------|
| MDL-01 | טבלאות `LocalDateTable_*`/`DateTableTemplate_*` — Auto date/time מופעל. מועלה ל-🔴 אם יש מדדי time-intelligence ואין טבלה מסומנת | טבלאות אוטומטיות מנפחות את המודל; TI עליהן לא אמין | BPA `REMOVE_AUTO-DATE_TABLE` + TE built-in |
| MDL-02 | טבלה עם date/calendar/תאריך בשמה בלי `dataCategory: Time` | בלי סימון Date table ה-TI שבור (היוריסטיקה לפי שם) | BPA `DATE/CALENDAR_TABLES_SHOULD_BE_MARKED_AS_A_DATE_TABLE` |
| MDL-03 | עמודת שם-חודש/יום ללא `sortByColumn` | חודשים ממוינים א-ב במקום כרונולוגית | Microsoft TMDL guidelines |
| MDL-04 | עמודות מספריות גלויות ללא `summarizeBy: none` | צבירה מרומזת = מספרים מטעים בגרירה ידנית | TE built-in — Set SummarizeBy to None |
| MDL-05 | מפתחות זרים (צד from) גלויים | גרירת FK במקום ממד = סינון שבור | TE built-in — Hide Foreign Key Columns |
| MDL-06 | תפקיד RLS בלי `USERPRINCIPALNAME`/`USERNAME`/`CUSTOMDATA` | RLS סטטי = עריכת מודל לכל שינוי הרכב | BPA `CHECK_IF_DYNAMIC_ROW_LEVEL_SECURITY...` |
| MDL-07 | `LEFT/RIGHT/MID/UPPER/LOWER/FIND/SEARCH` בסינון RLS | רץ על כל שאילתה וכל שורה | BPA `LIMIT_ROW_LEVEL_SECURITY_(RLS)_LOGIC` |
| MDL-08 | מחיצות `directQuery`/`dual` | פנייה למקור בזמן אמת | Microsoft optimization guide |
| MDL-09 | `[Query=...]` / `Value.NativeQuery` ב-M | שבירת query folding | Microsoft optimization guide |
| MDL-10 | מחרוזות חיבור/URL חקוקות ב-M (**ספירה בלבד — לעולם לא מצטטים**) | אבטחת מידע (§12ב) + תחזוקה | Microsoft TMDL guidelines — parameters |
| MDL-11 | עמודות `dataType: double` | שגיאות עיגול בסכימה | BPA `AVOID_FLOATING_POINT_DATA_TYPES` |
| MDL-12 | קשר על עמודת `dateTime` | קרדינליות גבוהה, זיכרון מנופח | BPA `SPLIT_DATE_AND_TIME` (עותק סטטי — בלי נתונים) |
| MDL-13 | קשר `isActive: false` ואין `USERELATIONSHIP` באף מדד | משקל מת | BPA `INACTIVE_RELATIONSHIPS_THAT_ARE_NEVER_ACTIVATED` |
| MDL-14 | אין במודל שום טבלת תאריכים (לא מסומנת ולא בשם) | בלי טבלת תאריכים אין time-intelligence אמין | BPA `MODEL_SHOULD_HAVE_A_DATE_TABLE` |
| MDL-15 | קצוות קשר בטיפוסי נתונים שונים (int64 מול string) | המרה בכל שאילתה + כשל שקט על ערכים לא-מתאימים | BPA `RELATIONSHIP_COLUMNS_SAME_DATA_TYPE` |
| MDL-16 | טבלה גלויה ללא אף קשר (יתומה) | לא מסתננת מאף ממד; יוצא-דופן: טבלת פרמטרים מנותקת בכוונה | BPA `ENSURE_TABLES_HAVE_RELATIONSHIPS` |
| MDL-17 | קשר many-to-many (`fromCardinality`+`toCardinality` שניהם many) | סינון דו-משמעי, תוצאות לא אינטואיטיביות, ביצועים | BPA `MANY-TO-MANY_RELATIONSHIPS_SHOULD_BE_SINGLE-DIRECTION` |
| MDL-18 | קשר דו-כיווני (`crossFilteringBehavior: bothDirections`) | דו-משמעות בנתיב סינון + האטה; לגיטימי רק עם צורך מתועד | BPA `CHECK_IF_BI-DIRECTIONAL_AND_MANY-TO-MANY_RELATIONSHIPS_ARE_VALID` |
| MDL-19 | 8+ מדדים בלי אף `displayFolder` | רשימת שדות שטוחה — קשה לאתר מדד במודל גדול | bernatagulloesbrina/TabularEditor-Scripts (MIT) — ארגון לתיקיות תצוגה |
| MDL-20 | מדדים/טבלאות ללא `description` | תיעוד חסר — המשמעות נעלמת למי שלא כתב את המדד | nara-technologies/pbip-lens `missing-description` (Apache-2.0) |
| MDL-21 | מדדים שלא מגיעים לאף ויזואל — גם לא דרך מדדים אחרים (הליכה לאחור על גרף ההפניות, כולל עמודות מחושבות ופרמטרי-שדה; ≥3) | משקל מת שמנפח את המודל ומבלבל | חישוב סטטי על גרף תלויות (רעיון IsReferenced של Bravo) |
| MDL-22 | עמודות גלויות ללא שום שימוש — לא בוויזואל, מסנן, קשר, DAX או היררכיה (≥3, לא מפתחות) | עמודה שאינה נצרכת תופסת זיכרון VertiPaq | sql-bi/Bravo (MIT) — עותק סטטי של בדיקת העמודות הלא-נצרכות |
| MDL-23 | ≥10 מדדים ואין טבלת מדדים ייעודית (טבלה ריקה שמארחת מדדים בלבד) | מדדים פזורים בטבלאות נתונים מערבבים אחריות ומקשים איתור | data-mozart.com — 5 tips to boost your Power BI development, Tip #1 (קרדיט: Nikola Ilic) |
| MDL-24 | צד ה-'to' של קשר הוא עמודת string שלא סומנה `isKey` — warn לעמודת שם-תצוגה (שם/תיאור/name/desc), tip לעמודת מזהה טקסטואלית (Claim_ID) | קשר על שם שביר פעמיים: שמות אינם מובטחים ייחודיים (כפילות בשקט), והשוואת טקסט איטית | radacad.com — Back to Basics: Power BI Relationship Demystified (קרדיט: Reza Rad) |
| MDL-25 | 2+ טבלאות נתונים (עם עמודות גלויות) בלי אף קשר ביניהן — warn; טבלאות תאריך אוטומטיות וטבלאות מדדים-בלבד אינן נספרות | בלי קשרים אין הפצת סינון: ויז'ואל חוצה-טבלאות מציג מכפלה קרטזית או ערכים כפולים/ריקים | learn.microsoft.com — Create and manage relationships in Power BI Desktop (CC-BY-4.0) |

## כללי DAX

| כלל | מה בודק | מקור |
|-----|---------|------|
| DAX-01 | מדדים עם נוסחה מנורמלת זהה (אחרי הסרת רווחים/הערות) | BPA `AVOID_DUPLICATE_MEASURES` |
| DAX-02 | `IFERROR(` | BPA `AVOID_USING_THE_IFERROR_FUNCTION` |
| DAX-03 | `FILTER('טבלה', ...)` כארגומנט ל-CALCULATE/CALCULATETABLE | Microsoft dax-avoid-filter-as-filter-argument; BPA `FILTER_COLUMN_VALUES` |
| DAX-04 | ‏≥3 `IF(` במדד אחד | קונבנציית SQLBI — SWITCH+VAR |
| DAX-05 | `EARLIER(` | SQLBI — משתנים מחליפים EARLIER |
| DAX-06 | עמודה מחושבת עם `RELATED(` | BPA `REDUCE_USAGE_OF_CALCULATED_COLUMNS_THAT_USE_THE_RELATED_FUNCTION` |
| DAX-07 | מדד שכולו `[מדד אחר]` | BPA `MEASURES_SHOULD_NOT_BE_DIRECT_REFERENCES...` |
| DAX-08 | חילוק חשוף `/` בביטוי מדד (בלי מחרוזות/הערות) — חלוקה באפס = שגיאה/אינסוף | תיקון אוטומטי: `pbi_fix.py --fix divide` של הבונה | BPA `USE_THE_DIVIDE_FUNCTION_FOR_DIVISION` |
| DAX-09 | `INTERSECT(` לקשר וירטואלי | TREATAS קריא ומהיר יותר | BPA `USE_THE_TREATAS_FUNCTION_INSTEAD_OF_INTERSECT` |
| DAX-10 | `EVALUATEANDLOG(` נשאר במודל | פונקציית דיבוג — לא לייצור | BPA `EVALUATEANDLOG_SHOULD_NOT_BE_USED_IN_PRODUCTION_MODELS` |
| DAX-11 | מדד ללא `formatString` | פורמט ברירת-מחדל לא עקבי (אלפים/אחוזים) | BPA `PROVIDE_FORMAT_STRING_FOR_MEASURES` |
| DAX-12 | סיווג שגוי בהפניות: `[עמודה]` בלי טבלה או `טבלה[מדד]` עם טבלה | קריאות: `טבלה[X]` נראית כעמודה, `[X]` כמדד | BPA `DAX_COLUMNS_FULLY_QUALIFIED` + `DAX_MEASURES_UNQUALIFIED` (MIT) |
| DAX-13 | קשר `isActive: false` שאף מדד לא מפעיל ב-`USERELATIONSHIP` | הגדרה מתה שלא משפיעה על שום חישוב | BPA `INACTIVE_RELATIONSHIPS_THAT_ARE_NEVER_ACTIVATED` (MIT) |
| DAX-14 | עמודה מספרית/תאריך גלויה בלי `formatString` | תוצג בפורמט כללי (1000000 במקום 1,000,000) | Tabular Editor 3 built-in BPA — Provide Format String for Numeric and Date Columns (docs.tabulareditor.com) |
| DAX-15 | `SUM(x)/COUNT(x)` על אותה עמודה — המצאה-מחדש של AVERAGE | ארוך יותר, חשוף לחלוקה באפס, מסתיר כוונה | dax.guide/AVERAGE (SQLBI) |
| DAX-16 | `COUNT(` על עמודת מפתח או במדד ששמו מבטיח ספירת שורות/ייחודיים — warn לייחודיים (שם מבטיח ספירה ייחודית, COUNT סופר גם כפילויות), tip ל-COUNTROWS | המספר שיוצג שגוי בשקט אם יש כפילות; COUNTROWS מדויק ומהיר יותר לספירת שורות | MS Learn DAX best practices — Use COUNTROWS instead of COUNT (CC-BY-4.0) |
| DAX-17 | אריתמטיקת no-op במדד (`*1`, `/1`, `+0`, `-0`) | שארית עריכה שמאריכה את הנוסחה ומטעה את הקורא | סריקת DAX סטטית (נמצא על דוחות אמיתיים) |
| DAX-18 | מספר קסם גדול (≥5 ספרות, עגול למאות) בהקשר השוואה/סף — לא סקיילינג של FORMAT | קבוע חקוק בלי שם משתנה בשקט כשהעסק זז; להוציא למדד-יעד או טבלת פרמטרים | נמצא על הדשבורדים השבורים (יעד 100000 חקוק) |
| DAX-19 | `IF` שמשווה מדד מבוסס-`SUM` למדד מבוסס-`AVERAGE` — תקלת רמת פירוט (grain) | סכום גדל עם מספר השורות בהקשר וממוצע לא; ההשוואה תלויה בכמות הרשומות ולא בביצועים | נמצא על הדשבורדים השבורים (סטטוס כולל); הבחנה לפי שורש האגרגציה |
| DAX-20 | FILTER על טבלת מודל שלמה עם תנאי פשוט (בלי &&/\|\|) — tip; FILTER על VAR מקומי או על VALUES/ALL אינו מסומן | ארגומנט סינון ב-CALCULATE הוא איטרטור — תנאי עמודה ישיר קצר ומהיר יותר מסריקת טבלה | sqlbi.com — Filter Arguments in CALCULATE (קרדיט: Marco Russo & Alberto Ferrari) |
| PQ-01 | `Value.NativeQuery(` בלי `EnableFolding=true` | שובר query folding — הכל רץ מקומית בזיכרון | Microsoft Learn: Query folding on native queries |
| PQ-02 | `Web.BrowserContents(` בשאילתה | שביר לשינויי אתר, איטי; לעומת Web.Contents/API | Microsoft Learn: Power Query best practices |
| PQ-03 | `Table.Buffer(` / `List.Buffer(` | מעתיק לזיכרון ושובר folding; לגיטימי רק ל-snapshot מתועד | Microsoft Learn: Query folding guidance |

## כללי דוח (RPT)

| כלל | מה בודק | מקור |
|-----|---------|------|
| RPT-01 | צבעי `solid.color` חקוקים שאינם בפלטת ה-theme | PBIR theme inheritance |
| RPT-02 | יותר מ-2 גופני `fontFace` שונים חקוקים | PBIR theme inheritance (textClasses) |
| RPT-03 | גדלי קנבס שונים בין דפים | Microsoft page settings |
| RPT-04 | אין `mobile.json` לאף ויזואל — תצוגת מובייל לא הוגדרה | Microsoft mobile-optimized reports |
| RPT-05 | ויזואלי נתונים בלי `altText` (visualContainerObjects.general) | Microsoft accessibility; PBIR הופך לניתן-ביקורת |
| RPT-06 | `tabOrder` זהה לכל הוויזואלים בדף — סדר טאב לא הוגדר (גבוה = מוקדם; פרופורציוני ל-z) | Microsoft accessibility |
| RPT-07 | אותו שדה סליסר בכמה דפים בלי `syncGroup` | PBIR visual.json — syncGroup |
| RPT-08 | מסננים ב-`report.json` filterConfig — גלובליים וסמויים | PBIR filterConfig; §11 |
| RPT-09 | מסנן שלילה (`Not` / `isInvertedSelectionMode`) בכל רמה | PBIR filter-pane — inverted selection; §11 |
| RPT-10 | אין דף drill-through באף `page.json` | PBIR page — drillthrough filter |
| RPT-11 | דף `type: Tooltip` בלי שום `visualTooltip` שמקושר אליו (או הפוך — אין בכלל) | PBIR page — tooltip pages |
| RPT-12 | `actionButton` בלי פעולת ניווט/סימנייה (היוריסטיקה) | navigation.md |
| RPT-13 | visualType שאינו מובנה (custom visual; HTML Content פטור — הוא מומלץ; חשודי RPT-27 אינם נספרים) | governance |
| RPT-27 | visualType לא מזוהה במראה שם מובנה וללא סיומת גיבוב של AppSource — חשד לשם שהומצא (stackedColumnChart וכו'; מקור: powerbi-report-mcp visual-types.md, MIT) | governance |
| RPT-28 | ציר קטגוריה מחזורי (שם חודש/רבעון עם sortByColumn) על נתונים רב-שנתיים (CALENDAR ליטרלי) בלי מסנן/סליסר שנה בדוח — צניחה מדומה בסוף הגרף | דוח שדה סבב 2 #8 |
| RPT-29 | תפריט textbox גאומטרי (>=3 תיבות: אותו x, רוחב זהה, y קבוע) בדוח ללא אף ויזואל ניווט אמיתי — תפריט שאינו לחיץ (crit) | דוח שדה סבב 2 #9 |
| RPT-30 | דוח רב-דפי (>=2) בלי אף סליסר ובלי filterConfig באף רמה (דוח/דף/וויזואל) — אפס פקדי סינון (crit) | דוח שדה סבב 2 #10 |
| MDL-26 | עמודת דליים מחושבת ('Overdue 1-30', '90+') בשימוש בדוח ללא sortByColumn — מיון א-ב שובר סדר גיולי | דוח שדה סבב 2 #11 |
| RPT-14 | ויזואל שמקושר ל-`LocalDateTable_*` | זוג ל-MDL-01 |
| RPT-15 | צבירה ישירה של עמודה בוויזואל (`Aggregation` ב-query) — "מדד מרומז" | אין מקור אמת אחד לחישוב; לא ניתן לשימוש חוזר/תיעוד/אימות | PBIR visual.json — Aggregation projections (QueryAggregateFunction); קונבנציית explicit measures |
| RPT-16 | ויזואל חורג מגבולות הקנבס (x/y/width/height מול גודל הדף) | PBIP Doctor PBIR002 (MIT); PBIR position |
| RPT-17 | חפיפה >= 50% בין שני ויזואלי נתונים (ויזואלי דקור פטורים — רקע לגיטימי) | PBIP Doctor PBIR003 (MIT) |
| RPT-18 | פעולת ניווט (`targetPage` וכד') שמצביעה לדף שלא קיים | PBIP Doctor PBIR005 (MIT) |
| RPT-19 | שם דף כפול (`name` או `displayName`) | PBIP Doctor PBIR004 (MIT) |
| RPT-20 | סימנייה (bookmarks/*.json) שמצביעה לדף שלא קיים | PBIP Doctor PBIR006 (MIT) |
| RPT-21 | `cache.abf` (מטמון נתונים אמיתי!) / `localSettings.json` / `editorSettings.json` בתיקיית הפרויקט — דליפה ל-Git | PBIP Doctor git rules (MIT); Microsoft PBIP git integration docs |
| RPT-22 | קובץ JSON בדוח שלא ניתן לקריאה / בצורה לא צפויה (visual.json שהוא מערך, page.json שבור) — נעלם מהביקורת ושובר Desktop | דפוס graceful-degradation — NVIDIA/SkillSpector #250; known-issues-log §16 |
| RPT-23 | דף tooltip/drillthrough שאינו מוסתר (visibility != Hidden) | מבלבל קוראים ומנפח את סרגל הדפים | PBI-Inspector `HIDE_TOOLTIP_DRILLTROUGH_PAGES` (MIT) |
| RPT-24 | מסנני TopN/Advanced ברמת ויזואל | מוסתר מהקורא ונשכח בתחזוקה; TopN אינטראקטיבי מונע שימוש חוזר במדדים | PBI-Inspector `REDUCE_TOPN_FILTERS` / `REDUCE_ADVANCED_FILTERS` (MIT) |
| RPT-25 | ויזואלי נתונים מוסתרים בדף גלוי (דילוג על דוח עם bookmarks — יעדי סימניות לגיטימיים) | ויזואל מוסתר נטען, מריץ שאילתה ומתעדכן — עלות בלי ערך | PBI-Inspector hidden-content checks (MIT) |
| RPT-26 | אי-אחידות ויזואלית בין דפים: פלטות חקוקות זרות לחלוטין (Jaccard=0, ≥3 צבעים לדף) או רקעים מעורבים בהיר/כהה | כל דף נראה כמו דוח אחר; מעבר בהיר↔כהה מכריח התאמת עין בכל ניווט | נמצא על הדשבורדים השבורים |

## כללי נגישות (A11Y)

משפחה דטרמיניסטית לנגישות דוח, בהשראת מנוע הכללים של PBIX A11y (pbiaudits.com) ותרגומו
ל-CLI ב-Juls-BI/pbir-a11y (רישיון PolyForm Shield 1.0.0 — אימצנו את *רעיונות הבדיקה* בלבד,
המימוש כאן נכתב מחדש במלואו ב-stdlib), NatVanG/PBI-Inspector (VisOps), ותקני W3C.
הערכת הניגודיות היא נוסחת הבהירות היחסית של WCAG 2.x; יעד ה-AA הוא 4.5:1 לטקסט רגיל.

| כלל | מה בודק | מקור |
|-----|---------|------|
| A11Y-01 | ניגודיות `foreground`/`background` של ה-theme < 4.5:1 (🔴 מתחת ל-3:1) | W3C WCAG 2.1 SC 1.4.3; pbiaudits.com theme audit |
| A11Y-02 | צבע מפורש של `textRuns` ב-textbox מול רקע הדף < 4.5:1 (🔴 < 3:1; ברירת מחדל לבן מסומנת כהנחה) | W3C WCAG 2.1 SC 1.4.3; pbir-a11y contrast |
| A11Y-03 | `tabOrder` כפול בדף (משלים את RPT-06 "לא הוגדר"). שליליים (~-9.99e6 = הסרה מכוונת מסדר tab) אינם ממצא — סבב 92 | Microsoft accessibility; pbir-a11y tab-order |
| A11Y-04 | אלמנט אינטראקטיבי (slicer/כפתור) קטן מ-24×24px | W3C WCAG 2.2 SC 2.5.8; pbir-a11y target-size |
| A11Y-05 | `fontSize` מפורש מתחת ל-9pt | pbir-a11y font-scaling; Microsoft accessibility |
| A11Y-06 | כותרת כבויה (`visualContainerObjects.title.show=false`) בוויזואל נתונים — לוודא textbox-כותרת | pbir-a11y missing-title; PBI-Inspector |
| A11Y-07 | יותר מ-10 ויזואלים גלויים בדף (עומס קוגניטיבי) | pbir-a11y clutter index; PBI-Inspector VisOps |
| A11Y-08 | פלטת `dataColors` בטווח בהירות < 0.15 — נמחקת תחת CVD/הדפסת שחור-לבן | ColorBrewer (luminance variation); pbir-a11y CVD guidance; פלטות מומלצות: Okabe-Ito / viridis |
| A11Y-09 | מטרת מגע אינטראקטיבית <44px בפריסת מובייל (mobile.json) | קשה ללחיצה באצבע; משלים A11Y-04 (24px דסקטופ) | lukasreese.com — Dashboard Design Best Practices (mobile touch targets); Apple HIG |
| A11Y-10 | טקסט עברי מיושר שמאל מפורשות (textbox paragraphs + כותרות ויזואלים) | יישור שמאל על עברית שובר סדר קריאה וחותך פיסוק לקצה הלא נכון | W3C Internationalization — RTL text basics |
| A11Y-11 | ≥2 ויזואלי נתונים בדף בלי אובייקט `title` בכלל (משלים A11Y-06 שתופס title כבוי) | כותרת אוטומטית משמות שדות — לעית טכנית באנגלית, ובכרטיסים נעלמת | pbir-a11y missing-title; PBI-Inspector |
| A11Y-12 | רקע דף כהה מפורש עם טקסט ברירת-מחדל כהה (theme foreground חסר = הכהה של Power BI) | כותרות ותוויות ברירת-מחדל נבלעות ברקע | W3C WCAG 2.1 SC 1.4.3 |
| A11Y-13 | ויזואל תמונה גלוי בלי alt text (משלים RPT-05 שמכסה ויזואלי נתונים; תמונות ב-DECOR) | קורא מסך מכריז "תמונה" בלבד — בלי תוכן או תפקיד; אין ב-Power BI סימון "דקורטיבי" | W3C WCAG 2.1 SC 1.1.1 (Understanding, W3C Document License — עקרון בלבד) |

מה משפחת A11Y *לא* בודקת (בכנות): איכות תוכן ה-alt text (רק קיום — RPT-05), סימולציית
עיוורון צבעים מלאה (מתקרבת דרך A11Y-08 בלבד), וניווט מקלדת חי.

## כללי עיצוב מבוססי-דאטה (ADV)

משפחת ייעוץ ויזואלי: כל הכללים 🟢 tip בלבד, עם רמת ביטחון מפורשת, ומבוססים על מטה-דאטה של
המודל (dataType, sortByColumn, dataCategory, isKey, isHidden, summarizeBy, גרף קשרים) —
לא על היוריסטיקת שמות. ההמלצה היא ייעוץ בלבד; הביצוע בבונה (`pbi_swap`/`pbi_fix`).

| כלל | מה בודק | מקור |
|-----|---------|------|
| ADV-01 | שדה זמן על ציר Category של ויזואל שאינו קו — מגמה לא נקריאה (ביטחון גבוהה כש-dataType=date) | עקרון עיצוב BI סטנדרטי; dataType מה-TMDL |
| ADV-02 | lineChart על קטגוריה שאינה זמן ואין לה sortByColumn — הקו מרמז על רצף שאין | עקרון עיצוב BI סטנדרטי |
| ADV-03 | טבלה דלה (עמודה+מדד / מדד בודד) — barChart/lineChart/cardVisual מספרים את הסיפור מהר יותר | עקרון pre-attentive processing; מחודד: date → lineChart בביטחון גבוהה |
| ADV-04 | דף עם מעל 8 ויזואלי נתונים — עומס קוגניטיבי | מוסכמת עיצוב דשבורדים |
| ADV-05 | KPI בלי Goal / gauge בלי TargetValue — ערך בלי יעד | MS KPI/gauge docs (מבני) |
| ADV-06 | שדה גיאוגרפי (dataCategory מוצהר) על ויזואל שאינו מפה; והפוך — מפה על שדה בלי dataCategory (ניחוש מיקום מסוכן) | dataCategory מה-TMDL; Bing geocoding behavior |
| ADV-07 | ציר על עמודת מזהה/מפתח כשבטבלה קיימת עמודת תווית (מפתח dateTime לגיטימי) | isKey/קשרים מה-TMDL |
| ADV-08 | עמודה עם `summarizeBy: none` ו-dataType מספרי ב-role ערך — תוצג כספירה בשקט (סליסרים פטורים — שם זו ההתנהגות הנכונה) | summarizeBy מה-TMDL (מחודד סבב 55-56 אחרי FP) |
| ADV-09 | שדה `isHidden` במודל המוצג בוויזואל — סתירת כוונת המודל | isHidden מה-TMDL |
| ADV-10 | ציר Category על עמודה מספרית לא-מפתח — שקול binning/scatter | dataType מה-TMDL |
| ADV-11 | עמודות מטבלאות ללא מסלול קשרים (BFS על גרף ה-relationships) על ויזואל אחד — קרטזי/ריק (סליסר על טבלת פרמטרים = what-if לגיטימי) | גרף קשרים מה-TMDL |
| ADV-12 | עוגה/טבעת בלי שדה קטגוריה — פרוסה אחת של 100% | מבני (queryState) |
| ADV-13 | card/multiRowCard מיושנים — cardVisual המחליף הרשמי | MS card.md (skills-for-fabric); ההמרה בבונה דרך cardmigration |
| ADV-14 | כמה cardVisual חד-ערכיים באותה שורה ובעיצוב זהה — לאחד לרב-ערכי (עיצוב שונה פר-כרטיס = הפרדה לגיטימית) | MS: ברירת המחדל לכמה KPIs היא cardVisual רב-ערכי |
| ADV-15 | סליסר על עמודת צד-many בקשר חד-כיווני — מסנן רק את ה-fact, לא מימדים; רשימת ערכים עלולה להיות עצומה (קשר דו-כיווני או סליסר על מדד — לא מסמנים) | cardinality מה-TMDL |
| ADV-16 | שורת ויזואלים כמעט-מיושרת (פער y של 1-20px) — סימן לגרירה בלי snapping | powerbi.tips (Mike Carlo) — Using Grids to Improve Visualization Placement |
| ADV-17 | ויזואל מפנה לשדה שלא קיים במודל (הפניה מתה; ביטחון גבוהה). סבב 85: הכיסוי הורחב מ-queryState ל-sortDefinition, ביטויי objects (כולל FillRule.Input — CF על שדה מת נזרק בשקט) ו-filterConfig | bernatagulloesbrina/TabularEditor-Scripts — Fix Broken Fields.cs GetAllFields (MIT) |
| ADV-18 | gridlines מופעלות במפורש בגרף cartesian (explicit-only נגד רעש) | Plainsight Playbook — Report Design Standards (playbook.plainsight.pro) |
| ADV-19 | מקרא במיקום Bottom — להעביר ל-Top | Plainsight Playbook — Report Design Standards |
| ADV-20 | עוגה/דונאט עם קטגוריה מטבלת fact-like (צד many או טבלה עם ≥3 מדדים) — קרדינליות גבוהה צפויה, פרוסות זעירות מתאחדות לרעש | Stephen Few — "Save the Pies for Dessert" (perceptualedge.com) |
| ADV-21 | כותרת גנרית של מילה אחת ("נתונים", "פילוח", "ניצול", "התפלגות" + מקבילות אנגליות) | נמצא על הדשבורדים השבורים |
| ADV-22 | multiRowCard המערבב ≥3 משפחות אגרגציה (גודל/יחס/ספירה) בכרטיס אחד — החלפת קנה מידה בין שורות | נמצא על הדשבורדים השבורים |
| ADV-23 | דף בלי אף אלמנט כותרת — לא textbox ולא ויזואל עם title מוצג (tip) | אומת בקורפוס: דוח 02 (תחזוקה מונעת) |
| ADV-24 | עמודות מטבלאות המחוברות רק דרך קשר לא-פעיל (isActive: false) על אותו ויזואל — הסינון ההדדי לא יעבוד (tip) | MS Learn desktop-relationships-understand; משלים את ADV-11 (גרף מלא) בגרף פעילים-בלבד. סבב 90 |
| ADV-25 | שם דף ברירת-מחדל 'Page N' / 'עמוד N' — לשונית חסרת משמעות בניווט ובשיתוף; שינוי שם לנושא התוכן (tip) | akhilannan/pbir-utils rules.yaml explicit_page_names (MIT). אומת בקורפוס: claude 'Page 1', 65 דפים אחרים נקיים. סבב 98 |

## ציון הבריאות (היוריסטי — למעקב בין ביקורות)

`100 − (🔴×8 + 🟡×3 + 🟢×1)`, מכסה של 3 מופעים לכלל, רצפה 0. הוא **לא** ציון איכות מוחלט —
הוא קו-בסיס שמאפשר לענות על "האם הדוח השתפר מאז הביקורת הקודמת". מופיע גם בפלט `--json`
לצורך השוואה בין ריצות.

## מה הבדיקות האופליין *לא* רואות (מדווחים בכנות)

כללים שדורשים מנוע חי או נתונים — אי אפשר לבדוק מקבצים, והסוקר אומר זאת במקום לנחש:
- **קרדינליות וגודל** (VertiPaq): עמודות ארוכות/בעלות קרדינליות גבוהה, טבלאות גדולות ללא
  חלוקה למחיצות — דורש DMV/סריקת מודל חי (כמו ש-SQLBI Bravo עושה).
- **ערכי מדדים אמיתיים** ואיזון כרטיס↔גרף (§11, §12) — דורש DAX query מול המנוע (MCP, אם מחובר).
- **רינדור בפועל** — כשל שקט של ויזואל, זמני טעינה אמיתיים.
- **ספירת פרוסות עוגה / שורות טבלה** — תלוי בנתונים, לא במבנה.
- **קרדינליות אמיתית** של עמודות (הבסיס לכללי cardinality של ה-BPA) — דורש נתונים חיים.
  (many-to-many *מוצהר* כבר נתפס ב-MDL-17 לפי מאפייני ה-cardinality ב-TMDL.)
MDL-12 הוא עותק סטטי של `SPLIT_DATE_AND_TIME`: ה-BPA בודק אם *יש ערכי שעה* בנתונים; אנחנו
מסמנים לפי *הטיפוס* בלבד — לכן זה 🟡 ולא 🔴, וצריך אימות.

### ביקורת עצמית

| קוד | בדיקה | למה זה משנה | מקור |
|---|---|---|---|
| ADV-26 | override ב-visual.json זהה לערך שה-theme כבר מספק (wildcard או visualTypes) | רעש נטו — לא משנה דבר היום אבל שובר שינוי theme עתידי | data-goblin modifying-theme-json (GPL-3.0) — מפל העיצוב |
| ADV-27 | אותו override חוזר זהה על 4+ ויזואלים לא-דקורטיביים (ממצא יחיד לדוח) | העיצוב ממומש ברמת ויזואל במקום ב-theme — רדיפה בכל שינוי | data-goblin modifying-theme-json (GPL-3.0) — theme-first |
| VER-01 | ציטוט בממצא (דף/ויזואל/טבלה/שדה) שלא קיים בארטיפקטים שחולצו — אימות דטרמיניסטי על רשימת דקדקי ציטוט סגורה | ציטוט שבור = באג בכלל המפיק, לא בדוח; מערער את אמינות הממצא | knoxgraeme/tieline graded evidence verdicts (AGPL-3.0) — אימוץ רעיון בלבד |
