# פירוט כללי pbi_validate.py — מה כל כלל בודק ומה המקור

`scripts/pbi_validate.py` הוא אימות המבנה הדטרמיניסטי של הבונה: 77 כללים (65 בקבוצת R,
12 בקבוצת M) על קבצי ה-PBIR/TMDL אחרי עריכה. מריצים אותו **אחרי כל batch של עריכות** —
זהו צעד ה-validate בלולאת edit→validate→read-back.

## בסיס (R-01..R-25, בקצרה)

JSON תקין בכל קובץ PBIR; pageOrder מול תיקיות הדפים (דף שלא נרשם **נעלם בשקט**); שמות מול
תיקיות; מזהים כפולים; גבולות קנבס; סימניות מול דפים; מסננים חסרי שדות; קישורי שדות מול
המודל (טבלה/עמודה שלא קיימת = ויזואל שבור בשקט); קצוות קשרים ב-TMDL; קשר עצמי; הפניות
'טבלה'[עמודה] שבורות בביטויי TMDL; וגאומטריית קנבס מלאה: חפיפה בין ויזואלי נתונים, z כפול
(clone בלי עדכון), גודל אפס, displayOption לא חוקי. (קואורדינטות עשרוניות הן נורמה ב-PBIR.)
גם: שמות visualType לא-חוקיים (stackedBarChart ≠ barChart), שדות מסננים מול המודל (מסנן
לעמודה ששונה שמה מפסיק לסנן בשקט), מצב סימניות מיושן, ויזואלי insert בלי howCreated,
sortByColumn שמפנה לעמודה מתה, התנגשות שמות מדד/עמודה במודל, sortDefinition שממיין לפי
שדה שהוסר מהוויזואל, ו-RLS שמפנה לטבלה/עמודה שלא קיימת — מתפוצץ רק אצל משתמשי התפקיד.

## R-26 ואילך — בפירוט (כל שורה: כלל + מקור)

בנוסף R-26: צורת queryState מול תפקידי הסוג — role חובה חסר (למשל Data ב-cardVisual)
   או role בשם שגוי (Fields במקום Data — מתועד כאריח ריק ב-MS skills-for-fabric).
   R-27: projections ישירות תחת query במקום queryState — schema error ב-Desktop.
   R-28: slicer עם Tooltips בלי visualTooltip.show=true — ה-tooltip לעולם לא יוצג.
   R-29..32: linearGradient3 בלי mid (שגיאת רינדור), TopN מחוץ לוויזואל או OrderBy בלי
   Aggregation (שגיאת Desktop), מסנן בלי howCreated, ו-SourceRef עם Entity בתוך Where
   (חובה Source/alias). כולן מ-MS skills-for-fabric filters/conditional-formatting.
   R-33..35: פורמט מותנה — בטבלאות/matrices חובה סלקטור מלא (data+metadata, אחרת כשל
   שקט; בתרשימים metadata אסורה), שמות אייקונים מהקטלוג בלבד (שם לא חוקי מקריס את
   Desktop עם "Unable to find resource"), ובלי שמות מאפיינים מומצאים (*Rule נזרק בשקט).
   מקור: MS skills-for-fabric conditional-formatting.
   R-36..41: רקע דף/wallpaper בלי show (ה-schema דוחה; show רק ב-VCO של ויזואל),
   image חייב מבנה מקונן image.image.name/url/scaling (שטוח נכשל בשקט) עם
   scaling=Fit/Stretch/Fill בלבד, filterCard selector.id ב-PascalCase
   (Applied/Available), scopeId ComparisonKind רק 0 (1-4 מתעלמים, 5+ שגיאת
   schema), ובלי selector על legend/categoryAxis/valueAxis/title/background/border.
   מקור: MS skills-for-fabric page-formatting/filter-pane/formatting.
   R-42: בטבלאות/matrices עם צבעי שורות מותאמים חובה visualContainerObjects.stylePreset
   =None — אחרת ה-preset הדיפולטי דורס אותם בשקט; שם preset לא מוכר נופל לדיפולט
   (Default/AlternatingRowsNew קיימים רק ב-tableEx).
   R-43: כל ResourcePackageItem (תמונה) חייב רשומה ב-report.json resourcePackages
   עם type="Image", שם כולל סיומת, וקובץ קיים ב-StaticResources/RegisteredResources.
   מקור: MS skills-for-fabric table.md/image.md.
   R-44..46: data.mode של סליסר — רק ל-visualType=slicer ומהקטלוג (Dropdown/Basic/
   Between/Single/Before/After/Relative/RelativeDatePicker/RelativeTime — RelativeDatePicker אומת מייצוא Desktop אמיתי, סבב 75); המצב חייב להתאים לטיפוס השדה
   (Between/Relative = תאריך, Before/After = תאריך/מספר, RelativeTime = dateTime);
   היררכיה בסליסר רק ב-Basic/Dropdown. מקור: MS skills-for-fabric slicers.md.
   read_model_map לוכד גם dataType לעמודה (col_types).
   R-47: אובייקטי פורמט של cardVisual (value/label/outline/padding/accentBar/divider/
   layout/image/referenceLabelTitle/referenceLabelValue/referenceLabelDetail/fillCustom/
   shadowCustom/glowCustom/spacing) חייבים selector {id:"default"} — בלעדיו נכשלים בשקט;
   cardCalloutArea/referenceLabel/referenceLabelLayout פטורים.
   R-48: visualType מיושן card/multiRowCard → warn, המחליף הרשמי cardVisual.
   מקור: MS skills-for-fabric card.md.
   R-49: אובייקטי lineStyles רק במשפחת קו/שטח (area/line/stackedArea/שני ה-combo/
   hundredPercentStackedArea), markers גם ב-scatterChart, seriesLabels רק ב-lineChart,
   y2Axis רק כש-role Y2 מאויש — אחרת נזרקים בשקט.
   R-50: ערכי enum ב-lineStyles — lineStyle (solid/dashed/dotted/custom), markerShape
   (circle/square/diamond/triangle/x/shortDash/longDash/plus), lineChartType
   (linear/smooth/step). מקור: MS skills-for-fabric cartesian.md.
   R-52: ribbonBands רק ב-barChart/columnChart (stacked); totals (תוויות סכום) רק
   שם ובטבלאות/matrices — במשפחת קו/שטח/אחרים האובייקט מת; smallMultiplesLayout
   דורש role Rows מאויש. מקור: MS skills-for-fabric cartesian.md.
   R-53: dataPoint.defaultColor ב-clustered column/bar מכריח צבע אחד לכל
   העמודות והמקרא — להשתמש ב-fill עם selector או ב-dataColors של ה-theme.
   R-54: logAxisScale=true — לוג של 0/שלילי לא מוגדר ו-Desktop נופל ללינארי
   בשקט; לאמת שהשדה חיובי תמיד. מקור: MS skills-for-fabric cartesian.md.
   R-55: dataPoint.fill עם ThemeDataColor + metadata selector (צבע פר-סידרה)
   נופל בשקט ללבן/שחור — במיקום הזה hex ליטרלי בלבד. מקור: MS theming.md §8.
   R-56: שמות מאפיינים ב-outspacePane (12) ו-filterCard (8) מול הרשימה הסגורה
   של MS — שם לא מוכר נזרק בשקט. מקור: MS skills-for-fabric filter-pane.md.
   R-57: expansionStates חוקי רק כשיש היררכיה (HierarchyLevel/Hierarchy) ב-projection;
   roles חייבים להיות roles קיימים ב-queryState, וכל queryRefs חייבים להתאים
   ל-queryRef של projection — אחרת מצב ההרחבה מת. מקור: MS expressions.md.
   M-10 (מפורט כאן): formatString תחביר — מרכאות לא מאוזנות = שגיאה; רצפי \\uXXXX/0xNN לא
   מתורגמים (להדביק את התו עצמו במרכאות); תווי תאריך/שעה (a c d h m n p q s t w / :)
   לא מצוטטים בפורמט מספרי מתפרשים כקודים — לצטט ליטרלים. מקור: MS Learn
   desktop-custom-format-strings.
   R-42 (הורחב): stylePreset custom תקין אם רשום ב-visualStyles של ה-theme
   (visualStyles[type][presetName]) — רק שם לא מובנה ולא רשום נופל לדיפולט בשקט.
   R-51: תקינות theme — dataColors וצבעים מבניים (good/neutral/bad/maximum/center/
   minimum/null/foreground/background/tableAccent) חייבים hex; ב-textClasses
   fontSize מספרי ו-color hex. מקור: MS skills-for-fabric theming.md.

## כיול והרחבות (הערות, לא כללים)

כיול-1: כיול על 10 דוחות PBIP אמיתיים מהרשת (aurora-bank, insurance-claims,
   powerbi-templates, service-operations, claude-powerbi-reporting,
   metro-staffing, AdventureWorks-Sales, superstore/fitcheck/retail-sample
   מ-imgwho/pbi-sample). תוקנו
   false-positives: R-47 סובל רשומת reset של Desktop בלי selector כשיש id:default;
   R-26 לא דורש roles על queryState ריק (placeholder) ו-map מכיר Y=Latitude/
   X=Longitude (MS map.md); M-02 פטור מחיצות calculationGroup/calculated;
   M-10 מדלג על מקטעי [Red]; R-24/R-06(שם)/R-20 הורככו ל-info לפי ראיות שטח.
   נשמרו ממצאים אמיתיים: decTree עם roles שגויים, scatter בלי X, '0.0 pp'.
   כיול-2: M-11 — מאפייני timestamps תנודתיים ב-TMDL (modifiedTime, refreshedTime,
   lastProcessed, structureModifiedTime, lastUpdate, lastSchemaUpdate,
   createdTimestamp) = רעש source-control; לקצוץ לפני commit. lineageTag אינו
   נספר (זהות, לא רעש). מקור: pbi-tools/pbi-tools ModelSettings (AGPL, עובדות).
   כיול-3: M-12 — עמודות קשר חייבות dataType זהה בשני הקצוות; M-13 — רווחים
   מובילים/נגררים בשמות אובייקטים. מקור: Tabular Editor 3 built-in BPA catalog
   (docs.tabulareditor.com, עובדות בלבד).

## אינדקס קודים מלא (כל הקודים במנוע — נבדק מול הקוד בטסט רגרסיה)

| קוד | מה בודק |
|-----|---------|
| R-01 | definition.pbir תקין — בלעדיו Desktop לא יפתח את הדוח |
| R-02 | definition/version.json חובה (PBIR metadata) |
| R-03 | definition/report.json חובה ותקין |
| R-04 | pages.json: pageOrder מול תיקיות הדפים + activePageName תקין |
| R-05 | page.json קיים ותקין בכל תיקיית דף |
| R-06 | visual.json תקין בכל תיקיית ויזואל; שם מול תיקייה |
| R-07 | ויזואל חורג מגבולות הקנבס (x/y שליליים / גלישה) |
| R-08 | מסנן בוויזואל בלי name/field |
| R-09 | מסנן דף בלי name/field |
| R-10 | visualInteractions מפנים לוויזואלים קיימים בדף |
| R-11 | bookmarks.json תקין; סימניות מול דפים קיימים |
| R-12 | reportExtensions.json תקין אם קיים; קובץ קיים עם entities ריק = שגיאה (Desktop מתרסק בפתיחה — למחוק את הקובץ, לא להשאיר ריק; סבב 97, powerbi-report-mcp pbir-gotchas.md B15 MIT) |
| R-13 | mobile.json תקין אם קיים + position הגיוני (x/y לא-שליליים, width/height חיוביים) |
| R-14 | קבצי theme/משאבים תקינים |
| R-15 | שדה בוויזואל מפנה לטבלה/עמודה שלא קיימת במודל — ויזואל שבור בשקט |
| R-16 | חפיפה בין ויזואלי נתונים בדף |
| R-18 | displayOption לא חוקי בדף (FitToPage/FitToWidth/ActualSize בלבד) |
| R-19 | רוחב/גובה אפס או שלילי בוויזואל |
| R-20 | z כפול בדף — סדר שכבות לא מוגדר |
| R-21 | שמות visualType שאינם סוגים חוקיים (stackedBarChart ≠ barChart) |
| R-22 | צורת מסנן לא תקינה בוויזואל (filter shape) |
| R-23 | סימנייה שומרת מצב לדף/ויזואל שלא קיים עוד |
| R-24 | ויזואלי insert (image/actionButton/pageNavigator) בלי howCreated — נעלמים בשקט |
| R-25 | sortDefinition: שדה מיון לא מוקרן / direction לא חוקי |
| R-26 | צורת queryState מול roles של סוג הוויזואל (Data ב-cardVisual; Fields במקום Data = אריח ריק). מכיר alias-ים של גרסאות Desktop (scatter: Category≡Details, Legend≡Series; map: Location≡Category + Gradient חוקי) |
| R-27 | projections ישירות תחת query במקום queryState — schema error ב-Desktop |
| R-28 | slicer עם Tooltips בלי visualTooltip.show=true — ה-tooltip לא יוצג |
| R-29 | linearGradient3 בלי mid — שגיאת רינדור |
| R-30 | מסנן TopN מחוץ לוויזואל |
| R-31 | מסנן בלי howCreated |
| R-32 | OrderBy בלי Aggregation / SourceRef עם Entity בתוך Where (חובה Source/alias) |
| R-33 | פורמט מותנה בטבלה/matrix בלי סלקטור מלא (data+metadata) — כשל שקט; בתרשים metadata אסורה |
| R-34 | שמות אייקונים בפורמט מותנה מחוץ לקטלוג — "Unable to find resource" מקריס את Desktop |
| R-35 | שמות מאפיינים מומצאים בפורמט מותנה (*Rule) — נזרקים בשקט |
| R-36 | רקע דף/wallpaper בלי show — ה-schema דוחה |
| R-37 | filterCard selector.id לא ב-PascalCase (Applied/Available) |
| R-38 | scopeId ComparisonKind שאינו 0 (1-4 מתעלמים, 5+ שגיאת schema) |
| R-39 | selector על אובייקטים אסורים (legend/categoryAxis/valueAxis/title/background/border) |
| R-40 | image בלי מבנה מקונן image.image.name/url/scaling, או scaling לא Fit/Stretch/Fill |
| R-41 | show על רקע דף במקום שגוי (show חוקי רק ב-VCO של ויזואל) |
| R-42 | טבלאות/matrices עם צבעי שורות מותאמים בלי stylePreset=None — ה-preset דורס בשקט (custom תקין אם רשום ב-visualStyles של ה-theme) |
| R-43 | ResourcePackageItem (תמונה) בלי רשומה ב-report.json resourcePackages (type=Image, סיומת, קובץ קיים) |
| R-44 | data.mode של סליסר רק ל-visualType=slicer ומהקטלוג (Dropdown/Basic/Between/…/RelativeDatePicker) |
| R-45 | מצב סליסר מול טיפוס השדה (Between/Relative = תאריך, Before/After = תאריך/מספר, RelativeTime = dateTime) |
| R-46 | היררכיה בסליסר רק במצב Basic/Dropdown |
| R-47 | אובייקטי פורמט של cardVisual חייבים selector {id:"default"} — בלעדיו נכשלים בשקט (סובל רשומת reset כשיש id:default) |
| R-48 | visualType מיושן card/multiRowCard — המחליף הרשמי cardVisual; תיקון: pbi_fix --fix cardmigration |
| R-49 | אובייקטי lineStyles רק במשפחת קו/שטח; markers גם ב-scatter; seriesLabels רק ב-lineChart; y2Axis רק כש-Y2 מאויש |
| R-50 | ערכי enum ב-lineStyles (lineStyle/markerShape/lineChartType) מול הרשימה הסגורה |
| R-51 | תקינות theme: dataColors וצבעים מבניים hex; textClasses fontSize מספרי ו-color hex |
| R-52 | ribbonBands רק ב-bar/column stacked; totals רק שם ובטבלאות; smallMultiplesLayout דורש role Rows |
| R-53 | dataPoint.defaultColor ב-clustered מכריח צבע אחד לכל העמודות |
| R-54 | logAxisScale=true — לוג של 0/שלילי לא מוגדר; Desktop נופל ללינארי בשקט |
| R-55 | dataPoint.fill עם ThemeDataColor + metadata selector נופל בשקט ללבן/שחור — hex ליטרלי בלבד במיקום הזה |
| R-56 | שמות מאפיינים ב-outspacePane/filterCard מול הרשימה הסגורה — שם לא מוכר נזרק בשקט |
| R-57 | expansionStates חוקי רק עם היררכיה ב-projection; roles/queryRefs חייבים להתאים ל-queryState |
| R-66 | תרשים קטן ממינימום קריא (80×60) |
| R-67 | שלמות קיבוץ ויזואלים (visualGroup): parentGroupName תלוי, מכולה עם פחות מ-2 חברים, חבר החורג מה-bbox. מכולות פטורות מ-R-06/R-16 (מבנה: mudassir09/pbi-enterprise-cli, MIT) |
| R-68 | סלייסר inline אנכי (ללא mode / Basic / Single, בלי orientation) מתחת לרצפת גובה 48px — כל שורה נקצצת (שורה 24 + מרווח 8 + padding 16 גם בלי header; slicers.md Inline-list formula; אומת בקורפוס insurance h=38, סבב 76). Dropdown/אופקי/boolean פטורים |
| R-70 | `linearGradient3` בלי עצירת `mid` (err) — שגיאת רינדור / גוף טבלה ריק; לשתי עצירות `linearGradient2` (conditional-formatting.md, סבב 83) |
| R-71 | שם אייקון CF מחוץ לקטלוג ב-`values.icon` Conditional Cases/DefaultValue (err) — קריסת Desktop "Unable to find resource"; 105 שמות חוקיים מהמקור (סבב 83) |
| R-72 | מאפייני CF פיקטיביים `backColorRule`/`fontColorRule`/`iconRule`/`iconDefinition` (warn) — לא קיימים במנוע ונזרקים בשקט; מלכודת הזיה (סבב 83) |
| R-73 | CF ערכי (FillRule/Conditional) על `dataPoint.fill`/`fillRule` בתרשים עם `metadata` selector (warn) — כשל שקט; בתרשימים CF בא בלי selector או עם dataViewWildcard בלבד (metadata = צביעה סטטית פר-סידרה) (סבב 83) |
| R-74 | `dataPoint.fill` סטטי עם `metadata` selector בוויזואל לא-קרטזי (pie/donut/scatter/treemap/funnel) (warn) — נזרק בשקט; metadata עובד רק בקרטזיים, לצביעה פר-קטגוריה שם צריך `scopeId` selectors (סבב 84, color-strategy.md § Compatibility; pbi_swap גם מזהיר בהחלפה ליעד כזה) |
| R-75 | `scopeId` selector עם `ComparisonKind` שונה מ-0 (Equal): 1-4 עוברים schema אבל נזרקים בשקט ברינדור (warn); >=5 שגיאת schema (err). לתנאים מורכבים — Conditional.Cases (סבב 86, formatting.md § Scope Identity) |
| R-76 | selector על אובייקט רוחבי שלא תומך בסלקטורים — legend / categoryAxis / valueAxis / VCO title,background,border (warn) — נזרק בשקט; סלקטורים רק באובייקטים data-bound או tile-based עם id (סבב 86, formatting.md § Which Objects Support Selectors) |
| R-77 | `objects` / `visualContainerObjects` ברמת השורש של visual.json במקום בתוך `visual` (err) — המנוע מתעלם לחלוטין; VCO הוא sibling של objects בתוך visual (סבב 86, formatting.md § VCO) |
| R-78 | ערבוב מכולות: אובייקטי דף (outspace/outspacePane/filterCard) בתוך visualContainerObjects, או אובייקטי VCO (title/subTitle/border/...) בתוך page.json (warn) — נזרקים; background חוקי בשני הצדדים (סבב 86, formatting.md § Page Objects vs VCO) |
| R-79 | מפתח VCO לא מוכר מחוץ ל-15 המתועדים (warn) — PBIR_FORMATTING_OBJECT_UNKNOWN (סבב 86, formatting.md § VCO Property Reference) |
| R-80 | פריסת PBIP מדור קודם (PBIR 1.x): report.json בשורש .Report ללא definition/ (warn) — מדכא את מפל ה-R-02/R-03/R-04 המטעה; שמירה מחדש ב-Desktop ממירה ל-PBIR (סבב 93, NatVanG/PBI-Inspector MIT — legacy fixtures) |
| R-81 | ויזואל עם שדות ב-queryState.Tooltips אבל visualContainerObjects.visualTooltip.show לא true (warn) — הלוח כבוי כברירת מחדל והשדות לא נראים בריחוף, בשקט; דילוג על tooltip מסוג Canvas. אומת בקורפוס: advw azureMap מכוון אמיתי, אפס FP ב-13 דוחות אחרים (סבב 94, microsoft/skills-for-fabric slicers.md CC-BY-4.0 § General rules). תיקון: `--fix tooltipshow` מזריק show=true (show מפורש ו-Canvas מדולגים; סבב 95, MS Learn desktop-tooltips CC-BY-4.0) |
| R-82 | מפתח 'filters' ברמת השורש של page.json/report.json (warn) — ב-schema 2.1.0+ עוגן הסינון הוא filterConfig.filters; מפתח עצמאי מבלבל את Desktop, לא לערבב פורמטים (סבב 97, powerbi-report-mcp pbir-gotchas.md Q3 MIT). אומת בקורפוס: אפס מופעים ב-15 דוחות — תופס שבירת-בונה בלבד |
| R-83 | filterConfig בתוך אובייקט visual ב-visual.json (err) — העוגן החוקי ברמת visual.json; Desktop דוחה בטעינה (additional property in /visual) והמסננים לא נטענים; ולידטורים headless לא תפסו (סבב 99, iamahlramz/pbip-tools TOOLCHAIN-FINDINGS-2026-07-13 #3, MIT). אומת בקורפוס: אפס מופעים — תופס שבירת-בונה בלבד. תיקון: `--fix filterhoist` מעביר לרמה העליונה (קונפליקט עם עליון קיים מדווח ומדולג; סבב 101, microsoft/json-schemas visualContainer 2.0.0 MIT) |
| M-14 | תלות מעגלית בין עמודות מחושבות/מדדים באותה טבלה (err) — גרף תלות מביטויי DAX + קשתות sortByColumn; Desktop מסרב לטעון מעגל (סבב 100, endjin.com sort-order circular refs + iamahlramz/pbip-tools TOOLCHAIN-FINDINGS #1). החרגות מאומתות-קורפוס: KPI statusExpression ו-formatStringDefinition מפנים חוקית למדד עצמו; מעגל דרך context-transition מכוסה חלקית בלבד |
| M-15 | שני קשרים פעילים בין אותו זוג טבלאות (err) — נתיב סינון לא דטרמיניסטי; Desktop אוכף פעיל יחיד לזוג, TMDL כתוב ביד נכשל בטעינה עם ambiguous path. התיקון: isActive: false על היתר + USERELATIONSHIP, או טבלת תפקידים (סבב 102, MS Learn relationships-active-inactive CC-BY-4.0). אומת בקורפוס: אפס מופעים ב-15 חריצים (זוגות עם פעיל+לא-פעיל חוקיים) |
| M-16 | נתיב מקומי מוחלט בביטוי M של מחיצה (warn) — כונן `X:\` או נתיב רשת `\\` ב-source של partition: הרענון עובד אצל הכותב בלבד ונשבר אצל כל מפתח אחר או בשירות. ערך הנתיב אינו מוצג (פרטיות). התיקון: פרמטר מקור או מקור ענן משותף (סבב 103, pbi-assure rule catalog PBI-SOURCE-001, MIT). אומת בקורפוס: מופעים אמיתיים ב-claude (2), advw (7), pbisample (superstore/fitcheck v1+v2) — כולם File.Contents/Folder.Files מקומיים |
| R-84 | הפניות פרויקט שבורות: `datasetReference.byPath` ב-definition.pbir חייב להיות יחסי (מוחלט = warn, נעילה למכונה) ולהצביע לתיקיית מודל קיימת (חסר = err, הדוח לא יפתח); גם artifacts ב-*.pbip בשורש הפרויקט נבדקים (חסר = err). ערך נתיב מוחלט אינו מוצג (פרטיות). יעד *.Dataset מדור קודם חוקי (סבב 104, Adam-pd/pbip-doctor PBIP002/PBIP005, MIT; מקביל pbi-assure PBI-MODEL-002). אומת בקורפוס: אפס מופעים ב-15 חריצים — כל ה-byPath יחסיים ומתרשמים |
| M-17 | נתיב מקומי מוחלט בביטוי משותף/פרמטר ב-expressions.tmdl (warn) — M-16 מכסה partitions; הפרמטרים יושבים ב-expressions.tmdl ושם הנתיב מתחבא. גם פרמטר (התבנית הנכונה) עם ברירת-מחדל מקומית שביר — לתעד שהערך משתנה בכל סביבה. ערך הנתיב אינו מוצג (פרטיות). הסריקה דורשת שהנתיב פותח מחרוזת (`"C:\` / `"\\`) — מונע FP על `\\` בתוך טקסט. (סבב 105, MS Learn Power Query parameters CC-BY-4.0; השלמה ל-pbi-assure PBI-SOURCE-001). אומת בקורפוס: metro SourceFile + insurance pProjectRoot — מופעים אמיתיים |
| M-18 | מדד SVG שבור: `<svg` בלי prefix `data:image/svg+xml` (err — טקסט גולמי לא מרונדר); prefix קיים בלי `viewBox` או בלי `dataCategory: Image URL` (warn — נחתך בסקיילינג / מוצג כטקסט); `<svg` בלי `xmlns='http://www.w3.org/2000/svg'` (warn — חלק מהרנדררים דורסים); גוף מדד מעל 30K תווים (warn — מעל ~32K תווים מרונדרים הדפדפן נכשל בשקט); SVG בלי שמירת HASONEVALUE/ISBLANK (info — מספר ערכים מרובה שובר את התמונה). מופעל רק על מדדים עם `<svg` — אפס FP. (סבב 115, Dashboard-Design/Power-BI-Design-Files SVG_BEST_PRACTICES v2.1 חוקים 1/5/6, MIT, קרדיט: Sajjad Ahmadi; סבב 121, הרחבות xmlns/גודל/שמירה לפי data-goblin/power-bi-agentic-development svg-reviewer checklist סעיפים 2/7, GPL-3.0 — רעיונות בלבד, מימוש מחדש). הקורפוס נקי — טכניקת SVG לא מופיעה בדוחות האמת |
| M-19 | `logicalId` זהה בקבצי `.platform` של שני פריטים שונים בפרויקט (err) — שיבוט בלי ריענון GUID: Fabric מזהה פריט לפי logicalId, וכפילות = קונפליקט פריסה (Git integration/Deploy). התיקון: GUID חדש לעותק. (סבב 122, data-goblin/power-bi-agentic-development c_filetypes.md § .platform, GPL-3.0 — רעיון בלבד, קרדיט). כיול: 30 קבצי .platform בקורפוס, אפס כפילויות |
| M-20 | סתירת גרסה ב-`definition.pbir`/`definition.pbism` (err) — `version` '1.x' מצהיר Legacy בלבד (report.json/model.bim) אך קיימת תיקיית `definition/` (PBIR/TMDL): Fabric Git integration מעבד לפי הגרסה והתיקייה תתעלם/תישבר. התיקון: '4.0'. (סבב 122, data-goblin c_filetypes.md § version Property, GPL-3.0 — קרדיט). כיול: כל ה-pbir בקורפוס 4.0 — אפס מופעים |
| M-21 | `unappliedChanges.json` קיים (warn) — שינויי Power Query ממתינים; Apply דורס את שאילתות המודל מהמטא-דאטה. ליישם או למחוק לפני commit. (סבב 122, data-goblin c_filetypes.md § unappliedChanges WARNING, GPL-3.0 — קרדיט). כיול: אפס בקורפוס |
| M-23 | גרסת `$schema` מול טבלת גרסאות נתמכות (בקשת משתמש 14.9) — הטבלה: איחוד microsoft/json-schemas (נשלף 14.09.2026: visualContainer 1.0.0–2.9.0, page 1.0.0–1.4.0+2.0.0–2.1.0, report 1.0.0–1.3.0+2.0.0–2.1.0+3.0.0–3.3.0, pagesMetadata 1.0.0–1.1.0, definitionProperties(report) 1.0.0+2.0.0, definitionProperties(semanticModel) 1.0.0, versionMetadata 1.0.0, platformProperties 2.0.0–2.1.0, pbipProperties 1.0.0, visualContainerMobileState 1.0.0–1.5.0+2.0.0–2.4.0) + גרסאות שנצפו בקורפוס Desktop-native (visualContainer 2.12.0/2.13.0 מ-advw/capital — Desktop משחרר לפני הריפו הציבורי) + kinds שנצפו בייצואי Desktop רשמיים (סבב 148, FabricTools/pbir-samples MIT — 8 דוחות הדוגמה של Microsoft ב-PBIR): bookmark 1.4.0, bookmarksMetadata 1.0.0, editorSettings 1.0.0. גרסה מחוץ לטבלה (2.10.0/2.11.0 = הזיית-מחולל טיפוסית) → **warn**; כתובת fabric מעוותת → **err**; kind לא מוכר → info. תיקון: `pbi_fix --fix schemaver` (הפניה לגרסה המתפרסמת העדכנית, visualContainer←2.9.0). כיול: metro v10→v12, branchperf v37→v40 (גרסאות 2.10.0 קיימות) |
| M-25 | `dataType` לא חוקי בעמודה (**err** — ממצא שדה סבב 2 #0: הוולידטור אשרר והחזיר "0 שגיאות" על פרויקט ש-Desktop מסרב לפתוח). הערכים החוקיים: string, int64, double, dateTime, decimal, boolean, binary, variant (enum `Microsoft.AnalysisServices.Tabular.DataType` — MS Learn, CC-BY-4.0). ההשוואה case-sensitive (`datetime` ≠ `dateTime`). טיפוסי: `integer`/`int`/`text` שהוקלדו ידנית או הולכו ע"י מחולל. כיול: 0 FP על 12 חריצי קורפוס (1,592 עמודות מוקלדות — כולן חוקיות). תיקון: לטיפוס המתאים (integer→int64, text→string) |
| M-26 | פרויקט מקונן (וריאנט) בתוך פרויקט-בסיס (**info** — ממצא שדה סבב 2 #13: 8/16 שגיאות ה-M-22 שלו הגיעו מהווריאנט הישן, לא מהפרויקט). כשהבסיס מכיל `.pbip` בראש, תת-תיקייה עם `.pbip` משלה מדולגת מהסריקה עם הערה זו — במקום ערבוב ממצאים. מכולת פרויקטים-אחים (בלי `.pbip` בראש) לא מושפעת. פעולה: לסרוק כל שורש בפני עצמו |
| M-27 | theme מול קטלוג הסכמה הרשמית (microsoft/powerbi-desktop-samples, reportThemeSchema-2.157.json, MIT — מחולץ ל-`data/theme-catalog-2.157.json`). (**err**) מפתח שורש לא מוכר ב-theme (הסכמה סוגרת את השורש: additionalProperties:false — `_source`/`_comment_chrome` חשודים מהשדה); (**err**) מאפיין לא מוכר תחת visualStyles.<vt>.<preset>.<card> מול איחוד מאפייני הסכמה לאותו vt + commonCards + textClass + שכבת "נצפה אצל Microsoft" (מאפיינים שערכות BaseThemes/BuiltInThemes רשמיות משתמשות בהם וסכמת 2.157 לא מונה). (**warn**) שוברי-שדה תקיני-סכמה רק בערכות מחבר: visualStyles.*.*.padding / dropShadow.shadowSpread / visualStyles.textbox (דוח שדה סבב 3 — אצלו פסלו/הסתירו; בערכות MS רשמיות קיימים ותקינים — הסתירה מתועדת בגוף האזהרה). (**info**) visualType לא מוכר (custom visual אפשרי); basicShape = כינוי legacy ל-shape. פעולה: לתקן שגיאת כתיב או לוודא ב-Desktop |
| M-28 | visual.json מול קטלוג מאפיינים נצפה-בקורפוס (`data/pbir-visual-catalog.json` — 2594 ויזואלים, 43 visualTypes, מייצואי Desktop בלבד; אין סכמת objects רשמית מפורטת). (**err**) כרטיס objects/visualContainerObjects שלא נצפה באף יצוא; (**err**) מאפיין שלא נצפה בכרטיס דגום-היטב (≥10 תצפיות); (**info**) כרטיס שלא נצפה אצל ה-vt הספציפי אך קיים אצל אחרים; (**info**) visualType שלא בקטלוג (custom visual אפשרי); (**info**) מאפיין לא מאומת בכרטיס דל-דגימה. הערה: הקטלוג נבנה מאותו קורפוס שמשמש לכיול — הערך הוא על קבצים שנבנים בקוד, לא על יצואים. פעולה: לתקן שגיאת כתיב או לוודא ב-Desktop |
| M-29 | ולידציית ערכים מול סכמת TMDL (דוח שדה סבב 3 #1, שורות 2–3). (**err**) `description:` בכתיב נקודתיים בקובץ tmdl — TMDL מגדיר תיאורים אך ורק כשורות `///` מעל הצהרת האובייקט (MS Learn tmdl-overview § Descriptions); מפתח JSON מרושת בתוך בלוק JSON (cultures) חוקי. (**err**) `compatibilityLevel` בקובץ tmdl שאינו definition/database.tmdl — מאפיין ברמת מסד בלבד (ב-Legacy: model.bim). (**err**) compatibilityLevel לא מספרי. (**warn**) רמה שלא בתיעוד MS Learn (1100/1103/1200/1400/1500/1600/1700) ולא נצפתה בקורפוס (1550/1567/1606/1702) — ייתכן רמה עתידית. (**err**, רמת פרויקט) סתירת compatibilityLevel בין model.bim ל-definition/database.tmdl באותו SemanticModel (המקרה שלו: 1600 מול 1606 → Frown). פעולה: /// לתיאורים; ליישר/לתקן את הערך או המיקום |
| R-95 | מפתחות שורש ב-visual.json (דוח שדה סבב 3 #1, שורה 4). (**err**) `syncGroup` ברמת השורש — חוקי רק כ-`visual.syncGroup` (דונור capital/daq; בשורש = 0/2640 בקורפוס, Desktop דיווח 12 issues). (**info**) מפתח שורש שלא נצפה בקורפוס 2640 קבצי visual.json ($schema/name/position/visual/parentGroupName/isHidden/filterConfig/visualGroup/howCreated) — כנראה מבנה שגוי או חידוש עתידי של Microsoft. פעולה: להעביר syncGroup לתוך visual; מפתח לא מוכר — לוודא מול Desktop |
| M-22 | UTF-8 BOM בקבצי מקור (`.json`/`.tmdl`/`.pbir`/`.pbism`/`.pbip`/`.platform`/`.csv`) (**err**) — **חוסם פתיחה ב-Desktop 2.157+**: "Only text with UTF8 encoding without BOM is supported. Detected BOM: 'UTF-8'" (דיווח שדה 14.9 — ווריאנט לא נפתח כלל; 55 קבצי BOM הוסרו ידנית). תיקון: `pbi_fix --fix debom` (או `--fix bom`); כל כתיבות הבונה נטולות BOM מסבב 134. (סבב 122, data-goblin c_pbip_skill.md, GPL-3.0 — קרדיט; warn→info בסבב 131, info→err בסבב 134 אחרי דיווח שדה #2; יומן §10 על "Desktop כותב BOM" תיאר Desktop ישן). כיול: אפס BOM בקורפוס; הפיקסצר נושא 2 וקטורי BOM מכוונים לבדיקות |
| R-93 | שם תיקיית דף/וויזואל או שדה name מחוץ ל-`^[\w-]+$` (err) — רווחים/נקודות/פיסוק = Desktop מתעלם מהפריט **בשקט** והוא נעלם מהדוח הטעון, בלי שגיאה. מקור: data-goblin v26.31.0 (GPL-3.0), pbip skill § Naming rules |
| R-94 | dataViewWildcard עם `matchingOption:0` לצד expr מסוג Measure/Conditional (warn) — 0 תואם סידרות/טוטלים; CF פר-נקודה דורש 1. מקור: data-goblin v26.31.0 (GPL-3.0), selectors.md § dataViewWildcard |
| R-89 | ThemeDataColor מחוץ לתחום (err) — `ColorId` הוא אינדקס 0-based ל-dataColors של ה-theme (מעבר לאורך = צבע שבור); `Percent` חייב [-1,1]. נבדק רק כשקיים theme בפרויקט. מקור: data-goblin v26.31.0 (GPL-3.0), expressions.md § ThemeDataColor |
| R-91 | queryRef ≠ Entity.Property של ה-field (warn) — שארית rename: ה-field עודכן אבל queryRef נשאר ישן; selectors/מיון שמכוונים ל-queryRef לא יתאימו. מדלג על visual calcs (`select`), Aggregation/Hierarchy/SparklineData. מקור: data-goblin v26.31.0 (GPL-3.0), renames.md § Reference fields |
| R-92 | SparklineData selector שבור (err) — המחרוזת הקומפקטית `SparklineData(Entity.Measure_[Entity.Hierarchy.Level])` מטמיעה שתי הפניות; המדד וטבלת הקיבוץ חייבים להתקיים במודל. מקור: data-goblin v26.31.0 (GPL-3.0), renames.md § SparklineData |
| R-87 | הפניות מדד-הרחבה שבורות (err) — `expr.Measure` עם `Schema:"extension"` חייב להצביע לישות שרשומה ב-reportExtensions.json (ולמדד שרשום תחתה); ישות הרחבה בלי `Schema:"extension"` = המנוע מחפש במודל ולא מוצא. מקור: data-goblin/power-bi-agentic-development v26.31.0 (GPL-3.0, רעיון בלבד), schema-patterns/expressions.md § Extension Measure |
| R-88 | selector מסוג scopeId עם expr מסוג Measure (warn) — scopeId מקבל ליטרלים בלבד; Measure תחתיו נדחק בשקט. התיקון: metadata selector או dataViewWildcard עם matchingOption:1. מקור: data-goblin v26.31.0 (GPL-3.0), measures-and-literals.md § scopeId |
| R-90 | Literal.Value מעוות (err) — Value חייב להיות מחרוזת תמיד; בוליאני lowercase בלבד (`true`/`false`); מספר עם סיומת סוג (`50D`/`0L`/`3M`). מקור: data-goblin v26.31.0 (GPL-3.0), expressions.md § Literals (Common Mistakes) |
| R-85 | פריטי cache/מקומיים בפרויקט (warn) — `.pbi/localSettings.json` ו-`.pbi/cache.abf` בתיקיות מודל/דוח, ו-`*.pbix`/`*.pbit` בשורש הפרויקט. ה-.gitignore ש-Desktop עצמו יוצר מתעלם משני הראשונים; editorSettings.json אינו מסומן (לא ברשימה). pbix/pbit בינאריים לא שייכים לעץ מקור (סבב 106, MS Learn projects-overview CC-BY-4.0; מקביל pbip-doctor PBIP004). אומת בקורפוס: claude +3, metro +1 (pbix בשורש) — מופעים אמיתיים |
| R-86 | נתיב יחסי מעל 200 תווים בפרויקט (warn) — מתקרב ל-MAX_PATH (260) של Windows; עם prefix שיבוט שגרתי (40-60 תווים) clone/pull נכשל בלי core.longpaths. תיקיית .git מוחרגת. (סבב 110, MS Learn maximum-file-path-limitation CC-BY-4.0). אומת בקורפוס: 0 מופעים ב-16 חריצים (הארוך ביותר 162) |
| R-69 | tableEx/pivotTable עם צבעים סטטיים מותאמים ב-objects (values backColorPrimary/Secondary/fontColorPrimary/Secondary, columnHeaders/rowHeaders/rowTotal/columnTotal/subTotals backColor/fontColor) בלי visualContainerObjects.stylePreset — פריסת ברירת-המחדל דורסת אותם בשקט ללבן (skills-for-fabric table.md: הבאג השכיח בטבלאות dark-mode). תיקון: `--fix stylepreset` מזריק 'None'; preset קיים לא נדרס. אומת בקורפוס: metro 4 + capital 3 מכוונים אמיתיים, אפס FP ב-21 דוחות אחרים (סבב 82) |
| M-01 | definition/tables חסר — ייתכן model.bim (לא TMDL) |
| M-02 | מחיצות: mode + source (פטור calculationGroup/calculated) |
| M-03 | קצה קשר בלתי קריא ב-relationships.tmdl |
| M-04 | קשר עצמי (מעמודה לעצמה) |
| M-06 | הפניות 'טבלה'[עמודה] בתוך קבצי TMDL מול המודל |
| M-07 | sortByColumn מפנה לעמודה שלא קיימת באותה טבלה — שגיאת deploy |
| M-08 | התנגשות שמות: מדד מול מדד/עמודה בכל המודל |
| M-09 | RLS: tablePermission מפנה לטבלה קיימת וההפניות בביטוי קיימות |
| M-10 | formatString עם מרכאות לא מאוזנות |
| M-11 | מאפייני timestamps תנודתיים (modifiedTime וכו') — רעש source-control; לקצוץ לפני commit |
| M-12 | עמודות קשר חייבות dataType זהה בשני הקצוות |
| M-13 | רווחים מובילים/נגררים בשמות אובייקטים |
