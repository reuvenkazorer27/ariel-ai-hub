# מבנה פרויקט PBIP/PBIR — איפה נמצא מה, ומה לחלץ

פרויקט Power BI בפורמט PBIP נשמר כתיקייה של קבצי טקסט (JSON/TMDL) שאפשר לקרוא ולבקר.

## מבנה כללי

```
<ProjectName>.pbip                     ← קובץ מצביע (JSON קטן), מפנה ל-Report
<ProjectName>.Report/
  definition.pbir                      ← מצביע לפורמט הדוח
  report.json                          ← [פורמט ישן] כל הדוח בקובץ אחד
  definition/                          ← [פורמט PBIR חדש] דוח מפורק
    report.json                        ← הגדרות ברמת הדוח (theme פעיל, settings)
    pages/
      pages.json                       ← סדר הדפים והדף הפעיל
      <pageId>/
        page.json                      ← הגדרות דף (שם, גודל, רקע)
        visuals/
          <visualId>/visual.json       ← ויזואל בודד (סוג, שדות, עיצוב, מיקום)
    bookmarks/                         ← סימניות (אם קיימות)
  StaticResources/
    SharedResources/BaseThemes/*.json  ← ערכת הנושא הבסיסית
    RegisteredResources/               ← ★ תמונות, לוגו, ערכות theme מותאמות
<ProjectName>.SemanticModel/
  definition.tmdl / definition/*.tmdl  ← [TMDL] טבלאות, מדדים, קשרים
  model.bim                            ← [BIM] אותו מודל בפורמט JSON יחיד
```

> זהה קודם אם הדוח בפורמט **PBIR חדש** (תיקיית `definition/pages/`) או **ישן** (`report.json`
> יחיד עם `sections[]` ו-`visualContainers[]`). שני הפורמטים מכילים את אותו מידע במבנה שונה.

## מה לחלץ מכל מקום

### דפים וויזואלים
- **PBIR חדש**: כל תיקיית `pages/<id>/` = דף. שם הדף ב-`page.json` → `displayName`.
  כל `visuals/<id>/visual.json` → סוג הוויזואל תחת `visual.visualType`, השדות תחת
  `visual.query`/`projections`, המיקום תחת `position` (x,y,width,height), עיצוב תחת `visual.objects`.
- **פורמט ישן**: `report.json` → `sections[]` (דפים) → כל section יש `visualContainers[]`.
  כל container שדה `config` הוא JSON-מוקודד-כמחרוזת; פענח אותו וקרא `singleVisual.visualType`.

ספירות שימושיות: מספר דפים, מספר ויזואלים לכל דף, פילוח סוגי ויזואלים, וכמה מהם מובנים מול מותאמים.

### סוגי visualType נפוצים (למיפוי לקטלוג)
`columnChart`, `clusteredColumnChart`, `hundredPercentStackedColumnChart` (והמקבילים
`barChart`, `clusteredBarChart`, `hundredPercentStackedBarChart`), `lineChart`, `areaChart`,
`stackedAreaChart`, `lineClusteredColumnComboChart`, `lineStackedColumnComboChart`,
`ribbonChart`, `waterfallChart`, `funnel`/`funnelChart`, `scatterChart`, `pieChart`,
`donutChart`, `treemap`, `card`, `cardNew`, `cardVisual`, `multiRowCard`, `kpi`, `gauge`,
`tableEx`, `pivotTable` (matrix), `filledMap`/`shapeMap`, `map`, `azureMap`,
`decompositionTreeVisual`, `keyDriversVisual` (key influencers), `slicer`, `listSlicer`,
`textSlicer`, `textbox`, `actionButton`, `pageNavigator`, `bookmarkNavigator`.
שים לב: **אין** `stackedColumnChart`/`stackedBarChart` — הגרסאות המוערמות הן
`columnChart`/`barChart` (מקור: powerbi-report-mcp docs/visual-types.md, MIT).

### ערכת נושא (Theme) — צבעים וגופנים
- Theme פעיל: ב-`definition/report.json` (או ב-`report.json` הישן תחת `themeCollection`).
- קובץ הערכה עצמו: `StaticResources/SharedResources/BaseThemes/*.json` ו/או
  `StaticResources/RegisteredResources/*.json`.
- חלץ: `dataColors[]` (פלטת הצבעים), `background`, `foreground`, `tableAccent`, ו-`textClasses`
  (גופנים/גדלים). בדוק ניגודיות רקע↔טקסט והאם הפלטה עקבית בין הדפים.

### ★ לוגו ומיתוג (סעיף חובה בדוח)
- בדוק את `StaticResources/RegisteredResources/` — קבצי `.png/.jpg/.jpeg/.svg` הם מועמדים ללוגו.
- ודא שהתמונה **בשימוש בפועל**: חפש ב-visuals ויזואל מסוג `image` או שדה `imageUrl`/`resourcePackage`
  שמפנה לקובץ. תמונה שקיימת בתיקייה אך לא ממוקמת בדף = "יש נכס לוגו אך אינו מוצג".
- אם אין קובץ תמונה כלל → "לא נמצא לוגו מחלקה/אוניברסיטה" → המלץ להוסיף (ראה SKILL שלב 4).

### ניווט
- **Bookmarks**: תיקיית `bookmarks/` או `report.json` → `config` → `bookmarks[]`.
- **כפתורים**: ויזואלים מסוג `actionButton` (בדוק `action.type`: bookmark/pageNavigation/url).
- **ניווט מובנה**: `pageNavigator` / `bookmarkNavigator`.
- אם אין אף אחד מאלה ויש יותר מ-2 דפים → ליקוי ניווט → המלץ (ראה `navigation.md`).

### מודל נתונים ו-DAX
- מקבצי `*.SemanticModel/definition/*.tmdl` (או `model.bim`):
  - **מדדים (measures)**: כל שורת `measure <name> = <DAX>`. הרץ בדיקות מ-`dax-patterns.md`.
  - **טבלת תאריכים**: חפש טבלה עם `isDate`/עמודות תאריך; ודא שמסומנת כ-Date table ורציפה.
  - **קשרים (relationships)**: כיוון סינון, קרדינליות, קשרים לא פעילים.
  - **שמות**: עברית/עקביות, תיקיות תצוגה (display folders), פורמט מספרים.

## טיפים לקריאה יעילה
- קבצי `config` בפורמט הישן הם JSON בתוך מחרוזת — פענח פעמיים.
- אל תטען את כל ה-JSON לזיכרון אם גדול; חפש (grep) את המפתחות: `visualType`, `dataColors`,
  `actionButton`, `bookmarks`, `displayName`, `measure `.
- אם קובץ פגום/חלקי — דווח על כך במקום להסיק.
