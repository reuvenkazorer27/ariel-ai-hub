# DAX ומודל — בדיקות איכות ותבניות מוכנות

בדקו את המדדים בקבצי `*.SemanticModel/`. לכל בעיה — הציעו את התיקון הקונקרטי מהתבניות כאן.

## בדיקות איכות מדדים (מה לחפש)
- **חלוקה ללא הגנה**: כל `/` שאינו `DIVIDE(...)` → סיכון שגיאת חלוקה באפס.
- **SAMEPERIODLASTYEAR חשוף**: מדד שנה-קודמת ללא טיפול בשנה חסרה → החזירו גרסה בטוחה (למטה).
- **קידוד קשיח**: מספרים/תאריכים קבועים בתוך DAX במקום פרמטר/מדד.
- **חזרתיות**: אותה תת-נוסחה נכתבת שוב ושוב במקום `VAR` או מדד-בסיס.
- **קונטקסט שגוי**: `CALCULATE` בלי הבנת מסנן; `ALL` רחב מדי; חוסר `KEEPFILTERS` היכן שצריך.
- **פורמט**: פורמט מספר לא מוגדר ברמת המדד; חוסר עקביות (₪, %, אלפים).
- **שמות**: לא עקבי/לא בעברית; אין תיקיות תצוגה (display folders); אין תיאורים.

## תבנית — טבלת תאריכים (TMDL/DAX)
מדד time-intelligence אמין דורש טבלת תאריכים רציפה המסומנת כ-Date table.
```DAX
Dim_Date =
VAR MinDate = MIN ( Fact[Date] )
VAR MaxDate = MAX ( Fact[Date] )
RETURN
ADDCOLUMNS (
    CALENDAR ( DATE ( YEAR(MinDate), 1, 1 ), DATE ( YEAR(MaxDate), 12, 31 ) ),
    "Year",        YEAR ( [Date] ),
    "MonthNo",     MONTH ( [Date] ),
    "MonthName",   FORMAT ( [Date], "MMMM", "he-IL" ),
    "YearMonth",   FORMAT ( [Date], "YYYY-MM" ),
    "Quarter",     "Q" & FORMAT ( [Date], "Q" ),
    "WeekdayNo",   WEEKDAY ( [Date], 2 ),
    "WeekdayName", FORMAT ( [Date], "dddd", "he-IL" )
)
```
לאחר יצירה: Table tools → **Mark as date table** → עמודת [Date]. מיינו MonthName לפי MonthNo.

## תבנית — יחס בטוח
```DAX
שיעור הצלחה % = DIVIDE ( [סטודנטים שעברו], [סה""כ סטודנטים] )   -- מחזיר ריק במקום שגיאה
```

## תבנית — שנה קודמת בטוחה (Same Period Last Year)
```DAX
מדד אשתקד =
VAR Cur = [מדד]
VAR Prev =
    CALCULATE ( [מדד], SAMEPERIODLASTYEAR ( Dim_Date[Date] ) )
RETURN
    IF ( NOT ISBLANK ( Cur ), Prev )   -- מונע "זליגה" של אשתקד לתקופות ללא ערך נוכחי
```

## תבנית — שינוי מול אשתקד (YoY)
```DAX
שינוי YoY % =
VAR Cur  = [מדד]
VAR Prev = [מדד אשתקד]
RETURN DIVIDE ( Cur - Prev, Prev )
```

## תבנית — צבירה משנת לימודים (YTD, נניח מתחילה באוקטובר)
```DAX
מדד YTD =
CALCULATE ( [מדד], DATESYTD ( Dim_Date[Date], "30/09" ) )   -- שנה אקדמית אוקטובר–ספטמבר
```

## תבנית — דירוג
```DAX
דירוג חוג =
RANKX ( ALL ( Dim_Course[Course] ), [מדד], , DESC, DENSE )
```

## מדדי HTML (לרכיבי "Extras" מהקטלוג)
חלק מהוויזואלים המורכבים (וופל, בולט, ספארקליין) נבנים דרך ויזואל שמרנדר HTML (למשל
"HTML Content"). המדד מחזיר מחרוזת HTML/SVG. עיקרון:
```DAX
HTML בר התקדמות =
VAR pct = DIVIDE ( [בפועל], [יעד] )
VAR w   = ROUND ( pct * 100, 0 )
RETURN
"<div style='direction:rtl;font-family:Segoe UI'>"
& "<div style='background:#eee;border-radius:6px;height:14px'>"
& "<div style='width:" & w & "%;height:14px;border-radius:6px;background:#2563EB'></div>"
& "</div><small>" & FORMAT ( pct, "0%" ) & "</small></div>"
```
המליצו על גישה זו רק כשאין ויזואל מובנה מתאים, וציינו שצריך ויזואל HTML (custom visual).

## מה לכתוב בדוח (דוגמה)
> 🟡 **DAX**: המדד `שיעור הצלחה` מחשב `passed/total` ישירות — יש להחליף ל-`DIVIDE(passed, total)`
> כדי למנוע שגיאת חלוקה באפס. בנוסף, `מדד אשתקד` משתמש ב-SAMEPERIODLASTYEAR ללא הגנה — מומלץ
> לעטוף ב-`IF(NOT ISBLANK([מדד]), ...)` (ראה תבנית).
