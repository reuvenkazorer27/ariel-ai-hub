# שילוב ה-MCP הרשמי של Power BI ‏(`powerbi-modeling`)

**עריכת קבצים היא ברירת המחדל** לכל שינוי (מודל ודוח) — דטרמיניסטי, ניתן ל-git-diff ולחזרה. שרת
ה-MCP הרשמי `powerbi-modeling` (הכלים `…powerbi-modeling__*_operations`), כשמחובר, משמש לשני
דברים בלבד:
1. **אימות read-back** עם `dax_query_operations` — השימוש העיקרי, החשוב ביותר.
2. **אופציה** לכתיבות מודל (מדד/עמודה/קשר) כשנוח — הוא כותב דרך מנוע ה-Tabular, ולידי מיד ועוקף
   כשל שקט/`cache.abf`. זו נוחות, לא חובה; אם אתה מעדיף עקביות ו-git — הישאר בעריכת TMDL.

אל תשתמש ב-MCP לרובד הדוח (PBIR: דפים/ויזואלים/סימניות/כפתורים) — אין לו כלים שם; שם תמיד עריכת
קבצים + clone-never-construct.

## מתי מה
- **דוח/ויזואלים/דפים/סימניות/כפתורים (PBIR JSON)** → עריכת קבצים (אין כלי MCP).
- **מודל (מדדים, עמודות, טבלאות, קשרים)** → ברירת מחדל: עריכת TMDL; אופציה: כלי `powerbi-modeling`.
- **אימות (read-back)** → `dax_query_operations` (מומלץ בכל שינוי מספרי).

## מיפוי משימה → כלי (`…__<tool>`)
| משימה | כלי |
|-------|-----|
| חיבור למודל הפתוח / רשימת מסדים | `connection_operations`, `database_operations`, `model_operations` |
| הוספה/עריכה/מחיקה של מדד (DAX, formatString, displayFolder) | `measure_operations` |
| עמודות: הוספה, עמודה מחושבת, **פיצול עמודה**, סוג נתונים | `column_operations` |
| טבלאות: יצירה/שינוי, סימון Date table | `table_operations`, `calendar_operations` |
| קשרים: יצירה על **מפתח**, כיוון סינון, קרדינליות, הפעלה/כיבוי | `relationship_operations` |
| היררכיות משתמש | `user_hierarchy_operations` |
| קבוצות חישוב (Calculation Groups) | `calculation_group_operations` |
| פרטישנים / מקורות / Power Query (M) | `partition_operations`, `named_expression_operations` |
| פונקציות DAX מותאמות | `function_operations` |
| תרגומים / תרבויות (RTL, he-IL) | `culture_operations`, `object_translation_operations` |
| פרספקטיבות | `perspective_operations` |
| אבטחת שורה (RLS) | `security_role_operations` |
| **הרצת DAX לאימות ערכים** | `dax_query_operations` |
| טרנזקציה (batch עם rollback) | `transaction_operations` |
| מעקב/דיאגנוסטיקה | `trace_operations` |

## לולאת עבודה מומלצת (מודל)
1. `connection_operations` → התחבר למודל הפתוח ב-Desktop (או ל-PBIP semantic model).
2. עטוף שינויים מרובים ב-`transaction_operations` (commit/rollback).
3. בצע את השינוי עם הכלי המתאים (למשל `measure_operations` להוספת מדד HTML מהסוקר).
4. **read-back** עם `dax_query_operations` — הרץ את המדד/שאילתה והשווה לבסיס ידוע.
5. אם נדרש רענון ב-Desktop — "Apply external changes" (ראה `pbir-editing-gotchas.md` §2).

## דגשים
- שינוי מודל דרך ה-MCP הוא ולידי מיידית — אין צורך ב"סגור/פתח" ולרוב לא ב-cache cleanup.
- לרובד הדוח (PBIR) אין כלי MCP — שם עדיין חלים clone-never-construct, byte-copy לדף, ועריכת קבצים.
- כשה-MCP לא מחובר — חזור לעריכת TMDL ידנית + Apply external changes.
