#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
בדיקות יחידה ל-pbi_check.py (stdlib unittest, ללא תלויות).

שיטה: בונים פרויקט PBIP מינימלי "מלוכלך" (fixture עם מלכודות מכוונות) ופרויקט "נקי",
ומוודאים שכל כלל תופס את המלכודה שלו — ושהפרויקט הנקי לא מייצר false-positives לכללי
הליבה. (אותו עקרון כמו ב-known-issues-log §13: בדיקה שמדווחת הצלחה על קלט ריק = כישלון.)

הרצה:  python tests/test_pbi_check.py
"""
import json, os, sys, shutil, tempfile, unittest

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'scripts'))
import pbi_check as C


def w(path, text):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, 'w', encoding='utf-8') as fh:
        fh.write(text)


class Fixture(unittest.TestCase):
    def setUp(self):
        C._FINDINGS.clear()
        self.root = tempfile.mkdtemp(prefix='pbicheck-')
        sm = os.path.join(self.root, 'D.SemanticModel')
        rp = os.path.join(self.root, 'D.Report')
        # מודל מלוכלך
        w(os.path.join(sm, 'definition', 'tables', 'fact.tmdl'),
          "table fact\n"
          "\tcolumn dt\n\t\tdataType: dateTime\n\t\tsourceColumn: dt\n"
          "\tcolumn qty\n\t\tdataType: double\n\t\tsourceColumn: qty\n"
          "\tcolumn cc = RELATED ( dim[x] )\n"
          "\tmeasure 'מ אחד' = SUM ( fact[qty] )\n"
          "\tmeasure 'מ שתיים' = SUM ( fact[qty] )\n"
          "\tmeasure 'כינוי' = [מ אחד]\n"
          "\tmeasure 'אשתקד' = CALCULATE ( [מ אחד], SAMEPERIODLASTYEAR ( dim[dt] ) )\n"
          "\tmeasure 'שגיאה' = IFERROR ( [a] / [b], 0 )\n"
          "\tmeasure 'מסנן' = CALCULATE ( [מ אחד], FILTER ( fact, fact[qty] > 1 ) )\n"
          "\tmeasure 'תנאי' = IF ( [x] = 1, \"a\", IF ( [x] = 2, \"b\", IF ( [x] = 3, \"c\", \"d\" ) ) )\n"
          "\tmeasure 'קודם' = EARLIER ( fact[qty] )\n"
          "\tmeasure 'לא מסווג' = SUM ( [qty] )\n"
          "\tmeasure 'מסווג יתר' = fact[מ אחד] * 2\n"
          "\tpartition fact = m\n\t\tmode: directQuery\n\t\tsource =\n"
          "\t\t\tlet S = Sql.Database(\"srv\", \"db\", [Query=\"SELECT 1\"]) in S\n")
        w(os.path.join(sm, 'definition', 'tables', 'dim_date.tmdl'),
          "table dim_date\n"
          "\tcolumn d\n\t\tdataType: dateTime\n\t\tisKey: true\n"
          "\tcolumn MonthName\n\t\tdataType: string\n"
          "\tpartition dim_date = m\n\t\tmode: import\n\t\tsource =\n\t\t\tlet x = 1 in x\n")
        w(os.path.join(sm, 'definition', 'tables', 'LocalDateTable_1.tmdl'), '')
        w(os.path.join(sm, 'definition', 'relationships.tmdl'),
          "relationship r1\n\tfromColumn: fact.dt\n\ttoColumn: dim_date.d\n\tcrossFilteringBehavior: bothDirections\n"
          "relationship r2\n\tisActive: false\n\tfromColumn: fact.qty\n\ttoColumn: dim_date.d\n"
          "relationship r3\n\tfromColumn: fact.qty\n\ttoColumn: dim_date.d\n\tfromCardinality: many\n\ttoCardinality: many\n")
        w(os.path.join(sm, 'definition', 'tables', 'pq_dirty.tmdl'),
          "table pq_dirty\n\tcolumn c\n\t\tdataType: string\n"
          "\tpartition p1 = m\n\t\tmode: import\n\t\tsource =\n"
          "\t\t\tlet S = Value.NativeQuery(Sql.Database(\"s\", \"d\"), \"SELECT 1\") in S\n"
          "\tpartition p2 = m\n\t\tmode: import\n\t\tsource =\n"
          "\t\t\tlet S = Web.BrowserContents(\"https://x\") in S\n"
          "\tpartition p3 = m\n\t\tmode: import\n\t\tsource =\n"
          "\t\t\tlet S = Table.Buffer(#table({}, {})) in S\n")
        w(os.path.join(sm, 'definition', 'tables', 'params.tmdl'),
          "table params\n\tcolumn p\n\t\tdataType: string\n"
          "\tpartition params = m\n\t\tmode: import\n\t\tsource =\n\t\t\tlet x = 1 in x\n")
        w(os.path.join(sm, 'definition', 'roles', 'r.tmdl'),
          "role r\n\tmodelPermission: read\n\ttablePermission fact = LEFT ( fact[x], 2 ) = \"ab\"\n")
        # דוח מלוכלך
        w(os.path.join(rp, 'definition', 'report.json'),
          json.dumps({"name": "r", "filterConfig": {"filters": [
              {"name": "f", "field": {"Column": {"Expression": {"SourceRef": {"Entity": "dim_date"}}, "Property": "d"}},
               "type": "Categorical", "filter": {"Version": 2, "From": [], "Where": [{"Condition": {"In": {"Expressions": [], "Values": []}}}]}}]}}))
        for pid, wdt, hgt, title in (('p1', 1280, 720, 'ראשי'), ('p2', 1920, 1080, 'פירוט')):
            pj = {"name": pid, "displayName": title, "width": wdt, "height": hgt}
            if pid == 'p2':
                pj["type"] = "Tooltip"   # מלכודת RPT-23: דף tooltip לא מוסתר
            w(os.path.join(rp, 'definition', 'pages', pid, 'page.json'), json.dumps(pj))
            w(os.path.join(rp, 'definition', 'pages', pid, 'visuals', 'v', 'visual.json'),
              json.dumps({"name": "v", "position": {"x": 0, "y": 0, "z": 1, "width": 4, "height": 3, "tabOrder": 0},
                          "visual": {"visualType": "slicer",
                                     "query": {"queryState": {"Values": {"projections": [
                                         {"field": {"Column": {"Expression": {"SourceRef": {"Entity": "dim_date"}},
                                                               "Property": "d"}}, "queryRef": "q"}]}}},
                                     "objects": {"dataPoint": [{"properties": {"fill": {"solid": {"color": {"expr": {"Literal": {"Value": "'#FF0000'"}}}}}}}]}}}))
        w(os.path.join(rp, 'definition', 'pages', 'p1', 'visuals', 'vc', 'visual.json'),
          json.dumps({"name": "vc", "position": {"x": 0, "y": 0, "z": 1, "width": 4, "height": 3, "tabOrder": 1},
                      "visual": {"visualType": "card",
                                 "visualContainerObjects": {"general": [{"properties":
                                     {"altText": {"expr": {"Literal": {"Value": "'x'"}}}}}]},
                                 "query": {"queryState": {"Values": {"projections": [
                                     {"field": {"Aggregation": {"Expression": {"Column": {
                                         "Expression": {"SourceRef": {"Entity": "fact"}},
                                         "Property": "qty"}}, "Function": 0}},
                                      "queryRef": "q2"}]}}}},
                                 "filterConfig": {"filters": [{"type": "TopN"}, {"type": "Advanced"}]}}))
        w(os.path.join(rp, 'StaticResources', 'RegisteredResources', 'theme.json'),
          json.dumps({"name": "t", "dataColors": ["#118DFF"]}))
        self.sm, self.rp = sm, rp

    def tearDown(self):
        shutil.rmtree(self.root, ignore_errors=True)

    def run_all(self):
        C._FINDINGS.clear()
        C.check_model(C.read_model(self.sm))
        C.check_report(C.read_report(self.rp))
        return {f['rule'] for f in C._FINDINGS}

    def test_rules_fire(self):
        rules = self.run_all()
        for r in ('MDL-01', 'MDL-02', 'MDL-03', 'MDL-06', 'MDL-07', 'MDL-08', 'MDL-09',
                  'MDL-10', 'MDL-11', 'MDL-12', 'MDL-13',
                  'MDL-15', 'MDL-16', 'MDL-17', 'MDL-18',
                  'DAX-01', 'DAX-02', 'DAX-03', 'DAX-04', 'DAX-05', 'DAX-06', 'DAX-07',
                  'DAX-08', 'DAX-11', 'DAX-12', 'DAX-13',
                  'PQ-01', 'PQ-02', 'PQ-03', 'RPT-23', 'RPT-24',
                  'RPT-01', 'RPT-03', 'RPT-04', 'RPT-05', 'RPT-07', 'RPT-08', 'RPT-15'):
            self.assertIn(r, rules, 'rule %s did not fire on the trap fixture' % r)

    def test_auto_datetime_critical_upgrade(self):
        self.run_all()
        m1 = next(f for f in C._FINDINGS if f['rule'] == 'MDL-01')
        self.assertEqual('crit', m1['severity'])  # TI בשימוש + אין טבלה מסומנת

    def test_score_drops_on_dirty_project(self):
        self.run_all()
        self.assertLess(C.health_score(), 60)

    def test_no_secrets_leak(self):
        """MDL-10 סופר מחרוזות חיבור — אסור שישרת/מסד יופיעו בפלט (§12ב)."""
        self.run_all()
        for f in C._FINDINGS:
            self.assertNotIn('srv', json.dumps(f, ensure_ascii=False))

    def test_json_output_shape(self):
        self.run_all()
        f = C._FINDINGS[0]
        for k in ('rule', 'severity', 'category', 'location', 'title', 'detail', 'fix'):
            self.assertIn(k, f)


class CleanProject(unittest.TestCase):
    """פרויקט תקין לא מייצר ממצאי ליבה (false-positive guard)."""
    def setUp(self):
        C._FINDINGS.clear()
        self.root = tempfile.mkdtemp(prefix='pbiclean-')
        sm = os.path.join(self.root, 'D.SemanticModel')
        rp = os.path.join(self.root, 'D.Report')
        w(os.path.join(sm, 'definition', 'tables', 'dim_date.tmdl'),
          "table dim_date\n\tdataCategory: Time\n"
          "\tcolumn d\n\t\tdataType: dateTime\n\t\tisKey: true\n"
          "\tcolumn MonthName\n\t\tdataType: string\n\t\tsortByColumn: MonthNo\n\t\tisHidden\n"
          "\tcolumn MonthNo\n\t\tdataType: int64\n\t\tisHidden\n\t\tsummarizeBy: none\n"
          "\tmeasure m = SUM ( dim_date[MonthNo] )\n\t\tformatString: #,##0\n"
          "\tpartition dim_date = m\n\t\tmode: import\n\t\tsource =\n\t\t\tlet x = 1 in x\n")
        w(os.path.join(rp, 'definition', 'report.json'), json.dumps({"name": "r"}))
        w(os.path.join(rp, 'definition', 'pages', 'p1', 'page.json'),
          json.dumps({"name": "p1", "displayName": "ראשי", "width": 1280, "height": 720}))
        w(os.path.join(rp, 'definition', 'pages', 'p1', 'visuals', 'v', 'visual.json'),
          json.dumps({"name": "v",
                      "position": {"x": 0, "y": 0, "z": 1, "width": 4, "height": 3, "tabOrder": 5},
                      "visual": {"visualType": "card",
                                 "visualContainerObjects": {"general": [{"properties":
                                     {"altText": {"expr": {"Literal": {"Value": "'כרטיס'"}}}}}]},
                                 "query": {"queryState": {"Values": {"projections": []}}}}}))
        self.sm, self.rp = sm, rp

    def tearDown(self):
        shutil.rmtree(self.root, ignore_errors=True)

    def test_clean_has_no_core_findings(self):
        C.check_model(C.read_model(self.sm))
        C.check_report(C.read_report(self.rp))
        rules = {f['rule'] for f in C._FINDINGS}
        for r in ('MDL-01', 'MDL-02', 'MDL-03', 'MDL-04', 'MDL-05', 'MDL-11', 'MDL-12',
                  'MDL-14', 'MDL-15', 'MDL-16', 'MDL-17', 'MDL-18', 'MDL-19', 'MDL-20',
                  'MDL-21', 'MDL-22',
                  'ADV-17', 'ADV-18', 'ADV-19', 'ADV-20', 'ADV-21', 'ADV-22',
                  'DAX-01', 'DAX-02', 'DAX-03', 'DAX-04', 'DAX-05', 'DAX-07',
                  'DAX-08', 'DAX-09', 'DAX-10', 'DAX-11', 'DAX-12', 'DAX-13', 'DAX-14', 'DAX-15',
                  'DAX-16', 'DAX-17', 'DAX-18', 'DAX-19', 'DAX-20', 'MDL-23', 'MDL-24', 'MDL-25',
                  'PQ-01', 'PQ-02', 'PQ-03', 'RPT-23', 'RPT-24', 'RPT-25', 'RPT-26', 'RPT-27',
                  'RPT-01', 'RPT-03', 'RPT-05', 'RPT-07', 'RPT-08', 'RPT-09', 'RPT-15'):
            self.assertNotIn(r, rules, 'false positive on clean project: %s' % r)

    def test_clean_score_high(self):
        C.check_model(C.read_model(self.sm))
        C.check_report(C.read_report(self.rp))
        self.assertGreaterEqual(C.health_score(), 95)


class A11yDirty(unittest.TestCase):
    """מלכודות נגישות: כל כלל A11Y תופס את המלכודת שלו."""
    def setUp(self):
        C._FINDINGS.clear()
        self.root = tempfile.mkdtemp(prefix='pbia11y-')
        rp = os.path.join(self.root, 'D.Report')
        w(os.path.join(rp, 'definition', 'report.json'), json.dumps({"name": "r"}))
        w(os.path.join(rp, 'StaticResources', 'RegisteredResources', 'theme.json'),
          json.dumps({"name": "t",
                      "dataColors": ["#B0483A", "#9A3AB0", "#AA3322", "#7744BB"],
                      "background": "#FFFFFF", "foreground": "#FFFF66"}))
        w(os.path.join(rp, 'definition', 'pages', 'p1', 'page.json'),
          json.dumps({"name": "p1", "displayName": "ראשי", "width": 1280, "height": 720}))

        def visual(name, vtype, tab, wdt=100, hgt=100, extra_visual=None):
            alt = {"expr": {"Literal": {"Value": "'x'"}}}
            vco = {"general": [{"properties": {"altText": alt}}]}
            query = {"queryState": {"Values": {"projections": []}}}
            d = {"name": name,
                 "position": {"x": 0, "y": 0, "z": 1, "width": wdt, "height": hgt,
                              "tabOrder": tab},
                 "visual": {"visualType": vtype, "visualContainerObjects": vco,
                            "query": query}}
            if extra_visual:
                d["visual"].update(extra_visual)
            return d

        # 11 כרטיסים (clutter) — לשניים tabOrder זהה 5 (כפילות), לאחד כותרת כבויה
        for i in range(11):
            tab = 5 if i in (0, 1) else 100 + i
            extra = None
            if i == 2:
                alt = {"expr": {"Literal": {"Value": "'x'"}}}
                show_off = {"expr": {"Literal": {"Value": "false"}}}
                extra = {"visualContainerObjects": {
                    "general": [{"properties": {"altText": alt}}],
                    "title": [{"properties": {"show": show_off}}]}}
            w(os.path.join(rp, 'definition', 'pages', 'p1', 'visuals', 'c%d' % i, 'visual.json'),
              json.dumps(visual('c%d' % i, 'card', tab, extra_visual=extra)))
        # כפתור קטן מדי
        w(os.path.join(rp, 'definition', 'pages', 'p1', 'visuals', 'btn', 'visual.json'),
          json.dumps(visual('btn', 'actionButton', 7, wdt=20, hgt=20)))
        # textbox עם גופן זעיר וניגודיות גרועה
        tb = visual('tb', 'textbox', 8)
        tb["visual"]["objects"] = {"general": [{"properties": {"paragraphs": [
            {"textRuns": [{"value": "טקסט", "textStyle": {"fontSize": "7", "color": "#DDDDDD"}}]}]}}]}
        w(os.path.join(rp, 'definition', 'pages', 'p1', 'visuals', 'tb', 'visual.json'),
          json.dumps(tb))
        self.rp = rp

    def tearDown(self):
        shutil.rmtree(self.root, ignore_errors=True)

    def run_a11y(self):
        C._FINDINGS.clear()
        C.check_a11y(C.read_report(self.rp))
        return {f['rule'] for f in C._FINDINGS}

    def test_a11y_rules_fire(self):
        rules = self.run_a11y()
        for r in ('A11Y-01', 'A11Y-02', 'A11Y-03', 'A11Y-04', 'A11Y-05', 'A11Y-06',
                  'A11Y-07', 'A11Y-08'):
            self.assertIn(r, rules, 'rule %s did not fire on the a11y trap fixture' % r)

    def test_contrast_severity_crit(self):
        self.run_a11y()
        f1 = next(f for f in C._FINDINGS if f['rule'] == 'A11Y-01')
        self.assertEqual('crit', f1['severity'])  # 1.06:1 — מתחת ל-3:1
        f2 = next(f for f in C._FINDINGS if f['rule'] == 'A11Y-02')
        self.assertEqual('crit', f2['severity'])


class A11yClean(unittest.TestCase):
    """פרויקט נגיש לא מייצר ממצאי A11Y (false-positive guard)."""
    def setUp(self):
        C._FINDINGS.clear()
        self.root = tempfile.mkdtemp(prefix='pbia11yclean-')
        rp = os.path.join(self.root, 'D.Report')
        w(os.path.join(rp, 'definition', 'report.json'), json.dumps({"name": "r"}))
        w(os.path.join(rp, 'StaticResources', 'RegisteredResources', 'theme.json'),
          json.dumps({"name": "t",
                      "dataColors": ["#E69F00", "#56B4E9", "#009E73", "#F0E442",
                                     "#0072B2", "#D55E00", "#CC79A7"],
                      "background": "#FFFFFF", "foreground": "#202020"}))
        w(os.path.join(rp, 'definition', 'pages', 'p1', 'page.json'),
          json.dumps({"name": "p1", "displayName": "ראשי", "width": 1280, "height": 720}))
        w(os.path.join(rp, 'definition', 'pages', 'p1', 'visuals', 'v1', 'visual.json'),
          json.dumps({"name": "v1",
                      "position": {"x": 0, "y": 0, "z": 1, "width": 200, "height": 100,
                                   "tabOrder": 5},
                      "visual": {"visualType": "card",
                                 "visualContainerObjects": {"general": [{"properties":
                                     {"altText": {"expr": {"Literal": {"Value": "'כרטיס'"}}}}}]},
                                 "query": {"queryState": {"Values": {"projections": []}}}}}))
        tb = {"name": "tb",
              "position": {"x": 0, "y": 0, "z": 2, "width": 300, "height": 40, "tabOrder": 3},
              "visual": {"visualType": "textbox",
                         "objects": {"general": [{"properties": {"paragraphs": [
                             {"textRuns": [{"value": "כותרת",
                                            "textStyle": {"fontSize": "11",
                                                          "color": "#202020"}}]}]}}]}}}
        w(os.path.join(rp, 'definition', 'pages', 'p1', 'visuals', 'tb', 'visual.json'),
          json.dumps(tb))
        self.rp = rp

    def tearDown(self):
        shutil.rmtree(self.root, ignore_errors=True)

    def test_clean_no_a11y_findings(self):
        C._FINDINGS.clear()
        C.check_a11y(C.read_report(self.rp))
        rules = {f['rule'] for f in C._FINDINGS}
        for r in ('A11Y-01', 'A11Y-02', 'A11Y-03', 'A11Y-04', 'A11Y-05', 'A11Y-06',
                  'A11Y-07', 'A11Y-08', 'A11Y-09', 'A11Y-10', 'A11Y-11', 'A11Y-12',
                  'A11Y-13'):
            self.assertNotIn(r, rules, 'false positive on clean a11y project: %s' % r)


class A11y03NegativeSentinel(unittest.TestCase):
    """סבב 92 — A11Y-03: tabOrder שלילי (~-9.99e6) הוא סכינת Desktop להוצאה
    מכוונת של ויזואל מסדר ה-tab (MS Learn desktop-accessibility-creating-reports:
    פרקטיקה מומלצת לאלמנטים דקורטיביים) — לא "סדר טאב שבור", גם כששניים זהים."""

    def setUp(self):
        C._FINDINGS.clear()
        self.root = tempfile.mkdtemp(prefix='pbin03-')
        self.rp = os.path.join(self.root, 'D.Report')
        w(os.path.join(self.rp, 'definition', 'report.json'), json.dumps({"name": "r"}))
        w(os.path.join(self.rp, 'definition', 'pages', 'p1', 'page.json'),
          json.dumps({"name": "p1", "displayName": "ראשי", "width": 1280, "height": 720}))

    def tearDown(self):
        shutil.rmtree(self.root, ignore_errors=True)

    def _visual(self, name, tab):
        w(os.path.join(self.rp, 'definition', 'pages', 'p1', 'visuals', name, 'visual.json'),
          json.dumps({"name": name,
                      "position": {"x": 0, "y": 0, "z": 1, "width": 100, "height": 100,
                                   "tabOrder": tab},
                      "visual": {"visualType": "card",
                                 "query": {"queryState": {"Values": {"projections": []}}}}}))

    def _rules(self):
        C._FINDINGS.clear()
        C.check_a11y(C.read_report(self.rp))
        return {f['rule'] for f in C._FINDINGS}

    def test_equal_negatives_no_fire(self):
        # שני ויזואלים עם אותה סכינת שלילית + שניים עם סדר חיובי תקין
        self._visual('a', -9999000)
        self._visual('b', -9999000)
        self._visual('c', 1)
        self._visual('d', 2)
        self.assertNotIn('A11Y-03', self._rules(),
                         'סכינת שלילית זהה סומנה כסדר טאב שבור (FP)')

    def test_positive_dup_still_fires_with_negative_present(self):
        # כפילות חיובית אמיתית עדיין נתפסת, גם כשיש סכינת שלילית בדף
        self._visual('a', 5)
        self._visual('b', 5)
        self._visual('c', 7)
        self._visual('d', -9999000)
        rules = self._rules()
        self.assertIn('A11Y-03', rules, 'כפילות חיובית לא נתפסה')
        f = next(x for x in C._FINDINGS if x['rule'] == 'A11Y-03')
        self.assertNotIn('שליליים', f['title'],
                         'הכותרת עדיין מציגה ערכים שליליים כממצא')
        self.assertIn('ערכים כפולים: 5', f['title'])


class A11y13ImageAltText(unittest.TestCase):
    """סבב 107 — A11Y-13: ויזואל תמונה גלוי בלי alt text. משלים RPT-05 (וויזואלי
    נתונים בלבד; תמונות ב-DECOR). מקור: W3C WCAG 2.1 Understanding SC 1.1.1."""

    def setUp(self):
        C._FINDINGS.clear()
        self.root = tempfile.mkdtemp(prefix='pbia13-')
        self.rp = os.path.join(self.root, 'D.Report')
        w(os.path.join(self.rp, 'definition', 'report.json'), json.dumps({"name": "r"}))
        w(os.path.join(self.rp, 'definition', 'pages', 'p1', 'page.json'),
          json.dumps({"name": "p1", "displayName": "ראשי", "width": 1280, "height": 720}))

    def tearDown(self):
        shutil.rmtree(self.root, ignore_errors=True)

    def _image(self, name, alt=None, hidden=False, cond=False):
        vco = {}
        if alt is not None:
            vco = {"general": [{"properties": {"altText": alt}}]}
        w(os.path.join(self.rp, 'definition', 'pages', 'p1', 'visuals', name, 'visual.json'),
          json.dumps({"name": name, "isHidden": hidden,
                      "position": {"x": 0, "y": 0, "z": 1, "width": 100, "height": 100},
                      "visual": {"visualType": "image", "visualContainerObjects": vco}}))

    def _rules(self):
        C._FINDINGS.clear()
        C.check_a11y(C.read_report(self.rp))
        return {f['rule'] for f in C._FINDINGS}

    def test_image_without_alttext_fires(self):
        self._image('img1')
        self.assertIn('A11Y-13', self._rules(), 'תמונה בלי alt text לא זוהתה')

    def test_image_with_alttext_clean(self):
        self._image('img1', alt={"expr": {"Literal": {"Value": "'לוגו החברה'"}}})
        self.assertNotIn('A11Y-13', self._rules(), 'תמונה עם alt text סומנה (FP)')

    def test_hidden_image_no_fire(self):
        self._image('img1', hidden=True)
        self.assertNotIn('A11Y-13', self._rules(), 'תמונה מוסתרת סומנה (FP)')

    def test_empty_alttext_fires_and_conditional_clean(self):
        # מחרוזת ריקה = לא הוגדר בפועל; ביטוי מותנה = הוגדר
        self._image('img1', alt={"expr": {"Literal": {"Value": "''"}}})
        self.assertIn('A11Y-13', self._rules(), 'altText ריק לא זוהה כחסר')
        os.remove(os.path.join(self.rp, 'definition', 'pages', 'p1', 'visuals', 'img1', 'visual.json'))
        self._image('img2', alt={"expr": {"If": {}}})
        self.assertNotIn('A11Y-13', self._rules(), 'altText מותנה סומן (FP)')


class LegacyLayoutHonesty(unittest.TestCase):
    """סבב 93 — פריסת PBIP מדור קודם (PBIR 1.x, report.json בשורש .Report):
    הסוקר מדלג, אבל שורת הסיכום חייבת לומר שהכיסוי חלקי — לא "100/100 נקי".
    מקור ה-layout: NatVanG/PBI-Inspector (MIT) fixtures."""

    def setUp(self):
        C._FINDINGS.clear()
        self.root = tempfile.mkdtemp(prefix='pbilegacyck-')
        rp = os.path.join(self.root, 'L.Report')
        w(os.path.join(rp, 'definition.pbir'),
          json.dumps({"version": "1.0",
                      "datasetReference": {"byPath": {"path": "../L.Dataset"},
                                           "byConnection": None}}))
        w(os.path.join(rp, 'report.json'), json.dumps({"config": "{}"}))
        w(os.path.join(self.root, 'L.Dataset', 'definition.pbidataset'), '{}')
        w(os.path.join(self.root, 'L.Dataset', 'model.bim'), '{}')

    def tearDown(self):
        os.chdir(os.path.dirname(os.path.abspath(__file__)))
        C._PARTIAL = False
        C._FINDINGS.clear()
        shutil.rmtree(self.root, ignore_errors=True)

    def _run_main(self):
        import contextlib, io
        buf = io.StringIO()
        argv = sys.argv
        cwd = os.getcwd()
        try:
            sys.argv = ['pbi_check.py']
            os.chdir(self.root)
            with contextlib.redirect_stdout(buf):
                C.main()
        finally:
            sys.argv = argv
            os.chdir(cwd)
        return buf.getvalue()

    def test_partial_scan_disclosed(self):
        out = self._run_main()
        self.assertIn('PBIR', out)  # הערת הדילוג על פריסה ישנה
        self.assertIn('הסריקה כיסתה חלק מהבדיקות בלבד', out,
                      'שורת הסיכום לא חשפה שהכיסוי חלקי')
        self.assertNotIn('לא נמצאו ליקויים דטרמיניסטיים. ✅', out,
                         'הצהרת "נקי" על פרויקט שלא נסרק בכלל')

    def test_full_scan_keeps_clean_line(self):
        # מגן FP: סריקה מלאה בלי ממצאים עדיין מקבלת את שורת ה"נקי"
        C._FINDINGS.clear()
        C._PARTIAL = False
        self.assertIn('לא נמצאו ליקויים דטרמיניסטיים. ✅', C.render_text())
        C._PARTIAL = True
        self.assertIn('הסריקה כיסתה חלק מהבדיקות בלבד', C.render_text())
        C._PARTIAL = False


class StructureDirty(unittest.TestCase):
    """מלכודות מבניות: גבולות קנבס, חפיפה, ניווט שבור, שמות כפולים, קבצי cache."""
    def setUp(self):
        C._FINDINGS.clear()
        self.root = tempfile.mkdtemp(prefix='pbistruct-')
        rp = os.path.join(self.root, 'D.Report')
        w(os.path.join(rp, 'definition', 'report.json'), json.dumps({"name": "r"}))
        w(os.path.join(rp, 'StaticResources', 'RegisteredResources', 'theme.json'),
          json.dumps({"name": "t", "dataColors": ["#118DFF"]}))
        for pid in ('p1', 'p2'):
            w(os.path.join(rp, 'definition', 'pages', pid, 'page.json'),
              json.dumps({"name": pid, "displayName": "ראשי", "width": 1280, "height": 720}))

        def vis(name, vtype, x, y, wdt, hgt, extra=None):
            d = {"name": name,
                 "position": {"x": x, "y": y, "z": 1, "width": wdt, "height": hgt,
                              "tabOrder": 1},
                 "visual": {"visualType": vtype,
                            "query": {"queryState": {"Values": {"projections": []}}}}}
            if extra:
                d["visual"].update(extra)
            return d

        # חורג מהקנבס (1400 > 1280)
        w(os.path.join(rp, 'definition', 'pages', 'p1', 'visuals', 'oob', 'visual.json'),
          json.dumps(vis('oob', 'card', 1200, 10, 200, 100)))
        # שני ויזואלי נתונים חופפים 56%
        w(os.path.join(rp, 'definition', 'pages', 'p1', 'visuals', 'ov1', 'visual.json'),
          json.dumps(vis('ov1', 'card', 0, 0, 100, 100)))
        w(os.path.join(rp, 'definition', 'pages', 'p1', 'visuals', 'ov2', 'visual.json'),
          json.dumps(vis('ov2', 'tableEx', 25, 25, 100, 100)))
        # כפתור שמנווט לדף שלא קיים
        w(os.path.join(rp, 'definition', 'pages', 'p1', 'visuals', 'nav', 'visual.json'),
          json.dumps(vis('nav', 'actionButton', 500, 10, 40, 40,
                         extra={"objects": {"icon": [{"properties": {
                             "action": {"targetPage": "NoSuchPage"}}}]}})))
        # סימנייה לדף רפאים
        w(os.path.join(rp, 'definition', 'bookmarks', 'bm1.json'),
          json.dumps({"items": [{"name": "bm1", "targetPage": "GhostPage"}]}))
        # קבצי cache/local בפרויקט
        w(os.path.join(rp, '.pbi', 'localSettings.json'), '{}')
        w(os.path.join(rp, '.pbi', 'cache.abf'), 'x')
        self.rp = rp

    def tearDown(self):
        shutil.rmtree(self.root, ignore_errors=True)

    def test_structure_rules_fire(self):
        C._FINDINGS.clear()
        rep = C.read_report(self.rp)
        C.check_report(rep)
        C.check_local_artifacts(self.rp, None)
        rules = {f['rule'] for f in C._FINDINGS}
        for r in ('RPT-16', 'RPT-17', 'RPT-18', 'RPT-19', 'RPT-20', 'RPT-21'):
            self.assertIn(r, rules, 'rule %s did not fire on the structure trap fixture' % r)

    def test_cache_abf_is_warn(self):
        C._FINDINGS.clear()
        C.check_local_artifacts(self.rp, None)
        f = next(f for f in C._FINDINGS if f['rule'] == 'RPT-21')
        self.assertEqual('warn', f['severity'])  # cache.abf = מטמון נתונים אמיתי


class GroupedVisuals(unittest.TestCase):
    """סבב 70: מכולת visualGroup (מבנה: mudassir09/pbi-enterprise-cli, MIT) —
    RPT-17 לא סופר זוגות מכולה↔חבר (ה-bbox מכיל אותם מתוך כוונה)."""

    def setUp(self):
        C._FINDINGS.clear()
        self.root = tempfile.mkdtemp(prefix='pbigrp-')
        rp = os.path.join(self.root, 'D.Report')
        w(os.path.join(rp, 'definition', 'report.json'), json.dumps({"name": "r"}))
        w(os.path.join(rp, 'definition', 'pages', 'p1', 'page.json'),
          json.dumps({"name": "p1", "displayName": "ראשי", "width": 1280, "height": 720}))

        def vis(name, vtype, x, y, wdt, hgt):
            return {"name": name,
                    "position": {"x": x, "y": y, "z": 1, "width": wdt, "height": hgt,
                                 "tabOrder": 1},
                    "visual": {"visualType": vtype,
                               "query": {"queryState": {"Values": {"projections": []}}}}}

        # שני חברים שלא חופפים זה את זה
        m1 = vis('gm1', 'card', 0, 0, 100, 100); m1['parentGroupName'] = 'g1'
        m2 = vis('gm2', 'tableEx', 200, 0, 100, 100); m2['parentGroupName'] = 'g1'
        w(os.path.join(rp, 'definition', 'pages', 'p1', 'visuals', 'gm1', 'visual.json'),
          json.dumps(m1))
        w(os.path.join(rp, 'definition', 'pages', 'p1', 'visuals', 'gm2', 'visual.json'),
          json.dumps(m2))
        # מכולת קבוצה — bbox מכיל את שני החברים (חופף לשניהם 100%)
        w(os.path.join(rp, 'definition', 'pages', 'p1', 'visuals', 'g1', 'visual.json'),
          json.dumps({"name": "g1",
                      "position": {"x": 0, "y": 0, "z": 1, "width": 300, "height": 100,
                                   "tabOrder": 1},
                      "visualGroup": {"displayName": "grp", "groupMode": "ScaleMode"}}))
        self.rp = rp

    def tearDown(self):
        shutil.rmtree(self.root, ignore_errors=True)

    def test_group_container_not_counted_in_overlap(self):
        rep = C.read_report(self.rp)
        types = {v['id']: v['type'] for p in rep['pages'] for v in p['visuals']}
        self.assertEqual(types.get('g1'), 'group', 'read_report לא זיהה מכולת קבוצה')
        C.check_report(rep)
        r17 = [f for f in C._FINDINGS if f['rule'] == 'RPT-17']
        self.assertEqual(r17, [], 'RPT-17 ספר זוגות מכולה↔חבר (FP): %s' % r17)


class StructureClean(unittest.TestCase):
    """מבנה תקין: ניווט ליעד קיים, בלי חפיפות, בלי cache — אפס ממצעי RPT-16..21."""
    def setUp(self):
        C._FINDINGS.clear()
        self.root = tempfile.mkdtemp(prefix='pbistructclean-')
        rp = os.path.join(self.root, 'D.Report')
        w(os.path.join(rp, 'definition', 'report.json'), json.dumps({"name": "r"}))
        for pid, title in (('p1', 'ראשי'), ('p2', 'פירוט')):
            w(os.path.join(rp, 'definition', 'pages', pid, 'page.json'),
              json.dumps({"name": pid, "displayName": title, "width": 1280, "height": 720}))
        w(os.path.join(rp, 'definition', 'pages', 'p1', 'visuals', 'a', 'visual.json'),
          json.dumps({"name": "a",
                      "position": {"x": 0, "y": 0, "z": 1, "width": 300, "height": 200,
                                   "tabOrder": 1},
                      "visual": {"visualType": "card",
                                 "query": {"queryState": {"Values": {"projections": []}}}}}))
        w(os.path.join(rp, 'definition', 'pages', 'p1', 'visuals', 'btn', 'visual.json'),
          json.dumps({"name": "btn",
                      "position": {"x": 1100, "y": 600, "z": 2, "width": 80, "height": 40,
                                   "tabOrder": 2},
                      "visual": {"visualType": "actionButton",
                                 "objects": {"icon": [{"properties": {
                                     "action": {"targetPage": "p2"}}}]},
                                 "query": {"queryState": {"Values": {"projections": []}}}}}))
        w(os.path.join(rp, 'definition', 'bookmarks', 'bm1.json'),
          json.dumps({"items": [{"name": "bm1", "targetPage": "p2"}]}))
        self.rp = rp

    def tearDown(self):
        shutil.rmtree(self.root, ignore_errors=True)

    def test_clean_no_structure_findings(self):
        C._FINDINGS.clear()
        rep = C.read_report(self.rp)
        C.check_report(rep)
        C.check_local_artifacts(self.rp, None)
        rules = {f['rule'] for f in C._FINDINGS}
        for r in ('RPT-16', 'RPT-17', 'RPT-18', 'RPT-19', 'RPT-20', 'RPT-21'):
            self.assertNotIn(r, rules, 'false positive on clean structure project: %s' % r)

class DaxCleanStringsBeforeComments(unittest.TestCase):
    """רגרסיה סבב 116: _dax_clean מסיר מחרוזות לפני הערות. אחרת 'http://...'
    בתוך מחרוזת (namespace חובה של SVG) נחתך כ'הערת //', המרכאות נשברות,
    ו-'/>' דולף כחילוק חשוף — FP של DAX-08 על כל מדד SVG. נחשף בתרגול הבונה."""

    def setUp(self):
        C._FINDINGS.clear()
        self.root = tempfile.mkdtemp(prefix='pbiclean-')
        sm = os.path.join(self.root, 'D.SemanticModel')
        w(os.path.join(sm, 'definition', 'tables', 't.tmdl'),
          "table t\n"
          "\tcolumn q\n\t\tdataType: double\n\t\tsourceColumn: q\n"
          # SVG תקין: namespace עם // בתוך מחרוזת + תגים סוגרים-עצמית — לא חילוק
          "\tmeasure 'svg' = \"data:image/svg+xml;charset=utf-8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 10 10'><circle cx='5' cy='5' r='4' fill='%23000'/></svg>\"\n"
          "\t\tdataCategory: Image URL\n"
          # שליטה: חילוק אמיתי — חייב להתפס
          "\tmeasure 'div' = [a] / [b]\n"
          "\tpartition t = m\n\t\tmode: import\n\t\tsource =\n\t\t\tlet x = 1 in x\n")
        self.sm = sm

    def tearDown(self):
        shutil.rmtree(self.root, ignore_errors=True)

    def test_no_dax08_on_svg_namespace_string(self):
        C.check_model(C.read_model(self.sm))
        d8 = {f.get('location', '') for f in C._FINDINGS if f['rule'] == 'DAX-08'}
        self.assertFalse(any('svg' in t for t in d8),
                         'FP: מדד SVG סומן DAX-08 (// בתוך מחרוזת נקרא כהערה): %s' % d8)
        self.assertTrue(any('div' in t for t in d8),
                        'חילוק אמיתי לא נתפס אחרי התיקון: %s' % d8)


class DesignAdvice(unittest.TestCase):
    """ADV-*: המלצות שינוי ויזואל מסיגנלים בקוד — יורים נכון, לא יורים על תקין."""

    def setUp(self):
        C._FINDINGS.clear()
        self.root = tempfile.mkdtemp(prefix='pbiadv-')
        self.sm = os.path.join(self.root, 'D.SemanticModel')
        self.rp = os.path.join(self.root, 'D.Report')
        w(os.path.join(self.sm, 'definition', 'tables', 'dim_date.tmdl'),
          "table dim_date\n"
          "\tcolumn d\n\t\tdataType: dateTime\n\t\tisKey: true\n"
          "\tcolumn MonthName\n\t\tdataType: string\n"
          "\tmeasure total = 1\n")
        w(os.path.join(self.rp, 'definition', 'report.json'), json.dumps({"name": "r"}))
        w(os.path.join(self.rp, 'definition', 'pages', 'p1', 'page.json'),
          json.dumps({"name": "p1", "displayName": "ראשי", "width": 1280, "height": 720}))

    def tearDown(self):
        shutil.rmtree(self.root, ignore_errors=True)

    def add_visual(self, vid, vtype, roles, page='p1'):
        qs = {role: {"projections": [
            {"field": {kind: {"Expression": {"SourceRef": {"Entity": ent}}, "Property": prop}},
             "queryRef": "q%d" % i}
            for i, (kind, ent, prop) in enumerate(flds)]} for role, flds in roles.items()}
        w(os.path.join(self.rp, 'definition', 'pages', page, 'visuals', vid, 'visual.json'),
          json.dumps({"name": vid,
                      "position": {"x": 0, "y": 0, "z": 1, "width": 4, "height": 3},
                      "visual": {"visualType": vtype, "query": {"queryState": qs}}}))

    def run_adv(self):
        C._FINDINGS.clear()
        C.check_design(C.read_report(self.rp), C.read_model(self.sm))
        return C._FINDINGS

    def run_model(self):
        C._FINDINGS.clear()
        C.check_model(C.read_model(self.sm))
        return C._FINDINGS

    def test_numeric_column_without_format_flagged(self):
        # DAX-14: עמודה מספרית גלויה בלי formatString (Tabular Editor built-in BPA)
        w(os.path.join(self.sm, 'definition', 'tables', 'fact.tmdl'),
          "table fact\n\tcolumn amount\n\t\tdataType: int64\n")
        self.assertTrue(any(f['rule'] == 'DAX-14' for f in self.run_model()),
                        'עמודה מספרית בלי formatString לא זוהתה')

    def test_formatted_column_clean(self):
        w(os.path.join(self.sm, 'definition', 'tables', 'fact.tmdl'),
          "table fact\n\tcolumn amount\n\t\tdataType: int64\n\t\tformatString: \"#,0\"\n")
        self.assertFalse(any(f['rule'] == 'DAX-14' for f in self.run_model()),
                         'עמודה עם formatString סומנה (FP)')

    def test_hidden_column_clean(self):
        w(os.path.join(self.sm, 'definition', 'tables', 'fact.tmdl'),
          "table fact\n\tcolumn amount\n\t\tdataType: int64\n\t\tisHidden\n")
        self.assertFalse(any(f['rule'] == 'DAX-14' for f in self.run_model()),
                         'עמודה מוסתרת סומנה (FP)')

    def test_string_column_clean(self):
        w(os.path.join(self.sm, 'definition', 'tables', 'fact.tmdl'),
          "table fact\n\tcolumn label\n\t\tdataType: string\n")
        self.assertFalse(any(f['rule'] == 'DAX-14' for f in self.run_adv()),
                         'עמודת טקסט סומנה (FP)')

    def test_broken_field_reference_flagged(self):
        # ADV-17: ויזואל מפנה לשדה שלא קיים במודל (TabularEditor-Scripts — Fix Broken Fields)
        roles = {'Category': [('Column', 'dim_date', 'NoSuchColumn')],
                 'Y': [('Measure', 'dim_date', 'total')]}
        self.add_visual_at('b1', 'clusteredBarChart', roles, y=200)
        fs = self.run_adv()
        self.assertTrue(any(f['rule'] == 'ADV-17' for f in fs), 'הפניה שבורה לא זוהתה')

    def test_valid_field_reference_clean(self):
        roles = {'Category': [('Column', 'dim_date', 'MonthName')],
                 'Y': [('Measure', 'dim_date', 'total')]}
        self.add_visual_at('b2', 'clusteredBarChart', roles, y=200)
        self.assertFalse(any(f['rule'] == 'ADV-17' for f in self.run_adv()),
                         'הפניה תקינה סומנה (FP)')

    def test_auto_date_table_reference_skipped(self):
        w(os.path.join(self.sm, 'definition', 'tables', 'LocalDateTable_x1.tmdl'),
          "table LocalDateTable_x1\n\tcolumn Month\n\t\tdataType: string\n")
        roles = {'Category': [('Column', 'LocalDateTable_x1', 'Month')],
                 'Y': [('Measure', 'dim_date', 'total')]}
        self.add_visual_at('b3', 'clusteredBarChart', roles, y=200)
        self.assertFalse(any(f['rule'] == 'ADV-17' for f in self.run_adv()),
                         'טבלת תאריך אוטומטית סומנה (FP)')

    def test_calc_group_reference_skipped(self):
        w(os.path.join(self.sm, 'definition', 'tables', 'time_calc.tmdl'),
          "table time_calc\n\tcalculationGroup\n\tcolumn Name\n\t\tdataType: string\n")
        roles = {'Category': [('Column', 'time_calc', 'YTD')],
                 'Y': [('Measure', 'dim_date', 'total')]}
        self.add_visual_at('b4', 'clusteredBarChart', roles, y=200)
        self.assertFalse(any(f['rule'] == 'ADV-17' for f in self.run_adv()),
                         'פריט calc group סומן (FP)')

    def test_many_measures_without_folders_flagged(self):
        # MDL-19: 8+ מדדים בלי אף displayFolder (TabularEditor-Scripts — ארגון לתיקיות)
        body = "table wide\n" + ''.join(
            "\tmeasure m%d = %d\n" % (i, i) for i in range(9))
        w(os.path.join(self.sm, 'definition', 'tables', 'wide.tmdl'), body)
        self.assertTrue(any(f['rule'] == 'MDL-19' for f in self.run_model()),
                        'מדדים רבים ללא תיקיות לא זוהו')

    def test_measures_with_folders_clean(self):
        body = "table wide\n" + ''.join(
            "\tmeasure m%d = %d\n\t\tdisplayFolder: grp\n" % (i, i) for i in range(9))
        w(os.path.join(self.sm, 'definition', 'tables', 'wide.tmdl'), body)
        self.assertFalse(any(f['rule'] == 'MDL-19' for f in self.run_model()),
                         'מדדים מאורגנים סומנו (FP)')

    def add_visual_objects(self, vid, vtype, objects, page='p1'):
        w(os.path.join(self.rp, 'definition', 'pages', page, 'visuals', vid, 'visual.json'),
          json.dumps({"name": vid,
                      "position": {"x": 0, "y": 300, "z": 1, "width": 4, "height": 3},
                      "visual": {"visualType": vtype, "objects": objects,
                                 "query": {"queryState": {"Values": {"projections": []}}}}}))

    def test_gridlines_explicitly_on_flagged(self):
        # ADV-18: gridlineShow: true מפורש בציר (Plainsight — gridlines off by default)
        self.add_visual_objects('g1', 'lineChart', {"valueAxis": [{"properties": {
            "gridlineShow": {"expr": {"Literal": {"Value": "true"}}}}}]})
        self.assertTrue(any(f['rule'] == 'ADV-18' for f in self.run_adv()),
                        'gridlines מופעלות לא זוהו')

    def test_gridlines_off_clean(self):
        self.add_visual_objects('g2', 'lineChart', {"valueAxis": [{"properties": {
            "gridlineShow": {"expr": {"Literal": {"Value": "false"}}}}}]})
        self.assertFalse(any(f['rule'] == 'ADV-18' for f in self.run_adv()),
                         'gridlines כבויות סומנו (FP)')

    def test_gridlines_absent_clean(self):
        # ברירת מחדל בלי הגדרה מפורשת — לא מסמנים (מדיניות explicit-only נגד רעש)
        self.add_visual_objects('g3', 'clusteredColumnChart', {})
        self.assertFalse(any(f['rule'] == 'ADV-18' for f in self.run_adv()),
                         'ויזואל בלי הגדרת gridlines סומן (FP)')

    def test_legend_bottom_flagged(self):
        # ADV-19: מקרא Bottom (Plainsight — מקרא עליון עדיף)
        self.add_visual_objects('g4', 'lineChart', {"legend": [{"properties": {
            "position": {"expr": {"Literal": {"Value": "'Bottom'"}}}}}]})
        self.assertTrue(any(f['rule'] == 'ADV-19' for f in self.run_adv()),
                        'מקרא תחתון לא זוהה')

    def test_legend_top_clean(self):
        self.add_visual_objects('g5', 'lineChart', {"legend": [{"properties": {
            "position": {"expr": {"Literal": {"Value": "'Top'"}}}}}]})
        self.assertFalse(any(f['rule'] == 'ADV-19' for f in self.run_adv()),
                         'מקרא עליון סומן (FP)')

    def test_space_indented_tmdl_parsed(self):
        # TMDL בהזחת רווחים (לא טאבים) — נמצא בקורפוס אמיתי; ההצהרות לא יוחמצו
        w(os.path.join(self.sm, 'definition', 'tables', 'spaced.tmdl'),
          "table spaced\n    column amount\n        dataType: int64\n")
        model = C.read_model(self.sm)
        tbl = [t for t in model['tables'] if t['name'] == 'spaced']
        self.assertTrue(tbl and [c['name'] for c in tbl[0]['columns']] == ['amount'],
                        'קובץ TMDL מוזחת-רווחים לא נקרא')
        self.assertTrue(any(f['rule'] == 'DAX-14' for f in self.run_model()),
                        'עמודה בקובץ מוזחת-רווחים לא הגיעה לכללים')

    def test_undocumented_measures_flagged(self):
        # MDL-20: 5+ מדדים ללא description (pbip-lens — missing-description)
        body = "table docs\n" + ''.join(
            "\tmeasure d%d = %d\n" % (i, i) for i in range(5))
        w(os.path.join(self.sm, 'definition', 'tables', 'docs.tmdl'), body)
        self.assertTrue(any(f['rule'] == 'MDL-20' for f in self.run_model()),
                        'מדדים לא-מתועדים לא זוהו')

    def test_documented_measures_clean(self):
        body = "table docs\n" + ''.join(
            "\tmeasure d%d = %d\n\t\tdescription: measure %d\n" % (i, i, i) for i in range(5))
        w(os.path.join(self.sm, 'definition', 'tables', 'docs.tmdl'), body)
        self.assertFalse(any(f['rule'] == 'MDL-20' for f in self.run_model()),
                         'מדדים מתועדים סומנו (FP)')

    def test_slashslash_documented_measures_clean(self):
        # סבב 136 (כשל שדה #7 מהדיווח המסודר): "27/27 מדדים ללא description" דווח
        # על מודל שכולו מתועד בשורות /// מעל כל measure — צורת ה-description ב-TMDL
        # (יומן #15). הכלל היה ביומן אבל לא הוחל בבדיקה (המלצה רוחבית 4).
        body = "table docs\n" + ''.join(
            "\t/// מדד מספר %d\n\tmeasure d%d = %d\n" % (i, i, i) for i in range(5))
        w(os.path.join(self.sm, 'definition', 'tables', 'docs.tmdl'), body)
        self.assertFalse(any(f['rule'] == 'MDL-20' for f in self.run_model()),
                         'מדדים מתועדים ב-/// סומנו כלא-מתועדים (כשל שדה #7)')

    def test_slashslash_documented_table_clean(self):
        # תיאור טבלה בשורות /// מעל ההצהרה — לא נספר כטבלה לא-מתועדת
        body = "/// טבלה מתועדת\ntable docs\n" + ''.join(
            "\t/// מדד %d\n\tmeasure d%d = %d\n" % (i, i, i) for i in range(5))
        w(os.path.join(self.sm, 'definition', 'tables', 'docs.tmdl'), body)
        tbl = [t for t in C.read_model(self.sm)['tables'] if t['name'] == 'docs']
        self.assertTrue(tbl and tbl[0]['desc'], 'תיאור /// של טבלה לא נקרא')

    def test_few_measures_clean(self):
        # פחות מ-5 מדדים — סף הרעש, לא מסמנים
        w(os.path.join(self.sm, 'definition', 'tables', 'docs.tmdl'),
          "table docs\n\tmeasure d1 = 1\n")
        self.assertFalse(any(f['rule'] == 'MDL-20' for f in self.run_model()),
                         'מודל קטן סומן (FP)')

    def test_orphan_measures_flagged(self):
        # MDL-21: 3+ מדדים שאף ויזואל/מסנן לא מגיע אליהם (pbip-impact-analyzer, MIT)
        w(os.path.join(self.sm, 'definition', 'tables', 'orph.tmdl'),
          "table orph\n" + ''.join("\tmeasure o%d = %d\n" % (i, i) for i in range(5)))
        self.assertTrue(any(f['rule'] == 'MDL-21' for f in self.run_adv()),
                        'מדדים יתומים לא זוהו')

    def test_base_measure_reachable_via_chain_clean(self):
        # מדד בסיס שמדד מוצג בונה עליו — חי (reachability, לא שימוש ישיר)
        w(os.path.join(self.sm, 'definition', 'tables', 'chain.tmdl'),
          "table chain\n\tmeasure base = 1\n\tmeasure der = [base] + 1\n"
          "\tmeasure q1 = 1\n\tmeasure q2 = 2\n\tmeasure q3 = 3\n")
        self.add_visual('ch1', 'cardVisual',
                        {'Values': [('Measure', 'chain', 'der')]})
        fs = [f for f in self.run_adv() if f['rule'] == 'MDL-21']
        self.assertTrue(fs, 'יתומים לא זוהו בכלל')
        self.assertNotIn('base', fs[0]['detail'], 'מדד בסיס בשרשרת סומן (FP)')
        self.assertNotIn('der', fs[0]['detail'], 'מדד מוצג סומן (FP)')
        self.assertIn('q1', fs[0]['detail'], 'יתום אמיתי לא דווח')

    def test_field_parameter_seed_clean(self):
        # מדד שמוזן לפרמטר-שדה (NAMEOF במקור מחיצה של טבלה מחושבת) — לא יתום
        w(os.path.join(self.sm, 'definition', 'tables', 'fp.tmdl'),
          "table fp\n\tpartition fp = calculated\n\t\tsource =\n"
          "\t\t\tSELECTCOLUMNS ( { NAMEOF ( dim_date[fpm] ) }, \"v\", [Value] )\n"
          "\tmeasure fpm = 1\n"
          "\tmeasure r1 = 1\n\tmeasure r2 = 2\n\tmeasure r3 = 3\n")
        fs = [f for f in self.run_adv() if f['rule'] == 'MDL-21']
        self.assertTrue(fs, 'יתומים לא זוהו בכלל')
        self.assertNotIn('fpm', fs[0]['detail'], 'מדד של פרמטר-שדה סומן (FP)')

    def test_few_orphans_below_threshold_clean(self):
        # מתחת לסף הרעש (3 יתומים) — לא מסמנים
        w(os.path.join(self.sm, 'definition', 'tables', 'orph.tmdl'),
          "table orph\n\tmeasure o1 = 1\n\tmeasure o2 = 2\n")
        self.assertFalse(any(f['rule'] == 'MDL-21' for f in self.run_adv()),
                         '2 יתומים סומנו (מתחת לסף) (FP)')

    def test_orphan_columns_flagged(self):
        # MDL-22: 3+ עמודות גלויות ללא שימוש (sql-bi/Bravo, MIT)
        w(os.path.join(self.sm, 'definition', 'tables', 'orphc.tmdl'),
          "table orphc\n\tcolumn c1\n\t\tdataType: string\n"
          "\tcolumn c2\n\t\tdataType: string\n\tcolumn c3\n\t\tdataType: int64\n")
        fs = [f for f in self.run_adv() if f['rule'] == 'MDL-22']
        self.assertTrue(fs, 'עמודות יתומות לא זוהו')
        self.assertIn('orphc[c1]', fs[0]['detail'])

    def test_hierarchy_level_binding_marks_column_used(self):
        # HierarchyLevel בוויזואל נפתר דרך מפת רמה->עמודה — העמודה לא יתומה
        w(os.path.join(self.sm, 'definition', 'tables', 'geo.tmdl'),
          "table geo\n\tcolumn Country\n\t\tdataType: string\n"
          "\thierarchy Geo\n\t\tlevel Country\n\t\t\tcolumn: Country\n")
        w(os.path.join(self.sm, 'definition', 'tables', 'orphc.tmdl'),
          "table orphc\n\tcolumn c1\n\t\tdataType: string\n"
          "\tcolumn c2\n\t\tdataType: string\n\tcolumn c3\n\t\tdataType: int64\n")
        w(os.path.join(self.rp, 'definition', 'pages', 'p1', 'visuals', 'hv', 'visual.json'),
          json.dumps({"name": "hv",
                      "position": {"x": 0, "y": 0, "z": 1, "width": 4, "height": 3},
                      "visual": {"visualType": "clusteredColumnChart",
                                 "query": {"queryState": {"Category": {"projections": [
                                     {"field": {"HierarchyLevel": {
                                         "Expression": {"Hierarchy": {
                                             "Expression": {"SourceRef": {"Entity": "geo"}},
                                             "Hierarchy": "Geo"}},
                                         "Level": "Country"}},
                                      "queryRef": "geo.Geo.Country"}]}}}}}))
        fs = [f for f in self.run_adv() if f['rule'] == 'MDL-22']
        self.assertTrue(fs, 'יתומים לא זוהו בכלל')
        self.assertNotIn('Country', fs[0]['detail'], 'עמודה קשורה להיררכיה סומנה (FP)')

    def test_few_orphan_columns_clean(self):
        # עמודה יתומה אחת — מתחת לסף, לא מסמנים
        w(os.path.join(self.sm, 'definition', 'tables', 'orphc.tmdl'),
          "table orphc\n\tcolumn c1\n\t\tdataType: string\n")
        self.assertFalse(any(f['rule'] == 'MDL-22' for f in self.run_adv()),
                         'עמודה בודדת סומנה (מתחת לסף) (FP)')

    def add_visual_at(self, vid, vtype, roles, y=0, x=0, page='p1'):
        qs = {role: {"projections": [
            {"field": {kind: {"Expression": {"SourceRef": {"Entity": ent}}, "Property": prop}},
             "queryRef": "q%d" % i}
            for i, (kind, ent, prop) in enumerate(flds)]} for role, flds in roles.items()}
        w(os.path.join(self.rp, 'definition', 'pages', page, 'visuals', vid, 'visual.json'),
          json.dumps({"name": vid,
                      "position": {"x": x, "y": y, "z": 1, "width": 4, "height": 3},
                      "visual": {"visualType": vtype, "query": {"queryState": qs}}}))

    def test_near_misaligned_row_flagged(self):
        # ADV-16: פער y של פיקסלים בודדים בשורה אחת (powerbi.tips — יישור לרשת)
        roles = {'Category': [('Column', 'dim_date', 'MonthName')],
                 'Y': [('Measure', 'dim_date', 'total')]}
        self.add_visual_at('a1', 'clusteredBarChart', roles, y=100)
        self.add_visual_at('a2', 'clusteredColumnChart', roles, y=108, x=400)
        fs = self.run_adv()
        self.assertTrue(any(f['rule'] == 'ADV-16' for f in fs), 'שורה כמעט-מיושרת לא זוהתה')

    def test_exactly_aligned_row_clean(self):
        roles = {'Category': [('Column', 'dim_date', 'MonthName')],
                 'Y': [('Measure', 'dim_date', 'total')]}
        self.add_visual_at('a3', 'clusteredBarChart', roles, y=100)
        self.add_visual_at('a4', 'clusteredColumnChart', roles, y=100, x=400)
        self.assertFalse(any(f['rule'] == 'ADV-16' for f in self.run_adv()),
                         'שורה מיושרת סומנה (FP)')

    def test_intentional_offset_clean(self):
        roles = {'Category': [('Column', 'dim_date', 'MonthName')],
                 'Y': [('Measure', 'dim_date', 'total')]}
        self.add_visual_at('a5', 'clusteredBarChart', roles, y=100)
        self.add_visual_at('a6', 'clusteredColumnChart', roles, y=132, x=400)
        self.assertFalse(any(f['rule'] == 'ADV-16' for f in self.run_adv()),
                         'סידור מכוון (>20px) סומן (FP)')

    def test_date_on_barchart_suggests_line(self):
        self.add_visual('v1', 'clusteredColumnChart',
                        {'Category': [('Column', 'dim_date', 'd')],
                         'Y': [('Measure', 'dim_date', 'total')]})
        fs = self.run_adv()
        a = [f for f in fs if f['rule'] == 'ADV-01']
        self.assertTrue(a and 'גבוהה' in a[0]['detail'], 'ציר זמן על עמודות לא זוהה')

    def test_linechart_on_string_category_suggests_bar(self):
        self.add_visual('v1', 'lineChart',
                        {'Category': [('Column', 'dim_date', 'MonthName')],
                         'Y': [('Measure', 'dim_date', 'total')]})
        self.assertTrue(any(f['rule'] == 'ADV-02' for f in self.run_adv()),
                        'lineChart על קטגוריית טקסט לא זוהה')

    def test_thin_table_suggests_chart(self):
        self.add_visual('v1', 'tableEx',
                        {'Values': [('Column', 'dim_date', 'MonthName'),
                                    ('Measure', 'dim_date', 'total')]})
        self.assertTrue(any(f['rule'] == 'ADV-03' for f in self.run_adv()),
                        'טבלה דלה לא זוהתה')

    def test_single_measure_table_suggests_card(self):
        self.add_visual('v1', 'tableEx', {'Values': [('Measure', 'dim_date', 'total')]})
        fs = [f for f in self.run_adv() if f['rule'] == 'ADV-03']
        self.assertTrue(fs and 'cardVisual' in fs[0]['fix'], 'טבלת מדד בודד לא זוהתה')

    def test_rich_table_no_advice(self):
        self.add_visual('v1', 'tableEx',
                        {'Values': [('Column', 'dim_date', 'MonthName'),
                                    ('Column', 'dim_date', 'MonthName'),
                                    ('Column', 'dim_date', 'MonthName'),
                                    ('Measure', 'dim_date', 'total')]})
        self.assertFalse(any(f['rule'] == 'ADV-03' for f in self.run_adv()),
                         'טבלת פירוט עשירה סומנה בטעות (FP)')

    def test_cluttered_page_suggests_split(self):
        for i in range(9):
            self.add_visual('v%d' % i, 'cardVisual',
                            {'Data': [('Measure', 'dim_date', 'total')]})
        self.assertTrue(any(f['rule'] == 'ADV-04' for f in self.run_adv()),
                        'דף עמוס לא זוהה')

    def test_kpi_without_goal_flagged(self):
        self.add_visual('v1', 'kpi', {'Indicator': [('Measure', 'dim_date', 'total')],
                                      'TrendLine': [('Column', 'dim_date', 'd')]})
        self.assertTrue(any(f['rule'] == 'ADV-05' for f in self.run_adv()),
                        'KPI בלי Goal לא זוהה')

    def test_kpi_with_goal_clean(self):
        self.add_visual('v1', 'kpi', {'Indicator': [('Measure', 'dim_date', 'total')],
                                      'TrendLine': [('Column', 'dim_date', 'd')],
                                      'Goal': [('Measure', 'dim_date', 'total')]})
        self.assertFalse(any(f['rule'] == 'ADV-05' for f in self.run_adv()),
                         'KPI תקין סומן בטעות (FP)')

    def test_sorted_category_no_line_advice(self):
        # ADV-02 suppression: קטגוריית טקסט עם sortByColumn — יש סדר טבעי מוגדר, לא ממליצים
        w(os.path.join(self.sm, 'definition', 'tables', 'dim_m.tmdl'),
          "table dim_m\n"
          "\tcolumn MonthName\n\t\tdataType: string\n\t\tsortByColumn: MonthNum\n"
          "\tcolumn MonthNum\n\t\tdataType: int64\n"
          "\tmeasure total = 1\n")
        self.add_visual('v1', 'lineChart',
                        {'Category': [('Column', 'dim_m', 'MonthName')],
                         'Y': [('Measure', 'dim_m', 'total')]})
        self.assertFalse(any(f['rule'] == 'ADV-02' for f in self.run_adv()),
                         'lineChart על קטגוריה עם sortByColumn סומן (FP)')

    def test_geo_category_suggests_map(self):
        w(os.path.join(self.sm, 'definition', 'tables', 'dim_geo.tmdl'),
          "table dim_geo\n"
          "\tcolumn City\n\t\tdataType: string\n\t\tdataCategory: City\n"
          "\tmeasure total = 1\n")
        self.add_visual('v1', 'barChart',
                        {'Category': [('Column', 'dim_geo', 'City')],
                         'Y': [('Measure', 'dim_geo', 'total')]})
        fs = [f for f in self.run_adv() if f['rule'] == 'ADV-06']
        self.assertTrue(fs and 'גבוהה' in fs[0]['detail'], 'ציר גיאוגרפי על עמודות לא זוהה')

    def test_map_without_geo_category_flagged(self):
        w(os.path.join(self.sm, 'definition', 'tables', 'dim_g2.tmdl'),
          "table dim_g2\n"
          "\tcolumn Place\n\t\tdataType: string\n"
          "\tmeasure total = 1\n")
        self.add_visual('v1', 'map',
                        {'Category': [('Column', 'dim_g2', 'Place')],
                         'Size': [('Measure', 'dim_g2', 'total')]})
        fs = [f for f in self.run_adv() if f['rule'] == 'ADV-06']
        self.assertTrue(any('dataCategory' in f['title'] for f in fs),
                        'מפה בלי dataCategory גיאוגרפי לא סומנה')

    def test_map_with_geo_category_clean(self):
        w(os.path.join(self.sm, 'definition', 'tables', 'dim_g3.tmdl'),
          "table dim_g3\n"
          "\tcolumn City\n\t\tdataType: string\n\t\tdataCategory: City\n"
          "\tmeasure total = 1\n")
        self.add_visual('v1', 'map',
                        {'Category': [('Column', 'dim_g3', 'City')],
                         'Size': [('Measure', 'dim_g3', 'total')]})
        self.assertFalse(any(f['rule'] == 'ADV-06' for f in self.run_adv()),
                         'מפה עם dataCategory תקין סומנה (FP)')

    def test_key_on_axis_suggests_label(self):
        w(os.path.join(self.sm, 'definition', 'tables', 'dim_p.tmdl'),
          "table dim_p\n"
          "\tcolumn ProductID\n\t\tdataType: int64\n\t\tisKey: true\n"
          "\tcolumn ProductName\n\t\tdataType: string\n"
          "\tmeasure total = 1\n")
        self.add_visual('v1', 'clusteredColumnChart',
                        {'Category': [('Column', 'dim_p', 'ProductID')],
                         'Y': [('Measure', 'dim_p', 'total')]})
        fs = [f for f in self.run_adv() if f['rule'] == 'ADV-07']
        self.assertTrue(fs and 'ProductName' in fs[0]['detail'], 'ציר על מפתח לא זוהה')

    def test_date_key_on_axis_no_label_advice(self):
        # מפתח מסוג dateTime על ציר = לגיטימי (זו עמודת התאריך), לא ממליצים תווית
        self.add_visual('v1', 'lineChart',
                        {'Category': [('Column', 'dim_date', 'd')],
                         'Y': [('Measure', 'dim_date', 'total')]})
        self.assertFalse(any(f['rule'] == 'ADV-07' for f in self.run_adv()),
                         'ציר על מפתח תאריך סומן (FP)')

    def test_summarizeby_none_as_value_flagged(self):
        w(os.path.join(self.sm, 'definition', 'tables', 'fact_s.tmdl'),
          "table fact_s\n"
          "\tcolumn Price\n\t\tdataType: int64\n\t\tsummarizeBy: none\n"
          "\tmeasure total = 1\n")
        self.add_visual('v1', 'clusteredColumnChart',
                        {'Category': [('Column', 'dim_date', 'MonthName')],
                         'Y': [('Column', 'fact_s', 'Price')]})
        fs = [f for f in self.run_adv() if f['rule'] == 'ADV-08']
        self.assertTrue(fs and 'גבוהה' in fs[0]['detail'], 'summarizeBy=none כערך לא זוהה')

    def test_slicer_summarizeby_none_no_adv08(self):
        # סליסר: role Values הוא שדה הסינון — לא מוצגת אגרגציה, אין FP
        # (נמצא על corpus אמיתי: superstore SlicerRegion/SlicerState)
        w(os.path.join(self.sm, 'definition', 'tables', 'fact_sl.tmdl'),
          "table fact_sl\n"
          "\tcolumn Region\n\t\tdataType: string\n\t\tsummarizeBy: none\n"
          "\tmeasure total = 1\n")
        self.add_visual('sl1', 'slicer', {'Values': [('Column', 'fact_sl', 'Region')]})
        self.assertFalse(any(f['rule'] == 'ADV-08' for f in self.run_adv()),
                         'סליסר עם עמודת summarizeBy=none סומן כ-ADV-08 (FP)')

    def test_table_numeric_summarizeby_none_no_adv08(self):
        # טבלה לא כופה אגרגציה — don't-summarize מציג ערכים; FP שנמצא בדוחות המשתמש
        w(os.path.join(self.sm, 'definition', 'tables', 'fact_t.tmdl'),
          "table fact_t\n"
          "\tcolumn Price\n\t\tdataType: int64\n\t\tsummarizeBy: none\n"
          "\tmeasure total = 1\n")
        self.add_visual('t1', 'tableEx', {'Values': [('Column', 'fact_t', 'Price')]})
        self.assertFalse(any(f['rule'] == 'ADV-08' for f in self.run_adv()),
                         'עמודה מספרית בטבלה סומנה כ-ADV-08 (FP)')

    def test_string_column_in_chart_no_adv08(self):
        # עמודת טקסט בגרף היא First/Count — אין בלבול סכום/ספירה; מחוץ להיקף ADV-08
        w(os.path.join(self.sm, 'definition', 'tables', 'fact_x.tmdl'),
          "table fact_x\n"
          "\tcolumn Region\n\t\tdataType: string\n\t\tsummarizeBy: none\n"
          "\tmeasure total = 1\n")
        self.add_visual('x1', 'clusteredColumnChart',
                        {'Category': [('Column', 'dim_date', 'MonthName')],
                         'Y': [('Column', 'fact_x', 'Region')]})
        self.assertFalse(any(f['rule'] == 'ADV-08' for f in self.run_adv()),
                         'עמודת טקסט בגרף סומנה כ-ADV-08 (FP)')

    def test_sum_count_pattern_advised(self):
        w(os.path.join(self.sm, 'definition', 'tables', 'fact_sc.tmdl'),
          "table fact_sc\n"
          "\tcolumn qty\n\t\tdataType: int64\n"
          "\tmeasure avg_hack = SUM ( fact_sc[qty] ) / COUNT ( fact_sc[qty] )\n")
        self.assertTrue(any(f['rule'] == 'DAX-15' for f in self.run_model()),
                        'SUM/COUNT על אותה עמודה לא זוהה')

    def test_average_builtin_no_dax15(self):
        w(os.path.join(self.sm, 'definition', 'tables', 'fact_av.tmdl'),
          "table fact_av\n"
          "\tcolumn qty\n\t\tdataType: int64\n"
          "\tmeasure avg_ok = AVERAGE ( fact_av[qty] )\n")
        self.assertFalse(any(f['rule'] == 'DAX-15' for f in self.run_model()),
                         'AVERAGE תקין סומן (FP)')

    def test_sum_count_different_columns_no_dax15(self):
        w(os.path.join(self.sm, 'definition', 'tables', 'fact_dc.tmdl'),
          "table fact_dc\n"
          "\tcolumn a\n\t\tdataType: int64\n\t\tcolumn b\n\t\tdataType: int64\n"
          "\tmeasure ratio = SUM ( fact_dc[a] ) / COUNT ( fact_dc[b] )\n")
        self.assertFalse(any(f['rule'] == 'DAX-15' for f in self.run_model()),
                         'SUM/COUNT על עמודות שונות סומן (FP)')

    def test_count_on_key_advised_countrows(self):
        # דוחות שבורים של המשתמש: מספר רשומות = COUNT(MoveID) על עמודת מפתח
        w(os.path.join(self.sm, 'definition', 'tables', 'fact_ck.tmdl'),
          "table fact_ck\n"
          "\tcolumn MoveID\n\t\tdataType: int64\n\t\tisKey: true\n"
          "\tmeasure 'מספר רשומות' = COUNT ( fact_ck[MoveID] )\n")
        fs = [f for f in self.run_model() if f['rule'] == 'DAX-16']
        self.assertTrue(fs, 'COUNT על עמודת מפתח לא זוהה')

    def test_count_named_unique_suggests_distinctcount(self):
        # דוחות שבורים של המשתמש: ספקים ייחודיים = COUNT על עמודה
        w(os.path.join(self.sm, 'definition', 'tables', 'fact_cu.tmdl'),
          "table fact_cu\n"
          "\tcolumn sup\n\t\tdataType: string\n"
          "\tmeasure 'ספקים ייחודיים' = COUNT ( fact_cu[sup] )\n")
        fs = [f for f in self.run_model() if f['rule'] == 'DAX-16' and f['severity'] == 'warn']
        self.assertTrue(fs, 'COUNT במדד עם שם ייחודי לא זוהה')

    def test_countrows_builtin_no_dax16(self):
        w(os.path.join(self.sm, 'definition', 'tables', 'fact_cr.tmdl'),
          "table fact_cr\n"
          "\tcolumn q\n\t\tdataType: int64\n"
          "\tmeasure rows_ok = COUNTROWS ( fact_cr )\n")
        self.assertFalse(any(f['rule'] == 'DAX-16' for f in self.run_model()),
                         'COUNTROWS תקין סומן (FP)')

    def test_count_neutral_name_no_dax16(self):
        # COUNT על עמודה רגילה בשם ניטרלי — לגיטימי (סופר ערכים לא-ריקים)
        w(os.path.join(self.sm, 'definition', 'tables', 'fact_cn.tmdl'),
          "table fact_cn\n"
          "\tcolumn price\n\t\tdataType: int64\n"
          "\tmeasure priced = COUNT ( fact_cn[price] )\n")
        self.assertFalse(any(f['rule'] == 'DAX-16' for f in self.run_model()),
                         'COUNT עם שם ניטרלי סומן (FP)')

    def test_noop_arithmetic_flagged(self):
        # דוחות שבורים של המשתמש: עלות מתואמת = SUM(x) * 1
        w(os.path.join(self.sm, 'definition', 'tables', 'fact_no.tmdl'),
          "table fact_no\n"
          "\tcolumn v\n\t\tdataType: int64\n"
          "\tmeasure adj = SUM ( fact_no[v] ) * 1\n")
        self.assertTrue(any(f['rule'] == 'DAX-17' for f in self.run_model()),
                        'SUM(x)*1 לא זוהה')

    def test_real_multiplier_no_dax17(self):
        w(os.path.join(self.sm, 'definition', 'tables', 'fact_rm.tmdl'),
          "table fact_rm\n"
          "\tcolumn v\n\t\tdataType: int64\n"
          "\tmeasure yearly = SUM ( fact_rm[v] ) * 12\n"
          "\tmeasure pct = SUM ( fact_rm[v] ) * 1.5\n")
        self.assertFalse(any(f['rule'] == 'DAX-17' for f in self.run_model()),
                         'כפל אמיתי (*12 / *1.5) סומן (FP)')

    def test_magic_number_flagged(self):
        # דוחות שבורים של המשתמש: פער מהיעד = SUM(x) - 100000
        w(os.path.join(self.sm, 'definition', 'tables', 'fact_mg.tmdl'),
          "table fact_mg\n"
          "\tcolumn v\n\t\tdataType: int64\n"
          "\tmeasure gap = SUM ( fact_mg[v] ) - 100000\n")
        self.assertTrue(any(f['rule'] == 'DAX-18' for f in self.run_model()),
                        'מספר קסם לא זוהה')

    def test_scaling_divisor_no_dax18(self):
        # FP שנמצא בקורפוס: capital מחלק ב-1000000 בתוך FORMAT לתצוגת מיליונים
        w(os.path.join(self.sm, 'definition', 'tables', 'fact_sd.tmdl'),
          "table fact_sd\n"
          "\tcolumn v\n\t\tdataType: int64\n"
          "\tmeasure disp = FORMAT ( SUM ( fact_sd[v] ) / 1000000, \"0.0\" )\n")
        self.assertFalse(any(f['rule'] == 'DAX-18' for f in self.run_model()),
                         'סקיילינג /10^n ב-FORMAT סומן (FP)')

    def _measures_tmdl(self, tbl, n):
        return "table %s\n" % tbl + "\tcolumn c\n\t\tdataType: int64\n" + "".join(
            "\tmeasure m%d = SUM ( %s[c] )\n" % (i, tbl) for i in range(n))

    def test_measures_in_fact_table_flagged(self):
        # 5 הדשבורדים השבורים: ~15 מדדים בתוך טבלת ה-fact, בלי טבלת מדדים
        w(os.path.join(self.sm, 'definition', 'tables', 'fact_m.tmdl'),
          self._measures_tmdl('fact_m', 12))
        self.assertTrue(any(f['rule'] == 'MDL-23' for f in self.run_model()),
                        'מדדים בטבלת נתונים בלי טבלת מדדים לא זוהו')

    def test_dedicated_measures_table_no_mdl23(self):
        w(os.path.join(self.sm, 'definition', 'tables', 'fact_m2.tmdl'),
          "table fact_m2\n\tcolumn c\n\t\tdataType: int64\n")
        w(os.path.join(self.sm, 'definition', 'tables', 'measures_m.tmdl'),
          "table measures_m\n" + "".join(
              "\tmeasure mm%d = SUM ( fact_m2[c] )\n" % i for i in range(12)))
        self.assertFalse(any(f['rule'] == 'MDL-23' for f in self.run_model()),
                         'טבלת מדדים ייעודית סומנה (FP)')

    def test_few_measures_no_mdl23(self):
        w(os.path.join(self.sm, 'definition', 'tables', 'fact_m3.tmdl'),
          self._measures_tmdl('fact_m3', 5))
        self.assertFalse(any(f['rule'] == 'MDL-23' for f in self.run_model()),
                         '5 מדדים בלבד סומנו (FP)')

    def _hebrew_textbox(self, align):
        par = {"textRuns": [{"value": "כותרת ראשית"}]}
        if align:
            par["horizontalTextAlignment"] = align
        w(os.path.join(self.rp, 'definition', 'pages', 'p1', 'visuals', 'tb1', 'visual.json'),
          json.dumps({"name": "tb1",
                      "position": {"x": 0, "y": 0, "z": 1, "width": 400, "height": 40},
                      "visual": {"visualType": "textbox",
                                 "objects": {"general": [{"properties": {"paragraphs": [par]}}]}}}))

    def _run_a11y(self):
        C._FINDINGS.clear()
        C.check_a11y(C.read_report(self.rp))
        return C._FINDINGS

    def test_hebrew_left_alignment_flagged(self):
        # 5 הדשבורדים השבורים: horizontalTextAlignment: left על textbox עברי
        self._hebrew_textbox('left')
        self.assertTrue(any(f['rule'] == 'A11Y-10' for f in self._run_a11y()),
                        'יישור שמאל על עברית לא זוהה')

    def test_hebrew_right_alignment_no_a11y10(self):
        self._hebrew_textbox('right')
        self.assertFalse(any(f['rule'] == 'A11Y-10' for f in self._run_a11y()),
                         'יישור ימין על עברית סומן (FP)')

    def test_english_left_alignment_no_a11y10(self):
        w(os.path.join(self.rp, 'definition', 'pages', 'p1', 'visuals', 'tb2', 'visual.json'),
          json.dumps({"name": "tb2",
                      "position": {"x": 0, "y": 0, "z": 1, "width": 400, "height": 40},
                      "visual": {"visualType": "textbox",
                                 "objects": {"general": [{"properties": {"paragraphs": [
                                     {"horizontalTextAlignment": "left",
                                      "textRuns": [{"value": "Dashboard"}]}]}}]}}}))
        self.assertFalse(any(f['rule'] == 'A11Y-10' for f in self._run_a11y()),
                         'אנגלית מיושרת שמאל סומנה (FP)')

    def _run_report(self):
        C._FINDINGS.clear()
        C.check_report(C.read_report(self.rp))
        return C._FINDINGS

    def test_hidden_visual_flagged(self):
        # 5 הדשבורדים השבורים: ויזואל isHidden בדף גלוי
        self.add_visual('h1', 'clusteredColumnChart',
                        {'Category': [('Column', 'dim_date', 'MonthName')],
                         'Y': [('Measure', 'dim_date', 'total')]})
        p = os.path.join(self.rp, 'definition', 'pages', 'p1', 'visuals', 'h1', 'visual.json')
        d = json.load(open(p)); d['isHidden'] = True
        w(p, json.dumps(d))
        self.assertTrue(any(f['rule'] == 'RPT-25' for f in self._run_report()),
                        'ויזואל מוסתר לא זוהה')

    def test_hidden_visual_with_bookmarks_no_rpt25(self):
        # FP שנמצא בקורפוס: capital — 42 ויזואלים מוסתרים שהם מטרות bookmark
        self.add_visual('h2', 'clusteredColumnChart',
                        {'Category': [('Column', 'dim_date', 'MonthName')],
                         'Y': [('Measure', 'dim_date', 'total')]})
        p = os.path.join(self.rp, 'definition', 'pages', 'p1', 'visuals', 'h2', 'visual.json')
        d = json.load(open(p)); d['isHidden'] = True
        w(p, json.dumps(d))
        w(os.path.join(self.rp, 'definition', 'bookmarks', 'bm1.bookmark.json'),
          json.dumps({"name": "bm1"}))
        self.assertFalse(any(f['rule'] == 'RPT-25' for f in self._run_report()),
                         'דוח עם bookmarks — ויזואל מוסתר סומן (FP)')

    def _page_with_colors(self, page, colors):
        w(os.path.join(self.rp, 'definition', 'pages', page, 'page.json'),
          json.dumps({"name": page, "displayName": page, "width": 1280, "height": 720}))
        for i, c in enumerate(colors):
            w(os.path.join(self.rp, 'definition', 'pages', page, 'visuals', 'x%d' % i, 'visual.json'),
              json.dumps({"name": "x%d" % i,
                          "position": {"x": 0, "y": 0, "z": 1, "width": 4, "height": 3},
                          "visual": {"visualType": "card",
                                     "visualContainerObjects": {"title": [{"properties": {
                                         "text": {"expr": {"Literal": {"Value": "'t'"}}}}}]},
                                     "query": {"queryState": {"Values": {"projections": []}}},
                                     "objects": {"dataPoint": [{"properties": {"fill": {"solid": {"color": {"expr": {"Literal": {"Value": "'%s'" % c}}}}}}}]}}}))

    def test_disjoint_palettes_flagged(self):
        # 5 השבורים: דף 1 פלטה אחת, דף 2 פלטה זרה לגמרי
        self._page_with_colors('p2', ['#FF0000', '#00B050', '#7030A0'])
        self._page_with_colors('p3', ['#C00000', '#002060', '#FF66CC'])
        self.assertTrue(any(f['rule'] == 'RPT-26' for f in self._run_report()),
                        'פלטות זרות בין דפים לא זוהו')

    def test_shared_palette_no_rpt26(self):
        self._page_with_colors('p2', ['#FF0000', '#00B050', '#7030A0'])
        self._page_with_colors('p3', ['#FF0000', '#FFC000', '#92D050'])
        self.assertFalse(any(f['rule'] == 'RPT-26' for f in self._run_report()),
                         'פלטות עם חפיפה סומנו (FP)')

    def test_hallucinated_visual_type_flagged(self):
        # RPT-27: stackedColumnChart אינו סוג חוקי (המוערם הוא columnChart) — חשד להזיית LLM
        self.add_visual('hall1', 'stackedColumnChart',
                        {'Category': [('Column', 'dim_date', 'MonthName')],
                         'Y': [('Measure', 'dim_date', 'total')]})
        f = [x for x in self._run_report() if x['rule'] == 'RPT-27']
        self.assertTrue(f, 'שם visualType שהומצא לא זוהה')
        self.assertIn('stackedColumnChart', f[0]['location'])

    def test_hallucinated_not_counted_as_custom(self):
        # RPT-27 מפריד חשודים מ-RPT-13: שם שהומצא אינו "ויזואל מותאם" תקין
        self.add_visual('hall2', 'stackedBarChart',
                        {'Category': [('Column', 'dim_date', 'MonthName')],
                         'Y': [('Measure', 'dim_date', 'total')]})
        f13 = [x for x in self._run_report() if x['rule'] == 'RPT-13']
        self.assertFalse(any('stackedBarChart' in x['location'] for x in f13),
                         'שם שהומצא נספר כ-custom ב-RPT-13')

    def test_modern_builtins_not_custom(self):
        # קטלוג visual-types.md (MIT): barChart/columnChart/listSlicer/cardNew מובנים
        for i, vt in enumerate(('barChart', 'columnChart', 'listSlicer', 'cardNew')):
            self.add_visual('mod%d' % i, vt,
                            {'Category': [('Column', 'dim_date', 'MonthName')],
                             'Y': [('Measure', 'dim_date', 'total')]})
        rep = self._run_report()
        self.assertFalse(any(f['rule'] == 'RPT-27' for f in rep),
                         'visualType מובנה מודרני סומן כחשוד (FP)')
        f13 = [f for f in rep if f['rule'] == 'RPT-13']
        self.assertFalse(f13, 'visualType מובנה מודרני נספר כ-custom (FP): %s'
                         % (f13 and f13[0]['location']))

    def test_custom_hash_visual_stays_custom(self):
        # ויזואל AppSource עם סיומת גיבוב — נשאר custom (RPT-13), לא חשוד (RPT-27)
        self.add_visual('cust1', 'BarChartF5983CEA542C47889C9DE852B430DE5F',
                        {'Category': [('Column', 'dim_date', 'MonthName')],
                         'Y': [('Measure', 'dim_date', 'total')]})
        rep = self._run_report()
        self.assertFalse(any(f['rule'] == 'RPT-27' for f in rep),
                         'ויזואל מותאם עם גיבוב סומן כחשוד (FP)')
        f13 = [f for f in rep if f['rule'] == 'RPT-13']
        self.assertTrue(any('BarChartF5983CEA542C47889C9DE852B430DE5F' in f['location']
                            for f in f13),
                        'ויזואל מותאם עם גיבוב לא נספר ב-RPT-13')

    def test_missing_title_objects_flagged(self):
        # 5 השבורים: 6 ויזואלים בלי אובייקט title בכלל
        for vid in ('nt1', 'nt2'):
            self.add_visual(vid, 'clusteredColumnChart',
                            {'Category': [('Column', 'dim_date', 'MonthName')],
                             'Y': [('Measure', 'dim_date', 'total')]})
        self.assertTrue(any(f['rule'] == 'A11Y-11' for f in self._run_a11y()),
                        'ויזואלים בלי title לא זוהו')

    def test_single_missing_title_no_a11y11(self):
        self.add_visual('nt1', 'clusteredColumnChart',
                        {'Category': [('Column', 'dim_date', 'MonthName')],
                         'Y': [('Measure', 'dim_date', 'total')]})
        self.assertFalse(any(f['rule'] == 'A11Y-11' for f in self._run_a11y()),
                         'ויזואל בודד בלי title סומן (FP)')

    def _dark_page(self):
        w(os.path.join(self.rp, 'definition', 'pages', 'p1', 'page.json'),
          json.dumps({"name": "p1", "displayName": "ראשי", "width": 1280, "height": 720,
                      "objects": {"background": [{"properties": {"color": {"solid": {"color": {
                          "expr": {"Literal": {"Value": "'#1F1F1F'"}}}}}}}]}}))

    def test_dark_page_dark_default_text_flagged(self):
        # 5 השבורים: דף 2 רקע #1F1F1F על theme ברירת-מחדל (טקסט כהה)
        self._dark_page()
        self.assertTrue(any(f['rule'] == 'A11Y-12' for f in self._run_a11y()),
                        'רקע כהה עם טקסט כהה לא זוהה')

    def test_light_page_no_a11y12(self):
        self.assertFalse(any(f['rule'] == 'A11Y-12' for f in self._run_a11y()),
                         'דף בהיר סומן (FP)')

    def _fact_with_measures(self, n=3):
        w(os.path.join(self.sm, 'definition', 'tables', 'fact_d.tmdl'),
          "table fact_d\n"
          "\tcolumn cat\n\t\tdataType: string\n" + "".join(
              "\tmeasure fm%d = SUM ( fact_d[cat] )\n" % i for i in range(n)))

    def test_pie_category_from_fact_flagged(self):
        # 5 השבורים: דונאט/עוגה עם קטגוריה מטבלת ה-fact (קרדינליות גבוהה)
        self._fact_with_measures()
        self.add_visual('pie1', 'donutChart',
                        {'Category': [('Column', 'fact_d', 'cat')],
                         'Y': [('Measure', 'fact_d', 'fm0')]})
        self.assertTrue(any(f['rule'] == 'ADV-20' for f in self.run_adv()),
                        'עוגה עם קטגוריה מ-fact לא זוהתה')

    def test_pie_category_from_dim_no_adv20(self):
        self.add_visual('pie2', 'donutChart',
                        {'Category': [('Column', 'dim_date', 'MonthName')],
                         'Y': [('Measure', 'dim_date', 'total')]})
        self.assertFalse(any(f['rule'] == 'ADV-20' for f in self.run_adv()),
                         'עוגה עם קטגוריה מממד סומנה (FP)')

    def test_generic_title_flagged(self):
        # 5 השבורים: כותרות "נתונים", "פילוח", "ניצול"
        self._page_with_colors('p2', ['#FF0000'])
        p = os.path.join(self.rp, 'definition', 'pages', 'p2', 'visuals', 'x0', 'visual.json')
        d = json.load(open(p))
        d['visual']['visualContainerObjects']['title'][0]['properties']['text'] = {
            "expr": {"Literal": {"Value": "'נתונים'"}}}
        w(p, json.dumps(d))
        self.assertTrue(any(f['rule'] == 'ADV-21' for f in self.run_adv()),
                        'כותרת גנרית לא זוהתה')

    def test_descriptive_title_no_adv21(self):
        self._page_with_colors('p2', ['#FF0000'])
        p = os.path.join(self.rp, 'definition', 'pages', 'p2', 'visuals', 'x0', 'visual.json')
        d = json.load(open(p))
        d['visual']['visualContainerObjects']['title'][0]['properties']['text'] = {
            "expr": {"Literal": {"Value": "'מכירות לפי אזור — חודש נוכחי'"}}}
        w(p, json.dumps(d))
        self.assertFalse(any(f['rule'] == 'ADV-21' for f in self.run_adv()),
                         'כותרת תיאורית סומנה (FP)')

    def test_multirowcard_mixed_scales_flagged(self):
        # 5 השבורים: כרטיס עם כסף + אחוז + ספירה
        w(os.path.join(self.sm, 'definition', 'tables', 'fact_mc.tmdl'),
          "table fact_mc\n\tcolumn v\n\t\tdataType: int64\n"
          "\tmeasure money = SUM ( fact_mc[v] )\n"
          "\tmeasure cnt = COUNTROWS ( fact_mc )\n"
          "\tmeasure pct = SUM ( fact_mc[v] ) / SUM ( fact_mc[v] )\n")
        self.add_visual('mc1', 'multiRowCard',
                        {'Values': [('Measure', 'fact_mc', 'money'),
                                    ('Measure', 'fact_mc', 'cnt'),
                                    ('Measure', 'fact_mc', 'pct')]})
        self.assertTrue(any(f['rule'] == 'ADV-22' for f in self.run_adv()),
                        'כרטיס מעורב סקאלות לא זוהה')

    def test_multirowcard_uniform_scales_no_adv22(self):
        w(os.path.join(self.sm, 'definition', 'tables', 'fact_mu.tmdl'),
          "table fact_mu\n\tcolumn v\n\t\tdataType: int64\n"
          "\tmeasure m1 = SUM ( fact_mu[v] )\n"
          "\tmeasure m2 = AVERAGE ( fact_mu[v] )\n")
        self.add_visual('mc2', 'multiRowCard',
                        {'Values': [('Measure', 'fact_mu', 'm1'),
                                    ('Measure', 'fact_mu', 'm2')]})
        self.assertFalse(any(f['rule'] == 'ADV-22' for f in self.run_adv()),
                         'כרטיס אחיד סומן (FP)')

    def _title_on_visual(self, vid, page='p1'):
        # להוסיף title מוצג (show=true) לוויזואל קיים
        p = os.path.join(self.rp, 'definition', 'pages', page, 'visuals', vid, 'visual.json')
        d = json.load(open(p))
        d['visual']['visualContainerObjects'] = {"title": [{"properties": {
            "show": {"expr": {"Literal": {"Value": "true"}}},
            "text": {"expr": {"Literal": {"Value": "'\u05db\u05d5\u05ea\u05e8\u05ea'"}}}}}]}
        w(p, json.dumps(d))

    def test_untitled_page_flagged(self):
        # דף עם ויזואלי נתונים, בלי textbox ובלי title מוצג → ADV-23
        self.add_visual('c1', 'card', {'Values': [('Measure', 'dim_date', 'total')]})
        self.assertTrue(any(f['rule'] == 'ADV-23' for f in self.run_adv()),
                        'דף בלי כותרת לא זוהה')

    def test_textbox_page_no_adv23(self):
        self.add_visual('c1', 'card', {'Values': [('Measure', 'dim_date', 'total')]})
        self.add_visual('tb1', 'textbox', {})
        self.assertFalse(any(f['rule'] == 'ADV-23' for f in self.run_adv()),
                         'דף עם textbox סומן (FP)')

    def test_titled_visual_page_no_adv23(self):
        self.add_visual('c1', 'card', {'Values': [('Measure', 'dim_date', 'total')]})
        self._title_on_visual('c1')
        self.assertFalse(any(f['rule'] == 'ADV-23' for f in self.run_adv()),
                         'דף עם title מוצג סומן (FP)')

    def test_empty_page_no_adv23(self):
        # דף ריק — אין על מה להמליץ כותרת
        self.assertFalse(any(f['rule'] == 'ADV-23' for f in self.run_adv()),
                         'דף ריק סומן (FP)')

    def _rename_page(self, name, page='p1'):
        pth = os.path.join(self.rp, 'definition', 'pages', page, 'page.json')
        d = json.load(open(pth))
        d['displayName'] = name
        w(pth, json.dumps(d))

    def test_default_page_name_flagged(self):
        # ADV-25: שם ברירת-מחדל אנגלי "Page 1" → הכותב לא שינה (pbir-utils, MIT)
        self._rename_page('Page 1')
        self.assertTrue(any(f['rule'] == 'ADV-25' for f in self.run_adv()),
                        "דף 'Page 1' לא זוהה")

    def test_hebrew_default_page_name_flagged(self):
        self._rename_page('\u05e2\u05de\u05d5\u05d3 2')
        self.assertTrue(any(f['rule'] == 'ADV-25' for f in self.run_adv()),
                        "דף 'עמוד 2' לא זוהה")

    def test_named_page_no_adv25(self):
        self._rename_page('\u05e1\u05e7\u05d9\u05e8\u05d4 \u05db\u05dc\u05dc\u05d9\u05ea')
        self.assertFalse(any(f['rule'] == 'ADV-25' for f in self.run_adv()),
                         'דף עם שם משמעותי סומן (FP)')

    def test_page_word_not_default_no_adv25(self):
        # "Pagination report" מתחיל ב-Page אבל אינו שם ברירת-מחדל
        self._rename_page('Pagination report')
        self.assertFalse(any(f['rule'] == 'ADV-25' for f in self.run_adv()),
                         'דף Page-like לא-ברירת-מחדל סומן (FP)')

    def _rel(self, frm, to, fcard='many', tcard='one'):
        w(os.path.join(self.sm, 'definition', 'relationships.tmdl'),
          "relationship r1\n"
          "\tfromCardinality: %s\n\ttoCardinality: %s\n"
          "\tfromColumn: %s\n\ttoColumn: %s\n" % (fcard, tcard, frm, to))

    def test_relationship_on_text_name_flagged(self):
        # 5 השבורים: קשר על עמודת שם טקסטואלית במקום מפתח
        w(os.path.join(self.sm, 'definition', 'tables', 'dim_item.tmdl'),
          "table dim_item\n\tcolumn שם_פריט\n\t\tdataType: string\n")
        self._rel('dim_date.d', 'dim_item.שם_פריט')
        fs = [f for f in self.run_model() if f['rule'] == 'MDL-24']
        self.assertTrue(fs and fs[0]['severity'] == 'warn', 'קשר על עמודת שם לא זוהה')

    def test_relationship_on_key_column_no_mdl24(self):
        w(os.path.join(self.sm, 'definition', 'tables', 'dim_k.tmdl'),
          "table dim_k\n\tcolumn code\n\t\tdataType: string\n\t\tisKey: true\n")
        self._rel('dim_date.d', 'dim_k.code')
        self.assertFalse(any(f['rule'] == 'MDL-24' for f in self.run_model()),
                         'קשר על עמודת מפתח סומן (FP)')

    def test_relationship_on_text_id_tip_not_warn(self):
        # FP מהקורפוס: insurance Claim_ID — עמודת מזהה טקסטואלית, לא שם תצוגה
        w(os.path.join(self.sm, 'definition', 'tables', 'dim_c.tmdl'),
          "table dim_c\n\tcolumn Claim_ID\n\t\tdataType: string\n")
        self._rel('dim_date.d', 'dim_c.Claim_ID')
        fs = [f for f in self.run_model() if f['rule'] == 'MDL-24']
        self.assertTrue(fs and fs[0]['severity'] == 'tip',
                        'עמודת ID טקסטואלית צריכה tip, לא warn')

    def test_two_tables_no_relationship_flagged(self):
        # דוחות המשתמש 01/03/05: שתי טבלאות נתונים בלי אף קשר
        w(os.path.join(self.sm, 'definition', 'tables', 'fact_a.tmdl'),
          "table fact_a\n\tcolumn v\n\t\tdataType: int64\n")
        fs = [f for f in self.run_model() if f['rule'] == 'MDL-25']
        self.assertTrue(fs and fs[0]['severity'] == 'warn', 'סכמה מנותקת לא זוהתה')

    def test_relationship_present_no_mdl25(self):
        w(os.path.join(self.sm, 'definition', 'tables', 'fact_b.tmdl'),
          "table fact_b\n\tcolumn v\n\t\tdataType: int64\n")
        self._rel('fact_b.v', 'dim_date.d')
        self.assertFalse(any(f['rule'] == 'MDL-25' for f in self.run_model()),
                         'מודל עם קשר סומן (FP)')

    def test_inline_model_tmdl_relationship_no_mdl25(self):
        # קשר inline בתוך model.tmdl (לא relationships.tmdl) — חייב להיספר
        w(os.path.join(self.sm, 'definition', 'tables', 'fact_c.tmdl'),
          "table fact_c\n\tcolumn v\n\t\tdataType: int64\n")
        w(os.path.join(self.sm, 'definition', 'model.tmdl'),
          "model Model\n\tculture: en-US\n\n"
          "relationship r9\n\tfromColumn: fact_c.v\n\ttoColumn: dim_date.d\n")
        self.assertFalse(any(f['rule'] == 'MDL-25' for f in self.run_model()),
                         'קשר inline ב-model.tmdl לא נספר (FP)')

    def test_measures_only_table_no_mdl25(self):
        # טבלת מדדים-בלבד מנותקת מכוונת — לא נספרת כטבלת נתונים
        w(os.path.join(self.sm, 'definition', 'tables', '_measures.tmdl'),
          "table _measures\n\tmeasure mm = 1\n")
        self.assertFalse(any(f['rule'] == 'MDL-25' for f in self.run_model()),
                         'טבלת מדדים-בלבד סומנה (FP)')

    def test_single_table_no_mdl25(self):
        self.assertFalse(any(f['rule'] == 'MDL-25' for f in self.run_model()),
                         'מודל טבלה-יחידה סומן (FP)')

    def test_filter_whole_table_simple_condition_flagged(self):
        # insurance בקורפוס: FILTER(FactClaims, NOT ISBLANK(FactClaims[Settlement_Days]))
        w(os.path.join(self.sm, 'definition', 'tables', 'fact_f.tmdl'),
          "table fact_f\n\tcolumn v\n\t\tdataType: int64\n"
          "\tmeasure m_f = CALCULATE ( COUNTROWS ( fact_f ), FILTER ( fact_f, fact_f[v] > 3 ) )\n")
        fs = [f for f in self.run_model() if f['rule'] == 'DAX-20']
        self.assertTrue(fs and fs[0]['severity'] == 'tip', 'FILTER על טבלה שלמה לא זוהה')

    def test_filter_complex_condition_no_dax20(self):
        # metro בקורפוס: תנאי עם && על שני מדדים — איטרציה חוקית
        w(os.path.join(self.sm, 'definition', 'tables', 'fact_c2.tmdl'),
          "table fact_c2\n\tcolumn v\n\t\tdataType: int64\n"
          "\tmeasure a2 = 1\n\tmeasure b2 = 2\n"
          "\tmeasure m_c = CALCULATE ( COUNTROWS ( fact_c2 ), FILTER ( fact_c2, [a2] > 0 && [b2] > 0 ) )\n")
        self.assertFalse(any(f['rule'] == 'DAX-20' for f in self.run_model()),
                         'תנאי מרוכב סומן (FP)')

    def test_filter_local_table_var_no_dax20(self):
        # claude בקורפוס: FILTER על VAR טבלה מקומי — לא טבלת מודל
        w(os.path.join(self.sm, 'definition', 'tables', 'fact_v.tmdl'),
          "table fact_v\n\tcolumn v\n\t\tdataType: int64\n"
          "\tmeasure m_v = VAR t = VALUES ( fact_v[v] ) RETURN CALCULATE ( COUNTROWS ( fact_v ), FILTER ( t, [v] > 1 ) )\n")
        self.assertFalse(any(f['rule'] == 'DAX-20' for f in self.run_model()),
                         'FILTER בתוך VAR סומן (FP)')

    def test_filter_values_wrapper_no_dax20(self):
        w(os.path.join(self.sm, 'definition', 'tables', 'fact_w.tmdl'),
          "table fact_w\n\tcolumn v\n\t\tdataType: int64\n"
          "\tmeasure m_w = CALCULATE ( COUNTROWS ( fact_w ), FILTER ( VALUES ( fact_w[v] ), fact_w[v] > 1 ) )\n")
        self.assertFalse(any(f['rule'] == 'DAX-20' for f in self.run_model()),
                         'FILTER(VALUES(...)) סומן (FP)')

    def test_sum_vs_average_comparison_flagged(self):
        # 5 השבורים: סטטוס כולל = IF([עלות כוללת] > [ממוצע עלות], ...)
        w(os.path.join(self.sm, 'definition', 'tables', 'fact_g.tmdl'),
          "table fact_g\n\tcolumn v\n\t\tdataType: int64\n"
          "\tmeasure total_g = SUM ( fact_g[v] )\n"
          "\tmeasure avg_g = AVERAGE ( fact_g[v] )\n"
          "\tmeasure status_g = IF ( [total_g] > [avg_g], \"high\", \"low\" )\n")
        self.assertTrue(any(f['rule'] == 'DAX-19' for f in self.run_model()),
                        'השוואת סכום-ממוצע לא זוהתה')

    def test_same_grain_comparison_no_dax19(self):
        w(os.path.join(self.sm, 'definition', 'tables', 'fact_sg.tmdl'),
          "table fact_sg\n\tcolumn v\n\t\tdataType: int64\n"
          "\tmeasure a_sg = SUM ( fact_sg[v] )\n"
          "\tmeasure b_sg = SUM ( fact_sg[v] ) * 2\n"
          "\tmeasure cmp_sg = IF ( [a_sg] > [b_sg], \"x\", \"y\" )\n")
        self.assertFalse(any(f['rule'] == 'DAX-19' for f in self.run_model()),
                         'השוואת סכום-סכום סומנה (FP)')

    def test_small_constant_no_dax18(self):
        w(os.path.join(self.sm, 'definition', 'tables', 'fact_sc2.tmdl'),
          "table fact_sc2\n"
          "\tcolumn v\n\t\tdataType: int64\n"
          "\tmeasure thresh = SUM ( fact_sc2[v] ) - 500\n")
        self.assertFalse(any(f['rule'] == 'DAX-18' for f in self.run_model()),
                         'קבוע קטן סומן (FP)')

    def test_normal_measure_value_no_adv08(self):
        self.add_visual('v1', 'clusteredColumnChart',
                        {'Category': [('Column', 'dim_date', 'MonthName')],
                         'Y': [('Measure', 'dim_date', 'total')]})
        self.assertFalse(any(f['rule'] == 'ADV-08' for f in self.run_adv()),
                         'מדד רגיל סומן כ-ADV-08 (FP)')

    def add_visual_raw_fields(self, vid, vtype, roles):
        """roles: {role: [field-dict]} — לצורות field מיוחדות (HierarchyLevel/Aggregation)."""
        qs = {role: {"projections": [
            {"field": fld, "queryRef": "q%d" % i}
            for i, fld in enumerate(flds)]} for role, flds in roles.items()}
        w(os.path.join(self.rp, 'definition', 'pages', 'p1', 'visuals', vid, 'visual.json'),
          json.dumps({"name": vid,
                      "position": {"x": 0, "y": 0, "z": 1, "width": 4, "height": 3},
                      "visual": {"visualType": vtype, "query": {"queryState": qs}}}))

    @staticmethod
    def _hier(ent, hier, level):
        return {"HierarchyLevel": {
            "Expression": {"Hierarchy": {"Expression": {"SourceRef": {"Entity": ent}},
                                          "Hierarchy": hier}},
            "Level": level}}

    def test_hierarchy_date_level_suggests_line(self):
        self.add_visual_raw_fields('v1', 'clusteredColumnChart',
            {'Category': [self._hier('dim_date', 'DateDrill', 'd')],
             'Y': [{"Measure": {"Expression": {"SourceRef": {"Entity": "dim_date"}},
                                "Property": "total"}}]})
        fs = [f for f in self.run_adv() if f['rule'] == 'ADV-01']
        self.assertTrue(fs and 'גבוהה' in fs[0]['detail'],
                        'רמת תאריך בהיררכיה על עמודות לא זוהתה כציר זמן')

    def test_hierarchy_string_level_on_line_suggests_bar(self):
        self.add_visual_raw_fields('v1', 'lineChart',
            {'Category': [self._hier('dim_date', 'DateDrill', 'MonthName')],
             'Y': [{"Measure": {"Expression": {"SourceRef": {"Entity": "dim_date"}},
                                "Property": "total"}}]})
        self.assertTrue(any(f['rule'] == 'ADV-02' for f in self.run_adv()),
                        'רמת טקסט בהיררכיה על lineChart לא זוהתה')

    def test_aggregation_wrapped_column_parsed(self):
        w(os.path.join(self.sm, 'definition', 'tables', 'fact_a.tmdl'),
          "table fact_a\n"
          "\tcolumn Price\n\t\tdataType: int64\n\t\tsummarizeBy: none\n"
          "\tmeasure total = 1\n")
        self.add_visual_raw_fields('v1', 'clusteredColumnChart',
            {'Category': [{"Column": {"Expression": {"SourceRef": {"Entity": "dim_date"}},
                                      "Property": "MonthName"}}],
             'Y': [{"Aggregation": {"Expression": {"Column": {
                        "Expression": {"SourceRef": {"Entity": "fact_a"}},
                        "Property": "Price"}}, "Function": 0}}]})
        self.assertTrue(any(f['rule'] == 'ADV-08' for f in self.run_adv()),
                        'עמודת summarizeBy=none בעטיפת Aggregation לא זוהתה')

    def test_hidden_column_on_axis_flagged(self):
        w(os.path.join(self.sm, 'definition', 'tables', 'dim_h.tmdl'),
          "table dim_h\n"
          "\tcolumn Secret\n\t\tdataType: string\n\t\tisHidden\n"
          "\tmeasure total = 1\n")
        self.add_visual('v1', 'barChart',
                        {'Category': [('Column', 'dim_h', 'Secret')],
                         'Y': [('Measure', 'dim_h', 'total')]})
        fs = [f for f in self.run_adv() if f['rule'] == 'ADV-09']
        self.assertTrue(fs and 'גבוהה' in fs[0]['detail'], 'שדה מוסתר בוויזואל לא זוהה')

    def test_visible_column_no_adv09(self):
        self.add_visual('v1', 'barChart',
                        {'Category': [('Column', 'dim_date', 'MonthName')],
                         'Y': [('Measure', 'dim_date', 'total')]})
        self.assertFalse(any(f['rule'] == 'ADV-09' for f in self.run_model()),
                         'עמודה גלויה סומנה כמוסתרת (FP)')

    def test_numeric_category_binning_note(self):
        w(os.path.join(self.sm, 'definition', 'tables', 'fact_n.tmdl'),
          "table fact_n\n"
          "\tcolumn Age\n\t\tdataType: int64\n"
          "\tmeasure total = 1\n")
        self.add_visual('v1', 'clusteredColumnChart',
                        {'Category': [('Column', 'fact_n', 'Age')],
                         'Y': [('Measure', 'fact_n', 'total')]})
        fs = [f for f in self.run_adv() if f['rule'] == 'ADV-10']
        self.assertTrue(fs and 'בינונית' in fs[0]['detail'], 'ציר מספרי רציף לא זוהה')

    def test_numeric_key_category_no_adv10(self):
        w(os.path.join(self.sm, 'definition', 'tables', 'dim_k.tmdl'),
          "table dim_k\n"
          "\tcolumn YearNum\n\t\tdataType: int64\n\t\tisKey: true\n"
          "\tmeasure total = 1\n")
        self.add_visual('v1', 'clusteredColumnChart',
                        {'Category': [('Column', 'dim_k', 'YearNum')],
                         'Y': [('Measure', 'dim_k', 'total')]})
        self.assertFalse(any(f['rule'] == 'ADV-10' for f in self.run_adv()),
                         'ציר על מפתח מספרי סומן (FP)')

    def test_disconnected_tables_on_one_visual_flagged(self):
        w(os.path.join(self.sm, 'definition', 'tables', 'dim_x.tmdl'),
          "table dim_x\n"
          "\tcolumn Region\n\t\tdataType: string\n"
          "\tmeasure total = 1\n")
        self.add_visual('v1', 'clusteredColumnChart',
                        {'Category': [('Column', 'dim_date', 'MonthName')],
                         'Series': [('Column', 'dim_x', 'Region')],
                         'Y': [('Measure', 'dim_date', 'total')]})
        fs = [f for f in self.run_adv() if f['rule'] == 'ADV-11']
        self.assertTrue(fs and 'dim_x' in fs[0]['title'], 'טבלאות מנותקות לא זוהו')

    def test_connected_tables_no_adv11(self):
        w(os.path.join(self.sm, 'definition', 'tables', 'dim_x.tmdl'),
          "table dim_x\n"
          "\tcolumn Region\n\t\tdataType: string\n"
          "\tcolumn d\n\t\tdataType: dateTime\n"
          "\tmeasure total = 1\n")
        w(os.path.join(self.sm, 'definition', 'relationships.tmdl'),
          "relationship r1\n\tfromColumn: dim_x.d\n\ttoColumn: dim_date.d\n")
        self.add_visual('v1', 'clusteredColumnChart',
                        {'Category': [('Column', 'dim_date', 'MonthName')],
                         'Series': [('Column', 'dim_x', 'Region')],
                         'Y': [('Measure', 'dim_date', 'total')]})
        self.assertFalse(any(f['rule'] == 'ADV-11' for f in self.run_adv()),
                         'טבלאות מחוברות סומנו (FP)')

    def test_slicer_on_disconnected_table_no_adv11(self):
        # דפוס what-if: סליסר על טבלת פרמטרים מנותקת — לגיטימי
        w(os.path.join(self.sm, 'definition', 'tables', 'param.tmdl'),
          "table param\n"
          "\tcolumn Choice\n\t\tdataType: string\n")
        self.add_visual('v1', 'slicer', {'Values': [('Column', 'param', 'Choice')]})
        self.assertFalse(any(f['rule'] == 'ADV-11' for f in self.run_adv()),
                         'סליסר על טבלה מנותקת סומן (FP)')

    def test_pie_without_category_flagged(self):
        self.add_visual('v1', 'pieChart', {'Values': [('Measure', 'dim_date', 'total')]})
        self.assertTrue(any(f['rule'] == 'ADV-12' for f in self.run_adv()),
                        'עוגה בלי קטגוריה לא זוהתה')

    def test_pie_with_legend_clean(self):
        self.add_visual('v1', 'pieChart',
                        {'Legend': [('Column', 'dim_date', 'MonthName')],
                         'Values': [('Measure', 'dim_date', 'total')]})
        self.assertFalse(any(f['rule'] == 'ADV-12' for f in self.run_adv()),
                         'עוגה עם Legend סומנה (FP)')

    def test_legacy_card_advised(self):
        self.add_visual('v1', 'card', {'Values': [('Measure', 'dim_date', 'total')]})
        self.assertTrue(any(f['rule'] == 'ADV-13' for f in self.run_adv()),
                        'card מיושן לא זוהה')

    def test_legacy_multirowcard_advised(self):
        self.add_visual('v1', 'multiRowCard', {'Values': [('Measure', 'dim_date', 'total')]})
        self.assertTrue(any(f['rule'] == 'ADV-13' for f in self.run_adv()),
                        'multiRowCard מיושן לא זוהה')

    def test_cardvisual_no_adv13(self):
        self.add_visual('v1', 'cardVisual', {'Data': [('Measure', 'dim_date', 'total')]})
        self.assertFalse(any(f['rule'] == 'ADV-13' for f in self.run_adv()),
                         'cardVisual סומן כמיושן (FP)')

    def _add_card(self, vid, y, objects=None):
        qs = {"Data": {"projections": [
            {"field": {"Measure": {"Expression": {"SourceRef": {"Entity": "dim_date"}},
                                   "Property": "total"}},
             "queryRef": "q0"}]}}
        w(os.path.join(self.rp, 'definition', 'pages', 'p1', 'visuals', vid, 'visual.json'),
          json.dumps({"name": vid,
                      "position": {"x": 0, "y": y, "z": 1, "width": 200, "height": 100},
                      "visual": {"visualType": "cardVisual",
                                 "query": {"queryState": qs},
                                 "objects": objects or {}}}))

    def test_two_single_cards_same_row_advised(self):
        self._add_card('c1', 0)
        self._add_card('c2', 8)
        self.assertTrue(any(f['rule'] == 'ADV-14' for f in self.run_adv()),
                        'שני כרטיסים חד-ערכיים באותה שורה לא זוהו')

    def test_cards_on_different_rows_no_adv14(self):
        self._add_card('c1', 0)
        self._add_card('c2', 400)
        self.assertFalse(any(f['rule'] == 'ADV-14' for f in self.run_adv()),
                         'כרטיסים בשורות שונות סומנו (FP)')

    def test_multivalue_card_no_adv14(self):
        self.add_visual('c1', 'cardVisual',
                        {'Data': [('Measure', 'dim_date', 'total'),
                                  ('Measure', 'dim_date', 'total2')]})
        self._add_card('c2', 0)
        self.assertFalse(any(f['rule'] == 'ADV-14' for f in self.run_adv()),
                         'כרטיס רב-ערכי + חד-ערכי סומנו (FP)')

    def test_slicer_on_many_side_column_advised(self):
        w(os.path.join(self.sm, 'definition', 'tables', 'fact_s.tmdl'),
          "table fact_s\n"
          "\tcolumn OrderId\n\t\tdataType: int64\n"
          "\tcolumn d\n\t\tdataType: dateTime\n"
          "\tmeasure total = 1\n")
        w(os.path.join(self.sm, 'definition', 'relationships.tmdl'),
          "relationship r1\n\tfromColumn: fact_s.d\n\tfromCardinality: many\n"
          "\ttoColumn: dim_date.d\n\ttoCardinality: one\n")
        self.add_visual('v1', 'slicer', {'Values': [('Column', 'fact_s', 'OrderId')]})
        self.assertTrue(any(f['rule'] == 'ADV-15' for f in self.run_adv()),
                        'סליסר על עמודת צד-many לא זוהה')

    def test_slicer_on_one_side_column_no_adv15(self):
        w(os.path.join(self.sm, 'definition', 'tables', 'fact_s.tmdl'),
          "table fact_s\n"
          "\tcolumn d\n\t\tdataType: dateTime\n"
          "\tmeasure total = 1\n")
        w(os.path.join(self.sm, 'definition', 'relationships.tmdl'),
          "relationship r1\n\tfromColumn: fact_s.d\n\tfromCardinality: many\n"
          "\ttoColumn: dim_date.d\n\ttoCardinality: one\n")
        self.add_visual('v1', 'slicer', {'Values': [('Column', 'dim_date', 'MonthName')]})
        self.assertFalse(any(f['rule'] == 'ADV-15' for f in self.run_adv()),
                         'סליסר על עמודת מימד סומן (FP)')

    def test_slicer_bidirectional_no_adv15(self):
        w(os.path.join(self.sm, 'definition', 'tables', 'fact_s.tmdl'),
          "table fact_s\n"
          "\tcolumn OrderId\n\t\tdataType: int64\n"
          "\tcolumn d\n\t\tdataType: dateTime\n"
          "\tmeasure total = 1\n")
        w(os.path.join(self.sm, 'definition', 'relationships.tmdl'),
          "relationship r1\n\tfromColumn: fact_s.d\n\tfromCardinality: many\n"
          "\ttoColumn: dim_date.d\n\ttoCardinality: one\n"
          "\tcrossFilteringBehavior: bothDirections\n")
        self.add_visual('v1', 'slicer', {'Values': [('Column', 'fact_s', 'OrderId')]})
        self.assertFalse(any(f['rule'] == 'ADV-15' for f in self.run_adv()),
                         'סליסר על קשר דו-כיווני סומן (FP)')

    def test_slicer_measure_no_adv15(self):
        self.add_visual('v1', 'slicer', {'Values': [('Measure', 'dim_date', 'total')]})
        self.assertFalse(any(f['rule'] == 'ADV-15' for f in self.run_adv()),
                         'סליסר על מדד סומן (FP)')

    def test_differently_styled_cards_no_adv14(self):
        self._add_card('c1', 0, {"accentBar": [{"properties": {}, "selector": {"id": "default"}}]})
        self._add_card('c2', 0)
        self.assertFalse(any(f['rule'] == 'ADV-14' for f in self.run_adv()),
                         'כרטיסים עם עיצוב שונה סומנו (FP)')

    def test_table_with_date_column_suggests_line(self):
        self.add_visual('v1', 'tableEx',
                        {'Values': [('Column', 'dim_date', 'd'),
                                    ('Measure', 'dim_date', 'total')]})
        fs = [f for f in self.run_adv() if f['rule'] == 'ADV-03']
        self.assertTrue(fs and 'lineChart' in fs[0]['title'] + fs[0]['fix'],
                        'טבלה עם עמודת תאריך לא קיבלה המלצת lineChart')

    def test_table_with_text_column_suggests_bar(self):
        self.add_visual('v1', 'tableEx',
                        {'Values': [('Column', 'dim_date', 'MonthName'),
                                    ('Measure', 'dim_date', 'total')]})
        fs = [f for f in self.run_adv() if f['rule'] == 'ADV-03']
        self.assertTrue(fs and 'barChart' in fs[0]['fix'],
                        'טבלה עם עמודת טקסט לא קיבלה המלצת barChart')

    def test_clean_visuals_no_advice(self):
        self.add_visual('v1', 'clusteredBarChart',
                        {'Category': [('Column', 'dim_date', 'MonthName')],
                         'Y': [('Measure', 'dim_date', 'total')]})
        self.add_visual('v2', 'cardVisual', {'Data': [('Measure', 'dim_date', 'total')]})
        self._title_on_visual('v1')  # דף מעוצב היטב כולל כותרת מוצגת (ADV-23)
        self.assertFalse([f for f in self.run_adv() if f['rule'].startswith('ADV')],
                         'ויזואלים תקינים סומנו בעיצוב (FP)')



class Adv17ExtendedRefs(unittest.TestCase):
    """סבב 85 — הרחבת ADV-17 מעבר ל-queryState: sortDefinition, ביטויי objects
    (כולל FillRule.Input) ו-filterConfig. מקור: TabularEditor-Scripts
    Fix Broken Fields.cs GetAllFields (MIT)."""

    def setUp(self):
        C._FINDINGS.clear()
        self.root = tempfile.mkdtemp(prefix='pbiadv17x-')
        self.sm = os.path.join(self.root, 'D.SemanticModel')
        self.rp = os.path.join(self.root, 'D.Report')
        w(os.path.join(self.sm, 'definition', 'tables', 'dim_date.tmdl'),
          "table dim_date\n"
          "\tcolumn d\n\t\tdataType: dateTime\n\t\tisKey: true\n"
          "\tcolumn MonthName\n\t\tdataType: string\n"
          "\tmeasure total = 1\n")
        w(os.path.join(self.rp, 'definition', 'report.json'), json.dumps({"name": "r"}))
        w(os.path.join(self.rp, 'definition', 'pages', 'p1', 'page.json'),
          json.dumps({"name": "p1", "displayName": "ראשי", "width": 1280, "height": 720}))

    def tearDown(self):
        shutil.rmtree(self.root, ignore_errors=True)

    def _vis(self, vid, extra=None, hidden=False):
        qs = {"Category": {"projections": [
                  {"field": {"Column": {"Expression": {"SourceRef": {"Entity": "dim_date"}},
                                        "Property": "MonthName"}},
                   "queryRef": "q0"}]},
              "Y": {"projections": [
                  {"field": {"Measure": {"Expression": {"SourceRef": {"Entity": "dim_date"}},
                                         "Property": "total"}},
                   "queryRef": "q1"}]}}
        vis = {"visualType": "clusteredBarChart", "query": {"queryState": qs}}
        if extra:
            vis.update(extra)
        doc = {"name": vid, "position": {"x": 0, "y": 0, "z": 1, "width": 4, "height": 3},
               "visual": vis}
        if hidden:
            doc["visual"]["visualContainerObjects"] = {
                "visibility": [{"properties": {"show": {"expr": {"Literal": {"Value": "false"}}}}}]}
            doc["isHidden"] = True
        w(os.path.join(self.rp, 'definition', 'pages', 'p1', 'visuals', vid, 'visual.json'),
          json.dumps(doc))

    def run_adv(self):
        C._FINDINGS.clear()
        C.check_design(C.read_report(self.rp), C.read_model(self.sm))
        return C._FINDINGS

    def test_dead_ref_in_sortdefinition_flagged(self):
        self._vis('s1', extra={})  # בקרה: בלי תוספות — נקי
        qs_doc = json.load(open(os.path.join(self.rp, 'definition', 'pages', 'p1',
                                             'visuals', 's1', 'visual.json')))
        qs_doc['visual']['query']['sortDefinition'] = {"sort": [
            {"field": {"Column": {"Expression": {"SourceRef": {"Entity": "dim_date"}},
                                  "Property": "GhostSortCol"}},
             "direction": "Ascending"}]}
        w(os.path.join(self.rp, 'definition', 'pages', 'p1', 'visuals', 's1', 'visual.json'),
          json.dumps(qs_doc))
        fs = self.run_adv()
        hits = [f for f in fs if f['rule'] == 'ADV-17']
        self.assertTrue(hits, 'הפניה מתה ב-sortDefinition לא זוהתה')
        self.assertIn('GhostSortCol', hits[0]['detail'] + hits[0]['title'])

    def test_dead_ref_in_filterconfig_flagged(self):
        ghost_col = {"Column": {"Expression": {"SourceRef": {"Entity": "dim_date"}},
                                "Property": "GhostFilterCol"}}
        filt = {"field": ghost_col, "type": "Categorical",
                "filter": {"Where": [{"Condition": {"In": {"Expressions": [ghost_col]}}}]}}
        self._vis('f1', extra={"filterConfig": {"filters": [filt]}})
        fs = self.run_adv()
        self.assertTrue(any(f['rule'] == 'ADV-17' for f in fs),
                        'הפניה מתה ב-filterConfig לא זוהתה')

    def test_dead_ref_in_objects_expr_flagged(self):
        self._vis('o1', extra={"objects": {"dataPoint": [
            {"selector": {"data": [{"dataViewWildcard": {"matchingOption": 1}}]},
             "properties": {"fill": {"solid": {"color": {"expr": {
                 "FillRule": {"linearGradient2": {"min": {}, "max": {}},
                              "Input": {"Measure": {"Expression": {"SourceRef":
                                                   {"Entity": "dim_date"}},
                                        "Property": "GhostMeasure"}}}}}}}}}]}})
        fs = self.run_adv()
        self.assertTrue(any(f['rule'] == 'ADV-17' for f in fs),
                        'הפניה מתה ב-FillRule.Input לא זוהתה')

    def test_valid_refs_everywhere_clean(self):
        self._vis('ok1', extra={
            "objects": {"dataPoint": [
                {"properties": {"fill": {"solid": {"color": {"expr": {
                    "Measure": {"Expression": {"SourceRef": {"Entity": "dim_date"}},
                                "Property": "total"}}}}}}}]},
            "filterConfig": {"filters": [
                {"field": {"Column": {"Expression": {"SourceRef": {"Entity": "dim_date"}},
                                      "Property": "MonthName"}},
                 "type": "Categorical"}]}})
        doc = json.load(open(os.path.join(self.rp, 'definition', 'pages', 'p1',
                                          'visuals', 'ok1', 'visual.json')))
        doc['visual']['query']['sortDefinition'] = {"sort": [
            {"field": {"Column": {"Expression": {"SourceRef": {"Entity": "dim_date"}},
                                  "Property": "MonthName"}}, "direction": "Ascending"}]}
        w(os.path.join(self.rp, 'definition', 'pages', 'p1', 'visuals', 'ok1', 'visual.json'),
          json.dumps(doc))
        fs = self.run_adv()
        self.assertFalse(any(f['rule'] == 'ADV-17' for f in fs),
                         'הפניות תקינות במיון/מסנן/עיצוב סומנו (FP)')

    def test_hidden_visual_out_of_scope(self):
        self._vis('h1', hidden=True, extra={"filterConfig": {"filters": [
            {"field": {"Column": {"Expression": {"SourceRef": {"Entity": "dim_date"}},
                                  "Property": "GhostHiddenCol"}},
             "type": "Categorical"}]}})
        fs = self.run_adv()
        self.assertFalse(any(f['rule'] == 'ADV-17' for f in fs),
                         'ויזואל מוסתר נסרק (חורג מהיקף ADV-17)')


class MobileTouch(unittest.TestCase):
    """A11Y-09: מטרת מגע <44px בפריסת מובייל (mobile.json)."""
    def setUp(self):
        C._FINDINGS.clear()
        self.root = tempfile.mkdtemp(prefix='pbimob-')
        self.rp = os.path.join(self.root, 'D.Report')
        w(os.path.join(self.rp, 'definition', 'report.json'), json.dumps({"name": "r"}))
        w(os.path.join(self.rp, 'definition', 'pages', 'p1', 'page.json'),
          json.dumps({"name": "p1", "displayName": "ראשי", "width": 1280, "height": 720}))

    def tearDown(self):
        shutil.rmtree(self.root, ignore_errors=True)

    def _visual(self, vid, vtype, mob_wh=None):
        w(os.path.join(self.rp, 'definition', 'pages', 'p1', 'visuals', vid, 'visual.json'),
          json.dumps({"name": vid,
                      "position": {"x": 0, "y": 0, "z": 1, "width": 300, "height": 200},
                      "visual": {"visualType": vtype,
                                 "query": {"queryState": {"Values": {"projections": []}}}}}))
        if mob_wh:
            w(os.path.join(self.rp, 'definition', 'pages', 'p1', 'visuals', vid, 'mobile.json'),
              json.dumps({"position": {"x": 0, "y": 0, "width": mob_wh[0], "height": mob_wh[1]}}))

    def run_a11y(self):
        C._FINDINGS.clear()
        C.check_a11y(C.read_report(self.rp))
        return C._FINDINGS

    def test_mobile_small_touch_target_flagged(self):
        # lukasreese.com — 44px touch targets במובייל
        self._visual('s1', 'slicer', mob_wh=(320, 30))
        self.assertTrue(any(f['rule'] == 'A11Y-09' for f in self.run_a11y()),
                        'מטרת מגע ניידת קטנה לא זוהתה')

    def test_mobile_ok_touch_target_clean(self):
        self._visual('s2', 'slicer', mob_wh=(320, 56))
        self.assertFalse(any(f['rule'] == 'A11Y-09' for f in self.run_a11y()),
                         'מטרה בגודל תקין סומנה (FP)')

    def test_non_interactive_small_clean(self):
        # כרטיס קטן בפריסת מובייל — לא מטרת מגע, לא מסמנים
        self._visual('c1', 'card', mob_wh=(100, 30))
        self.assertFalse(any(f['rule'] == 'A11Y-09' for f in self.run_a11y()),
                         'ויזואל לא-אינטראקטיבי סומן (FP)')

    def test_no_mobile_layout_clean(self):
        self._visual('s3', 'slicer', mob_wh=None)
        self.assertFalse(any(f['rule'] == 'A11Y-09' for f in self.run_a11y()),
                         'ויזואל בלי פריסת מובייל סומן (FP)')

class DatasetSuffixAutoDetect(Fixture):
    """סבב 88 — סיומת המודל הישנה *.Dataset (עדיין בשימוש בפרויקטים אמיתיים,
    למשל NatVanG/fab-inspector Inventory sample, MIT): הזיהוי האוטומטי חייב
    למצוא גם אותה, וכשאין מודל בכלל — הערה גלויה במקום דילוג שקט.
    (השם משונה רק בתוך הבדיקות של המחלקה, כדי לא לשבור את בדיקות Fixture.)"""

    def _run_script(self):
        import subprocess
        return subprocess.run([sys.executable, C.__file__], cwd=self.root,
                              capture_output=True, text=True).stdout

    def test_dataset_suffix_detected(self):
        os.rename(self.sm, self.sm.replace('.SemanticModel', '.Dataset'))
        out = self._run_script()
        self.assertNotIn('לא נמצאה תיקיית מודל', out)
        self.assertIn('MDL-01', out, 'בדיקות המודל לא רצו דרך *.Dataset')

    def test_missing_model_noted(self):
        os.rename(self.sm, os.path.join(self.root, 'gone'))
        out = self._run_script()
        self.assertIn('לא נמצאה תיקיית מודל', out, 'דילוג על בדיקות מודל חייב להיות גלוי')


# בדיקות ה-fixture הכלליות לא אמורות לרוץ שוב תחת התת-מחלקה (Ran == grep -c)
for _n in unittest.defaultTestLoader.getTestCaseNames(Fixture):
    if _n not in DatasetSuffixAutoDetect.__dict__:
        setattr(DatasetSuffixAutoDetect, _n, None)

class Adv24InactiveOnlyPath(DesignAdvice):
    """סבב 90 — ADV-24: עמודות מטבלאות שמחוברות רק דרך קשר לא-פעיל על אותו
    ויזואל. קשר לא-פעיל לא מפיץ סינון לוויזואלים — רק USERELATIONSHIP בחישוב
    (MS Learn desktop-relationships-understand, CC-BY-4.0)."""

    def setUp(self):
        super().setUp()
        w(os.path.join(self.sm, 'definition', 'tables', 'fact.tmdl'),
          "table fact\n\tcolumn qty\n\t\tdataType: double\n")
        w(os.path.join(self.sm, 'definition', 'tables', 'targets.tmdl'),
          "table targets\n\tcolumn tc\n\t\tdataType: double\n")
        w(os.path.join(self.sm, 'definition', 'relationships.tmdl'),
          "relationship r1\n\tfromColumn: fact.qty\n\ttoColumn: dim_date.d\n"
          "relationship r9\n\tisActive: false\n\tfromColumn: fact.qty\n\ttoColumn: targets.tc\n")

    def test_adv24_fires_on_inactive_only_path(self):
        self.add_visual('vt', 'barChart', {'Category': [('Column', 'fact', 'qty')],
                                           'Values': [('Column', 'targets', 'tc')]})
        fs = self.run_adv()
        adv24 = [f for f in fs if f['rule'] == 'ADV-24']
        self.assertTrue(any('fact + targets' in f['title'] for f in adv24),
                        'ADV-24 לא ירה על מסלול לא-פעיל בלבד: %s' % [f['title'] for f in fs if f['rule'].startswith('ADV')])
        self.assertFalse(any(f['rule'] == 'ADV-11' and 'targets' in f['title'] for f in fs),
                         'ADV-11 דיווח על זוג שמחובר בגרף המלא (כפילות)')

    def test_adv24_active_path_clean(self):
        # fact ו-dim_date מחוברים בקשר פעיל (r1) — אסור ADV-24 (FP guard)
        self.add_visual('vt2', 'barChart', {'Category': [('Column', 'dim_date', 'MonthName')],
                                            'Values': [('Column', 'fact', 'qty')]})
        self.assertFalse(any(f['rule'] == 'ADV-24' for f in self.run_adv()),
                         'ADV-24 ירה על מסלול פעיל (FP)')


# כנ"ל — בדיקות DesignAdvice לא רצות שוב תחת התת-מחלקה
for _n in unittest.defaultTestLoader.getTestCaseNames(DesignAdvice):
    if _n not in Adv24InactiveOnlyPath.__dict__:
        setattr(Adv24InactiveOnlyPath, _n, None)


class TestTextboxExprLiteralParagraphs(unittest.TestCase):
    """סבב 132 (כשל שדה 14.9 — pbi_check קרס על הדוח האמיתי של המשתמש):
    Desktop כותב paragraphs של textbox גם כ-expr-Literal שבתוכו מחרוזת JSON.
    check_a11y הניח מערך native וקרס (str.get). הרצים גם חייבים להיות נראים
    לבדיקות (A11Y-02), לא רק "לא לקרוס"."""

    def setUp(self):
        C._FINDINGS.clear()
        self.root = tempfile.mkdtemp(prefix='pbiexpr-')
        rp = os.path.join(self.root, 'D.Report')
        w(os.path.join(rp, 'definition', 'report.json'), json.dumps({"name": "r"}))
        w(os.path.join(rp, 'definition', 'pages', 'p1', 'page.json'),
          json.dumps({"name": "p1", "displayName": "ראשי", "width": 1280, "height": 720}))
        payload = json.dumps([{"textRuns": [{"value": "כותרת",
                                             "textStyle": {"color": "#DDDDDD"}}],
                               "horizontalTextAlignment": "right"}],
                             ensure_ascii=False)
        tb = {"name": "tb",
              "position": {"x": 0, "y": 0, "z": 1, "width": 100, "height": 40,
                           "tabOrder": 1},
              "visual": {"visualType": "textbox",
                         "objects": {"general": [{"properties": {
                             "paragraphs": {"expr": {"Literal": {"Value": payload}}}}}]},
                         "visualContainerObjects": {"general": [{"properties": {
                             "altText": {"expr": {"Literal": {"Value": "'x'"}}}}}]},
                         "query": {"queryState": {"Values": {"projections": []}}}}}
        w(os.path.join(rp, 'definition', 'pages', 'p1', 'visuals', 'tb', 'visual.json'),
          json.dumps(tb))
        self.rp = rp

    def tearDown(self):
        shutil.rmtree(self.root, ignore_errors=True)

    def test_no_crash_and_runs_visible(self):
        C._FINDINGS.clear()
        C.check_a11y(C.read_report(self.rp))   # לפני התיקון: AttributeError
        self.assertTrue(any(f['rule'] == 'A11Y-02' for f in C._FINDINGS),
                        'רצי הטקסט בתוך expr-Literal לא נראו לבדיקת הניגודיות')


class TestTextboxLayeredBg(unittest.TestCase):
    """סבב 133 (המשך כשל שדה 14.9): A11Y-02 השוותה טקסט לרקע הדף בלבד — 47
    קריטים על הפרויקט האמיתי של המשתמש היו FP (טקסט לבן על צורות צבעוניות).
    הרקע הנכון: מילוי משלו ← צורה מתחת (z נמוך + חפיפה) ← רקע דף.
    מקור: microsoft/skills-for-fabric textbox.md, MIT."""

    def _project(self, with_shape=True, shape_above=False, own_fill=None):
        C._FINDINGS.clear()
        root = tempfile.mkdtemp(prefix='pbilayer-')
        rp = os.path.join(root, 'D.Report')
        w(os.path.join(rp, 'definition', 'report.json'), json.dumps({"name": "r"}))
        w(os.path.join(rp, 'definition', 'pages', 'p1', 'page.json'),
          json.dumps({"name": "p1", "displayName": "ראשי", "width": 1280, "height": 720}))
        pos = {"x": 10, "y": 10, "z": 5, "width": 200, "height": 40, "tabOrder": 1}
        tb = {"name": "tb", "position": pos,
              "visual": {"visualType": "textbox",
                         "objects": {"general": [{"properties": {"paragraphs": [
                             {"textRuns": [{"value": "כותרת",
                                            "textStyle": {"color": "#FFFFFF"}}]}]}}]},
                         "visualContainerObjects": {"general": [{"properties": {
                             "altText": {"expr": {"Literal": {"Value": "'x'"}}}}}]},
                         "query": {"queryState": {"Values": {"projections": []}}}}}
        if own_fill:
            tb["visual"]["objects"]["background"] = [{"properties": {
                "show": {"expr": {"Literal": {"Value": "true"}}},
                "color": {"solid": {"color": {"expr": {"Literal": {"Value": "'#047857'"}}}}}}}]
        w(os.path.join(rp, 'definition', 'pages', 'p1', 'visuals', 'tb', 'visual.json'),
          json.dumps(tb))
        if with_shape:
            sh = {"name": "sh",
                  "position": {"x": 5, "y": 5, "z": 6 if shape_above else 3,
                               "width": 220, "height": 60, "tabOrder": 0},
                  "visual": {"visualType": "shape",
                             "objects": {"fill": [{"properties": {
                                 "fillColor": {"solid": {"color": {
                                     "expr": {"Literal": {"Value": "'#047857'"}}}}}},
                                 "selector": {"id": "default"}}]},
                             "visualContainerObjects": {},
                             "query": {"queryState": {}}}}
            w(os.path.join(rp, 'definition', 'pages', 'p1', 'visuals', 'sh', 'visual.json'),
              json.dumps(sh))
        self._root = root
        return rp

    def tearDown(self):
        shutil.rmtree(getattr(self, '_root', ''), ignore_errors=True)

    def _a11y02(self, rp):
        C._FINDINGS.clear()
        C.check_a11y(C.read_report(rp))
        return [f for f in C._FINDINGS if f['rule'] == 'A11Y-02']

    def test_shape_below_kills_fp(self):
        # לבן על #047857 (ירוק כהה) = ניגודיות תקינה — לא לסמן
        self.assertEqual(self._a11y02(self._project(with_shape=True)), [],
                         'טקסט על צורה כהה סומן (FP)')

    def test_no_shape_still_fires(self):
        # לבן על רקע דף לבן (ברירת מחדל) = קריט אמיתי
        self.assertTrue(self._a11y02(self._project(with_shape=False)),
                        'טקסט לבן על דף לבן לא סומן')

    def test_shape_above_is_not_background(self):
        # צורה עם z גבוה מה-textbox מכסה אותו — אינה הרקע שלו
        self.assertTrue(self._a11y02(self._project(with_shape=True, shape_above=True)),
                        'צורה מעל הטקסט נחשבה כרקע')

    def test_own_fill_beats_shape(self):
        # מילוי משלו (כהה) גובר על צורה מתחת — לבן עליו תקין
        self.assertEqual(self._a11y02(self._project(with_shape=True, own_fill=True)), [],
                         'מילוי עצמי כהה + טקסט לבן סומן (FP)')


class TestVerifyCitations(unittest.TestCase):
    """סבב 124 · VER-01 — אימות ציטוטים דטרמיניסטי (רעיון: knoxgraeme/tieline AGPL-3.0).
    כל ציטוט בדקדק מוכר חייב להתקיים בארטיפקטים; ציטוט שבור = באג בכלל."""

    def setUp(self):
        C._FINDINGS.clear()
        self.model = {'tables': [
            {'name': 'Jobs', 'columns': [{'name': 'Date'}], 'measures': [{'name': 'Benchmark CPA'}]},
            {'name': 'Dim Date', 'columns': [{'name': 'Month'}], 'measures': []},
        ]}
        self.rep = {'pages': [
            {'id': 'page1', 'name': 'Overview',
             'visuals': [{'id': 'v1', 'vid': 'v1', 'type': 'textbox'},
                         {'id': 'v2abcd1234567890', 'vid': 'v2abcd1234567890', 'type': 'barChart'}]},
            {'id': 'page2', 'name': 'Detail',
             'visuals': [{'id': 'v3', 'vid': 'v3', 'type': 'cardVisual'}]},
        ]}

    def _ver(self, rep='default', model='default'):
        C.verify_citations(self.rep if rep == 'default' else rep,
                           self.model if model == 'default' else model)
        return [f for f in C._FINDINGS if f['rule'] == 'VER-01']

    def test_broken_page_citation_flagged(self):
        C.add('RPT-24', 'warn', 'דוח', "דף 'NoSuchPage'", 't', 'd', 'f')
        self.assertEqual(len(self._ver()), 1)

    def test_valid_citations_quiet(self):
        C.add('DAX-03', 'warn', 'DAX', 'Jobs[Benchmark CPA]', 't', 'd', 'f')
        C.add('MDL-02', 'warn', 'מודל', "טבלה 'Jobs'", 't', 'd', 'f')
        C.add('A11Y-02', 'warn', 'נגישות', "textbox בדף 'Overview'", 't', 'd', 'f')
        C.add('ADV-13', 'tip', 'עיצוב', "דף 'Detail' ויזואל 'v3'", 't', 'd', 'f')
        C.add('MDL-13', 'warn', 'מודל', 'Jobs.Date → Dim Date.Month', 't', 'd', 'f')
        C.add('RPT-13', 'tip', 'דוח', 'barChart×2, cardVisual×1', 't', 'd', 'f')
        C.add('RPT-07', 'warn', 'דוח', "סליסר 'Jobs[Date]'", 't', 'd', 'f')
        C.add('MDL-01', 'warn', 'מודל', 'SemanticModel', 't', 'd', 'f')
        C.add('RPT-19', 'warn', 'דוח', "displayName 'Detail'", 't', 'd', 'f')
        self.assertEqual(self._ver(), [])

    def test_broken_ref_flagged(self):
        C.add('DAX-03', 'warn', 'DAX', 'Jobs[No Such Measure]', 't', 'd', 'f')
        self.assertEqual(len(self._ver()), 1)

    def test_broken_visual_flagged(self):
        C.add('ADV-13', 'tip', 'עיצוב', "דף 'Detail' ויזואל 'nope'", 't', 'd', 'f')
        self.assertEqual(len(self._ver()), 1)

    def test_visual_id_prefix_resolves(self):
        # RPT-15/16 מצטטים v['id'][:12] — קידומת חד-חד-ערכית חוקית
        C.add('RPT-15', 'warn', 'דוח', "דף 'Overview' · ויזואל 'v2abcd123456'", 't', 'd', 'f')
        self.assertEqual(self._ver(), [])

    def test_quoted_dotted_ref(self):
        C.add('MDL-12', 'warn', 'מודל', "'Dim Date'.Month", 't', 'd', 'f')
        self.assertEqual(self._ver(), [])
        C._FINDINGS.clear()
        C.add('MDL-12', 'warn', 'מודל', "'Dim Date'.Nope", 't', 'd', 'f')
        self.assertEqual(len(self._ver()), 1)

    def test_textbox_claim_verified(self):
        C.add('A11Y-02', 'warn', 'נגישות', "textbox בדף 'Detail'", 't', 'd', 'f')
        self.assertEqual(len(self._ver()), 1)   # בדף Detail אין textbox

    def test_no_model_skips_ref_checks(self):
        C.add('DAX-03', 'warn', 'DAX', 'Jobs[Benchmark CPA]', 't', 'd', 'f')
        self.assertEqual(self._ver(model=None), [])

    def test_free_text_location_untouched(self):
        # location חופשי ללא דקדק מוכר — לא מאומת, לא נכשל
        C.add('RPT-04', 'warn', 'דוח', 'כל הדוח', 't', 'd', 'f')
        C.add('DAX-11', 'warn', 'DAX', '5 מדדים', 't', 'd', 'f')
        self.assertEqual(self._ver(), [])


class TestThemeCascade(unittest.TestCase):
    """סבב 125 · ADV-26/27 — אכיפת מפל העיצוב (data-goblin modifying-theme-json, GPL-3.0)."""

    def _rep(self, overrides_per_visual, theme_wild=None, theme_typed=None, vtype='barChart'):
        pages = []
        for i, objs in enumerate(overrides_per_visual):
            vid = 'vis%d' % i
            pages.append({'id': 'page%d' % i, 'name': 'P%d' % i, 'visuals': [
                {'id': vid, 'vid': vid, 'type': vtype, 'hidden': False,
                 'raw': {'visual': {'visualType': vtype, 'objects': objs}}}]})
        return {'pages': pages, 'theme_wild': theme_wild or {}, 'theme_typed': theme_typed or {}}

    def _obj(self, group, prop, value, selector=False):
        ent = {'properties': {prop: {'expr': {'Literal': {'Value': value}}}}}
        if selector:
            ent['selector'] = {'data': [{'scopeId': 'x'}]}
        return {group: [ent]}

    def setUp(self):
        C._FINDINGS.clear()

    def _run(self, rep):
        C.check_theme_cascade(rep)
        return [f['rule'] for f in C._FINDINGS]

    def test_redundant_override_flagged(self):
        rep = self._rep([self._obj('legend', 'show', 'false')],
                        theme_wild={('legend', 'show'): False})
        self.assertIn('ADV-26', self._run(rep))

    def test_different_value_quiet(self):
        rep = self._rep([self._obj('legend', 'show', 'true')],
                        theme_wild={('legend', 'show'): False})
        self.assertEqual(self._run(rep), [])

    def test_typed_scope_beats_wildcard(self):
        # הסוג קובע true וה-wildcard false; override=true זהה לערך האפקטיבי
        rep = self._rep([self._obj('legend', 'show', 'true')],
                        theme_wild={('legend', 'show'): False},
                        theme_typed={('barChart', 'legend', 'show'): True})
        self.assertIn('ADV-26', self._run(rep))

    def test_repeat_four_fires_three_quiet(self):
        rep4 = self._rep([self._obj('labels', 'fontSize', '9.0D')] * 4)
        self.assertIn('ADV-27', self._run(rep4))
        C._FINDINGS.clear()
        rep3 = self._rep([self._obj('labels', 'fontSize', '9.0D')] * 3)
        self.assertEqual(self._run(rep3), [])

    def test_selector_and_decor_skipped(self):
        # selector = פורמט לפי סדרה (ספציפי לתוכן); textbox = דקורטיבי
        rep = self._rep([self._obj('dataPoint', 'fill', "'#FF0000'", selector=True)] * 6)
        self.assertEqual(self._run(rep), [])
        C._FINDINGS.clear()
        rep = self._rep([self._obj('fill', 'show', 'true')] * 6, vtype='textbox')
        self.assertEqual(self._run(rep), [])

    def test_emitted_locations_pass_ver(self):
        # המיקומים ש-ADV-26/27 מפיקים חייבים לעבור את אימות הציטוטים שלנו
        rep = self._rep([self._obj('legend', 'show', 'false')] * 5,
                        theme_wild={('legend', 'show'): False})
        C.check_theme_cascade(rep)
        C.verify_citations(rep, None)
        self.assertEqual([f for f in C._FINDINGS if f['rule'] == 'VER-01'], [])

    def test_fmt_val_unwrap(self):
        self.assertEqual(C._fmt_val({'expr': {'Literal': {'Value': "'#ABCDEF'"}}}), '#abcdef')
        self.assertEqual(C._fmt_val({'expr': {'Literal': {'Value': '8.5D'}}}), 8.5)
        self.assertEqual(C._fmt_val({'expr': {'Literal': {'Value': 'true'}}}), True)
        self.assertEqual(C._fmt_val({'solid': {'color': '#FFF'}}), '#fff')
        self.assertIsNone(C._fmt_val({'expr': {'Measure': {'Expression': 'x'}}}))


class TestDriftManifest(unittest.TestCase):
    """סבב 126 · מניפסט hashes לבדיקת סטייה (tieline רעיון 3, AGPL-3.0)."""

    def setUp(self):
        C._FINDINGS.clear()
        self.root = tempfile.mkdtemp(prefix='pbidrift-')
        rp = os.path.join(self.root, 'D.Report')
        w(os.path.join(rp, 'definition', 'pages', 'p1', 'page.json'),
          '{"name": "p1", "displayName": "One"}')
        w(os.path.join(rp, 'definition', 'report.json'), '{"name": "r"}')
        self.rp = rp
        self.manifest = os.path.join(self.root, 'm.json')

    def tearDown(self):
        shutil.rmtree(self.root, ignore_errors=True)

    def _run_drift(self):
        import io, contextlib
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            code = C.drift_check(self.manifest, self.rp, None)
        return code, buf.getvalue()

    def test_manifest_roundtrip_clean(self):
        n = C.write_manifest(self.manifest, self.rp, None)
        self.assertEqual(n, 2)
        doc = json.load(open(self.manifest, encoding='utf-8'))
        self.assertEqual(doc['schema'], 1)
        self.assertIn(os.path.join('D.Report', 'definition', 'report.json'), doc['files'])
        code, out = self._run_drift()
        self.assertEqual(code, 0)
        self.assertIn('בת-תוקף', out)

    def test_change_detected(self):
        C.write_manifest(self.manifest, self.rp, None)
        w(os.path.join(self.rp, 'definition', 'report.json'), '{"name": "r", "x": 1}')
        code, out = self._run_drift()
        self.assertEqual(code, 1)
        self.assertIn('1 שונו', out)
        self.assertIn('report.json', out)

    def test_add_remove_detected(self):
        C.write_manifest(self.manifest, self.rp, None)
        w(os.path.join(self.rp, 'definition', 'pages', 'p2', 'page.json'), '{"name": "p2"}')
        os.remove(os.path.join(self.rp, 'definition', 'report.json'))
        code, out = self._run_drift()
        self.assertEqual(code, 1)
        self.assertIn('1 נוספו', out)
        self.assertIn('1 נמחקו', out)

    def test_bad_manifest(self):
        w(self.manifest, 'not json')
        code, out = self._run_drift()
        self.assertEqual(code, 2)

    def test_hash_deterministic(self):
        h1 = C._hash_tree(self.rp, self.root)
        h2 = C._hash_tree(self.rp, self.root)
        self.assertEqual(h1, h2)
        self.assertEqual(len(h1), 2)


if __name__ == '__main__':


    unittest.main(verbosity=2)

