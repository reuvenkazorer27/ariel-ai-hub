#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
בדיקות יחידה ל-pbi_bench.py (stdlib unittest, ללא תלויות).

מוודאים: הסינתזה דטרמיניסטית, הבנץ׳ מחזיר ארבעה שלבים תקינים על פרויקט סינתטי,
והשוואת baseline תופסת רגרסיה (ומשתיקה כשאין).

הרצה:  python tests/test_pbi_bench.py
"""
import os, shutil, sys, tempfile, unittest

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'scripts'))
import pbi_bench as B


class Synthesize(unittest.TestCase):
    def setUp(self):
        self.root = tempfile.mkdtemp(prefix='pbibench-')

    def tearDown(self):
        shutil.rmtree(self.root, ignore_errors=True)

    def test_deterministic(self):
        r1, s1 = B.synthesize(os.path.join(self.root, 'a'), 2, 3, seed=7)
        r2, s2 = B.synthesize(os.path.join(self.root, 'b'), 2, 3, seed=7)
        f1 = os.path.join(r1, 'definition', 'pages', 'p0000', 'visuals', 'v0000', 'visual.json')
        f2 = os.path.join(r2, 'definition', 'pages', 'p0000', 'visuals', 'v0000', 'visual.json')
        self.assertEqual(open(f1, encoding='utf-8').read(), open(f2, encoding='utf-8').read())

    def test_structure_counts(self):
        rep, sm = B.synthesize(self.root, 4, 5)
        pages = os.listdir(os.path.join(rep, 'definition', 'pages'))
        self.assertEqual(4, len(pages))
        vids = os.listdir(os.path.join(rep, 'definition', 'pages', 'p0000', 'visuals'))
        self.assertEqual(5, len(vids))
        tables = os.listdir(os.path.join(sm, 'definition', 'tables'))
        self.assertEqual(3, len(tables))


class JsonMode(unittest.TestCase):
    """--json מדפיס אובייקט JSON יחיד ותקין ל-stdout (צריכה תכנותית ע"י סוכן/CI)."""
    def setUp(self):
        self.root = tempfile.mkdtemp(prefix='pbibench-')

    def tearDown(self):
        shutil.rmtree(self.root, ignore_errors=True)

    def test_json_stdout(self):
        import contextlib, io, json as js
        rep, sm = B.synthesize(self.root, 2, 3)
        argv = sys.argv
        sys.argv = ['pbi_bench.py', rep, '--model', sm, '--rounds', '1', '--json']
        buf = io.StringIO()
        try:
            with contextlib.redirect_stdout(buf):
                B.main()
        finally:
            sys.argv = argv
        out = js.loads(buf.getvalue())
        self.assertEqual({'extract', 'analyze', 'check', 'map'}, set(out['results']))
        self.assertEqual(1, out['rounds'])
        self.assertIsNone(out['compare'])


class Bench(unittest.TestCase):
    def setUp(self):
        self.root = tempfile.mkdtemp(prefix='pbibench-')
        self.rep, self.sm = B.synthesize(self.root, 3, 4)

    def tearDown(self):
        shutil.rmtree(self.root, ignore_errors=True)

    def test_all_stages_ok(self):
        results = B.bench(self.rep, self.sm, rounds=1)
        self.assertEqual({'extract', 'analyze', 'check', 'map'}, set(results))
        for name, r in results.items():
            self.assertTrue(r['ok'], 'stage %s failed: %s' % (name, r['err']))
            self.assertGreaterEqual(r['min_ms'], 0)
            self.assertGreaterEqual(r['peak_mb'], 0)

    def test_compare_flags_regression(self):
        results = B.bench(self.rep, self.sm, rounds=1)
        baseline = {k: dict(v, min_ms=v['min_ms'] / 100.0) for k, v in results.items()}
        rows = B.compare(results, baseline, tolerance=1.5)
        for stage, ratio, verdict in rows:
            self.assertIn('רגרסיה', verdict, 'stage %s regression not flagged' % stage)

    def test_compare_quiet_when_same(self):
        results = B.bench(self.rep, self.sm, rounds=1)
        rows = B.compare(results, results, tolerance=1.5)
        for stage, ratio, verdict in rows:
            self.assertEqual('תקין', verdict, 'false regression on identical baseline: %s' % stage)


if __name__ == '__main__':
    unittest.main(verbosity=2)
