#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
בדיקות יציבות (mutation sweep) לשלושת הקוראים: pbi_extract, pbi_map, pbi_check.

המוטציה שמצאנו בשטח (known-issues-log §16): קובץ JSON *תקין סינטקטית* אבל בצורה
לא צפויה — מערך במקום אובייקט, מחרוזת במקום אובייקט, position.x כמחרוזת — הפילה
את כל הסריקה ב-AttributeError, כי ה-try עטף רק את json.loads ולא את השימוש בתוצאה.
(אותו דפוס כשל כמו NVIDIA/SkillSpector issue #250: קלט פגום אחד הפיל scan שלם.)

החוזה: שום מוטציה לא זורקת חריגה החוצה; הקובץ הפגום נרשם כשגיאה מובנית; וב-pbi_check
הוא הופך לממצא RPT-22 (קריטי) במקום להיעלם בשקט. פרויקט בריא לא מייצר RPT-22.

הרצה:  python tests/test_stability.py
"""
import json, os, shutil, sys, tempfile, unittest
from pathlib import Path

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'scripts'))
import pbi_extract as EX
import pbi_map as MP
import pbi_check as CK

FIX = Path(__file__).resolve().parents[3] / 'tests' / 'fixture'

MUTS = {
    'not-json': b'{invalid',
    'json-array': b'[]',
    'json-string': b'"hello"',
    'wrong-types': json.dumps({'visual': 'x', 'position': {'x': 'abc'}, 'name': 5}).encode(),
    'utf16': '{"a": 1}'.encode('utf-16'),
    'deep-nest': ('[' * 5000 + ']' * 5000).encode(),
}
TARGETS = [
    'definition/report.json',
    'definition/pages/pages.json',
    'definition/pages/page001/page.json',
    'definition/pages/page001/visuals/vis001/visual.json',
]


class MutationSweep(unittest.TestCase):
    def setUp(self):
        CK._FINDINGS.clear()
        self.root = Path(tempfile.mkdtemp(prefix='pbistab-'))
        shutil.copytree(FIX / 'MiniReport.Report', self.root / 'MiniReport.Report')
        shutil.copytree(FIX / 'MiniReport.SemanticModel', self.root / 'MiniReport.SemanticModel')
        self.rep = str(self.root / 'MiniReport.Report')
        self.mod = str(self.root / 'MiniReport.SemanticModel')

    def tearDown(self):
        shutil.rmtree(self.root, ignore_errors=True)

    def mutate(self, rel, payload):
        (self.root / 'MiniReport.Report' / rel).write_bytes(payload)

    def fresh(self):
        """העתק נקי של ה-fixture (כל מוטציה מתחילה מפרויקט בריא)."""
        shutil.rmtree(self.root, ignore_errors=True)
        self.root = Path(tempfile.mkdtemp(prefix='pbistab-'))
        shutil.copytree(FIX / 'MiniReport.Report', self.root / 'MiniReport.Report')
        shutil.copytree(FIX / 'MiniReport.SemanticModel', self.root / 'MiniReport.SemanticModel')
        self.rep = str(self.root / 'MiniReport.Report')
        self.mod = str(self.root / 'MiniReport.SemanticModel')

    def test_sweep_never_raises(self):
        """כל צירוף מוטציה×קובץ×קורא חייב להשלים בלי חריגה."""
        failures = []
        for rel in TARGETS:
            for mname, payload in MUTS.items():
                self.fresh()
                self.mutate(rel, payload)
                for label, fn in [
                    ('extract', lambda: EX.read_report(self.rep)),
                    ('map', lambda: MP.build_map(self.rep, self.mod)),
                    ('check', lambda: (CK._FINDINGS.clear(),
                                       CK.check_report(CK.read_report(self.rep)))),
                ]:
                    try:
                        fn()
                    except Exception as e:
                        failures.append('%s × %s × %s: %s: %s'
                                        % (label, rel, mname, type(e).__name__, e))
        self.assertEqual([], failures)

    def test_broken_visual_becomes_rpt22(self):
        """visual.json בצורת מערך → ממצא RPT-22 שמנקוב בשם הקובץ."""
        self.mutate('definition/pages/page001/visuals/vis001/visual.json', b'[]')
        CK.check_report(CK.read_report(self.rep))
        r22 = [f for f in CK._FINDINGS if f['rule'] == 'RPT-22']
        self.assertEqual(1, len(r22))
        self.assertIn('vis001/visual.json', r22[0]['location'])
        self.assertEqual('crit', r22[0]['severity'])

    def test_broken_page_json_becomes_rpt22(self):
        self.mutate('definition/pages/page001/page.json', b'{invalid')
        CK.check_report(CK.read_report(self.rep))
        r22 = [f for f in CK._FINDINGS if f['rule'] == 'RPT-22']
        self.assertTrue(any('page001/page.json' in f['location'] for f in r22))

    def test_healthy_fixture_no_rpt22(self):
        """פרויקט בריא לא מייצר RPT-22 (אין false-positive)."""
        CK.check_report(CK.read_report(self.rep))
        self.assertEqual([], [f for f in CK._FINDINGS if f['rule'] == 'RPT-22'])

    def test_extract_marks_broken_visual(self):
        """pbi_extract רושם רשומת error מובנית ולא נופל."""
        self.mutate('definition/pages/page001/visuals/vis001/visual.json', b'"str"')
        pages = EX.read_report(self.rep)
        errs = [v for p in pages for v in p['visuals'] if 'error' in v]
        self.assertEqual(1, len(errs))
        self.assertIn('vis001', errs[0]['error'])

    def test_map_marks_broken_visual(self):
        self.mutate('definition/pages/page001/visuals/vis001/visual.json', b'"str"')
        m = MP.build_map(self.rep, self.mod)
        errs = [v for p in m['pages'] for v in p['visuals'] if 'error' in v]
        self.assertEqual(1, len(errs))


if __name__ == '__main__':
    unittest.main(verbosity=2)
